package com.facebook.appevents.internal;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import com.facebook.FacebookSdk;
import com.facebook.LoggingBehavior;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.appevents.aam.MetadataIndexer;
import com.facebook.appevents.codeless.CodelessManager;
import com.facebook.appevents.iap.InAppPurchaseManager;
import com.facebook.appevents.suggestedevents.SuggestedEventsManager;
import com.facebook.internal.FeatureManager;
import com.facebook.internal.FetchedAppSettings;
import com.facebook.internal.FetchedAppSettingsManager;
import com.facebook.internal.Logger;
import com.facebook.internal.Utility;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.lang.ref.WeakReference;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000n\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\020\t\n\002\b\002\n\002\020\b\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\b\n\002\030\002\n\000\bÆ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\b\020\036\032\0020\037H\002J\n\020 \032\004\030\0010\rH\007J\n\020!\032\004\030\0010\"H\007J\b\020#\032\0020$H\007J\b\020%\032\0020$H\007J\022\020&\032\0020\0372\b\020'\032\004\030\0010\rH\007J\020\020(\032\0020\0372\006\020'\032\0020\rH\002J\020\020)\032\0020\0372\006\020'\032\0020\rH\002J\020\020*\032\0020\0372\006\020'\032\0020\rH\007J\032\020+\032\0020\0372\006\020,\032\0020-2\b\020\n\032\004\030\0010\004H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\006XT¢\006\002\n\000R\016\020\007\032\0020\004X\004¢\006\002\n\000R\016\020\b\032\0020\tX\016¢\006\002\n\000R\020\020\n\032\004\030\0010\004X\016¢\006\002\n\000R\026\020\013\032\n\022\004\022\0020\r\030\0010\fX\016¢\006\002\n\000R\016\020\016\032\0020\006X\016¢\006\002\n\000R\024\020\017\032\b\022\002\b\003\030\0010\020X\016¢\006\002\n\000R\016\020\021\032\0020\001X\004¢\006\002\n\000R\020\020\022\032\004\030\0010\023X\016¢\006\002\n\000R\016\020\024\032\0020\025X\004¢\006\002\n\000R\024\020\026\032\0020\t8BX\004¢\006\006\032\004\b\027\020\030R\026\020\031\032\n \033*\004\030\0010\0320\032X\004¢\006\002\n\000R\016\020\034\032\0020\035X\004¢\006\002\n\000¨\006."}, d2 = {"Lcom/facebook/appevents/internal/ActivityLifecycleTracker;", "", "()V", "INCORRECT_IMPL_WARNING", "", "INTERRUPTION_THRESHOLD_MILLISECONDS", "", "TAG", "activityReferences", "", "appId", "currActivity", "Ljava/lang/ref/WeakReference;", "Landroid/app/Activity;", "currentActivityAppearTime", "currentFuture", "Ljava/util/concurrent/ScheduledFuture;", "currentFutureLock", "currentSession", "Lcom/facebook/appevents/internal/SessionInfo;", "foregroundActivityCount", "Ljava/util/concurrent/atomic/AtomicInteger;", "sessionTimeoutInSeconds", "getSessionTimeoutInSeconds", "()I", "singleThreadExecutor", "Ljava/util/concurrent/ScheduledExecutorService;", "kotlin.jvm.PlatformType", "tracking", "Ljava/util/concurrent/atomic/AtomicBoolean;", "cancelCurrentTask", "", "getCurrentActivity", "getCurrentSessionGuid", "Ljava/util/UUID;", "isInBackground", "", "isTracking", "onActivityCreated", "activity", "onActivityDestroyed", "onActivityPaused", "onActivityResumed", "startTracking", "application", "Landroid/app/Application;", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class ActivityLifecycleTracker {
  private static final String INCORRECT_IMPL_WARNING = "Unexpected activity pause without a matching activity resume. Logging data may be incorrect. Make sure you call activateApp from your Application's onCreate method";
  
  public static final ActivityLifecycleTracker INSTANCE = new ActivityLifecycleTracker();
  
  private static final long INTERRUPTION_THRESHOLD_MILLISECONDS = 1000L;
  
  private static final String TAG;
  
  private static int activityReferences;
  
  private static String appId;
  
  private static WeakReference<Activity> currActivity;
  
  private static long currentActivityAppearTime;
  
  private static volatile ScheduledFuture<?> currentFuture;
  
  private static final Object currentFutureLock;
  
  private static volatile SessionInfo currentSession;
  
  private static final AtomicInteger foregroundActivityCount;
  
  private static final ScheduledExecutorService singleThreadExecutor = Executors.newSingleThreadScheduledExecutor();
  
  private static final AtomicBoolean tracking;
  
  static {
    currentFutureLock = new Object();
    foregroundActivityCount = new AtomicInteger(0);
    tracking = new AtomicBoolean(false);
  }
  
  private final void cancelCurrentTask() {
    synchronized (currentFutureLock) {
      if (currentFuture != null) {
        ScheduledFuture<?> scheduledFuture1 = currentFuture;
        if (scheduledFuture1 != null)
          scheduledFuture1.cancel(false); 
      } 
      ScheduledFuture scheduledFuture = (ScheduledFuture)null;
      currentFuture = null;
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  @JvmStatic
  public static final Activity getCurrentActivity() {
    WeakReference<Activity> weakReference = currActivity;
    Activity activity2 = null;
    Activity activity1 = activity2;
    if (weakReference != null) {
      activity1 = activity2;
      if (weakReference != null)
        activity1 = weakReference.get(); 
    } 
    return activity1;
  }
  
  @JvmStatic
  public static final UUID getCurrentSessionGuid() {
    SessionInfo sessionInfo = currentSession;
    UUID uUID2 = null;
    UUID uUID1 = uUID2;
    if (sessionInfo != null) {
      sessionInfo = currentSession;
      uUID1 = uUID2;
      if (sessionInfo != null)
        uUID1 = sessionInfo.getSessionId(); 
    } 
    return uUID1;
  }
  
  private final int getSessionTimeoutInSeconds() {
    FetchedAppSettings fetchedAppSettings = FetchedAppSettingsManager.getAppSettingsWithoutQuery(FacebookSdk.getApplicationId());
    return (fetchedAppSettings != null) ? fetchedAppSettings.getSessionTimeoutInSeconds() : Constants.getDefaultAppEventsSessionTimeoutInSeconds();
  }
  
  @JvmStatic
  public static final boolean isInBackground() {
    return (activityReferences == 0);
  }
  
  @JvmStatic
  public static final boolean isTracking() {
    return tracking.get();
  }
  
  @JvmStatic
  public static final void onActivityCreated(Activity paramActivity) {
    singleThreadExecutor.execute(ActivityLifecycleTracker$onActivityCreated$1.INSTANCE);
  }
  
  private final void onActivityDestroyed(Activity paramActivity) {
    CodelessManager.onActivityDestroyed(paramActivity);
  }
  
  private final void onActivityPaused(Activity paramActivity) {
    AtomicInteger atomicInteger = foregroundActivityCount;
    if (atomicInteger.decrementAndGet() < 0) {
      atomicInteger.set(0);
      Log.w(TAG, "Unexpected activity pause without a matching activity resume. Logging data may be incorrect. Make sure you call activateApp from your Application's onCreate method");
    } 
    cancelCurrentTask();
    long l = System.currentTimeMillis();
    String str = Utility.getActivityName((Context)paramActivity);
    CodelessManager.onActivityPaused(paramActivity);
    ActivityLifecycleTracker$onActivityPaused$handleActivityPaused$1 activityLifecycleTracker$onActivityPaused$handleActivityPaused$1 = new ActivityLifecycleTracker$onActivityPaused$handleActivityPaused$1(l, str);
    singleThreadExecutor.execute(activityLifecycleTracker$onActivityPaused$handleActivityPaused$1);
  }
  
  @JvmStatic
  public static final void onActivityResumed(Activity paramActivity) {
    Intrinsics.checkNotNullParameter(paramActivity, "activity");
    currActivity = new WeakReference<Activity>(paramActivity);
    foregroundActivityCount.incrementAndGet();
    INSTANCE.cancelCurrentTask();
    long l = System.currentTimeMillis();
    currentActivityAppearTime = l;
    String str = Utility.getActivityName((Context)paramActivity);
    CodelessManager.onActivityResumed(paramActivity);
    MetadataIndexer.onActivityResumed(paramActivity);
    SuggestedEventsManager.trackActivity(paramActivity);
    InAppPurchaseManager.startTracking();
    ActivityLifecycleTracker$onActivityResumed$handleActivityResume$1 activityLifecycleTracker$onActivityResumed$handleActivityResume$1 = new ActivityLifecycleTracker$onActivityResumed$handleActivityResume$1(l, str, paramActivity.getApplicationContext());
    singleThreadExecutor.execute(activityLifecycleTracker$onActivityResumed$handleActivityResume$1);
  }
  
  @JvmStatic
  public static final void startTracking(Application paramApplication, String paramString) {
    Intrinsics.checkNotNullParameter(paramApplication, "application");
    if (!tracking.compareAndSet(false, true))
      return; 
    FeatureManager.checkFeature(FeatureManager.Feature.CodelessEvents, ActivityLifecycleTracker$startTracking$1.INSTANCE);
    appId = paramString;
    paramApplication.registerActivityLifecycleCallbacks(new ActivityLifecycleTracker$startTracking$2());
  }
  
  static {
    String str = ActivityLifecycleTracker.class.getCanonicalName();
    if (str == null)
      str = "com.facebook.appevents.internal.ActivityLifecycleTracker"; 
    TAG = str;
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class ActivityLifecycleTracker$onActivityCreated$1 implements Runnable {
    public static final ActivityLifecycleTracker$onActivityCreated$1 INSTANCE = new ActivityLifecycleTracker$onActivityCreated$1();
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class ActivityLifecycleTracker$onActivityPaused$handleActivityPaused$1 implements Runnable {
    ActivityLifecycleTracker$onActivityPaused$handleActivityPaused$1(long param1Long, String param1String) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
    
    @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
    static final class ActivityLifecycleTracker$onActivityPaused$handleActivityPaused$1$task$1 implements Runnable {
      public final void run() {
        if (CrashShieldHandler.isObjectCrashing(this))
          return; 
        try {
          boolean bool = CrashShieldHandler.isObjectCrashing(this);
        } finally {
          Exception exception = null;
          CrashShieldHandler.handleThrowable(exception, this);
        } 
      }
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class ActivityLifecycleTracker$onActivityPaused$handleActivityPaused$1$task$1 implements Runnable {
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class ActivityLifecycleTracker$onActivityResumed$handleActivityResume$1 implements Runnable {
    ActivityLifecycleTracker$onActivityResumed$handleActivityResume$1(long param1Long, String param1String, Context param1Context) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\020\013\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "enabled", "", "onCompleted"}, k = 3, mv = {1, 5, 1})
  static final class ActivityLifecycleTracker$startTracking$1 implements FeatureManager.Callback {
    public static final ActivityLifecycleTracker$startTracking$1 INSTANCE = new ActivityLifecycleTracker$startTracking$1();
    
    public final void onCompleted(boolean param1Boolean) {
      if (param1Boolean) {
        CodelessManager.enable();
        return;
      } 
      CodelessManager.disable();
    }
  }
  
  @Metadata(d1 = {"\000\037\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\b*\001\000\b\n\030\0002\0020\001J\032\020\002\032\0020\0032\006\020\004\032\0020\0052\b\020\006\032\004\030\0010\007H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\t\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\n\032\0020\0032\006\020\004\032\0020\005H\026J\030\020\013\032\0020\0032\006\020\004\032\0020\0052\006\020\f\032\0020\007H\026J\020\020\r\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\016\032\0020\0032\006\020\004\032\0020\005H\026¨\006\017"}, d2 = {"com/facebook/appevents/internal/ActivityLifecycleTracker$startTracking$2", "Landroid/app/Application$ActivityLifecycleCallbacks;", "onActivityCreated", "", "activity", "Landroid/app/Activity;", "savedInstanceState", "Landroid/os/Bundle;", "onActivityDestroyed", "onActivityPaused", "onActivityResumed", "onActivitySaveInstanceState", "outState", "onActivityStarted", "onActivityStopped", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class ActivityLifecycleTracker$startTracking$2 implements Application.ActivityLifecycleCallbacks {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      Logger.Companion.log(LoggingBehavior.APP_EVENTS, ActivityLifecycleTracker.access$getTAG$p(ActivityLifecycleTracker.INSTANCE), "onActivityCreated");
      AppEventUtility.assertIsMainThread();
      ActivityLifecycleTracker.onActivityCreated(param1Activity);
    }
    
    public void onActivityDestroyed(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      Logger.Companion.log(LoggingBehavior.APP_EVENTS, ActivityLifecycleTracker.access$getTAG$p(ActivityLifecycleTracker.INSTANCE), "onActivityDestroyed");
      ActivityLifecycleTracker.INSTANCE.onActivityDestroyed(param1Activity);
    }
    
    public void onActivityPaused(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      Logger.Companion.log(LoggingBehavior.APP_EVENTS, ActivityLifecycleTracker.access$getTAG$p(ActivityLifecycleTracker.INSTANCE), "onActivityPaused");
      AppEventUtility.assertIsMainThread();
      ActivityLifecycleTracker.INSTANCE.onActivityPaused(param1Activity);
    }
    
    public void onActivityResumed(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      Logger.Companion.log(LoggingBehavior.APP_EVENTS, ActivityLifecycleTracker.access$getTAG$p(ActivityLifecycleTracker.INSTANCE), "onActivityResumed");
      AppEventUtility.assertIsMainThread();
      ActivityLifecycleTracker.onActivityResumed(param1Activity);
    }
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      Intrinsics.checkNotNullParameter(param1Bundle, "outState");
      Logger.Companion.log(LoggingBehavior.APP_EVENTS, ActivityLifecycleTracker.access$getTAG$p(ActivityLifecycleTracker.INSTANCE), "onActivitySaveInstanceState");
    }
    
    public void onActivityStarted(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      ActivityLifecycleTracker activityLifecycleTracker = ActivityLifecycleTracker.INSTANCE;
      ActivityLifecycleTracker.access$setActivityReferences$p(activityLifecycleTracker, ActivityLifecycleTracker.access$getActivityReferences$p(activityLifecycleTracker) + 1);
      Logger.Companion.log(LoggingBehavior.APP_EVENTS, ActivityLifecycleTracker.access$getTAG$p(ActivityLifecycleTracker.INSTANCE), "onActivityStarted");
    }
    
    public void onActivityStopped(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      Logger.Companion.log(LoggingBehavior.APP_EVENTS, ActivityLifecycleTracker.access$getTAG$p(ActivityLifecycleTracker.INSTANCE), "onActivityStopped");
      AppEventsLogger.Companion.onContextStop();
      ActivityLifecycleTracker activityLifecycleTracker = ActivityLifecycleTracker.INSTANCE;
      ActivityLifecycleTracker.access$setActivityReferences$p(activityLifecycleTracker, ActivityLifecycleTracker.access$getActivityReferences$p(activityLifecycleTracker) - 1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\internal\ActivityLifecycleTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */