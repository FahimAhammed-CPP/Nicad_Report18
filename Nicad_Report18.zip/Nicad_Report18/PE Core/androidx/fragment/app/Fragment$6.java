package androidx.fragment.app;

import android.view.View;
import y.尻;
import y.肉;
import y.腰;
import y.싱;

class Fragment$6 implements 肉 {
  public Fragment$6(싱 param싱) {}
  
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 == 尻.ON_STOP) {
      View view = this.淋.크;
      if (view != null)
        view.cancelPendingInputEvents(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\fragment\app\Fragment$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */