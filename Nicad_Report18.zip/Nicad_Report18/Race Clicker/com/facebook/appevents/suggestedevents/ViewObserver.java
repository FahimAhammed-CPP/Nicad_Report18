package com.facebook.appevents.suggestedevents;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewTreeObserver;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000,\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\005\b\001\030\000 \0202\0020\001:\001\020B\017\b\002\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020\013\032\0020\fH\026J\b\020\r\032\0020\fH\002J\b\020\016\032\0020\fH\002J\b\020\017\032\0020\fH\002R\024\020\005\032\b\022\004\022\0020\0030\006X\004¢\006\002\n\000R\016\020\007\032\0020\bX\004¢\006\002\n\000R\016\020\t\032\0020\nX\004¢\006\002\n\000¨\006\021"}, d2 = {"Lcom/facebook/appevents/suggestedevents/ViewObserver;", "Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;", "activity", "Landroid/app/Activity;", "(Landroid/app/Activity;)V", "activityWeakReference", "Ljava/lang/ref/WeakReference;", "isTracking", "Ljava/util/concurrent/atomic/AtomicBoolean;", "uiThreadHandler", "Landroid/os/Handler;", "onGlobalLayout", "", "process", "startTracking", "stopTracking", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class ViewObserver implements ViewTreeObserver.OnGlobalLayoutListener {
  public static final Companion Companion = new Companion(null);
  
  private static final int MAX_TEXT_LENGTH = 300;
  
  private static final Map<Integer, ViewObserver> observers = new HashMap<Integer, ViewObserver>();
  
  private final WeakReference<Activity> activityWeakReference;
  
  private final AtomicBoolean isTracking;
  
  private final Handler uiThreadHandler;
  
  private ViewObserver(Activity paramActivity) {
    this.activityWeakReference = new WeakReference<Activity>(paramActivity);
    this.uiThreadHandler = new Handler(Looper.getMainLooper());
    this.isTracking = new AtomicBoolean(false);
  }
  
  private final void process() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      ViewObserver$process$runnable$1 viewObserver$process$runnable$1 = new ViewObserver$process$runnable$1();
      Thread thread = Thread.currentThread();
      Looper looper = Looper.getMainLooper();
      Intrinsics.checkNotNullExpressionValue(looper, "Looper.getMainLooper()");
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  private final void startTracking() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      if (this.isTracking.getAndSet(true))
        return; 
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  @JvmStatic
  public static final void startTrackingActivity(Activity paramActivity) {
    if (CrashShieldHandler.isObjectCrashing(ViewObserver.class))
      return; 
    try {
      return;
    } finally {
      paramActivity = null;
      CrashShieldHandler.handleThrowable((Throwable)paramActivity, ViewObserver.class);
    } 
  }
  
  private final void stopTracking() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      if (!this.isTracking.getAndSet(false))
        return; 
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  @JvmStatic
  public static final void stopTrackingActivity(Activity paramActivity) {
    if (CrashShieldHandler.isObjectCrashing(ViewObserver.class))
      return; 
    try {
      return;
    } finally {
      paramActivity = null;
      CrashShieldHandler.handleThrowable((Throwable)paramActivity, ViewObserver.class);
    } 
  }
  
  public void onGlobalLayout() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\000\n\002\020%\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\b\032\0020\t2\006\020\n\032\0020\013H\007J\020\020\f\032\0020\t2\006\020\n\032\0020\013H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\032\020\005\032\016\022\004\022\0020\004\022\004\022\0020\0070\006X\004¢\006\002\n\000¨\006\r"}, d2 = {"Lcom/facebook/appevents/suggestedevents/ViewObserver$Companion;", "", "()V", "MAX_TEXT_LENGTH", "", "observers", "", "Lcom/facebook/appevents/suggestedevents/ViewObserver;", "startTrackingActivity", "", "activity", "Landroid/app/Activity;", "stopTrackingActivity", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    @JvmStatic
    public final void startTrackingActivity(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      int i = param1Activity.hashCode();
      Map<Integer, Object> map = ViewObserver.access$getObservers$cp();
      Integer integer = Integer.valueOf(i);
      Object object2 = map.get(integer);
      Object object1 = object2;
      if (object2 == null) {
        object1 = new ViewObserver(param1Activity, null);
        map.put(integer, object1);
      } 
      ViewObserver.access$startTracking((ViewObserver)object1);
    }
    
    @JvmStatic
    public final void stopTrackingActivity(Activity param1Activity) {
      Intrinsics.checkNotNullParameter(param1Activity, "activity");
      int i = param1Activity.hashCode();
      ViewObserver viewObserver = (ViewObserver)ViewObserver.access$getObservers$cp().get(Integer.valueOf(i));
      if (viewObserver != null) {
        ViewObserver.access$getObservers$cp().remove(Integer.valueOf(i));
        ViewObserver.access$stopTracking(viewObserver);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class ViewObserver$process$runnable$1 implements Runnable {
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
        return;
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\suggestedevents\ViewObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */