package com.appsflyer.internal;

import android.util.Base64;
import com.appsflyer.AFLogger;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

@Metadata(d1 = {"\000*\n\002\030\002\n\000\n\002\020\016\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\007\n\002\020\000\b\026\030\000 \0012\0020\027:\001\001B\027\022\006\020\023\032\0020\t\022\006\020\024\032\0020\017¢\006\004\b\025\020\026R\023\020\005\032\0020\002X\002¢\006\006\n\004\b\003\020\004R\023\020\006\032\0020\002X\002¢\006\006\n\004\b\006\020\004R\021\020\b\032\0020\0028G¢\006\006\032\004\b\006\020\007R\024\020\013\032\0020\t8\002X\004¢\006\006\n\004\b\b\020\nR\024\020\016\032\0020\f8CX\004¢\006\006\032\004\b\013\020\rR\024\020\021\032\0020\0178\002X\004¢\006\006\n\004\b\013\020\020R\021\020\022\032\0020\0028G¢\006\006\032\004\b\005\020\007"}, d2 = {"Lcom/appsflyer/internal/AFd1xSDK;", "AFa1wSDK", "", "afDebugLog", "Lkotlin/Lazy;", "values", "AFInAppEventParameterName", "()Ljava/lang/String;", "AFKeystoreWrapper", "Lcom/appsflyer/internal/AFb1bSDK;", "Lcom/appsflyer/internal/AFb1bSDK;", "valueOf", "", "()Z", "AFInAppEventType", "Lcom/appsflyer/internal/AFc1xSDK;", "Lcom/appsflyer/internal/AFc1xSDK;", "afRDLog", "afErrorLog", "p0", "p1", "<init>", "(Lcom/appsflyer/internal/AFb1bSDK;Lcom/appsflyer/internal/AFc1xSDK;)V", ""}, k = 1, mv = {1, 6, 0}, xi = 48)
public class AFd1xSDK {
  public static String AFInAppEventType;
  
  private static AFd1zSDK AFLogger;
  
  public static final AFa1wSDK AFa1wSDK = new AFa1wSDK(null);
  
  private static final List<String> afRDLog;
  
  public static String values;
  
  public final Lazy AFInAppEventParameterName;
  
  private final AFb1bSDK AFKeystoreWrapper;
  
  private final Lazy afDebugLog;
  
  private final AFc1xSDK valueOf;
  
  static {
    AFInAppEventType = "https://%scdn-%ssettings.%s/android/v1/%s/settings";
    values = "https://%scdn-%stestsettings.%s/android/v1/%s/settings";
    afRDLog = CollectionsKt.listOf((Object[])new String[] { "googleplay", "playstore", "googleplaystore" });
  }
  
  public AFd1xSDK(AFb1bSDK paramAFb1bSDK, AFc1xSDK paramAFc1xSDK) {
    this.AFKeystoreWrapper = paramAFb1bSDK;
    this.valueOf = paramAFc1xSDK;
    this.afDebugLog = LazyKt.lazy(new Function0<String>(this) {
          public final String valueOf() {
            boolean bool;
            String str1 = AFb1xSDK.values(AFd1xSDK.AFKeystoreWrapper(this.AFInAppEventParameterName), AFd1xSDK.AFInAppEventParameterName(this.AFInAppEventParameterName).values());
            CharSequence charSequence = str1;
            if (charSequence == null || StringsKt.isBlank(charSequence)) {
              bool = true;
            } else {
              bool = false;
            } 
            String str2 = "";
            if (!bool) {
              str1 = StringsKt.trim(charSequence).toString();
              AFd1xSDK.AFa1wSDK aFa1wSDK = AFd1xSDK.AFa1wSDK;
              List<String> list = AFd1xSDK.AFa1wSDK.AFInAppEventParameterName();
              Locale locale = Locale.getDefault();
              Intrinsics.checkNotNullExpressionValue(locale, "");
              String str = str1.toLowerCase(locale);
              Intrinsics.checkNotNullExpressionValue(str, "");
              if (!list.contains(str)) {
                str1 = "-".concat(String.valueOf(str1));
              } else {
                StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                str1 = String.format("AF detected using redundant Google-Play channel for attribution - %s. Using without channel postfix.", Arrays.copyOf(new Object[] { str1 }, 1));
                Intrinsics.checkNotNullExpressionValue(str1, "");
                AFLogger.afWarnLog(str1);
                str1 = "";
              } 
            } 
            if (str1 == null)
              str1 = str2; 
            return StringsKt.trim(str1).toString();
          }
        });
    this.AFInAppEventParameterName = LazyKt.lazy(new Function0<String>(this) {
          public final String values() {
            String str = (AFd1xSDK.AFInAppEventParameterName(this.AFInAppEventParameterName)).values.AFKeystoreWrapper.getPackageName();
            Intrinsics.checkNotNullExpressionValue(str, "");
            return AFd1xSDK.values(str, AFd1xSDK.valueOf(this.AFInAppEventParameterName));
          }
        });
  }
  
  public static boolean valueOf() {
    return (AFLogger == null);
  }
  
  public static final void values(AFd1zSDK paramAFd1zSDK) {
    AFa1wSDK.AFKeystoreWrapper(paramAFd1zSDK);
  }
  
  public final String AFInAppEventParameterName() {
    AFd1vSDK aFd1vSDK;
    if (valueOf()) {
      aFd1vSDK = AFd1vSDK.AFInAppEventParameterName;
    } else {
      aFd1vSDK = AFd1vSDK.values;
    } 
    int i = AFa1zSDK.AFInAppEventType[aFd1vSDK.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i == 3)
          return ""; 
        throw new NoWhenBranchMatchedException();
      } 
      AFd1zSDK aFd1zSDK = AFLogger;
      if (aFd1zSDK != null) {
        String str = aFd1zSDK.AFInAppEventType;
      } else {
        aFd1zSDK = null;
      } 
      return (String)((aFd1zSDK == null) ? "" : aFd1zSDK);
    } 
    return "appsflyersdk.com";
  }
  
  public final String values() {
    AFd1vSDK aFd1vSDK;
    if (valueOf()) {
      aFd1vSDK = AFd1vSDK.AFInAppEventParameterName;
    } else {
      aFd1vSDK = AFd1vSDK.values;
    } 
    int i = AFa1zSDK.AFInAppEventType[aFd1vSDK.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i == 3)
          return ""; 
        throw new NoWhenBranchMatchedException();
      } 
      AFd1zSDK aFd1zSDK = AFLogger;
      if (aFd1zSDK != null) {
        String str = aFd1zSDK.values;
      } else {
        aFd1zSDK = null;
      } 
      return (String)((aFd1zSDK == null) ? "" : aFd1zSDK);
    } 
    return (String)this.AFInAppEventParameterName.getValue();
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020 \n\002\020\016\n\002\b\t\n\002\030\002\n\002\b\005\n\002\020\000\b\003\030\0002\0020\022B\t\b\002¢\006\004\b\020\020\021R \020\007\032\b\022\004\022\0020\0020\0018\007X\004¢\006\f\n\004\b\003\020\004\032\004\b\005\020\006R\022\020\t\032\0020\002X\002¢\006\006\n\004\b\007\020\bR\022\020\013\032\0020\002X\002¢\006\006\n\004\b\n\020\bR\034\020\005\032\004\030\0010\f@\007X\n¢\006\f\n\004\b\r\020\016\"\004\b\013\020\017"}, d2 = {"Lcom/appsflyer/internal/AFd1xSDK$AFa1wSDK;", "", "", "afRDLog", "Ljava/util/List;", "AFInAppEventParameterName", "()Ljava/util/List;", "AFInAppEventType", "Ljava/lang/String;", "valueOf", "values", "AFKeystoreWrapper", "Lcom/appsflyer/internal/AFd1zSDK;", "AFLogger", "Lcom/appsflyer/internal/AFd1zSDK;", "(Lcom/appsflyer/internal/AFd1zSDK;)V", "<init>", "()V", ""}, k = 1, mv = {1, 6, 0}, xi = 48)
  public static final class AFa1wSDK {
    private AFa1wSDK() {}
    
    public static List<String> AFInAppEventParameterName() {
      return AFd1xSDK.AFInAppEventType();
    }
    
    public static void AFKeystoreWrapper(AFd1zSDK param1AFd1zSDK) {
      AFd1xSDK.valueOf(param1AFd1zSDK);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFd1xSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */