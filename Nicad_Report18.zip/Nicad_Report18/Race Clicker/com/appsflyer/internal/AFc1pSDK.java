package com.appsflyer.internal;

import android.content.Context;
import android.os.Build;
import android.widget.ExpandableListView;
import com.appsflyer.AFLogger;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.text.Charsets;
import org.json.JSONObject;

public final class AFc1pSDK implements AFc1nSDK {
  private static int AFVersionDeclaration = 0;
  
  private static long afInfoLog = -3085294026707372307L;
  
  private static int getLevel = 1;
  
  private final Lazy AFInAppEventParameterName;
  
  private final Lazy AFInAppEventType;
  
  private final Lazy AFKeystoreWrapper;
  
  private final Lazy AFLogger;
  
  private final Lazy afDebugLog;
  
  private final String afErrorLog;
  
  private final Lazy afRDLog;
  
  private final Lazy valueOf;
  
  private AFc1vSDK values;
  
  public AFc1pSDK(AFc1vSDK paramAFc1vSDK) {
    this.values = paramAFc1vSDK;
    this.AFKeystoreWrapper = LazyKt.lazy(new Function0<AFb1rSDK>(this) {
          public final AFb1rSDK valueOf() {
            AFb1rSDK aFb1rSDK = AFc1pSDK.valueOf(this.AFInAppEventParameterName).afRDLog();
            Intrinsics.checkNotNullExpressionValue(aFb1rSDK, "");
            return aFb1rSDK;
          }
        });
    this.AFInAppEventType = LazyKt.lazy(new Function0<AFb1bSDK>(this) {
          public final AFb1bSDK valueOf() {
            AFb1bSDK aFb1bSDK = AFc1pSDK.valueOf(this.AFKeystoreWrapper).AFInAppEventParameterName();
            Intrinsics.checkNotNullExpressionValue(aFb1bSDK, "");
            return aFb1bSDK;
          }
        });
    this.AFInAppEventParameterName = LazyKt.lazy(new Function0<AFc1xSDK>(this) {
          public final AFc1xSDK AFInAppEventParameterName() {
            AFc1xSDK aFc1xSDK = AFc1pSDK.valueOf(this.values).afErrorLog();
            Intrinsics.checkNotNullExpressionValue(aFc1xSDK, "");
            return aFc1xSDK;
          }
        });
    this.valueOf = LazyKt.lazy(new Function0<AFe1kSDK>(this) {
          public final AFe1kSDK valueOf() {
            AFe1kSDK aFe1kSDK = AFc1pSDK.valueOf(this.AFInAppEventType).afWarnLog();
            Intrinsics.checkNotNullExpressionValue(aFe1kSDK, "");
            return aFe1kSDK;
          }
        });
    this.afDebugLog = LazyKt.lazy(new Function0<ExecutorService>(this) {
          public final ExecutorService AFKeystoreWrapper() {
            ExecutorService executorService = AFc1pSDK.valueOf(this.values).AFInAppEventType();
            Intrinsics.checkNotNullExpressionValue(executorService, "");
            return executorService;
          }
        });
    this.afErrorLog = "6.10.3";
    this.afRDLog = LazyKt.lazy(new Function0<AFa1bSDK>(this) {
          public final AFa1bSDK AFInAppEventType() {
            AFc1wSDK aFc1wSDK = AFc1pSDK.valueOf(this.AFInAppEventParameterName).afErrorLogForExcManagerOnly();
            Intrinsics.checkNotNullExpressionValue(aFc1wSDK, "");
            return new AFa1bSDK(aFc1wSDK);
          }
        });
    this.AFLogger = LazyKt.lazy(new Function0<AFa1cSDK>(this) {
          public final AFa1cSDK AFInAppEventParameterName() {
            return new AFa1cSDK(this.AFInAppEventParameterName.values());
          }
        });
  }
  
  private final AFb1rSDK AFInAppEventParameterName() {
    int i = AFVersionDeclaration + 1;
    getLevel = i % 128;
    AFb1rSDK aFb1rSDK = (AFb1rSDK)this.AFKeystoreWrapper.getValue();
    i = AFVersionDeclaration + 93;
    getLevel = i % 128;
    return aFb1rSDK;
  }
  
  private static final void AFInAppEventParameterName(AFc1pSDK paramAFc1pSDK) {
    int i = getLevel + 123;
    AFVersionDeclaration = i % 128;
    Intrinsics.checkNotNullParameter(paramAFc1pSDK, "");
    paramAFc1pSDK.afErrorLogForExcManagerOnly();
    i = getLevel + 61;
    AFVersionDeclaration = i % 128;
    if (i % 2 != 0) {
      i = 68;
    } else {
      i = 46;
    } 
    if (i != 68)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private static final void AFInAppEventType(AFc1pSDK paramAFc1pSDK) {
    int i = AFVersionDeclaration + 63;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 11;
    } else {
      i = 44;
    } 
    if (i != 11) {
      Intrinsics.checkNotNullParameter(paramAFc1pSDK, "");
      paramAFc1pSDK.AFLogger$LogLevel();
      return;
    } 
    Intrinsics.checkNotNullParameter(paramAFc1pSDK, "");
    paramAFc1pSDK.AFLogger$LogLevel();
    try {
      throw null;
    } finally {}
  }
  
  private static void AFInAppEventType(String paramString, int paramInt, Object[] paramArrayOfObject) {
    String str = paramString;
    if (paramString != null)
      arrayOfChar = paramString.toCharArray(); 
    char[] arrayOfChar = arrayOfChar;
    synchronized (AFg1tSDK.values) {
      AFg1tSDK.valueOf = paramInt;
      char[] arrayOfChar1 = new char[arrayOfChar.length];
      AFg1tSDK.AFKeystoreWrapper = 0;
      while (AFg1tSDK.AFKeystoreWrapper < arrayOfChar.length) {
        arrayOfChar1[AFg1tSDK.AFKeystoreWrapper] = (char)(int)((arrayOfChar[AFg1tSDK.AFKeystoreWrapper] ^ AFg1tSDK.AFKeystoreWrapper * AFg1tSDK.valueOf) ^ afInfoLog);
        AFg1tSDK.AFKeystoreWrapper++;
      } 
      String str1 = new String(arrayOfChar1);
      paramArrayOfObject[0] = str1;
      return;
    } 
  }
  
  private static Map<String, Object> AFKeystoreWrapper(Map<String, ? extends Object> paramMap, List<AFc1sSDK> paramList) {
    int i = getLevel + 125;
    AFVersionDeclaration = i % 128;
    paramMap = MapsKt.mapOf(new Pair[] { TuplesKt.to("deviceInfo", paramMap), TuplesKt.to("excs", AFc1qSDK.AFa1vSDK.valueOf(paramList)) });
    i = AFVersionDeclaration + 91;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 76;
    } else {
      i = 25;
    } 
    if (i == 25)
      return (Map)paramMap; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private static final void AFKeystoreWrapper(AFc1pSDK paramAFc1pSDK) {
    int i = AFVersionDeclaration + 67;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 59;
    } else {
      i = 39;
    } 
    if (i == 39) {
      Intrinsics.checkNotNullParameter(paramAFc1pSDK, "");
      paramAFc1pSDK.afWarnLog();
      i = getLevel + 101;
      AFVersionDeclaration = i % 128;
      return;
    } 
    Intrinsics.checkNotNullParameter(paramAFc1pSDK, "");
    paramAFc1pSDK.afWarnLog();
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private static final void AFKeystoreWrapper(AFc1pSDK paramAFc1pSDK, Throwable paramThrowable, String paramString) {
    int i;
    Intrinsics.checkNotNullParameter(paramAFc1pSDK, "");
    Intrinsics.checkNotNullParameter(paramThrowable, "");
    Intrinsics.checkNotNullParameter(paramString, "");
    AFb1nSDK aFb1nSDK = paramAFc1pSDK.AFVersionDeclaration();
    byte b = 0;
    if (aFb1nSDK != null) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i) {
      i = b;
    } else {
      i = getLevel + 45;
      AFVersionDeclaration = i % 128;
      if (paramAFc1pSDK.AFKeystoreWrapper(aFb1nSDK) == true) {
        i = AFVersionDeclaration + 117;
        getLevel = i % 128;
        i = 1;
      } else {
        i = AFVersionDeclaration + 87;
        getLevel = i % 128;
        i = b;
      } 
    } 
    if (i != 0) {
      i = getLevel + 1;
      AFVersionDeclaration = i % 128;
      paramAFc1pSDK.values().AFInAppEventParameterName(paramThrowable, paramString);
    } 
  }
  
  private final void AFKeystoreWrapper(String paramString1, String paramString2) {
    int i = getLevel + 43;
    AFVersionDeclaration = i % 128;
    byte[] arrayOfByte = paramString1.getBytes(Charsets.UTF_8);
    Intrinsics.checkNotNullExpressionValue(arrayOfByte, "");
    Map map = MapsKt.mapOf(TuplesKt.to("Authorization", AFb1ySDK.values(paramString1, paramString2)));
    getLevel().AFKeystoreWrapper(arrayOfByte, map, 2000);
    i = getLevel + 63;
    AFVersionDeclaration = i % 128;
  }
  
  private final boolean AFKeystoreWrapper(AFb1nSDK paramAFb1nSDK) {
    long l1 = System.currentTimeMillis();
    long l2 = afRDLog().AFKeystoreWrapper("af_send_exc_to_server_window", -1L);
    if (paramAFb1nSDK.AFInAppEventParameterName >= l1 / 1000L && l2 != -1L) {
      int i = AFVersionDeclaration + 73;
      getLevel = i % 128;
      if (l2 < l1) {
        i = 0;
      } else {
        i = 1;
      } 
      if (i != 0) {
        String str = paramAFb1nSDK.values;
        Intrinsics.checkNotNullExpressionValue(str, "");
        if (AFc1qSDK.AFa1vSDK.AFInAppEventType(str) == AFc1qSDK.AFa1vSDK.AFInAppEventType(AFLogger())) {
          i = 27;
        } else {
          i = 45;
        } 
        if (i != 27)
          return false; 
        i = getLevel + 15;
        AFVersionDeclaration = i % 128;
        return !(i % 2 != 0);
      } 
    } 
    return false;
  }
  
  private String AFLogger() {
    int j = getLevel;
    int i = j + 59;
    AFVersionDeclaration = i % 128;
    null = this.afErrorLog;
    i = j + 43;
    AFVersionDeclaration = i % 128;
    if (i % 2 != 0) {
      i = 44;
    } else {
      i = 62;
    } 
    if (i != 44)
      return null; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private final void AFLogger$LogLevel() {
    int i = getLevel + 119;
    AFVersionDeclaration = i % 128;
    AFb1nSDK aFb1nSDK = AFVersionDeclaration();
    if (aFb1nSDK != null) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 1) {
      i = getLevel + 93;
      AFVersionDeclaration = i % 128;
      if (values(aFb1nSDK)) {
        i = 73;
      } else {
        i = 7;
      } 
      if (i != 7) {
        String str = (afDebugLog()).AFInAppEventType;
        if (str != null) {
          String str1 = (new JSONObject(AFKeystoreWrapper((Map)valueOf(aFb1nSDK), values().valueOf()))).toString();
          Intrinsics.checkNotNullExpressionValue(str1, "");
          Intrinsics.checkNotNullExpressionValue(str, "");
          AFKeystoreWrapper(str1, str);
        } 
        return;
      } 
      Intrinsics.checkNotNullParameter("skipping", "");
      AFLogger.afRDLog("[Exception Manager]: ".concat("skipping"));
    } 
  }
  
  private final AFb1nSDK AFVersionDeclaration() {
    AFb1lSDK aFb1lSDK = (AFInAppEventParameterName()).AFKeystoreWrapper.values;
    boolean bool = false;
    if (aFb1lSDK != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 1) {
      i = AFVersionDeclaration + 73;
      getLevel = i % 128;
      AFb1pSDK aFb1pSDK = aFb1lSDK.AFInAppEventParameterName;
      if (aFb1pSDK != null) {
        i = bool;
      } else {
        i = 1;
      } 
      if (i != 1) {
        i = getLevel + 77;
        AFVersionDeclaration = i % 128;
        return aFb1pSDK.values;
      } 
    } 
    int i = getLevel + 87;
    AFVersionDeclaration = i % 128;
    return null;
  }
  
  private final AFe1kSDK afDebugLog() {
    int i = AFVersionDeclaration + 67;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 14;
    } else {
      i = 17;
    } 
    if (i == 17) {
      AFe1kSDK aFe1kSDK = (AFe1kSDK)this.valueOf.getValue();
      i = AFVersionDeclaration + 9;
      getLevel = i % 128;
      return aFe1kSDK;
    } 
    null = (AFe1kSDK)this.valueOf.getValue();
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private final AFb1bSDK afErrorLog() {
    int i = AFVersionDeclaration + 115;
    getLevel = i % 128;
    null = (AFb1bSDK)this.AFInAppEventType.getValue();
    i = AFVersionDeclaration + 9;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 62;
    } else {
      i = 33;
    } 
    if (i == 33)
      return null; 
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private final void afErrorLogForExcManagerOnly() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/appsflyer/internal/AFc1pSDK.AFVersionDeclaration : I
    //   5: bipush #57
    //   7: iadd
    //   8: istore_1
    //   9: iload_1
    //   10: sipush #128
    //   13: irem
    //   14: putstatic com/appsflyer/internal/AFc1pSDK.getLevel : I
    //   17: iload_1
    //   18: iconst_2
    //   19: irem
    //   20: ifeq -> 248
    //   23: aload_0
    //   24: invokespecial AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1nSDK;
    //   27: astore #7
    //   29: aload #7
    //   31: ifnull -> 39
    //   34: iconst_0
    //   35: istore_1
    //   36: goto -> 41
    //   39: iconst_1
    //   40: istore_1
    //   41: iload_1
    //   42: ifeq -> 48
    //   45: aload_0
    //   46: monitorexit
    //   47: return
    //   48: aload #7
    //   50: getfield AFKeystoreWrapper : I
    //   53: iconst_m1
    //   54: if_icmpne -> 128
    //   57: getstatic com/appsflyer/internal/AFc1pSDK.getLevel : I
    //   60: bipush #113
    //   62: iadd
    //   63: istore_1
    //   64: iload_1
    //   65: sipush #128
    //   68: irem
    //   69: putstatic com/appsflyer/internal/AFc1pSDK.AFVersionDeclaration : I
    //   72: iload_1
    //   73: iconst_2
    //   74: irem
    //   75: ifeq -> 273
    //   78: bipush #83
    //   80: istore_1
    //   81: goto -> 84
    //   84: iload_1
    //   85: bipush #83
    //   87: if_icmpeq -> 104
    //   90: aload_0
    //   91: invokespecial afRDLog : ()Lcom/appsflyer/internal/AFc1xSDK;
    //   94: ldc 'af_send_exc_to_server_window'
    //   96: invokeinterface valueOf : (Ljava/lang/String;)V
    //   101: aload_0
    //   102: monitorexit
    //   103: return
    //   104: aload_0
    //   105: invokespecial afRDLog : ()Lcom/appsflyer/internal/AFc1xSDK;
    //   108: ldc 'af_send_exc_to_server_window'
    //   110: invokeinterface valueOf : (Ljava/lang/String;)V
    //   115: bipush #83
    //   117: iconst_0
    //   118: idiv
    //   119: istore_1
    //   120: aload_0
    //   121: monitorexit
    //   122: return
    //   123: astore #7
    //   125: aload #7
    //   127: athrow
    //   128: aload_0
    //   129: invokespecial afRDLog : ()Lcom/appsflyer/internal/AFc1xSDK;
    //   132: ldc 'af_send_exc_to_server_window'
    //   134: ldc2_w -1
    //   137: invokeinterface AFKeystoreWrapper : (Ljava/lang/String;J)J
    //   142: ldc2_w -1
    //   145: lcmp
    //   146: ifne -> 279
    //   149: bipush #48
    //   151: istore_1
    //   152: goto -> 282
    //   155: aload #7
    //   157: getfield valueOf : I
    //   160: istore_2
    //   161: aload #7
    //   163: getfield AFKeystoreWrapper : I
    //   166: istore_1
    //   167: invokestatic currentTimeMillis : ()J
    //   170: lstore_3
    //   171: getstatic java/util/concurrent/TimeUnit.DAYS : Ljava/util/concurrent/TimeUnit;
    //   174: iload_1
    //   175: i2l
    //   176: invokevirtual toMillis : (J)J
    //   179: lstore #5
    //   181: aload_0
    //   182: invokespecial afRDLog : ()Lcom/appsflyer/internal/AFc1xSDK;
    //   185: astore #7
    //   187: aload #7
    //   189: ldc 'af_send_exc_to_server_window'
    //   191: lload_3
    //   192: lload #5
    //   194: ladd
    //   195: invokeinterface AFInAppEventType : (Ljava/lang/String;J)V
    //   200: aload #7
    //   202: ldc_w 'af_send_exc_min'
    //   205: iload_2
    //   206: invokeinterface valueOf : (Ljava/lang/String;I)V
    //   211: getstatic com/appsflyer/internal/AFc1pSDK.AFVersionDeclaration : I
    //   214: bipush #79
    //   216: iadd
    //   217: istore_1
    //   218: iload_1
    //   219: sipush #128
    //   222: irem
    //   223: putstatic com/appsflyer/internal/AFc1pSDK.getLevel : I
    //   226: iload_1
    //   227: iconst_2
    //   228: irem
    //   229: ifne -> 245
    //   232: bipush #22
    //   234: iconst_0
    //   235: idiv
    //   236: istore_1
    //   237: aload_0
    //   238: monitorexit
    //   239: return
    //   240: astore #7
    //   242: aload #7
    //   244: athrow
    //   245: aload_0
    //   246: monitorexit
    //   247: return
    //   248: aload_0
    //   249: invokespecial AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1nSDK;
    //   252: pop
    //   253: new java/lang/NullPointerException
    //   256: dup
    //   257: invokespecial <init> : ()V
    //   260: athrow
    //   261: astore #7
    //   263: aload #7
    //   265: athrow
    //   266: astore #7
    //   268: aload_0
    //   269: monitorexit
    //   270: aload #7
    //   272: athrow
    //   273: bipush #44
    //   275: istore_1
    //   276: goto -> 84
    //   279: bipush #30
    //   281: istore_1
    //   282: iload_1
    //   283: bipush #48
    //   285: if_icmpeq -> 155
    //   288: goto -> 211
    // Exception table:
    //   from	to	target	type
    //   2	17	266	finally
    //   23	29	266	finally
    //   48	72	266	finally
    //   90	101	266	finally
    //   104	115	266	finally
    //   115	120	123	finally
    //   125	128	266	finally
    //   128	149	266	finally
    //   155	211	266	finally
    //   211	226	266	finally
    //   232	237	240	finally
    //   242	245	266	finally
    //   248	253	266	finally
    //   253	261	261	finally
    //   263	266	266	finally
  }
  
  private final ExecutorService afInfoLog() {
    int i = AFVersionDeclaration + 109;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 1)
      return (ExecutorService)this.afDebugLog.getValue(); 
    null = (ExecutorService)this.afDebugLog.getValue();
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private final AFc1xSDK afRDLog() {
    int i = AFVersionDeclaration + 67;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 85;
    } else {
      i = 62;
    } 
    if (i != 85)
      return (AFc1xSDK)this.AFInAppEventParameterName.getValue(); 
    null = (AFc1xSDK)this.AFInAppEventParameterName.getValue();
    try {
      throw null;
    } finally {}
  }
  
  private final void afWarnLog() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1nSDK;
    //   6: astore #7
    //   8: aload #7
    //   10: ifnull -> 351
    //   13: iconst_1
    //   14: istore_1
    //   15: goto -> 353
    //   18: getstatic com/appsflyer/internal/AFc1pSDK.AFVersionDeclaration : I
    //   21: bipush #97
    //   23: iadd
    //   24: istore_1
    //   25: iload_1
    //   26: sipush #128
    //   29: irem
    //   30: putstatic com/appsflyer/internal/AFc1pSDK.getLevel : I
    //   33: iload_1
    //   34: iconst_2
    //   35: irem
    //   36: ifne -> 368
    //   39: bipush #73
    //   41: istore_1
    //   42: goto -> 45
    //   45: iload_1
    //   46: bipush #73
    //   48: if_icmpeq -> 320
    //   51: aload #7
    //   53: getfield AFInAppEventParameterName : J
    //   56: lstore_2
    //   57: invokestatic currentTimeMillis : ()J
    //   60: ldc2_w 1000
    //   63: ldiv
    //   64: lstore #4
    //   66: aload_0
    //   67: invokespecial AFVersionDeclaration : ()Lcom/appsflyer/internal/AFb1nSDK;
    //   70: astore #7
    //   72: aload #7
    //   74: ifnull -> 133
    //   77: getstatic com/appsflyer/internal/AFc1pSDK.getLevel : I
    //   80: bipush #51
    //   82: iadd
    //   83: istore_1
    //   84: iload_1
    //   85: sipush #128
    //   88: irem
    //   89: putstatic com/appsflyer/internal/AFc1pSDK.AFVersionDeclaration : I
    //   92: iload_1
    //   93: iconst_2
    //   94: irem
    //   95: ifeq -> 103
    //   98: iconst_1
    //   99: istore_1
    //   100: goto -> 105
    //   103: iconst_0
    //   104: istore_1
    //   105: iload_1
    //   106: ifne -> 119
    //   109: aload #7
    //   111: getfield values : Ljava/lang/String;
    //   114: astore #6
    //   116: goto -> 133
    //   119: aload #7
    //   121: getfield values : Ljava/lang/String;
    //   124: astore #6
    //   126: aconst_null
    //   127: athrow
    //   128: astore #6
    //   130: aload #6
    //   132: athrow
    //   133: aload #6
    //   135: astore #7
    //   137: aload #6
    //   139: ifnonnull -> 146
    //   142: ldc ''
    //   144: astore #7
    //   146: getstatic com/appsflyer/internal/AFc1pSDK.AFVersionDeclaration : I
    //   149: bipush #7
    //   151: iadd
    //   152: istore_1
    //   153: iload_1
    //   154: sipush #128
    //   157: irem
    //   158: putstatic com/appsflyer/internal/AFc1pSDK.getLevel : I
    //   161: goto -> 379
    //   164: iload_1
    //   165: ifeq -> 227
    //   168: ldc_w 'TTL is already passed'
    //   171: ldc ''
    //   173: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   176: ldc_w '[Exception Manager]: '
    //   179: ldc_w 'TTL is already passed'
    //   182: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   185: invokestatic afRDLog : (Ljava/lang/String;)V
    //   188: aload_0
    //   189: invokespecial afRDLog : ()Lcom/appsflyer/internal/AFc1xSDK;
    //   192: ldc 'af_send_exc_to_server_window'
    //   194: invokeinterface valueOf : (Ljava/lang/String;)V
    //   199: aload_0
    //   200: invokevirtual values : ()Lcom/appsflyer/internal/AFc1tSDK;
    //   203: invokeinterface AFInAppEventParameterName : ()Z
    //   208: pop
    //   209: getstatic com/appsflyer/internal/AFc1pSDK.getLevel : I
    //   212: bipush #69
    //   214: iadd
    //   215: istore_1
    //   216: iload_1
    //   217: sipush #128
    //   220: irem
    //   221: putstatic com/appsflyer/internal/AFc1pSDK.AFVersionDeclaration : I
    //   224: aload_0
    //   225: monitorexit
    //   226: return
    //   227: aload #7
    //   229: invokestatic AFInAppEventType : (Ljava/lang/String;)I
    //   232: iconst_m1
    //   233: if_icmpeq -> 396
    //   236: bipush #21
    //   238: istore_1
    //   239: goto -> 399
    //   242: getstatic com/appsflyer/internal/AFc1pSDK.getLevel : I
    //   245: bipush #77
    //   247: iadd
    //   248: istore_1
    //   249: iload_1
    //   250: sipush #128
    //   253: irem
    //   254: putstatic com/appsflyer/internal/AFc1pSDK.AFVersionDeclaration : I
    //   257: aload #7
    //   259: invokestatic AFInAppEventType : (Ljava/lang/String;)I
    //   262: aload_0
    //   263: invokespecial AFLogger : ()Ljava/lang/String;
    //   266: invokestatic AFInAppEventType : (Ljava/lang/String;)I
    //   269: if_icmpgt -> 296
    //   272: aload_0
    //   273: invokevirtual values : ()Lcom/appsflyer/internal/AFc1tSDK;
    //   276: iconst_1
    //   277: anewarray java/lang/String
    //   280: dup
    //   281: iconst_0
    //   282: aload_0
    //   283: invokespecial AFLogger : ()Ljava/lang/String;
    //   286: aastore
    //   287: invokeinterface values : ([Ljava/lang/String;)Z
    //   292: pop
    //   293: aload_0
    //   294: monitorexit
    //   295: return
    //   296: aload_0
    //   297: invokespecial afRDLog : ()Lcom/appsflyer/internal/AFc1xSDK;
    //   300: ldc 'af_send_exc_to_server_window'
    //   302: invokeinterface valueOf : (Ljava/lang/String;)V
    //   307: aload_0
    //   308: invokevirtual values : ()Lcom/appsflyer/internal/AFc1tSDK;
    //   311: invokeinterface AFInAppEventParameterName : ()Z
    //   316: pop
    //   317: aload_0
    //   318: monitorexit
    //   319: return
    //   320: aload #7
    //   322: getfield AFInAppEventParameterName : J
    //   325: lstore_2
    //   326: new java/lang/NullPointerException
    //   329: dup
    //   330: invokespecial <init> : ()V
    //   333: athrow
    //   334: astore #6
    //   336: aload #6
    //   338: athrow
    //   339: astore #6
    //   341: aload_0
    //   342: monitorexit
    //   343: aload #6
    //   345: athrow
    //   346: astore #6
    //   348: goto -> 374
    //   351: iconst_0
    //   352: istore_1
    //   353: aconst_null
    //   354: astore #6
    //   356: iload_1
    //   357: iconst_1
    //   358: if_icmpeq -> 18
    //   361: ldc2_w -1
    //   364: lstore_2
    //   365: goto -> 57
    //   368: bipush #81
    //   370: istore_1
    //   371: goto -> 45
    //   374: ldc_w 'NOT_DETECTED'
    //   377: astore #7
    //   379: lload_2
    //   380: lload #4
    //   382: lcmp
    //   383: ifge -> 391
    //   386: iconst_1
    //   387: istore_1
    //   388: goto -> 164
    //   391: iconst_0
    //   392: istore_1
    //   393: goto -> 164
    //   396: bipush #64
    //   398: istore_1
    //   399: iload_1
    //   400: bipush #21
    //   402: if_icmpeq -> 242
    //   405: goto -> 296
    // Exception table:
    //   from	to	target	type
    //   2	8	339	finally
    //   18	33	339	finally
    //   51	57	339	finally
    //   57	66	339	finally
    //   66	72	346	java/lang/NullPointerException
    //   66	72	339	finally
    //   77	92	339	finally
    //   109	116	346	java/lang/NullPointerException
    //   109	116	339	finally
    //   119	126	346	java/lang/NullPointerException
    //   119	126	339	finally
    //   126	128	346	java/lang/NullPointerException
    //   126	128	128	finally
    //   130	133	339	finally
    //   146	161	339	finally
    //   168	224	339	finally
    //   227	236	339	finally
    //   242	293	339	finally
    //   296	317	339	finally
    //   320	326	339	finally
    //   326	334	334	finally
    //   336	339	339	finally
  }
  
  private AFc1qSDK getLevel() {
    int i = getLevel + 95;
    AFVersionDeclaration = i % 128;
    if (i % 2 != 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 0)
      return (AFc1qSDK)this.AFLogger.getValue(); 
    null = (AFc1qSDK)this.AFLogger.getValue();
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  private final Map<String, String> valueOf(AFb1nSDK paramAFb1nSDK) {
    long l = ExpandableListView.getPackedPositionForGroup(0);
    Object[] arrayOfObject = new Object[1];
    AFInAppEventType("㭌洪鿺쇅", (l cmp 0L) + 52691, arrayOfObject);
    Map<String, String> map = MapsKt.mapOf(new Pair[] { TuplesKt.to(((String)arrayOfObject[0]).intern(), Build.BRAND), TuplesKt.to("model", Build.MODEL), TuplesKt.to("app_id", (afErrorLog()).values.AFKeystoreWrapper.getPackageName()), TuplesKt.to("p_ex", (new AFb1uSDK()).AFKeystoreWrapper()), TuplesKt.to("api", String.valueOf(Build.VERSION.SDK_INT)), TuplesKt.to("sdk", AFLogger()), TuplesKt.to("uid", AFb1wSDK.AFInAppEventParameterName(new WeakReference<Context>((afErrorLog()).values.AFKeystoreWrapper))), TuplesKt.to("exc_config", paramAFb1nSDK.values()) });
    int i = getLevel + 63;
    AFVersionDeclaration = i % 128;
    return map;
  }
  
  private final boolean values(AFb1nSDK paramAFb1nSDK) {
    int i;
    long l2 = System.currentTimeMillis();
    long l1 = afRDLog().AFKeystoreWrapper("af_send_exc_to_server_window", -1L);
    if (paramAFb1nSDK.AFInAppEventParameterName < l2 / 1000L) {
      i = AFVersionDeclaration + 77;
      getLevel = i % 128;
      if (i % 2 != 0)
        return false; 
      try {
        throw new NullPointerException();
      } finally {}
    } 
    if (l1 != -1L) {
      i = 58;
    } else {
      i = 27;
    } 
    if (i != 27) {
      if (l1 < l2)
        return false; 
      int j = afRDLog().AFKeystoreWrapper("af_send_exc_min", -1);
      if (j != -1) {
        i = 81;
      } else {
        i = 99;
      } 
      if (i != 99) {
        i = getLevel + 113;
        AFVersionDeclaration = i % 128;
        if (i % 2 != 0) {
          i = 18;
        } else {
          i = 91;
        } 
        if (i != 18) {
          if (values().AFKeystoreWrapper() < j)
            return false; 
          String str = paramAFb1nSDK.values;
          Intrinsics.checkNotNullExpressionValue(str, "");
          if (AFc1qSDK.AFa1vSDK.AFInAppEventType(str) == AFc1qSDK.AFa1vSDK.AFInAppEventType(AFLogger())) {
            i = AFVersionDeclaration + 9;
            getLevel = i % 128;
            return true;
          } 
          return false;
        } 
        values().AFKeystoreWrapper();
        try {
          throw new NullPointerException();
        } finally {}
      } 
    } 
    return false;
  }
  
  public final void AFInAppEventType() {
    int i = AFVersionDeclaration + 9;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 71;
    } else {
      i = 77;
    } 
    if (i != 71) {
      afInfoLog().execute((Runnable)new AFc1pSDK$.ExternalSyntheticLambda1(this));
      return;
    } 
    afInfoLog().execute((Runnable)new AFc1pSDK$.ExternalSyntheticLambda1(this));
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final void AFKeystoreWrapper() {
    int i = getLevel + 123;
    AFVersionDeclaration = i % 128;
    afInfoLog().execute((Runnable)new AFc1pSDK$.ExternalSyntheticLambda2(this));
    i = AFVersionDeclaration + 91;
    getLevel = i % 128;
  }
  
  public final void valueOf() {
    int i = getLevel + 11;
    AFVersionDeclaration = i % 128;
    if (i % 2 != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0) {
      afInfoLog().execute((Runnable)new AFc1pSDK$.ExternalSyntheticLambda0(this));
      i = getLevel + 107;
      AFVersionDeclaration = i % 128;
      if (i % 2 != 0) {
        i = 92;
      } else {
        i = 45;
      } 
      if (i != 92)
        return; 
      try {
        throw new NullPointerException();
      } finally {}
    } 
    afInfoLog().execute((Runnable)new AFc1pSDK$.ExternalSyntheticLambda0(this));
    try {
      throw new NullPointerException();
    } finally {}
  }
  
  public final AFc1tSDK values() {
    int i = AFVersionDeclaration + 79;
    getLevel = i % 128;
    AFc1tSDK aFc1tSDK = (AFc1tSDK)this.afRDLog.getValue();
    i = getLevel + 121;
    AFVersionDeclaration = i % 128;
    return aFc1tSDK;
  }
  
  public final void values(Throwable paramThrowable, String paramString) {
    int i = getLevel + 21;
    AFVersionDeclaration = i % 128;
    Intrinsics.checkNotNullParameter(paramThrowable, "");
    Intrinsics.checkNotNullParameter(paramString, "");
    afInfoLog().execute((Runnable)new AFc1pSDK$.ExternalSyntheticLambda3(this, paramThrowable, paramString));
    i = AFVersionDeclaration + 23;
    getLevel = i % 128;
    if (i % 2 == 0) {
      i = 0;
    } else {
      i = 1;
    } 
    if (i != 0)
      return; 
    try {
      throw new NullPointerException();
    } finally {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFc1pSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */