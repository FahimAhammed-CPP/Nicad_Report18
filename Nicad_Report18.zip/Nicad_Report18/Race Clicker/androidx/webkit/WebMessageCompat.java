package androidx.webkit;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Objects;

public class WebMessageCompat {
  public static final int TYPE_ARRAY_BUFFER = 1;
  
  public static final int TYPE_STRING = 0;
  
  private final byte[] mArrayBuffer;
  
  private final WebMessagePortCompat[] mPorts;
  
  private final String mString;
  
  private final int mType;
  
  public WebMessageCompat(String paramString) {
    this(paramString, (WebMessagePortCompat[])null);
  }
  
  public WebMessageCompat(String paramString, WebMessagePortCompat[] paramArrayOfWebMessagePortCompat) {
    this.mString = paramString;
    this.mArrayBuffer = null;
    this.mPorts = paramArrayOfWebMessagePortCompat;
    this.mType = 0;
  }
  
  public WebMessageCompat(byte[] paramArrayOfbyte) {
    this(paramArrayOfbyte, (WebMessagePortCompat[])null);
  }
  
  public WebMessageCompat(byte[] paramArrayOfbyte, WebMessagePortCompat[] paramArrayOfWebMessagePortCompat) {
    Objects.requireNonNull(paramArrayOfbyte);
    this.mArrayBuffer = paramArrayOfbyte;
    this.mString = null;
    this.mPorts = paramArrayOfWebMessagePortCompat;
    this.mType = 1;
  }
  
  public byte[] getArrayBuffer() {
    return this.mArrayBuffer;
  }
  
  public String getData() {
    return this.mString;
  }
  
  public WebMessagePortCompat[] getPorts() {
    return this.mPorts;
  }
  
  public int getType() {
    return this.mType;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface Type {}
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\webkit\WebMessageCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */