package com.appsflyer.internal;

import android.content.ContentResolver;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import com.appsflyer.AppsFlyerProperties;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class AFa1bSDK implements AFc1tSDK {
  static Boolean AFInAppEventType;
  
  static String values;
  
  private final AFc1wSDK AFKeystoreWrapper;
  
  public AFa1bSDK() {}
  
  public AFa1bSDK(AFc1wSDK paramAFc1wSDK) {
    this.AFKeystoreWrapper = paramAFc1wSDK;
  }
  
  public static AFc1qSDK.AFa1vSDK AFInAppEventParameterName(Context paramContext) {
    // Byte code:
    //   0: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   3: astore_3
    //   4: getstatic com/appsflyer/internal/AFa1bSDK.values : Ljava/lang/String;
    //   7: astore_2
    //   8: aload_2
    //   9: ifnull -> 17
    //   12: iconst_1
    //   13: istore_1
    //   14: goto -> 19
    //   17: iconst_0
    //   18: istore_1
    //   19: iload_1
    //   20: ifeq -> 30
    //   23: aload_2
    //   24: astore_0
    //   25: aconst_null
    //   26: astore_2
    //   27: goto -> 125
    //   30: getstatic com/appsflyer/internal/AFa1bSDK.AFInAppEventType : Ljava/lang/Boolean;
    //   33: astore_2
    //   34: aload_2
    //   35: ifnull -> 45
    //   38: aload_2
    //   39: invokevirtual booleanValue : ()Z
    //   42: ifne -> 61
    //   45: getstatic com/appsflyer/internal/AFa1bSDK.AFInAppEventType : Ljava/lang/Boolean;
    //   48: ifnonnull -> 121
    //   51: aload_3
    //   52: ldc 'collectOAID'
    //   54: iconst_1
    //   55: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   58: ifeq -> 121
    //   61: new com/appsflyer/oaid/OaidClient
    //   64: dup
    //   65: aload_0
    //   66: invokespecial <init> : (Landroid/content/Context;)V
    //   69: astore_0
    //   70: aload_0
    //   71: aload_3
    //   72: invokevirtual isEnableLog : ()Z
    //   75: invokevirtual setLogging : (Z)V
    //   78: aload_0
    //   79: invokevirtual fetch : ()Lcom/appsflyer/oaid/OaidClient$Info;
    //   82: astore_2
    //   83: aload_2
    //   84: ifnull -> 121
    //   87: aload_2
    //   88: invokevirtual getId : ()Ljava/lang/String;
    //   91: astore_0
    //   92: aload_2
    //   93: invokevirtual getLat : ()Ljava/lang/Boolean;
    //   96: astore_2
    //   97: goto -> 125
    //   100: astore_2
    //   101: goto -> 107
    //   104: astore_2
    //   105: aconst_null
    //   106: astore_0
    //   107: ldc 'No OAID library'
    //   109: aload_2
    //   110: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   113: ldc 'No OAID library'
    //   115: invokestatic afDebugLog : (Ljava/lang/String;)V
    //   118: goto -> 25
    //   121: aconst_null
    //   122: astore_2
    //   123: aload_2
    //   124: astore_0
    //   125: aload_0
    //   126: ifnull -> 149
    //   129: new com/appsflyer/internal/AFc1qSDK$AFa1vSDK
    //   132: dup
    //   133: aload_0
    //   134: aload_2
    //   135: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Boolean;)V
    //   138: astore_0
    //   139: aload_0
    //   140: iload_1
    //   141: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   144: putfield AFKeystoreWrapper : Ljava/lang/Boolean;
    //   147: aload_0
    //   148: areturn
    //   149: aconst_null
    //   150: areturn
    // Exception table:
    //   from	to	target	type
    //   61	83	104	finally
    //   87	92	104	finally
    //   92	97	100	finally
  }
  
  public static AFc1qSDK.AFa1vSDK AFInAppEventType(Context paramContext, Map<String, Object> paramMap) {
    // Byte code:
    //   0: invokestatic AFInAppEventType : ()Z
    //   3: istore_3
    //   4: aconst_null
    //   5: astore #6
    //   7: aconst_null
    //   8: astore #8
    //   10: iload_3
    //   11: ifne -> 16
    //   14: aconst_null
    //   15: areturn
    //   16: ldc 'Trying to fetch GAID..'
    //   18: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   21: new java/lang/StringBuilder
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore #9
    //   30: invokestatic getInstance : ()Lcom/google/android/gms/common/GoogleApiAvailability;
    //   33: aload_0
    //   34: invokevirtual isGooglePlayServicesAvailable : (Landroid/content/Context;)I
    //   37: istore_2
    //   38: goto -> 52
    //   41: astore #5
    //   43: ldc 'isGooglePlayServicesAvailable error'
    //   45: aload #5
    //   47: invokestatic afErrorLogForExcManagerOnly : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   50: iconst_m1
    //   51: istore_2
    //   52: ldc 'com.google.android.gms.ads.identifier.AdvertisingIdClient'
    //   54: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   57: pop
    //   58: aload_0
    //   59: invokestatic getAdvertisingIdInfo : (Landroid/content/Context;)Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;
    //   62: astore #5
    //   64: aload #5
    //   66: ifnull -> 158
    //   69: aload #5
    //   71: invokevirtual getId : ()Ljava/lang/String;
    //   74: astore #7
    //   76: aload #5
    //   78: invokevirtual isLimitAdTrackingEnabled : ()Z
    //   81: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   84: astore #5
    //   86: aload #7
    //   88: ifnull -> 99
    //   91: aload #7
    //   93: invokevirtual length : ()I
    //   96: ifne -> 107
    //   99: aload #9
    //   101: ldc 'emptyOrNull |'
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: pop
    //   107: iconst_1
    //   108: istore_3
    //   109: aload #7
    //   111: astore #6
    //   113: goto -> 378
    //   116: astore #8
    //   118: iconst_1
    //   119: istore_3
    //   120: aload #5
    //   122: astore #6
    //   124: aload #8
    //   126: astore #5
    //   128: goto -> 139
    //   131: astore #5
    //   133: iconst_0
    //   134: istore_3
    //   135: aload #8
    //   137: astore #6
    //   139: aload #6
    //   141: astore #8
    //   143: aload #7
    //   145: astore #6
    //   147: aload #5
    //   149: astore #7
    //   151: aload #8
    //   153: astore #5
    //   155: goto -> 183
    //   158: aload #9
    //   160: ldc 'gpsAdInfo-null |'
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: new java/lang/IllegalStateException
    //   169: dup
    //   170: ldc 'GpsAdIndo is null'
    //   172: invokespecial <init> : (Ljava/lang/String;)V
    //   175: athrow
    //   176: astore #7
    //   178: iconst_0
    //   179: istore_3
    //   180: aconst_null
    //   181: astore #5
    //   183: aload #7
    //   185: invokevirtual getMessage : ()Ljava/lang/String;
    //   188: aload #7
    //   190: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   193: aload #9
    //   195: aload #7
    //   197: invokevirtual getClass : ()Ljava/lang/Class;
    //   200: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: pop
    //   207: aload #9
    //   209: ldc ' |'
    //   211: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: pop
    //   215: ldc 'WARNING: Google Play Services is missing.'
    //   217: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   220: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   223: ldc 'enableGpsFallback'
    //   225: iconst_1
    //   226: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   229: ifeq -> 378
    //   232: aload_0
    //   233: invokestatic values : (Landroid/content/Context;)Lcom/appsflyer/internal/AFa1eSDK$AFa1ySDK;
    //   236: astore #5
    //   238: aload #5
    //   240: getfield values : Ljava/lang/String;
    //   243: astore #6
    //   245: aload #5
    //   247: invokevirtual valueOf : ()Z
    //   250: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   253: astore #5
    //   255: aload #6
    //   257: ifnull -> 268
    //   260: aload #6
    //   262: invokevirtual length : ()I
    //   265: ifne -> 276
    //   268: aload #9
    //   270: ldc 'emptyOrNull (bypass) |'
    //   272: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: pop
    //   276: goto -> 378
    //   279: astore #5
    //   281: aload #5
    //   283: invokevirtual getMessage : ()Ljava/lang/String;
    //   286: aload #5
    //   288: iconst_1
    //   289: iconst_0
    //   290: iconst_0
    //   291: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;ZZZ)V
    //   294: aload #9
    //   296: aload #5
    //   298: invokevirtual getClass : ()Ljava/lang/Class;
    //   301: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   304: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   307: pop
    //   308: aload #9
    //   310: ldc ' |'
    //   312: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   315: pop
    //   316: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   319: ldc 'advertiserId'
    //   321: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   324: astore #6
    //   326: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   329: ldc 'advertiserIdEnabled'
    //   331: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   334: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   337: istore #4
    //   339: aload #5
    //   341: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
    //   344: ifnull -> 358
    //   347: aload #5
    //   349: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
    //   352: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   355: goto -> 366
    //   358: aload #5
    //   360: invokevirtual toString : ()Ljava/lang/String;
    //   363: invokestatic afInfoLog : (Ljava/lang/String;)V
    //   366: iload #4
    //   368: iconst_1
    //   369: ixor
    //   370: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   373: astore #5
    //   375: goto -> 378
    //   378: aload_0
    //   379: invokevirtual getClass : ()Ljava/lang/Class;
    //   382: invokevirtual getName : ()Ljava/lang/String;
    //   385: ldc 'android.app.ReceiverRestrictedContext'
    //   387: invokevirtual equals : (Ljava/lang/Object;)Z
    //   390: ifeq -> 429
    //   393: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   396: ldc 'advertiserId'
    //   398: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   401: astore #6
    //   403: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   406: ldc 'advertiserIdEnabled'
    //   408: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   411: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   414: iconst_1
    //   415: ixor
    //   416: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   419: astore #5
    //   421: aload #9
    //   423: ldc 'context = android.app.ReceiverRestrictedContext |'
    //   425: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   428: pop
    //   429: aload #9
    //   431: invokevirtual length : ()I
    //   434: ifle -> 478
    //   437: new java/lang/StringBuilder
    //   440: dup
    //   441: invokespecial <init> : ()V
    //   444: astore_0
    //   445: aload_0
    //   446: iload_2
    //   447: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   450: pop
    //   451: aload_0
    //   452: ldc ': '
    //   454: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   457: pop
    //   458: aload_0
    //   459: aload #9
    //   461: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   464: pop
    //   465: aload_1
    //   466: ldc 'gaidError'
    //   468: aload_0
    //   469: invokevirtual toString : ()Ljava/lang/String;
    //   472: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   477: pop
    //   478: aload #6
    //   480: ifnull -> 559
    //   483: aload #5
    //   485: ifnull -> 559
    //   488: aload_1
    //   489: ldc 'advertiserId'
    //   491: aload #6
    //   493: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   498: pop
    //   499: aload_1
    //   500: ldc 'advertiserIdEnabled'
    //   502: aload #5
    //   504: invokevirtual booleanValue : ()Z
    //   507: iconst_1
    //   508: ixor
    //   509: invokestatic valueOf : (Z)Ljava/lang/String;
    //   512: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   517: pop
    //   518: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   521: ldc 'advertiserId'
    //   523: aload #6
    //   525: invokevirtual set : (Ljava/lang/String;Ljava/lang/String;)V
    //   528: invokestatic getInstance : ()Lcom/appsflyer/AppsFlyerProperties;
    //   531: ldc 'advertiserIdEnabled'
    //   533: aload #5
    //   535: invokevirtual booleanValue : ()Z
    //   538: iconst_1
    //   539: ixor
    //   540: invokestatic valueOf : (Z)Ljava/lang/String;
    //   543: invokevirtual set : (Ljava/lang/String;Ljava/lang/String;)V
    //   546: aload_1
    //   547: ldc 'isGaidWithGps'
    //   549: iload_3
    //   550: invokestatic valueOf : (Z)Ljava/lang/String;
    //   553: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   558: pop
    //   559: new com/appsflyer/internal/AFc1qSDK$AFa1vSDK
    //   562: dup
    //   563: aload #6
    //   565: aload #5
    //   567: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Boolean;)V
    //   570: areturn
    // Exception table:
    //   from	to	target	type
    //   30	38	41	finally
    //   52	64	176	finally
    //   69	76	176	finally
    //   76	86	131	finally
    //   91	99	116	finally
    //   99	107	116	finally
    //   158	176	176	finally
    //   232	255	279	finally
    //   260	268	279	finally
    //   268	276	279	finally
  }
  
  private static boolean AFInAppEventType() {
    Boolean bool = AFInAppEventType;
    return (bool == null || bool.booleanValue());
  }
  
  private File afRDLog() {
    File file = values();
    if (file != null) {
      file = new File(file, "6.10.3");
      if (!file.exists())
        file.mkdirs(); 
      return file;
    } 
    return null;
  }
  
  public static AFc1qSDK.AFa1vSDK values(ContentResolver paramContentResolver) {
    boolean bool = AFInAppEventType();
    AFc1qSDK.AFa1vSDK aFa1vSDK2 = null;
    if (!bool)
      return null; 
    if (paramContentResolver == null)
      return null; 
    AFc1qSDK.AFa1vSDK aFa1vSDK1 = aFa1vSDK2;
    if (AppsFlyerProperties.getInstance().getString("amazon_aid") == null) {
      aFa1vSDK1 = aFa1vSDK2;
      if ("Amazon".equals(Build.MANUFACTURER)) {
        String str;
        int i = Settings.Secure.getInt(paramContentResolver, "limit_ad_tracking", 2);
        if (i == 0)
          return new AFc1qSDK.AFa1vSDK(Settings.Secure.getString(paramContentResolver, "advertising_id"), Boolean.FALSE); 
        if (i == 2)
          return null; 
      } 
    } 
    return aFa1vSDK1;
  }
  
  private File values() {
    Context context = this.AFKeystoreWrapper.AFKeystoreWrapper;
    if (context != null) {
      File file = new File(context.getFilesDir(), "AFExceptionsCache");
      if (!file.exists())
        file.mkdirs(); 
      return file;
    } 
    return null;
  }
  
  public final String AFInAppEventParameterName(Throwable paramThrowable, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ldc ''
    //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_2
    //   7: ldc ''
    //   9: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: invokespecial afRDLog : ()Ljava/io/File;
    //   18: astore #5
    //   20: aconst_null
    //   21: astore #4
    //   23: aload #4
    //   25: astore_3
    //   26: aload #5
    //   28: ifnull -> 423
    //   31: aload_1
    //   32: ldc ''
    //   34: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   37: aload_2
    //   38: ldc ''
    //   40: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   43: new java/lang/StringBuilder
    //   46: dup
    //   47: invokespecial <init> : ()V
    //   50: astore_3
    //   51: aload_1
    //   52: ldc ''
    //   54: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   57: aload_1
    //   58: invokevirtual getClass : ()Ljava/lang/Class;
    //   61: invokevirtual getName : ()Ljava/lang/String;
    //   64: astore #6
    //   66: aload #6
    //   68: ldc ''
    //   70: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
    //   73: aload_3
    //   74: aload #6
    //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: pop
    //   80: aload_3
    //   81: ldc ': '
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: aload_3
    //   88: aload_2
    //   89: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   92: pop
    //   93: aload_3
    //   94: invokevirtual toString : ()Ljava/lang/String;
    //   97: astore_2
    //   98: aload_1
    //   99: ldc ''
    //   101: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   104: aload_1
    //   105: ldc ''
    //   107: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   110: new java/lang/StringBuilder
    //   113: dup
    //   114: invokespecial <init> : ()V
    //   117: astore_3
    //   118: aload_3
    //   119: aload_1
    //   120: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   123: pop
    //   124: aload_3
    //   125: bipush #10
    //   127: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   130: pop
    //   131: aload_3
    //   132: aload_1
    //   133: invokestatic AFInAppEventParameterName : (Ljava/lang/Throwable;)Ljava/util/List;
    //   136: checkcast java/lang/Iterable
    //   139: ldc_w '\\n'
    //   142: checkcast java/lang/CharSequence
    //   145: aconst_null
    //   146: aconst_null
    //   147: iconst_0
    //   148: aconst_null
    //   149: getstatic com/appsflyer/internal/AFc1lSDK$3.values : Lcom/appsflyer/internal/AFc1lSDK$3;
    //   152: checkcast kotlin/jvm/functions/Function1
    //   155: bipush #30
    //   157: aconst_null
    //   158: invokestatic joinToString$default : (Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: new com/appsflyer/internal/AFc1sSDK
    //   168: dup
    //   169: aload_2
    //   170: aload_3
    //   171: invokevirtual toString : ()Ljava/lang/String;
    //   174: invokestatic values : (Ljava/lang/String;)Ljava/lang/String;
    //   177: aload_1
    //   178: invokestatic stackTraceToString : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   181: iconst_0
    //   182: bipush #8
    //   184: aconst_null
    //   185: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   188: astore_2
    //   189: aload_2
    //   190: getfield AFKeystoreWrapper : Ljava/lang/String;
    //   193: astore_3
    //   194: new java/io/File
    //   197: dup
    //   198: aload #5
    //   200: aload_3
    //   201: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   204: astore #6
    //   206: aload_2
    //   207: astore_1
    //   208: aload #6
    //   210: invokevirtual exists : ()Z
    //   213: ifeq -> 255
    //   216: getstatic com/appsflyer/internal/AFc1sSDK.AFa1zSDK : Lcom/appsflyer/internal/AFc1sSDK$AFa1zSDK;
    //   219: astore_1
    //   220: aload #6
    //   222: aconst_null
    //   223: iconst_1
    //   224: aconst_null
    //   225: invokestatic readText$default : (Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;
    //   228: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)Lcom/appsflyer/internal/AFc1sSDK;
    //   231: astore #5
    //   233: aload_2
    //   234: astore_1
    //   235: aload #5
    //   237: ifnull -> 255
    //   240: aload #5
    //   242: aload #5
    //   244: getfield AFInAppEventParameterName : I
    //   247: iconst_1
    //   248: iadd
    //   249: putfield AFInAppEventParameterName : I
    //   252: aload #5
    //   254: astore_1
    //   255: new java/lang/StringBuilder
    //   258: dup
    //   259: ldc_w 'label='
    //   262: invokespecial <init> : (Ljava/lang/String;)V
    //   265: astore_2
    //   266: aload_2
    //   267: aload_1
    //   268: getfield valueOf : Ljava/lang/String;
    //   271: invokestatic AFKeystoreWrapper : (Ljava/lang/String;)Ljava/lang/String;
    //   274: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   277: pop
    //   278: aload_2
    //   279: ldc_w '\\nhashName='
    //   282: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   285: pop
    //   286: aload_2
    //   287: aload_1
    //   288: getfield AFKeystoreWrapper : Ljava/lang/String;
    //   291: invokestatic AFKeystoreWrapper : (Ljava/lang/String;)Ljava/lang/String;
    //   294: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   297: pop
    //   298: aload_2
    //   299: ldc_w '\\nstackTrace='
    //   302: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   305: pop
    //   306: aload_2
    //   307: aload_1
    //   308: getfield AFInAppEventType : Ljava/lang/String;
    //   311: invokestatic AFKeystoreWrapper : (Ljava/lang/String;)Ljava/lang/String;
    //   314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: pop
    //   318: aload_2
    //   319: ldc_w '\\nc='
    //   322: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: pop
    //   326: aload_2
    //   327: aload_1
    //   328: getfield AFInAppEventParameterName : I
    //   331: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   334: pop
    //   335: aload #6
    //   337: aload_2
    //   338: invokevirtual toString : ()Ljava/lang/String;
    //   341: aconst_null
    //   342: iconst_2
    //   343: aconst_null
    //   344: invokestatic writeText$default : (Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V
    //   347: goto -> 423
    //   350: astore_2
    //   351: new java/lang/StringBuilder
    //   354: dup
    //   355: ldc_w 'Could not cache exception\\n'
    //   358: invokespecial <init> : (Ljava/lang/String;)V
    //   361: astore_1
    //   362: new java/lang/StringBuilder
    //   365: dup
    //   366: ldc_w ' '
    //   369: invokespecial <init> : (Ljava/lang/String;)V
    //   372: astore_3
    //   373: aload_3
    //   374: aload_2
    //   375: invokevirtual getMessage : ()Ljava/lang/String;
    //   378: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   381: pop
    //   382: aload_3
    //   383: invokevirtual toString : ()Ljava/lang/String;
    //   386: astore_2
    //   387: aload_2
    //   388: ldc ''
    //   390: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   393: aload_1
    //   394: ldc_w '[Exception Manager]: '
    //   397: aload_2
    //   398: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   401: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   404: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   407: pop
    //   408: aload_1
    //   409: invokevirtual toString : ()Ljava/lang/String;
    //   412: invokestatic afRDLog : (Ljava/lang/String;)V
    //   415: aconst_null
    //   416: checkcast java/lang/String
    //   419: astore_1
    //   420: aload #4
    //   422: astore_3
    //   423: aload_0
    //   424: monitorexit
    //   425: aload_3
    //   426: areturn
    //   427: astore_1
    //   428: aload_0
    //   429: monitorexit
    //   430: aload_1
    //   431: athrow
    // Exception table:
    //   from	to	target	type
    //   14	20	427	finally
    //   31	206	350	java/lang/Exception
    //   31	206	427	finally
    //   208	233	350	java/lang/Exception
    //   208	233	427	finally
    //   240	252	350	java/lang/Exception
    //   240	252	427	finally
    //   255	347	350	java/lang/Exception
    //   255	347	427	finally
    //   351	420	427	finally
  }
  
  public final boolean AFInAppEventParameterName() {
    return values(new String[0]);
  }
  
  public final int AFKeystoreWrapper() {
    Iterator<AFc1sSDK> iterator = valueOf().iterator();
    int i;
    for (i = 0; iterator.hasNext(); i += ((AFc1sSDK)iterator.next()).AFInAppEventParameterName);
    return i;
  }
  
  public final List<AFc1sSDK> valueOf() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial afRDLog : ()Ljava/io/File;
    //   6: astore #5
    //   8: aconst_null
    //   9: astore #4
    //   11: aload #4
    //   13: astore_3
    //   14: aload #5
    //   16: ifnull -> 175
    //   19: aload #5
    //   21: invokevirtual listFiles : ()[Ljava/io/File;
    //   24: astore #5
    //   26: aload #4
    //   28: astore_3
    //   29: aload #5
    //   31: ifnull -> 175
    //   34: aload #5
    //   36: ldc ''
    //   38: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
    //   41: new java/util/ArrayList
    //   44: dup
    //   45: invokespecial <init> : ()V
    //   48: checkcast java/util/Collection
    //   51: astore_3
    //   52: aload #5
    //   54: arraylength
    //   55: istore_2
    //   56: iconst_0
    //   57: istore_1
    //   58: iload_1
    //   59: iload_2
    //   60: if_icmpge -> 111
    //   63: aload #5
    //   65: iload_1
    //   66: aaload
    //   67: astore #6
    //   69: getstatic com/appsflyer/internal/AFc1sSDK.AFa1zSDK : Lcom/appsflyer/internal/AFc1sSDK$AFa1zSDK;
    //   72: astore #7
    //   74: aload #6
    //   76: ldc ''
    //   78: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
    //   81: aload #6
    //   83: aconst_null
    //   84: iconst_1
    //   85: aconst_null
    //   86: invokestatic readText$default : (Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;
    //   89: invokestatic AFInAppEventParameterName : (Ljava/lang/String;)Lcom/appsflyer/internal/AFc1sSDK;
    //   92: astore #6
    //   94: aload #6
    //   96: ifnull -> 197
    //   99: aload_3
    //   100: aload #6
    //   102: invokeinterface add : (Ljava/lang/Object;)Z
    //   107: pop
    //   108: goto -> 197
    //   111: aload_3
    //   112: checkcast java/util/List
    //   115: astore_3
    //   116: goto -> 175
    //   119: astore_3
    //   120: new java/lang/StringBuilder
    //   123: dup
    //   124: ldc_w 'Could not get stored exceptions\\n '
    //   127: invokespecial <init> : (Ljava/lang/String;)V
    //   130: astore #5
    //   132: aload #5
    //   134: aload_3
    //   135: invokevirtual getMessage : ()Ljava/lang/String;
    //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   141: pop
    //   142: aload #5
    //   144: invokevirtual toString : ()Ljava/lang/String;
    //   147: astore_3
    //   148: aload_3
    //   149: ldc ''
    //   151: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   154: ldc_w '[Exception Manager]: '
    //   157: aload_3
    //   158: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   161: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   164: invokestatic afRDLog : (Ljava/lang/String;)V
    //   167: aconst_null
    //   168: checkcast java/util/List
    //   171: astore_3
    //   172: aload #4
    //   174: astore_3
    //   175: aload_3
    //   176: astore #4
    //   178: aload_3
    //   179: ifnonnull -> 187
    //   182: invokestatic emptyList : ()Ljava/util/List;
    //   185: astore #4
    //   187: aload_0
    //   188: monitorexit
    //   189: aload #4
    //   191: areturn
    //   192: astore_3
    //   193: aload_0
    //   194: monitorexit
    //   195: aload_3
    //   196: athrow
    //   197: iload_1
    //   198: iconst_1
    //   199: iadd
    //   200: istore_1
    //   201: goto -> 58
    // Exception table:
    //   from	to	target	type
    //   2	8	192	finally
    //   19	26	119	finally
    //   34	56	119	finally
    //   69	94	119	finally
    //   99	108	119	finally
    //   111	116	119	finally
    //   120	172	192	finally
    //   182	187	192	finally
  }
  
  public final boolean values(String... paramVarArgs) {
    // Byte code:
    //   0: aload_1
    //   1: ldc ''
    //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_0
    //   7: monitorenter
    //   8: aload_0
    //   9: invokespecial values : ()Ljava/io/File;
    //   12: astore #6
    //   14: iconst_1
    //   15: istore #5
    //   17: iload #5
    //   19: istore #4
    //   21: aload #6
    //   23: ifnull -> 375
    //   26: aload_1
    //   27: arraylength
    //   28: ifne -> 385
    //   31: iconst_1
    //   32: istore_2
    //   33: goto -> 36
    //   36: iload_2
    //   37: ifeq -> 70
    //   40: ldc_w 'delete all exceptions'
    //   43: ldc ''
    //   45: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   48: ldc_w '[Exception Manager]: '
    //   51: ldc_w 'delete all exceptions'
    //   54: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   57: invokestatic afRDLog : (Ljava/lang/String;)V
    //   60: aload #6
    //   62: invokestatic deleteRecursively : (Ljava/io/File;)Z
    //   65: istore #4
    //   67: goto -> 375
    //   70: new java/lang/StringBuilder
    //   73: dup
    //   74: ldc_w 'delete all exceptions except for: '
    //   77: invokespecial <init> : (Ljava/lang/String;)V
    //   80: astore #7
    //   82: aload #7
    //   84: aload_1
    //   85: ldc_w ', '
    //   88: checkcast java/lang/CharSequence
    //   91: aconst_null
    //   92: aconst_null
    //   93: iconst_0
    //   94: aconst_null
    //   95: aconst_null
    //   96: bipush #62
    //   98: aconst_null
    //   99: invokestatic joinToString$default : ([Ljava/lang/Object;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: aload #7
    //   108: invokevirtual toString : ()Ljava/lang/String;
    //   111: astore #7
    //   113: aload #7
    //   115: ldc ''
    //   117: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   120: ldc_w '[Exception Manager]: '
    //   123: aload #7
    //   125: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   128: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   131: invokestatic afRDLog : (Ljava/lang/String;)V
    //   134: aload #6
    //   136: invokevirtual listFiles : ()[Ljava/io/File;
    //   139: astore #6
    //   141: iload #5
    //   143: istore #4
    //   145: aload #6
    //   147: ifnull -> 375
    //   150: aload #6
    //   152: ldc ''
    //   154: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
    //   157: new java/util/ArrayList
    //   160: dup
    //   161: invokespecial <init> : ()V
    //   164: checkcast java/util/Collection
    //   167: astore #7
    //   169: aload #6
    //   171: arraylength
    //   172: istore_3
    //   173: iconst_0
    //   174: istore_2
    //   175: iload_2
    //   176: iload_3
    //   177: if_icmpge -> 211
    //   180: aload #6
    //   182: iload_2
    //   183: aaload
    //   184: astore #8
    //   186: aload_1
    //   187: aload #8
    //   189: invokevirtual getName : ()Ljava/lang/String;
    //   192: invokestatic contains : ([Ljava/lang/Object;Ljava/lang/Object;)Z
    //   195: ifne -> 390
    //   198: aload #7
    //   200: aload #8
    //   202: invokeinterface add : (Ljava/lang/Object;)Z
    //   207: pop
    //   208: goto -> 390
    //   211: aload #7
    //   213: checkcast java/util/List
    //   216: checkcast java/lang/Iterable
    //   219: astore #6
    //   221: new java/util/ArrayList
    //   224: dup
    //   225: aload #6
    //   227: bipush #10
    //   229: invokestatic collectionSizeOrDefault : (Ljava/lang/Iterable;I)I
    //   232: invokespecial <init> : (I)V
    //   235: checkcast java/util/Collection
    //   238: astore_1
    //   239: aload #6
    //   241: invokeinterface iterator : ()Ljava/util/Iterator;
    //   246: astore #6
    //   248: aload #6
    //   250: invokeinterface hasNext : ()Z
    //   255: ifeq -> 295
    //   258: aload #6
    //   260: invokeinterface next : ()Ljava/lang/Object;
    //   265: checkcast java/io/File
    //   268: astore #7
    //   270: aload #7
    //   272: ldc ''
    //   274: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
    //   277: aload_1
    //   278: aload #7
    //   280: invokestatic deleteRecursively : (Ljava/io/File;)Z
    //   283: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   286: invokeinterface add : (Ljava/lang/Object;)Z
    //   291: pop
    //   292: goto -> 248
    //   295: aload_1
    //   296: checkcast java/util/List
    //   299: checkcast java/lang/Iterable
    //   302: invokestatic toSet : (Ljava/lang/Iterable;)Ljava/util/Set;
    //   305: checkcast java/util/Collection
    //   308: astore #6
    //   310: aload #6
    //   312: astore_1
    //   313: aload #6
    //   315: invokeinterface isEmpty : ()Z
    //   320: ifeq -> 330
    //   323: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   326: invokestatic setOf : (Ljava/lang/Object;)Ljava/util/Set;
    //   329: astore_1
    //   330: aload_1
    //   331: checkcast java/util/Set
    //   334: astore_1
    //   335: aload_1
    //   336: invokeinterface size : ()I
    //   341: iconst_1
    //   342: if_icmpne -> 372
    //   345: aload_1
    //   346: checkcast java/lang/Iterable
    //   349: invokestatic first : (Ljava/lang/Iterable;)Ljava/lang/Object;
    //   352: checkcast java/lang/Boolean
    //   355: invokevirtual booleanValue : ()Z
    //   358: istore #4
    //   360: iload #4
    //   362: ifeq -> 372
    //   365: iload #5
    //   367: istore #4
    //   369: goto -> 375
    //   372: iconst_0
    //   373: istore #4
    //   375: aload_0
    //   376: monitorexit
    //   377: iload #4
    //   379: ireturn
    //   380: astore_1
    //   381: aload_0
    //   382: monitorexit
    //   383: aload_1
    //   384: athrow
    //   385: iconst_0
    //   386: istore_2
    //   387: goto -> 36
    //   390: iload_2
    //   391: iconst_1
    //   392: iadd
    //   393: istore_2
    //   394: goto -> 175
    // Exception table:
    //   from	to	target	type
    //   8	14	380	finally
    //   26	31	380	finally
    //   40	67	380	finally
    //   70	141	380	finally
    //   150	173	380	finally
    //   186	208	380	finally
    //   211	248	380	finally
    //   248	292	380	finally
    //   295	310	380	finally
    //   313	330	380	finally
    //   330	360	380	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFa1bSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */