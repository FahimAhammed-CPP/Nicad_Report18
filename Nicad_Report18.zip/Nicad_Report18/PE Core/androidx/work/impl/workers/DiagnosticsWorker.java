package androidx.work.impl.workers;

import android.content.Context;
import android.database.Cursor;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import y.fi;
import y.g41;
import y.i10;
import y.ik;
import y.kh;
import y.oy0;
import y.p31;
import y.rp;
import y.z00;
import y.そ;
import y.獅;
import y.祖;
import y.茎;
import y.급;
import y.독;
import y.칙;

public class DiagnosticsWorker extends Worker {
  static {
    獅.苦("DiagnosticsWrkr");
  }
  
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public static String 硬(독 param독1, 독 param독2, 茎 param茎, ArrayList paramArrayList) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    if (Build.VERSION.SDK_INT >= 23) {
      str = "Job Id";
    } else {
      str = "Alarm Id";
    } 
    stringBuilder.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", new Object[] { str }));
    for (i10 i10 : paramArrayList) {
      ArrayList<String> arrayList1;
      rp rp = param茎.苦(i10.硬);
      if (rp != null) {
        Integer integer = Integer.valueOf(rp.堅);
      } else {
        rp = null;
      } 
      String str3 = i10.硬;
      param독1.getClass();
      fi fi = fi.熱("SELECT name FROM workname WHERE work_spec_id=?", 1);
      if (str3 == null) {
        fi.嬉(1);
      } else {
        fi.壊(str3, 1);
      } 
      kh kh = param독1.硬;
      kh.堅();
      Cursor cursor = p31.起(kh, fi, false);
      try {
        arrayList1 = new ArrayList(cursor.getCount());
        while (cursor.moveToNext())
          arrayList1.add(cursor.getString(0)); 
      } finally {}
      cursor.close();
      fi.寂();
      ArrayList arrayList = param독2.熱(i10.硬);
      String str2 = TextUtils.join(",", arrayList1);
      String str1 = TextUtils.join(",", arrayList);
      stringBuilder.append(String.format("\n%s\t %s\t %s\t %s\t %s\t %s\t", new Object[] { i10.硬, i10.熱, rp, i10.堅.name(), str2, str1 }));
    } 
    return stringBuilder.toString();
  }
  
  public final 祖 doWork() {
    獅 獅1;
    獅 獅2;
    WorkDatabase workDatabase = (z00.ニ(getApplicationContext())).寝;
    g41 g41 = workDatabase.興();
    독 독1 = workDatabase.臭();
    독 독2 = workDatabase.産();
    茎 茎 = workDatabase.痒();
    long l1 = System.currentTimeMillis();
    long l2 = TimeUnit.DAYS.toMillis(1L);
    g41.getClass();
    fi fi = fi.熱("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC", 1);
    fi.臭(1, l1 - l2);
    kh kh = (kh)g41.硬;
    kh.堅();
    Cursor cursor = p31.起(kh, fi, false);
    try {
      int m = oy0.泳(cursor, "required_network_type");
      int j = oy0.泳(cursor, "requires_charging");
      int i = oy0.泳(cursor, "requires_device_idle");
      int i4 = oy0.泳(cursor, "requires_battery_not_low");
      int i5 = oy0.泳(cursor, "requires_storage_not_low");
      int i6 = oy0.泳(cursor, "trigger_content_update_delay");
      int i7 = oy0.泳(cursor, "trigger_max_content_delay");
      int i8 = oy0.泳(cursor, "content_uri_triggers");
      int k = oy0.泳(cursor, "id");
      int i9 = oy0.泳(cursor, "state");
      int i1 = oy0.泳(cursor, "worker_class_name");
      int n = oy0.泳(cursor, "input_merger_class_name");
      int i2 = oy0.泳(cursor, "input");
      int i3 = oy0.泳(cursor, "output");
      try {
        int i16 = oy0.泳(cursor, "initial_delay");
        int i15 = oy0.泳(cursor, "interval_duration");
        int i20 = oy0.泳(cursor, "flex_duration");
        int i13 = oy0.泳(cursor, "run_attempt_count");
        int i10 = oy0.泳(cursor, "backoff_policy");
        int i11 = oy0.泳(cursor, "backoff_delay_duration");
        int i19 = oy0.泳(cursor, "period_start_time");
        int i12 = oy0.泳(cursor, "minimum_retention_duration");
        int i17 = oy0.泳(cursor, "schedule_requested_at");
        int i14 = oy0.泳(cursor, "run_in_foreground");
        int i18 = oy0.泳(cursor, "out_of_quota_policy");
        ArrayList<i10> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(k);
            String str2 = cursor.getString(i1);
            칙 칙 = new 칙();
            칙.硬 = ik.触(cursor.getInt(m));
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            칙.堅 = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            칙.熱 = bool;
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            칙.暑 = bool;
            if (cursor.getInt(i5) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            칙.冷 = bool;
            칙.寒 = cursor.getLong(i6);
            칙.美 = cursor.getLong(i7);
            칙.旨 = ik.冷(cursor.getBlob(i8));
            i10 i101 = new i10(str1, str2);
            i101.堅 = ik.あ(cursor.getInt(i9));
            i101.暑 = cursor.getString(n);
            i101.冷 = 급.硬(cursor.getBlob(i2));
            i101.寒 = 급.硬(cursor.getBlob(i3));
            i101.美 = cursor.getLong(i16);
            i101.旨 = cursor.getLong(i15);
            i101.不 = cursor.getLong(i20);
            i101.ぱ = cursor.getInt(i13);
            i101.苦 = ik.噛(cursor.getInt(i10));
            i101.嬉 = cursor.getLong(i11);
            i101.悲 = cursor.getLong(i19);
            i101.寂 = cursor.getLong(i12);
            i101.淋 = cursor.getLong(i17);
            if (cursor.getInt(i14) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            i101.怖 = bool;
            i101.恐 = ik.投(cursor.getInt(i18));
            i101.辛 = 칙;
            arrayList.add(i101);
            continue;
          } 
          cursor.close();
          fi.寂();
          ArrayList arrayList1 = g41.熱();
          ArrayList arrayList2 = g41.硬();
          if (!arrayList.isEmpty()) {
            獅.辛().ぱ(new Throwable[0]);
            獅2 = 獅.辛();
            硬(독1, 독2, 茎, arrayList);
            獅2.ぱ(new Throwable[0]);
          } 
          if (!arrayList1.isEmpty()) {
            獅.辛().ぱ(new Throwable[0]);
            獅2 = 獅.辛();
            硬(독1, 독2, 茎, arrayList1);
            獅2.ぱ(new Throwable[0]);
          } 
          if (!arrayList2.isEmpty()) {
            獅.辛().ぱ(new Throwable[0]);
            獅1 = 獅.辛();
            硬(독1, 독2, 茎, arrayList2);
            獅1.ぱ(new Throwable[0]);
          } 
          return (祖)new そ(급.堅);
        } 
      } finally {}
    } finally {}
    獅2.close();
    獅1.寂();
    throw 독1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */