package com.facebook.appevents.codeless;

import android.app.Activity;
import android.content.Context;
import android.hardware.SensorManager;
import com.facebook.FacebookSdk;
import com.facebook.internal.FetchedAppSettings;
import com.facebook.internal.FetchedAppSettingsManager;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000B\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\f\n\002\030\002\n\002\b\006\bÇ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\027\020\020\032\0020\0212\b\020\022\032\004\030\0010\004H\001¢\006\002\b\023J\b\020\024\032\0020\021H\007J\b\020\025\032\0020\021H\007J\r\020\026\032\0020\004H\001¢\006\002\b\027J\r\020\030\032\0020\bH\001¢\006\002\b\031J\r\020\032\032\0020\bH\001¢\006\002\b\033J\020\020\034\032\0020\0212\006\020\035\032\0020\036H\007J\020\020\037\032\0020\0212\006\020\035\032\0020\036H\007J\020\020 \032\0020\0212\006\020\035\032\0020\036H\007J\025\020!\032\0020\0212\006\020\"\032\0020\bH\001¢\006\002\b#R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000R\016\020\007\032\0020\bX\016¢\006\002\n\000R\016\020\t\032\0020\006X\004¢\006\002\n\000R\020\020\n\032\004\030\0010\013X\016¢\006\002\n\000R\020\020\f\032\004\030\0010\rX\016¢\006\002\n\000R\016\020\016\032\0020\017X\004¢\006\002\n\000¨\006$"}, d2 = {"Lcom/facebook/appevents/codeless/CodelessManager;", "", "()V", "deviceSessionID", "", "isAppIndexingEnabled", "Ljava/util/concurrent/atomic/AtomicBoolean;", "isCheckingSession", "", "isCodelessEnabled", "sensorManager", "Landroid/hardware/SensorManager;", "viewIndexer", "Lcom/facebook/appevents/codeless/ViewIndexer;", "viewIndexingTrigger", "Lcom/facebook/appevents/codeless/ViewIndexingTrigger;", "checkCodelessSession", "", "applicationId", "checkCodelessSession$facebook_core_release", "disable", "enable", "getCurrentDeviceSessionID", "getCurrentDeviceSessionID$facebook_core_release", "getIsAppIndexingEnabled", "getIsAppIndexingEnabled$facebook_core_release", "isDebugOnEmulator", "isDebugOnEmulator$facebook_core_release", "onActivityDestroyed", "activity", "Landroid/app/Activity;", "onActivityPaused", "onActivityResumed", "updateAppIndexing", "appIndexingEnabled", "updateAppIndexing$facebook_core_release", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class CodelessManager {
  public static final CodelessManager INSTANCE = new CodelessManager();
  
  private static String deviceSessionID;
  
  private static final AtomicBoolean isAppIndexingEnabled;
  
  private static volatile boolean isCheckingSession;
  
  private static final AtomicBoolean isCodelessEnabled;
  
  private static SensorManager sensorManager;
  
  private static ViewIndexer viewIndexer;
  
  private static final ViewIndexingTrigger viewIndexingTrigger = new ViewIndexingTrigger();
  
  static {
    isCodelessEnabled = new AtomicBoolean(true);
    isAppIndexingEnabled = new AtomicBoolean(false);
  }
  
  @JvmStatic
  public static final void checkCodelessSession$facebook_core_release(String paramString) {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return; 
    try {
      if (isCheckingSession)
        return; 
      return;
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, CodelessManager.class);
    } 
  }
  
  @JvmStatic
  public static final void disable() {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, CodelessManager.class);
    } 
  }
  
  @JvmStatic
  public static final void enable() {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, CodelessManager.class);
    } 
  }
  
  @JvmStatic
  public static final String getCurrentDeviceSessionID$facebook_core_release() {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return null; 
    try {
      if (deviceSessionID == null)
        deviceSessionID = UUID.randomUUID().toString(); 
      String str = deviceSessionID;
      if (str != null)
        return str; 
      throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, CodelessManager.class);
    } 
  }
  
  @JvmStatic
  public static final boolean getIsAppIndexingEnabled$facebook_core_release() {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return false; 
    try {
      return isAppIndexingEnabled.get();
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, CodelessManager.class);
    } 
  }
  
  @JvmStatic
  public static final boolean isDebugOnEmulator$facebook_core_release() {
    CrashShieldHandler.isObjectCrashing(CodelessManager.class);
    return false;
  }
  
  @JvmStatic
  public static final void onActivityDestroyed(Activity paramActivity) {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return; 
    try {
      return;
    } finally {
      paramActivity = null;
      CrashShieldHandler.handleThrowable((Throwable)paramActivity, CodelessManager.class);
    } 
  }
  
  @JvmStatic
  public static final void onActivityPaused(Activity paramActivity) {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return; 
    try {
      Intrinsics.checkNotNullParameter(paramActivity, "activity");
      if (!isCodelessEnabled.get())
        return; 
      CodelessMatcher.Companion.getInstance().remove(paramActivity);
      ViewIndexer viewIndexer = viewIndexer;
      if (viewIndexer != null)
        viewIndexer.unschedule(); 
      return;
    } finally {
      paramActivity = null;
      CrashShieldHandler.handleThrowable((Throwable)paramActivity, CodelessManager.class);
    } 
  }
  
  @JvmStatic
  public static final void onActivityResumed(Activity paramActivity) {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return; 
    try {
      Intrinsics.checkNotNullParameter(paramActivity, "activity");
      if (!isCodelessEnabled.get())
        return; 
      CodelessMatcher.Companion.getInstance().add(paramActivity);
      Context context = paramActivity.getApplicationContext();
      String str = FacebookSdk.getApplicationId();
      FetchedAppSettings fetchedAppSettings = FetchedAppSettingsManager.getAppSettingsWithoutQuery(str);
      return;
    } finally {
      paramActivity = null;
      CrashShieldHandler.handleThrowable((Throwable)paramActivity, CodelessManager.class);
    } 
  }
  
  @JvmStatic
  public static final void updateAppIndexing$facebook_core_release(boolean paramBoolean) {
    if (CrashShieldHandler.isObjectCrashing(CodelessManager.class))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, CodelessManager.class);
    } 
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class CodelessManager$checkCodelessSession$1 implements Runnable {
    CodelessManager$checkCodelessSession$1(String param1String) {}
    
    public final void run() {
      String str = "0";
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "onShake"}, k = 3, mv = {1, 5, 1})
  static final class CodelessManager$onActivityResumed$1 implements ViewIndexingTrigger.OnShakeListener {
    CodelessManager$onActivityResumed$1(FetchedAppSettings param1FetchedAppSettings, String param1String) {}
    
    public final void onShake() {
      boolean bool1;
      FetchedAppSettings fetchedAppSettings = this.$appSettings;
      boolean bool2 = true;
      if (fetchedAppSettings != null && fetchedAppSettings.getCodelessEventsEnabled()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (!FacebookSdk.getCodelessSetupEnabled())
        bool2 = false; 
      if (bool1 && bool2)
        CodelessManager.checkCodelessSession$facebook_core_release(this.$appId); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\codeless\CodelessManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */