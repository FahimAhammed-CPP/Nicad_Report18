package androidx.core.hardware.display;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.view.Display;
import java.util.WeakHashMap;

public final class DisplayManagerCompat {
  public static final String DISPLAY_CATEGORY_PRESENTATION = "android.hardware.display.category.PRESENTATION";
  
  private static final WeakHashMap<Context, DisplayManagerCompat> sInstances = new WeakHashMap<Context, DisplayManagerCompat>();
  
  private final Context mContext;
  
  private DisplayManagerCompat(Context paramContext) {
    this.mContext = paramContext;
  }
  
  public static DisplayManagerCompat getInstance(Context paramContext) {
    synchronized (sInstances) {
      DisplayManagerCompat displayManagerCompat2 = null.get(paramContext);
      DisplayManagerCompat displayManagerCompat1 = displayManagerCompat2;
      if (displayManagerCompat2 == null) {
        displayManagerCompat1 = new DisplayManagerCompat(paramContext);
        null.put(paramContext, displayManagerCompat1);
      } 
      return displayManagerCompat1;
    } 
  }
  
  public Display getDisplay(int paramInt) {
    return Api17Impl.getDisplay((DisplayManager)this.mContext.getSystemService("display"), paramInt);
  }
  
  public Display[] getDisplays() {
    return Api17Impl.getDisplays((DisplayManager)this.mContext.getSystemService("display"));
  }
  
  public Display[] getDisplays(String paramString) {
    return Api17Impl.getDisplays((DisplayManager)this.mContext.getSystemService("display"));
  }
  
  static class Api17Impl {
    static Display getDisplay(DisplayManager param1DisplayManager, int param1Int) {
      return param1DisplayManager.getDisplay(param1Int);
    }
    
    static Display[] getDisplays(DisplayManager param1DisplayManager) {
      return param1DisplayManager.getDisplays();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\core\hardware\display\DisplayManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */