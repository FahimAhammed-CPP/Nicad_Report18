package androidx.work.impl.model;

import java.util.List;

public interface SystemIdInfoDao {
  SystemIdInfo getSystemIdInfo(String paramString);
  
  List<String> getWorkSpecIds();
  
  void insertSystemIdInfo(SystemIdInfo paramSystemIdInfo);
  
  void removeSystemIdInfo(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\work\impl\model\SystemIdInfoDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */