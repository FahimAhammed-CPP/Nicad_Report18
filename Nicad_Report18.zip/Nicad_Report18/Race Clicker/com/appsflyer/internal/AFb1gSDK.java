package com.appsflyer.internal;

import android.app.Activity;
import android.content.Context;
import kotlin.Metadata;

@Metadata(d1 = {"\000&\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\003\n\002\020\000\bf\030\000 \0012\0020\r:\002\001\fJ\017\020\003\032\0020\002H&¢\006\004\b\003\020\004J\037\020\003\032\0020\t2\006\020\006\032\0020\0052\006\020\b\032\0020\007H&¢\006\004\b\003\020\nJ\027\020\003\032\0020\t2\006\020\006\032\0020\005H&¢\006\004\b\003\020\013"}, d2 = {"Lcom/appsflyer/internal/AFb1gSDK;", "AFa1ySDK", "", "AFKeystoreWrapper", "()Z", "Landroid/content/Context;", "p0", "Lcom/appsflyer/internal/AFb1gSDK$AFa1zSDK;", "p1", "", "(Landroid/content/Context;Lcom/appsflyer/internal/AFb1gSDK$AFa1zSDK;)V", "(Landroid/content/Context;)V", "AFa1zSDK", ""}, k = 1, mv = {1, 6, 0}, xi = 48)
public interface AFb1gSDK {
  public static final AFa1ySDK AFa1ySDK = AFa1ySDK.values;
  
  void AFKeystoreWrapper(Context paramContext);
  
  void AFKeystoreWrapper(Context paramContext, AFa1zSDK paramAFa1zSDK);
  
  boolean AFKeystoreWrapper();
  
  public static final class AFa1ySDK {
    private static long AFInAppEventType = 500L;
    
    static {
    
    }
    
    public static long AFInAppEventType() {
      return AFInAppEventType;
    }
  }
  
  public static interface AFa1zSDK {
    void AFInAppEventType(Activity param1Activity);
    
    void AFInAppEventType(Context param1Context);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFb1gSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */