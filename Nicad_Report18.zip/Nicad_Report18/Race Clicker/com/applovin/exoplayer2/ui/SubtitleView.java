package com.applovin.exoplayer2.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.CaptioningManager;
import android.widget.FrameLayout;
import com.applovin.exoplayer2.ab;
import com.applovin.exoplayer2.ac;
import com.applovin.exoplayer2.ak;
import com.applovin.exoplayer2.am;
import com.applovin.exoplayer2.an;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.h.ad;
import com.applovin.exoplayer2.j.h;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.m.o;
import com.applovin.exoplayer2.o;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class SubtitleView extends FrameLayout implements an.d {
  private List<com.applovin.exoplayer2.i.a> a = Collections.emptyList();
  
  private c b = c.a;
  
  private int c = 0;
  
  private float d = 0.0533F;
  
  private float e = 0.08F;
  
  private boolean f = true;
  
  private boolean g = true;
  
  private int h;
  
  private a i;
  
  private View j;
  
  public SubtitleView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public SubtitleView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    b b = new b(paramContext);
    this.i = (a)b;
    this.j = (View)b;
    addView((View)b);
    this.h = 1;
  }
  
  private com.applovin.exoplayer2.i.a a(com.applovin.exoplayer2.i.a parama) {
    com.applovin.exoplayer2.i.a.a a1 = parama.a();
    if (!this.f) {
      j.a(a1);
    } else if (!this.g) {
      j.b(a1);
    } 
    return a1.e();
  }
  
  private void a(int paramInt, float paramFloat) {
    this.c = paramInt;
    this.d = paramFloat;
    e();
  }
  
  private void e() {
    this.i.a(getCuesWithStylingPreferencesApplied(), this.b, this.d, this.c, this.e);
  }
  
  private List<com.applovin.exoplayer2.i.a> getCuesWithStylingPreferencesApplied() {
    if (this.f && this.g)
      return this.a; 
    ArrayList<com.applovin.exoplayer2.i.a> arrayList = new ArrayList(this.a.size());
    for (int i = 0; i < this.a.size(); i++)
      arrayList.add(a(this.a.get(i))); 
    return arrayList;
  }
  
  private float getUserCaptionFontScale() {
    int i = ai.a;
    float f2 = 1.0F;
    float f1 = f2;
    if (i >= 19) {
      if (isInEditMode())
        return 1.0F; 
      CaptioningManager captioningManager = (CaptioningManager)getContext().getSystemService("captioning");
      f1 = f2;
      if (captioningManager != null) {
        f1 = f2;
        if (captioningManager.isEnabled())
          f1 = captioningManager.getFontScale(); 
      } 
    } 
    return f1;
  }
  
  private c getUserCaptionStyle() {
    if (ai.a < 19 || isInEditMode())
      return c.a; 
    CaptioningManager captioningManager = (CaptioningManager)getContext().getSystemService("captioning");
    return (captioningManager != null && captioningManager.isEnabled()) ? c.a(captioningManager.getUserStyle()) : c.a;
  }
  
  private <T extends View & a> void setView(T paramT) {
    removeView(this.j);
    View view = this.j;
    if (view instanceof l)
      ((l)view).a(); 
    this.j = (View)paramT;
    this.i = (a)paramT;
    addView((View)paramT);
  }
  
  public void a(float paramFloat, boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void a(List<com.applovin.exoplayer2.i.a> paramList) {
    setCues(paramList);
  }
  
  public void c() {
    setFractionalTextSize(getUserCaptionFontScale() * 0.0533F);
  }
  
  public void d() {
    setStyle(getUserCaptionStyle());
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.viewOnTouch("com.applovin", (View)this, paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setApplyEmbeddedFontSizes(boolean paramBoolean) {
    this.g = paramBoolean;
    e();
  }
  
  public void setApplyEmbeddedStyles(boolean paramBoolean) {
    this.f = paramBoolean;
    e();
  }
  
  public void setBottomPaddingFraction(float paramFloat) {
    this.e = paramFloat;
    e();
  }
  
  public void setCues(List<com.applovin.exoplayer2.i.a> paramList) {
    if (paramList == null)
      paramList = Collections.emptyList(); 
    this.a = paramList;
    e();
  }
  
  public void setFractionalTextSize(float paramFloat) {
    a(paramFloat, false);
  }
  
  public void setStyle(c paramc) {
    this.b = paramc;
    e();
  }
  
  public void setViewType(int paramInt) {
    if (this.h == paramInt)
      return; 
    if (paramInt != 1) {
      if (paramInt == 2) {
        setView(new l(getContext()));
      } else {
        throw new IllegalArgumentException();
      } 
    } else {
      setView(new b(getContext()));
    } 
    this.h = paramInt;
  }
  
  static interface a {
    void a(List<com.applovin.exoplayer2.i.a> param1List, c param1c, float param1Float1, int param1Int, float param1Float2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer\\ui\SubtitleView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */