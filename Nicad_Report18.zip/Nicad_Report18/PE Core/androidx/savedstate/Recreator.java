package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.do;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import y.bm;
import y.dj;
import y.fj;
import y.hj;
import y.ix;
import y.p31;
import y.qx;
import y.rx;
import y.尻;
import y.心;
import y.肉;
import y.腰;

public final class Recreator implements 肉 {
  public final hj 淋;
  
  public Recreator(hj paramhj) {
    this.淋 = paramhj;
  }
  
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 == 尻.ON_CREATE) {
      param腰.痒().興((心)this);
      hj hj1 = this.淋;
      Bundle bundle = hj1.硬().硬("androidx.savedstate.Restarter");
      if (bundle == null)
        return; 
      ArrayList arrayList = bundle.getStringArrayList("classes_to_restore");
      if (arrayList != null) {
        Iterator<String> iterator = arrayList.iterator();
        while (iterator.hasNext()) {
          qx qx;
          String str = iterator.next();
          try {
            fj fj;
            Class<? extends dj> clazz = Class.forName(str, false, Recreator.class.getClassLoader()).asSubclass(dj.class);
            try {
              Constructor<? extends dj> constructor = clazz.getDeclaredConstructor(new Class[0]);
              constructor.setAccessible(true);
              try {
                dj dj = constructor.newInstance(new Object[0]);
                if (hj1 instanceof rx) {
                  qx = ((rx)hj1).悲();
                  fj = hj1.硬();
                  qx.getClass();
                  Iterator<?> iterator1 = (new HashSet(qx.硬.keySet())).iterator();
                  while (true) {
                    boolean bool = iterator1.hasNext();
                    HashMap hashMap = qx.硬;
                    if (bool) {
                      do.硬((ix)hashMap.get(iterator1.next()), fj, (p31)hj1.痒());
                      continue;
                    } 
                    if (!(new HashSet(hashMap.keySet())).isEmpty())
                      fj.暑(); 
                  } 
                } 
                throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner");
              } catch (Exception exception) {
                throw new RuntimeException(bm.恐("Failed to instantiate ", qx), exception);
              } 
            } catch (NoSuchMethodException noSuchMethodException) {
              StringBuilder stringBuilder = new StringBuilder("Class ");
              stringBuilder.append(fj.getSimpleName());
              stringBuilder.append(" must have default constructor in order to be automatically recreated");
              throw new IllegalStateException(stringBuilder.toString(), noSuchMethodException);
            } 
          } catch (ClassNotFoundException classNotFoundException) {
            throw new RuntimeException(bm.痛("Class ", qx, " wasn't found"), classNotFoundException);
          } 
        } 
        return;
      } 
      throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
    } 
    throw new AssertionError("Next event must be ON_CREATE");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\savedstate\Recreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */