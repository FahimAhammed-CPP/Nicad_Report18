package com.applovin.impl.adview;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;

public abstract class j extends View {
  protected float a = 1.0F;
  
  protected final Context b;
  
  protected j(Context paramContext) {
    super(paramContext);
    this.b = paramContext;
  }
  
  public static j a(a parama, Context paramContext) {
    return (j)(parama.equals(a.c) ? new r(paramContext) : (parama.equals(a.b) ? new s(paramContext) : (parama.equals(a.d) ? new t(paramContext) : new z(paramContext))));
  }
  
  public void a(int paramInt) {
    setViewScale(paramInt / 30.0F);
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams != null) {
      layoutParams.width = (int)getSize();
      layoutParams.height = (int)getSize();
    } 
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.viewOnTouch("com.applovin", this, paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  public float getSize() {
    return this.a * 30.0F;
  }
  
  public abstract a getStyle();
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setViewScale(float paramFloat) {
    this.a = paramFloat;
  }
  
  public enum a {
    a, b, c, d;
    
    private final int e;
    
    static {
      a a1 = new a("WHITE_ON_BLACK", 0, 0);
      a = a1;
      a a2 = new a("WHITE_ON_TRANSPARENT", 1, 1);
      b = a2;
      a a3 = new a("INVISIBLE", 2, 2);
      c = a3;
      a a4 = new a("TRANSPARENT_SKIP", 3, 3);
      d = a4;
      f = new a[] { a1, a2, a3, a4 };
    }
    
    a(int param1Int1) {
      this.e = param1Int1;
    }
    
    public int a() {
      return this.e;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\adview\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */