package com.facebook.share.internal;

import android.graphics.Bitmap;
import android.net.Uri;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.internal.Utility;
import com.facebook.internal.Validate;
import com.facebook.share.model.ShareCameraEffectContent;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareMedia;
import com.facebook.share.model.ShareMediaContent;
import com.facebook.share.model.ShareMessengerActionButton;
import com.facebook.share.model.ShareMessengerGenericTemplateContent;
import com.facebook.share.model.ShareMessengerMediaTemplateContent;
import com.facebook.share.model.ShareMessengerOpenGraphMusicTemplateContent;
import com.facebook.share.model.ShareMessengerURLActionButton;
import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.ShareOpenGraphObject;
import com.facebook.share.model.ShareOpenGraphValueContainer;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.model.ShareStoryContent;
import com.facebook.share.model.ShareVideo;
import com.facebook.share.model.ShareVideoContent;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class ShareContentValidation {
  private static Validator ApiValidator;
  
  private static Validator DefaultValidator;
  
  private static Validator StoryValidator;
  
  private static Validator WebShareValidator;
  
  private static Validator getApiValidator() {
    if (ApiValidator == null)
      ApiValidator = new ApiValidator(); 
    return ApiValidator;
  }
  
  private static Validator getDefaultValidator() {
    if (DefaultValidator == null)
      DefaultValidator = new Validator(); 
    return DefaultValidator;
  }
  
  private static Validator getStoryValidator() {
    if (StoryValidator == null)
      StoryValidator = new StoryShareValidator(); 
    return StoryValidator;
  }
  
  private static Validator getWebShareValidator() {
    if (WebShareValidator == null)
      WebShareValidator = new WebShareValidator(); 
    return WebShareValidator;
  }
  
  private static void validate(ShareContent paramShareContent, Validator paramValidator) throws FacebookException {
    if (paramShareContent != null) {
      if (paramShareContent instanceof ShareLinkContent) {
        paramValidator.validate((ShareLinkContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof SharePhotoContent) {
        paramValidator.validate((SharePhotoContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof ShareVideoContent) {
        paramValidator.validate((ShareVideoContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof ShareOpenGraphContent) {
        paramValidator.validate((ShareOpenGraphContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof ShareMediaContent) {
        paramValidator.validate((ShareMediaContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof ShareCameraEffectContent) {
        paramValidator.validate((ShareCameraEffectContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof ShareMessengerOpenGraphMusicTemplateContent) {
        paramValidator.validate((ShareMessengerOpenGraphMusicTemplateContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof ShareMessengerMediaTemplateContent) {
        paramValidator.validate((ShareMessengerMediaTemplateContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof ShareMessengerGenericTemplateContent) {
        paramValidator.validate((ShareMessengerGenericTemplateContent)paramShareContent);
        return;
      } 
      if (paramShareContent instanceof ShareStoryContent)
        paramValidator.validate((ShareStoryContent)paramShareContent); 
      return;
    } 
    throw new FacebookException("Must provide non-null content to share");
  }
  
  private static void validateCameraEffectContent(ShareCameraEffectContent paramShareCameraEffectContent, Validator paramValidator) {
    if (!Utility.isNullOrEmpty(paramShareCameraEffectContent.getEffectId()))
      return; 
    throw new FacebookException("Must specify a non-empty effectId");
  }
  
  public static void validateForApiShare(ShareContent paramShareContent) {
    validate(paramShareContent, getApiValidator());
  }
  
  public static void validateForMessage(ShareContent paramShareContent) {
    validate(paramShareContent, getDefaultValidator());
  }
  
  public static void validateForNativeShare(ShareContent paramShareContent) {
    validate(paramShareContent, getDefaultValidator());
  }
  
  public static void validateForStoryShare(ShareContent paramShareContent) {
    validate(paramShareContent, getStoryValidator());
  }
  
  public static void validateForWebShare(ShareContent paramShareContent) {
    validate(paramShareContent, getWebShareValidator());
  }
  
  private static void validateLinkContent(ShareLinkContent paramShareLinkContent, Validator paramValidator) {
    Uri uri = paramShareLinkContent.getImageUrl();
    if (uri != null) {
      if (Utility.isWebUri(uri))
        return; 
      throw new FacebookException("Image Url must be an http:// or https:// url");
    } 
  }
  
  private static void validateMediaContent(ShareMediaContent paramShareMediaContent, Validator paramValidator) {
    List list = paramShareMediaContent.getMedia();
    if (list != null && !list.isEmpty()) {
      if (list.size() <= 6) {
        Iterator<ShareMedia> iterator = list.iterator();
        while (iterator.hasNext())
          paramValidator.validate(iterator.next()); 
        return;
      } 
      throw new FacebookException(String.format(Locale.ROOT, "Cannot add more than %d media.", new Object[] { Integer.valueOf(6) }));
    } 
    throw new FacebookException("Must specify at least one medium in ShareMediaContent.");
  }
  
  public static void validateMedium(ShareMedia paramShareMedia, Validator paramValidator) {
    if (paramShareMedia instanceof SharePhoto) {
      paramValidator.validate((SharePhoto)paramShareMedia);
      return;
    } 
    if (paramShareMedia instanceof ShareVideo) {
      paramValidator.validate((ShareVideo)paramShareMedia);
      return;
    } 
    throw new FacebookException(String.format(Locale.ROOT, "Invalid media type: %s", new Object[] { paramShareMedia.getClass().getSimpleName() }));
  }
  
  private static void validateMessengerOpenGraphMusicTemplate(ShareMessengerOpenGraphMusicTemplateContent paramShareMessengerOpenGraphMusicTemplateContent) {
    if (!Utility.isNullOrEmpty(paramShareMessengerOpenGraphMusicTemplateContent.getPageId())) {
      if (paramShareMessengerOpenGraphMusicTemplateContent.getUrl() != null) {
        validateShareMessengerActionButton(paramShareMessengerOpenGraphMusicTemplateContent.getButton());
        return;
      } 
      throw new FacebookException("Must specify url for ShareMessengerOpenGraphMusicTemplateContent");
    } 
    throw new FacebookException("Must specify Page Id for ShareMessengerOpenGraphMusicTemplateContent");
  }
  
  private static void validateOpenGraphAction(ShareOpenGraphAction paramShareOpenGraphAction, Validator paramValidator) {
    if (paramShareOpenGraphAction != null) {
      if (!Utility.isNullOrEmpty(paramShareOpenGraphAction.getActionType())) {
        paramValidator.validate((ShareOpenGraphValueContainer)paramShareOpenGraphAction, false);
        return;
      } 
      throw new FacebookException("ShareOpenGraphAction must have a non-empty actionType");
    } 
    throw new FacebookException("Must specify a non-null ShareOpenGraphAction");
  }
  
  private static void validateOpenGraphContent(ShareOpenGraphContent paramShareOpenGraphContent, Validator paramValidator) {
    paramValidator.validate(paramShareOpenGraphContent.getAction());
    String str = paramShareOpenGraphContent.getPreviewPropertyName();
    if (!Utility.isNullOrEmpty(str)) {
      if (paramShareOpenGraphContent.getAction().get(str) != null)
        return; 
      StringBuilder stringBuilder = new StringBuilder("Property \"");
      stringBuilder.append(str);
      stringBuilder.append("\" was not found on the action. The name of the preview property must match the name of an action property.");
      throw new FacebookException(stringBuilder.toString());
    } 
    throw new FacebookException("Must specify a previewPropertyName.");
  }
  
  private static void validateOpenGraphKey(String paramString, boolean paramBoolean) {
    if (!paramBoolean)
      return; 
    String[] arrayOfString = paramString.split(":");
    if (arrayOfString.length >= 2) {
      int j = arrayOfString.length;
      int i = 0;
      while (i < j) {
        if (!arrayOfString[i].isEmpty()) {
          i++;
          continue;
        } 
        throw new FacebookException("Invalid key found in Open Graph dictionary: %s", new Object[] { paramString });
      } 
      return;
    } 
    throw new FacebookException("Open Graph keys must be namespaced: %s", new Object[] { paramString });
  }
  
  private static void validateOpenGraphObject(ShareOpenGraphObject paramShareOpenGraphObject, Validator paramValidator) {
    if (paramShareOpenGraphObject != null) {
      paramValidator.validate((ShareOpenGraphValueContainer)paramShareOpenGraphObject, true);
      return;
    } 
    throw new FacebookException("Cannot share a null ShareOpenGraphObject");
  }
  
  private static void validateOpenGraphValueContainer(ShareOpenGraphValueContainer paramShareOpenGraphValueContainer, Validator paramValidator, boolean paramBoolean) {
    for (String str : paramShareOpenGraphValueContainer.keySet()) {
      validateOpenGraphKey(str, paramBoolean);
      Object object = paramShareOpenGraphValueContainer.get(str);
      if (object instanceof List) {
        for (Object object1 : object) {
          if (object1 != null) {
            validateOpenGraphValueContainerObject(object1, paramValidator);
            continue;
          } 
          throw new FacebookException("Cannot put null objects in Lists in ShareOpenGraphObjects and ShareOpenGraphActions");
        } 
        continue;
      } 
      validateOpenGraphValueContainerObject(object, paramValidator);
    } 
  }
  
  private static void validateOpenGraphValueContainerObject(Object paramObject, Validator paramValidator) {
    if (paramObject instanceof ShareOpenGraphObject) {
      paramValidator.validate((ShareOpenGraphObject)paramObject);
      return;
    } 
    if (paramObject instanceof SharePhoto)
      paramValidator.validate((SharePhoto)paramObject); 
  }
  
  private static void validatePhoto(SharePhoto paramSharePhoto) {
    if (paramSharePhoto != null) {
      Bitmap bitmap = paramSharePhoto.getBitmap();
      Uri uri = paramSharePhoto.getImageUrl();
      if (bitmap == null) {
        if (uri != null)
          return; 
        throw new FacebookException("SharePhoto does not have a Bitmap or ImageUrl specified");
      } 
      return;
    } 
    throw new FacebookException("Cannot share a null SharePhoto");
  }
  
  private static void validatePhotoContent(SharePhotoContent paramSharePhotoContent, Validator paramValidator) {
    List list = paramSharePhotoContent.getPhotos();
    if (list != null && !list.isEmpty()) {
      if (list.size() <= 6) {
        Iterator<SharePhoto> iterator = list.iterator();
        while (iterator.hasNext())
          paramValidator.validate(iterator.next()); 
        return;
      } 
      throw new FacebookException(String.format(Locale.ROOT, "Cannot add more than %d photos.", new Object[] { Integer.valueOf(6) }));
    } 
    throw new FacebookException("Must specify at least one Photo in SharePhotoContent.");
  }
  
  private static void validatePhotoForApi(SharePhoto paramSharePhoto, Validator paramValidator) {
    validatePhoto(paramSharePhoto);
    Bitmap bitmap = paramSharePhoto.getBitmap();
    Uri uri = paramSharePhoto.getImageUrl();
    if (bitmap == null && Utility.isWebUri(uri)) {
      if (paramValidator.isOpenGraphContent())
        return; 
      throw new FacebookException("Cannot set the ImageUrl of a SharePhoto to the Uri of an image on the web when sharing SharePhotoContent");
    } 
  }
  
  private static void validatePhotoForNativeDialog(SharePhoto paramSharePhoto, Validator paramValidator) {
    validatePhotoForApi(paramSharePhoto, paramValidator);
    if (paramSharePhoto.getBitmap() != null || !Utility.isWebUri(paramSharePhoto.getImageUrl()))
      Validate.hasContentProvider(FacebookSdk.getApplicationContext()); 
  }
  
  private static void validatePhotoForWebDialog(SharePhoto paramSharePhoto, Validator paramValidator) {
    validatePhoto(paramSharePhoto);
  }
  
  private static void validateShareMessengerActionButton(ShareMessengerActionButton paramShareMessengerActionButton) {
    if (paramShareMessengerActionButton == null)
      return; 
    if (!Utility.isNullOrEmpty(paramShareMessengerActionButton.getTitle())) {
      if (paramShareMessengerActionButton instanceof ShareMessengerURLActionButton)
        validateShareMessengerURLActionButton((ShareMessengerURLActionButton)paramShareMessengerActionButton); 
      return;
    } 
    throw new FacebookException("Must specify title for ShareMessengerActionButton");
  }
  
  private static void validateShareMessengerGenericTemplateContent(ShareMessengerGenericTemplateContent paramShareMessengerGenericTemplateContent) {
    if (!Utility.isNullOrEmpty(paramShareMessengerGenericTemplateContent.getPageId())) {
      if (paramShareMessengerGenericTemplateContent.getGenericTemplateElement() != null) {
        if (!Utility.isNullOrEmpty(paramShareMessengerGenericTemplateContent.getGenericTemplateElement().getTitle())) {
          validateShareMessengerActionButton(paramShareMessengerGenericTemplateContent.getGenericTemplateElement().getButton());
          return;
        } 
        throw new FacebookException("Must specify title for ShareMessengerGenericTemplateElement");
      } 
      throw new FacebookException("Must specify element for ShareMessengerGenericTemplateContent");
    } 
    throw new FacebookException("Must specify Page Id for ShareMessengerGenericTemplateContent");
  }
  
  private static void validateShareMessengerMediaTemplateContent(ShareMessengerMediaTemplateContent paramShareMessengerMediaTemplateContent) {
    if (!Utility.isNullOrEmpty(paramShareMessengerMediaTemplateContent.getPageId())) {
      if (paramShareMessengerMediaTemplateContent.getMediaUrl() != null || !Utility.isNullOrEmpty(paramShareMessengerMediaTemplateContent.getAttachmentId())) {
        validateShareMessengerActionButton(paramShareMessengerMediaTemplateContent.getButton());
        return;
      } 
      throw new FacebookException("Must specify either attachmentId or mediaURL for ShareMessengerMediaTemplateContent");
    } 
    throw new FacebookException("Must specify Page Id for ShareMessengerMediaTemplateContent");
  }
  
  private static void validateShareMessengerURLActionButton(ShareMessengerURLActionButton paramShareMessengerURLActionButton) {
    if (paramShareMessengerURLActionButton.getUrl() != null)
      return; 
    throw new FacebookException("Must specify url for ShareMessengerURLActionButton");
  }
  
  private static void validateStoryContent(ShareStoryContent paramShareStoryContent, Validator paramValidator) {
    if (paramShareStoryContent != null && (paramShareStoryContent.getBackgroundAsset() != null || paramShareStoryContent.getStickerAsset() != null)) {
      if (paramShareStoryContent.getBackgroundAsset() != null)
        paramValidator.validate(paramShareStoryContent.getBackgroundAsset()); 
      if (paramShareStoryContent.getStickerAsset() != null)
        paramValidator.validate(paramShareStoryContent.getStickerAsset()); 
      return;
    } 
    throw new FacebookException("Must pass the Facebook app a background asset, a sticker asset, or both");
  }
  
  private static void validateVideo(ShareVideo paramShareVideo, Validator paramValidator) {
    if (paramShareVideo != null) {
      Uri uri = paramShareVideo.getLocalUrl();
      if (uri != null) {
        if (!Utility.isContentUri(uri)) {
          if (Utility.isFileUri(uri))
            return; 
          throw new FacebookException("ShareVideo must reference a video that is on the device");
        } 
        return;
      } 
      throw new FacebookException("ShareVideo does not have a LocalUrl specified");
    } 
    throw new FacebookException("Cannot share a null ShareVideo");
  }
  
  private static void validateVideoContent(ShareVideoContent paramShareVideoContent, Validator paramValidator) {
    paramValidator.validate(paramShareVideoContent.getVideo());
    SharePhoto sharePhoto = paramShareVideoContent.getPreviewPhoto();
    if (sharePhoto != null)
      paramValidator.validate(sharePhoto); 
  }
  
  private static class ApiValidator extends Validator {
    private ApiValidator() {}
    
    public void validate(ShareLinkContent param1ShareLinkContent) {
      if (Utility.isNullOrEmpty(param1ShareLinkContent.getQuote()))
        return; 
      throw new FacebookException("Cannot share link content with quote using the share api");
    }
    
    public void validate(ShareMediaContent param1ShareMediaContent) {
      throw new FacebookException("Cannot share ShareMediaContent using the share api");
    }
    
    public void validate(SharePhoto param1SharePhoto) {
      ShareContentValidation.validatePhotoForApi(param1SharePhoto, this);
    }
    
    public void validate(ShareVideoContent param1ShareVideoContent) {
      if (Utility.isNullOrEmpty(param1ShareVideoContent.getPlaceId())) {
        if (Utility.isNullOrEmpty(param1ShareVideoContent.getPeopleIds())) {
          if (Utility.isNullOrEmpty(param1ShareVideoContent.getRef()))
            return; 
          throw new FacebookException("Cannot share video content with referrer URL using the share api");
        } 
        throw new FacebookException("Cannot share video content with people IDs using the share api");
      } 
      throw new FacebookException("Cannot share video content with place IDs using the share api");
    }
  }
  
  private static class StoryShareValidator extends Validator {
    private StoryShareValidator() {}
    
    public void validate(ShareStoryContent param1ShareStoryContent) {
      ShareContentValidation.validateStoryContent(param1ShareStoryContent, this);
    }
  }
  
  private static class Validator {
    private boolean isOpenGraphContent = false;
    
    private Validator() {}
    
    public boolean isOpenGraphContent() {
      return this.isOpenGraphContent;
    }
    
    public void validate(ShareCameraEffectContent param1ShareCameraEffectContent) {
      ShareContentValidation.validateCameraEffectContent(param1ShareCameraEffectContent, this);
    }
    
    public void validate(ShareLinkContent param1ShareLinkContent) {
      ShareContentValidation.validateLinkContent(param1ShareLinkContent, this);
    }
    
    public void validate(ShareMedia param1ShareMedia) {
      ShareContentValidation.validateMedium(param1ShareMedia, this);
    }
    
    public void validate(ShareMediaContent param1ShareMediaContent) {
      ShareContentValidation.validateMediaContent(param1ShareMediaContent, this);
    }
    
    public void validate(ShareMessengerGenericTemplateContent param1ShareMessengerGenericTemplateContent) {
      ShareContentValidation.validateShareMessengerGenericTemplateContent(param1ShareMessengerGenericTemplateContent);
    }
    
    public void validate(ShareMessengerMediaTemplateContent param1ShareMessengerMediaTemplateContent) {
      ShareContentValidation.validateShareMessengerMediaTemplateContent(param1ShareMessengerMediaTemplateContent);
    }
    
    public void validate(ShareMessengerOpenGraphMusicTemplateContent param1ShareMessengerOpenGraphMusicTemplateContent) {
      ShareContentValidation.validateMessengerOpenGraphMusicTemplate(param1ShareMessengerOpenGraphMusicTemplateContent);
    }
    
    public void validate(ShareOpenGraphAction param1ShareOpenGraphAction) {
      ShareContentValidation.validateOpenGraphAction(param1ShareOpenGraphAction, this);
    }
    
    public void validate(ShareOpenGraphContent param1ShareOpenGraphContent) {
      this.isOpenGraphContent = true;
      ShareContentValidation.validateOpenGraphContent(param1ShareOpenGraphContent, this);
    }
    
    public void validate(ShareOpenGraphObject param1ShareOpenGraphObject) {
      ShareContentValidation.validateOpenGraphObject(param1ShareOpenGraphObject, this);
    }
    
    public void validate(ShareOpenGraphValueContainer param1ShareOpenGraphValueContainer, boolean param1Boolean) {
      ShareContentValidation.validateOpenGraphValueContainer(param1ShareOpenGraphValueContainer, this, param1Boolean);
    }
    
    public void validate(SharePhoto param1SharePhoto) {
      ShareContentValidation.validatePhotoForNativeDialog(param1SharePhoto, this);
    }
    
    public void validate(SharePhotoContent param1SharePhotoContent) {
      ShareContentValidation.validatePhotoContent(param1SharePhotoContent, this);
    }
    
    public void validate(ShareStoryContent param1ShareStoryContent) {
      ShareContentValidation.validateStoryContent(param1ShareStoryContent, this);
    }
    
    public void validate(ShareVideo param1ShareVideo) {
      ShareContentValidation.validateVideo(param1ShareVideo, this);
    }
    
    public void validate(ShareVideoContent param1ShareVideoContent) {
      ShareContentValidation.validateVideoContent(param1ShareVideoContent, this);
    }
  }
  
  private static class WebShareValidator extends Validator {
    private WebShareValidator() {}
    
    public void validate(ShareMediaContent param1ShareMediaContent) {
      throw new FacebookException("Cannot share ShareMediaContent via web sharing dialogs");
    }
    
    public void validate(SharePhoto param1SharePhoto) {
      ShareContentValidation.validatePhotoForWebDialog(param1SharePhoto, this);
    }
    
    public void validate(ShareVideoContent param1ShareVideoContent) {
      throw new FacebookException("Cannot share ShareVideoContent via web sharing dialogs");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\internal\ShareContentValidation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */