package com.facebook.share.widget;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.appevents.InternalAppEventsLogger;
import com.facebook.internal.AppCall;
import com.facebook.internal.CallbackManagerImpl;
import com.facebook.internal.DialogFeature;
import com.facebook.internal.DialogPresenter;
import com.facebook.internal.FacebookDialogBase;
import com.facebook.internal.FragmentWrapper;
import com.facebook.share.Sharer;
import com.facebook.share.internal.LegacyNativeDialogParameters;
import com.facebook.share.internal.MessageDialogFeature;
import com.facebook.share.internal.NativeDialogParameters;
import com.facebook.share.internal.ShareContentValidation;
import com.facebook.share.internal.ShareInternalUtility;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareMessengerGenericTemplateContent;
import com.facebook.share.model.ShareMessengerMediaTemplateContent;
import com.facebook.share.model.ShareMessengerOpenGraphMusicTemplateContent;
import java.util.ArrayList;
import java.util.List;

@Deprecated
public final class MessageDialog extends FacebookDialogBase<ShareContent, Sharer.Result> implements Sharer {
  private static final int DEFAULT_REQUEST_CODE = CallbackManagerImpl.RequestCodeOffset.Message.toRequestCode();
  
  private boolean shouldFailOnDataError = false;
  
  public MessageDialog(Activity paramActivity) {
    super(paramActivity, i);
    ShareInternalUtility.registerStaticShareCallback(i);
  }
  
  MessageDialog(Activity paramActivity, int paramInt) {
    super(paramActivity, paramInt);
    ShareInternalUtility.registerStaticShareCallback(paramInt);
  }
  
  public MessageDialog(Fragment paramFragment) {
    this(new FragmentWrapper(paramFragment));
  }
  
  MessageDialog(Fragment paramFragment, int paramInt) {
    this(new FragmentWrapper(paramFragment), paramInt);
  }
  
  public MessageDialog(Fragment paramFragment) {
    this(new FragmentWrapper(paramFragment));
  }
  
  MessageDialog(Fragment paramFragment, int paramInt) {
    this(new FragmentWrapper(paramFragment), paramInt);
  }
  
  private MessageDialog(FragmentWrapper paramFragmentWrapper) {
    super(paramFragmentWrapper, i);
    ShareInternalUtility.registerStaticShareCallback(i);
  }
  
  private MessageDialog(FragmentWrapper paramFragmentWrapper, int paramInt) {
    super(paramFragmentWrapper, paramInt);
    ShareInternalUtility.registerStaticShareCallback(paramInt);
  }
  
  public static boolean canShow(Class<? extends ShareContent> paramClass) {
    DialogFeature dialogFeature = getFeature(paramClass);
    return (dialogFeature != null && DialogPresenter.canPresentNativeDialogWithFeature(dialogFeature));
  }
  
  private static DialogFeature getFeature(Class<? extends ShareContent> paramClass) {
    return (DialogFeature)(ShareLinkContent.class.isAssignableFrom(paramClass) ? MessageDialogFeature.MESSAGE_DIALOG : (ShareMessengerGenericTemplateContent.class.isAssignableFrom(paramClass) ? MessageDialogFeature.MESSENGER_GENERIC_TEMPLATE : (ShareMessengerOpenGraphMusicTemplateContent.class.isAssignableFrom(paramClass) ? MessageDialogFeature.MESSENGER_OPEN_GRAPH_MUSIC_TEMPLATE : (ShareMessengerMediaTemplateContent.class.isAssignableFrom(paramClass) ? MessageDialogFeature.MESSENGER_MEDIA_TEMPLATE : null))));
  }
  
  private static void logDialogShare(Context paramContext, ShareContent paramShareContent, AppCall paramAppCall) {
    String str;
    DialogFeature dialogFeature = getFeature((Class)paramShareContent.getClass());
    if (dialogFeature == MessageDialogFeature.MESSAGE_DIALOG) {
      str = "status";
    } else if (str == MessageDialogFeature.MESSENGER_GENERIC_TEMPLATE) {
      str = "GenericTemplate";
    } else if (str == MessageDialogFeature.MESSENGER_MEDIA_TEMPLATE) {
      str = "MediaTemplate";
    } else if (str == MessageDialogFeature.MESSENGER_OPEN_GRAPH_MUSIC_TEMPLATE) {
      str = "OpenGraphMusicTemplate";
    } else {
      str = "unknown";
    } 
    InternalAppEventsLogger internalAppEventsLogger = new InternalAppEventsLogger(paramContext);
    Bundle bundle = new Bundle();
    bundle.putString("fb_share_dialog_content_type", str);
    bundle.putString("fb_share_dialog_content_uuid", paramAppCall.getCallId().toString());
    bundle.putString("fb_share_dialog_content_page_id", paramShareContent.getPageId());
    internalAppEventsLogger.logEventImplicitly("fb_messenger_share_dialog_show", bundle);
  }
  
  public static void show(Activity paramActivity, ShareContent paramShareContent) {
    (new MessageDialog(paramActivity)).show(paramShareContent);
  }
  
  public static void show(Fragment paramFragment, ShareContent paramShareContent) {
    show(new FragmentWrapper(paramFragment), paramShareContent);
  }
  
  public static void show(Fragment paramFragment, ShareContent paramShareContent) {
    show(new FragmentWrapper(paramFragment), paramShareContent);
  }
  
  private static void show(FragmentWrapper paramFragmentWrapper, ShareContent paramShareContent) {
    (new MessageDialog(paramFragmentWrapper)).show(paramShareContent);
  }
  
  protected AppCall createBaseAppCall() {
    return new AppCall(getRequestCode());
  }
  
  protected List<FacebookDialogBase<ShareContent, Sharer.Result>.ModeHandler> getOrderedModeHandlers() {
    ArrayList<NativeHandler> arrayList = new ArrayList();
    arrayList.add(new NativeHandler());
    return (List)arrayList;
  }
  
  public boolean getShouldFailOnDataError() {
    return this.shouldFailOnDataError;
  }
  
  protected void registerCallbackImpl(CallbackManagerImpl paramCallbackManagerImpl, FacebookCallback<Sharer.Result> paramFacebookCallback) {
    ShareInternalUtility.registerSharerCallback(getRequestCode(), (CallbackManager)paramCallbackManagerImpl, paramFacebookCallback);
  }
  
  public void setShouldFailOnDataError(boolean paramBoolean) {
    this.shouldFailOnDataError = paramBoolean;
  }
  
  private class NativeHandler extends FacebookDialogBase<ShareContent, Sharer.Result>.ModeHandler {
    private NativeHandler() {
      super(MessageDialog.this);
    }
    
    public boolean canShow(ShareContent param1ShareContent, boolean param1Boolean) {
      return (param1ShareContent != null && MessageDialog.canShow((Class)param1ShareContent.getClass()));
    }
    
    public AppCall createAppCall(final ShareContent content) {
      ShareContentValidation.validateForMessage(content);
      final AppCall appCall = MessageDialog.this.createBaseAppCall();
      final boolean shouldFailOnDataError = MessageDialog.this.getShouldFailOnDataError();
      MessageDialog.logDialogShare((Context)MessageDialog.this.getActivityContext(), content, appCall);
      DialogPresenter.setupAppCallForNativeDialog(appCall, new DialogPresenter.ParameterProvider() {
            public Bundle getLegacyParameters() {
              return LegacyNativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
            }
            
            public Bundle getParameters() {
              return NativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
            }
          }MessageDialog.getFeature((Class)content.getClass()));
      return appCall;
    }
  }
  
  class null implements DialogPresenter.ParameterProvider {
    public Bundle getLegacyParameters() {
      return LegacyNativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
    }
    
    public Bundle getParameters() {
      return NativeDialogParameters.create(appCall.getCallId(), content, shouldFailOnDataError);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\widget\MessageDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */