package com.appsflyer.internal;

import android.content.Context;
import android.content.pm.ProviderInfo;

public final class AFf1lSDK extends AFf1jSDK {
  final ProviderInfo AFInAppEventParameterName;
  
  private final AFc1vSDK afErrorLog;
  
  public AFf1lSDK(ProviderInfo paramProviderInfo, Runnable paramRunnable, AFc1vSDK paramAFc1vSDK) {
    super("af_referrer", paramProviderInfo.authority, paramRunnable);
    this.afErrorLog = paramAFc1vSDK;
    this.AFInAppEventParameterName = paramProviderInfo;
  }
  
  public final void values(Context paramContext) {
    Runnable runnable = new Runnable(this, paramContext) {
        public final void run() {
          // Byte code:
          //   0: aload_0
          //   1: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   4: astore_2
          //   5: aload_2
          //   6: invokestatic currentTimeMillis : ()J
          //   9: putfield AFLogger : J
          //   12: aload_2
          //   13: getstatic com/appsflyer/internal/AFf1jSDK$AFa1wSDK.valueOf : Lcom/appsflyer/internal/AFf1jSDK$AFa1wSDK;
          //   16: putfield AFKeystoreWrapper : Lcom/appsflyer/internal/AFf1jSDK$AFa1wSDK;
          //   19: aload_2
          //   20: new com/appsflyer/internal/AFf1jSDK$4
          //   23: dup
          //   24: aload_2
          //   25: invokespecial <init> : (Lcom/appsflyer/internal/AFf1jSDK;)V
          //   28: invokevirtual addObserver : (Ljava/util/Observer;)V
          //   31: new java/lang/StringBuilder
          //   34: dup
          //   35: ldc 'content://'
          //   37: invokespecial <init> : (Ljava/lang/String;)V
          //   40: astore_2
          //   41: aload_2
          //   42: aload_0
          //   43: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   46: getfield AFInAppEventParameterName : Landroid/content/pm/ProviderInfo;
          //   49: getfield authority : Ljava/lang/String;
          //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
          //   55: pop
          //   56: aload_2
          //   57: ldc '/transaction_id'
          //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
          //   62: pop
          //   63: aload_2
          //   64: invokevirtual toString : ()Ljava/lang/String;
          //   67: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
          //   70: astore_2
          //   71: aload_0
          //   72: getfield AFInAppEventType : Landroid/content/Context;
          //   75: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
          //   78: aload_2
          //   79: invokevirtual acquireUnstableContentProviderClient : (Landroid/net/Uri;)Landroid/content/ContentProviderClient;
          //   82: astore_3
          //   83: aload_3
          //   84: ifnull -> 224
          //   87: new java/lang/StringBuilder
          //   90: dup
          //   91: ldc 'app_id='
          //   93: invokespecial <init> : (Ljava/lang/String;)V
          //   96: astore #4
          //   98: aload #4
          //   100: aload_0
          //   101: getfield AFInAppEventType : Landroid/content/Context;
          //   104: invokevirtual getPackageName : ()Ljava/lang/String;
          //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
          //   110: pop
          //   111: aload_3
          //   112: aload_2
          //   113: aconst_null
          //   114: aload #4
          //   116: invokevirtual toString : ()Ljava/lang/String;
          //   119: aconst_null
          //   120: aconst_null
          //   121: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
          //   124: astore_2
          //   125: getstatic android/os/Build$VERSION.SDK_INT : I
          //   128: bipush #24
          //   130: if_icmplt -> 140
          //   133: aload_3
          //   134: invokevirtual close : ()V
          //   137: goto -> 226
          //   140: aload_3
          //   141: invokevirtual release : ()Z
          //   144: pop
          //   145: goto -> 226
          //   148: astore_2
          //   149: goto -> 202
          //   152: astore_2
          //   153: ldc '[Preinstall]: Failed to query unstable content providerClient'
          //   155: aload_2
          //   156: iconst_0
          //   157: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;Z)V
          //   160: getstatic android/os/Build$VERSION.SDK_INT : I
          //   163: bipush #24
          //   165: if_icmplt -> 194
          //   168: goto -> 187
          //   171: astore_2
          //   172: ldc '[Preinstall]: Failed to acquire unstable content providerClient'
          //   174: aload_2
          //   175: iconst_0
          //   176: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;Z)V
          //   179: getstatic android/os/Build$VERSION.SDK_INT : I
          //   182: bipush #24
          //   184: if_icmplt -> 194
          //   187: aload_3
          //   188: invokevirtual close : ()V
          //   191: goto -> 224
          //   194: aload_3
          //   195: invokevirtual release : ()Z
          //   198: pop
          //   199: goto -> 224
          //   202: getstatic android/os/Build$VERSION.SDK_INT : I
          //   205: bipush #24
          //   207: if_icmplt -> 217
          //   210: aload_3
          //   211: invokevirtual close : ()V
          //   214: goto -> 222
          //   217: aload_3
          //   218: invokevirtual release : ()Z
          //   221: pop
          //   222: aload_2
          //   223: athrow
          //   224: aconst_null
          //   225: astore_2
          //   226: aload_2
          //   227: ifnull -> 345
          //   230: aload_2
          //   231: ldc 'transaction_id'
          //   233: invokeinterface getColumnIndex : (Ljava/lang/String;)I
          //   238: istore_1
          //   239: iload_1
          //   240: iconst_m1
          //   241: if_icmpne -> 269
          //   244: ldc '[Preinstall]: Wrong column name'
          //   246: invokestatic afWarnLog : (Ljava/lang/String;)V
          //   249: aload_0
          //   250: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   253: getfield AFInAppEventType : Ljava/util/Map;
          //   256: ldc 'response'
          //   258: ldc 'FEATURE_NOT_SUPPORTED'
          //   260: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
          //   265: pop
          //   266: goto -> 336
          //   269: aload_0
          //   270: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   273: getfield AFInAppEventType : Ljava/util/Map;
          //   276: ldc 'response'
          //   278: ldc 'OK'
          //   280: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
          //   285: pop
          //   286: aload_2
          //   287: invokeinterface moveToFirst : ()Z
          //   292: ifeq -> 336
          //   295: aload_2
          //   296: iload_1
          //   297: invokeinterface getString : (I)Ljava/lang/String;
          //   302: astore_3
          //   303: aload_2
          //   304: invokeinterface close : ()V
          //   309: aload_3
          //   310: ifnull -> 336
          //   313: aload_3
          //   314: invokevirtual isEmpty : ()Z
          //   317: ifne -> 336
          //   320: aload_0
          //   321: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   324: getfield AFInAppEventType : Ljava/util/Map;
          //   327: ldc 'referrer'
          //   329: aload_3
          //   330: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
          //   335: pop
          //   336: aload_2
          //   337: invokeinterface close : ()V
          //   342: goto -> 367
          //   345: ldc '[Preinstall]: ContentProvider query failed, got null Cursor'
          //   347: invokestatic afWarnLog : (Ljava/lang/String;)V
          //   350: aload_0
          //   351: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   354: getfield AFInAppEventType : Ljava/util/Map;
          //   357: ldc 'response'
          //   359: ldc 'SERVICE_UNAVAILABLE'
          //   361: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
          //   366: pop
          //   367: aload_0
          //   368: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   371: getfield AFInAppEventType : Ljava/util/Map;
          //   374: ldc 'api_ver'
          //   376: aload_0
          //   377: getfield AFInAppEventType : Landroid/content/Context;
          //   380: aload_0
          //   381: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   384: getfield AFInAppEventParameterName : Landroid/content/pm/ProviderInfo;
          //   387: getfield packageName : Ljava/lang/String;
          //   390: invokestatic values : (Landroid/content/Context;Ljava/lang/String;)J
          //   393: invokestatic valueOf : (J)Ljava/lang/Long;
          //   396: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
          //   401: pop
          //   402: aload_0
          //   403: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   406: getfield AFInAppEventType : Ljava/util/Map;
          //   409: ldc 'api_ver_name'
          //   411: aload_0
          //   412: getfield AFInAppEventType : Landroid/content/Context;
          //   415: aload_0
          //   416: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   419: getfield AFInAppEventParameterName : Landroid/content/pm/ProviderInfo;
          //   422: getfield packageName : Ljava/lang/String;
          //   425: invokestatic AFInAppEventParameterName : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
          //   428: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
          //   433: pop
          //   434: aload_0
          //   435: getfield valueOf : Lcom/appsflyer/internal/AFf1lSDK;
          //   438: invokevirtual values : ()V
          //   441: return
          // Exception table:
          //   from	to	target	type
          //   87	125	171	android/os/DeadObjectException
          //   87	125	152	android/os/RemoteException
          //   87	125	148	finally
          //   153	160	148	finally
          //   172	179	148	finally
        }
      };
    this.afErrorLog.AFInAppEventType().execute(runnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFf1lSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */