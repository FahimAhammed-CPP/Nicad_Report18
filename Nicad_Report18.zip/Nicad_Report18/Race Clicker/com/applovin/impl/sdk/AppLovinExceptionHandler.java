package com.applovin.impl.sdk;

import android.os.Process;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.utils.CollectionUtils;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public class AppLovinExceptionHandler implements Thread.UncaughtExceptionHandler {
  private static final AppLovinExceptionHandler a = new AppLovinExceptionHandler();
  
  private final Set<o> b = new HashSet<o>(2);
  
  private final AtomicBoolean c = new AtomicBoolean();
  
  private Thread.UncaughtExceptionHandler d;
  
  public static AppLovinExceptionHandler shared() {
    return a;
  }
  
  public void addSdk(o paramo) {
    this.b.add(paramo);
  }
  
  public void enable() {
    if (this.c.compareAndSet(false, true)) {
      this.d = Thread.getDefaultUncaughtExceptionHandler();
      Thread.setDefaultUncaughtExceptionHandler(this);
    } 
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    Iterator<o> iterator = this.b.iterator();
    long l = 500L;
    while (iterator.hasNext()) {
      o o = iterator.next();
      if (!o.e()) {
        o.F();
        if (y.a())
          o.F().b("AppLovinExceptionHandler", "Detected unhandled exception"); 
        o.ag().a(s.a.c, CollectionUtils.map("top_main_method", paramThrowable.toString()));
        o.x().trackEventSynchronously("paused");
        l = ((Long)o.a(b.dR)).longValue();
      } 
    } 
    try {
      Thread.sleep(l);
    } catch (InterruptedException interruptedException) {}
    Thread.UncaughtExceptionHandler uncaughtExceptionHandler = this.d;
    if (uncaughtExceptionHandler != null) {
      uncaughtExceptionHandler.uncaughtException(paramThread, paramThrowable);
      return;
    } 
    Process.killProcess(Process.myPid());
    System.exit(1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\sdk\AppLovinExceptionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */