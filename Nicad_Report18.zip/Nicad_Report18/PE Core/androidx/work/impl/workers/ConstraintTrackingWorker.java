package androidx.work.impl.workers;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import java.util.ArrayList;
import java.util.List;
import y.iq;
import y.l00;
import y.qk;
import y.z00;
import y.姉;
import y.獅;
import y.정;

public class ConstraintTrackingWorker extends ListenableWorker implements l00 {
  public ListenableWorker 死;
  
  public final qk 産;
  
  public final WorkerParameters 臭;
  
  public volatile boolean 興;
  
  public final Object 起;
  
  static {
    獅.苦("ConstraintTrkngWrkr");
  }
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.臭 = paramWorkerParameters;
    this.起 = new Object();
    this.興 = false;
    this.産 = new qk();
  }
  
  public final iq getTaskExecutor() {
    return (z00.ニ(getApplicationContext())).噛;
  }
  
  public final boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.死;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public final void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.死;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.死.stop(); 
  }
  
  public final 姉 startWork() {
    getBackgroundExecutor().execute((Runnable)new 정(10, this));
    return (姉)this.産;
  }
  
  public final void 冷(List paramList) {}
  
  public final void 熱(ArrayList paramArrayList) {
    null = 獅.辛();
    String.format("Constraints changed for %s", new Object[] { paramArrayList });
    null.寒(new Throwable[0]);
    synchronized (this.起) {
      this.興 = true;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */