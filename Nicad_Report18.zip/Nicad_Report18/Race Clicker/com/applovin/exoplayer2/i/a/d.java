package com.applovin.exoplayer2.i.a;

import com.applovin.exoplayer2.i.a;
import com.applovin.exoplayer2.i.f;
import com.applovin.exoplayer2.l.a;
import java.util.Collections;
import java.util.List;

final class d implements f {
  private final List<a> a;
  
  public d(List<a> paramList) {
    this.a = paramList;
  }
  
  public int a(long paramLong) {
    return (paramLong < 0L) ? 0 : -1;
  }
  
  public long a(int paramInt) {
    boolean bool;
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    a.a(bool);
    return 0L;
  }
  
  public List<a> b(long paramLong) {
    return (paramLong >= 0L) ? this.a : Collections.emptyList();
  }
  
  public int f_() {
    return 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\i\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */