package com.facebook.share.model;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

@Deprecated
public final class ShareMessengerURLActionButton extends ShareMessengerActionButton {
  public static final Parcelable.Creator<ShareMessengerURLActionButton> CREATOR = new Parcelable.Creator<ShareMessengerURLActionButton>() {
      public ShareMessengerURLActionButton createFromParcel(Parcel param1Parcel) {
        return new ShareMessengerURLActionButton(param1Parcel);
      }
      
      public ShareMessengerURLActionButton[] newArray(int param1Int) {
        return new ShareMessengerURLActionButton[param1Int];
      }
    };
  
  private final Uri fallbackUrl;
  
  private final boolean isMessengerExtensionURL;
  
  private final boolean shouldHideWebviewShareButton;
  
  private final Uri url;
  
  private final WebviewHeightRatio webviewHeightRatio;
  
  ShareMessengerURLActionButton(Parcel paramParcel) {
    super(paramParcel);
    boolean bool1;
    this.url = (Uri)paramParcel.readParcelable(Uri.class.getClassLoader());
    byte b = paramParcel.readByte();
    boolean bool2 = true;
    if (b != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.isMessengerExtensionURL = bool1;
    this.fallbackUrl = (Uri)paramParcel.readParcelable(Uri.class.getClassLoader());
    this.webviewHeightRatio = (WebviewHeightRatio)paramParcel.readSerializable();
    if (paramParcel.readByte() != 0) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    this.shouldHideWebviewShareButton = bool1;
  }
  
  private ShareMessengerURLActionButton(Builder paramBuilder) {
    super(paramBuilder);
    this.url = paramBuilder.url;
    this.isMessengerExtensionURL = paramBuilder.isMessengerExtensionURL;
    this.fallbackUrl = paramBuilder.fallbackUrl;
    this.webviewHeightRatio = paramBuilder.webviewHeightRatio;
    this.shouldHideWebviewShareButton = paramBuilder.shouldHideWebviewShareButton;
  }
  
  public Uri getFallbackUrl() {
    return this.fallbackUrl;
  }
  
  public boolean getIsMessengerExtensionURL() {
    return this.isMessengerExtensionURL;
  }
  
  public boolean getShouldHideWebviewShareButton() {
    return this.shouldHideWebviewShareButton;
  }
  
  public Uri getUrl() {
    return this.url;
  }
  
  public WebviewHeightRatio getWebviewHeightRatio() {
    return this.webviewHeightRatio;
  }
  
  public static final class Builder extends ShareMessengerActionButton.Builder<ShareMessengerURLActionButton, Builder> {
    private Uri fallbackUrl;
    
    private boolean isMessengerExtensionURL;
    
    private boolean shouldHideWebviewShareButton;
    
    private Uri url;
    
    private ShareMessengerURLActionButton.WebviewHeightRatio webviewHeightRatio;
    
    public ShareMessengerURLActionButton build() {
      return new ShareMessengerURLActionButton(this);
    }
    
    public Builder readFrom(ShareMessengerURLActionButton param1ShareMessengerURLActionButton) {
      return (param1ShareMessengerURLActionButton == null) ? this : setUrl(param1ShareMessengerURLActionButton.getUrl()).setIsMessengerExtensionURL(param1ShareMessengerURLActionButton.getIsMessengerExtensionURL()).setFallbackUrl(param1ShareMessengerURLActionButton.getFallbackUrl()).setWebviewHeightRatio(param1ShareMessengerURLActionButton.getWebviewHeightRatio()).setShouldHideWebviewShareButton(param1ShareMessengerURLActionButton.getShouldHideWebviewShareButton());
    }
    
    public Builder setFallbackUrl(Uri param1Uri) {
      this.fallbackUrl = param1Uri;
      return this;
    }
    
    public Builder setIsMessengerExtensionURL(boolean param1Boolean) {
      this.isMessengerExtensionURL = param1Boolean;
      return this;
    }
    
    public Builder setShouldHideWebviewShareButton(boolean param1Boolean) {
      this.shouldHideWebviewShareButton = param1Boolean;
      return this;
    }
    
    public Builder setUrl(Uri param1Uri) {
      this.url = param1Uri;
      return this;
    }
    
    public Builder setWebviewHeightRatio(ShareMessengerURLActionButton.WebviewHeightRatio param1WebviewHeightRatio) {
      this.webviewHeightRatio = param1WebviewHeightRatio;
      return this;
    }
  }
  
  public enum WebviewHeightRatio {
    WebviewHeightRatioCompact, WebviewHeightRatioFull, WebviewHeightRatioTall;
    
    static {
      WebviewHeightRatio webviewHeightRatio1 = new WebviewHeightRatio("WebviewHeightRatioFull", 0);
      WebviewHeightRatioFull = webviewHeightRatio1;
      WebviewHeightRatio webviewHeightRatio2 = new WebviewHeightRatio("WebviewHeightRatioTall", 1);
      WebviewHeightRatioTall = webviewHeightRatio2;
      WebviewHeightRatio webviewHeightRatio3 = new WebviewHeightRatio("WebviewHeightRatioCompact", 2);
      WebviewHeightRatioCompact = webviewHeightRatio3;
      $VALUES = new WebviewHeightRatio[] { webviewHeightRatio1, webviewHeightRatio2, webviewHeightRatio3 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\model\ShareMessengerURLActionButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */