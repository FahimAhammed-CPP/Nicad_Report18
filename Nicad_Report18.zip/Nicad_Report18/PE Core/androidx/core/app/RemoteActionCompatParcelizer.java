package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import y.ov;
import y.pv;
import y.qv;

public class RemoteActionCompatParcelizer {
  public static RemoteActionCompat read(ov paramov) {
    qv qv;
    RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
    IconCompat iconCompat = remoteActionCompat.硬;
    boolean bool1 = true;
    if (paramov.冷(1))
      qv = paramov.旨(); 
    remoteActionCompat.硬 = (IconCompat)qv;
    CharSequence charSequence = remoteActionCompat.堅;
    if (paramov.冷(2)) {
      pv pv = (pv)paramov;
      charSequence = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(pv.冷);
    } 
    remoteActionCompat.堅 = charSequence;
    charSequence = remoteActionCompat.熱;
    if (paramov.冷(3)) {
      pv pv = (pv)paramov;
      charSequence = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(pv.冷);
    } 
    remoteActionCompat.熱 = charSequence;
    remoteActionCompat.暑 = (PendingIntent)paramov.美((Parcelable)remoteActionCompat.暑, 4);
    boolean bool = remoteActionCompat.冷;
    if (paramov.冷(5))
      if (((pv)paramov).冷.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      }  
    remoteActionCompat.冷 = bool;
    bool = remoteActionCompat.寒;
    if (paramov.冷(6))
      if (((pv)paramov).冷.readInt() != 0) {
        bool = bool1;
      } else {
        bool = false;
      }  
    remoteActionCompat.寒 = bool;
    return remoteActionCompat;
  }
  
  public static void write(RemoteActionCompat paramRemoteActionCompat, ov paramov) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\core\app\RemoteActionCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */