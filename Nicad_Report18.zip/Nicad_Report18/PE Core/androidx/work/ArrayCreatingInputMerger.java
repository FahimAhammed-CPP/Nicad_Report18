package androidx.work;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import y.z3;
import y.俺;
import y.급;

public final class ArrayCreatingInputMerger extends 俺 {
  public final 급 硬(ArrayList paramArrayList) {
    z3 z3 = new z3();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator iterator = paramArrayList.iterator();
    while (iterator.hasNext()) {
      for (Object object1 : Collections.unmodifiableMap(((급)iterator.next()).硬).entrySet()) {
        String str = (String)object1.getKey();
        object1 = object1.getValue();
        Object object2 = object1.getClass();
        Object object3 = hashMap.get(str);
        if (object3 == null) {
          if (!object2.isArray()) {
            object2 = Array.newInstance(object1.getClass(), 1);
            Array.set(object2, 0, object1);
            object1 = object2;
          } 
        } else {
          Class<?> clazz = object3.getClass();
          if (clazz.equals(object2)) {
            if (clazz.isArray()) {
              int i = Array.getLength(object3);
              int j = Array.getLength(object1);
              object2 = Array.newInstance(object3.getClass().getComponentType(), i + j);
              System.arraycopy(object3, 0, object2, 0, i);
              System.arraycopy(object1, 0, object2, i, j);
              object1 = object2;
            } else {
              object2 = Array.newInstance(object3.getClass(), 2);
              Array.set(object2, 0, object3);
              Array.set(object2, 1, object1);
              object1 = object2;
            } 
          } else if (clazz.isArray() && clazz.getComponentType().equals(object2)) {
            int i = Array.getLength(object3);
            object2 = Array.newInstance(object1.getClass(), i + 1);
            System.arraycopy(object3, 0, object2, 0, i);
            Array.set(object2, i, object1);
            object1 = object2;
          } else if (object2.isArray() && object2.getComponentType().equals(clazz)) {
            int i = Array.getLength(object1);
            object2 = Array.newInstance(object3.getClass(), i + 1);
            System.arraycopy(object1, 0, object2, 0, i);
            Array.set(object2, i, object3);
            object1 = object2;
          } else {
            throw new IllegalArgumentException();
          } 
        } 
        hashMap.put(str, object1);
      } 
    } 
    z3.硬(hashMap);
    급 급 = new 급(z3.硬);
    급.堅(급);
    return 급;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\ArrayCreatingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */