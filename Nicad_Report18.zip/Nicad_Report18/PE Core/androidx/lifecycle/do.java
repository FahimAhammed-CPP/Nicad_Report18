package androidx.lifecycle;

import y.fj;
import y.ix;
import y.p31;
import y.ぞ;
import y.心;
import y.背;

public abstract class do {
  public static void 堅(p31 paramp31, fj paramfj) {
    ぞ ぞ = ((背)paramp31).興;
    if (ぞ == ぞ.怖 || ぞ.硬(ぞ.痛)) {
      paramfj.暑();
      return;
    } 
    paramp31.硬((心)new LegacySavedStateHandleController$1(paramp31, paramfj));
  }
  
  public static void 硬(ix paramix, fj paramfj, p31 paramp31) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 硬 : Ljava/util/HashMap;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnonnull -> 14
    //   9: aconst_null
    //   10: astore_0
    //   11: goto -> 28
    //   14: aload_1
    //   15: monitorenter
    //   16: aload_0
    //   17: getfield 硬 : Ljava/util/HashMap;
    //   20: ldc 'androidx.lifecycle.savedstate.vm.tag'
    //   22: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   25: astore_0
    //   26: aload_1
    //   27: monitorexit
    //   28: aload_0
    //   29: checkcast androidx/lifecycle/SavedStateHandleController
    //   32: astore_0
    //   33: aload_0
    //   34: ifnull -> 77
    //   37: aload_0
    //   38: getfield 淋 : Z
    //   41: istore_3
    //   42: iload_3
    //   43: ifne -> 77
    //   46: iload_3
    //   47: ifne -> 67
    //   50: aload_0
    //   51: iconst_1
    //   52: putfield 淋 : Z
    //   55: aload_2
    //   56: aload_0
    //   57: invokevirtual 硬 : (Ly/心;)V
    //   60: aload_0
    //   61: invokevirtual getClass : ()Ljava/lang/Class;
    //   64: pop
    //   65: aconst_null
    //   66: athrow
    //   67: new java/lang/IllegalStateException
    //   70: dup
    //   71: ldc 'Already attached to lifecycleOwner'
    //   73: invokespecial <init> : (Ljava/lang/String;)V
    //   76: athrow
    //   77: return
    //   78: astore_0
    //   79: aload_1
    //   80: monitorexit
    //   81: aload_0
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   16	28	78	finally
    //   79	81	78	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */