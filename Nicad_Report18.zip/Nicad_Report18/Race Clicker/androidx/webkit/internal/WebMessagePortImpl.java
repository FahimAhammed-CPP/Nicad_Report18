package androidx.webkit.internal;

import android.os.Handler;
import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebMessagePortCompat;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.chromium.support_lib_boundary.WebMessagePortBoundaryInterface;
import org.chromium.support_lib_boundary.util.BoundaryInterfaceReflectionUtil;

public class WebMessagePortImpl extends WebMessagePortCompat {
  private WebMessagePortBoundaryInterface mBoundaryInterface;
  
  private WebMessagePort mFrameworksImpl;
  
  public WebMessagePortImpl(WebMessagePort paramWebMessagePort) {
    this.mFrameworksImpl = paramWebMessagePort;
  }
  
  public WebMessagePortImpl(InvocationHandler paramInvocationHandler) {
    this.mBoundaryInterface = (WebMessagePortBoundaryInterface)BoundaryInterfaceReflectionUtil.castToSuppLibClass(WebMessagePortBoundaryInterface.class, paramInvocationHandler);
  }
  
  public static WebMessage compatToFrameworkMessage(WebMessageCompat paramWebMessageCompat) {
    return ApiHelperForM.createWebMessage(paramWebMessageCompat);
  }
  
  public static WebMessagePort[] compatToPorts(WebMessagePortCompat[] paramArrayOfWebMessagePortCompat) {
    if (paramArrayOfWebMessagePortCompat == null)
      return null; 
    int j = paramArrayOfWebMessagePortCompat.length;
    WebMessagePort[] arrayOfWebMessagePort = new WebMessagePort[j];
    for (int i = 0; i < j; i++)
      arrayOfWebMessagePort[i] = paramArrayOfWebMessagePortCompat[i].getFrameworkPort(); 
    return arrayOfWebMessagePort;
  }
  
  public static WebMessageCompat frameworkMessageToCompat(WebMessage paramWebMessage) {
    return ApiHelperForM.createWebMessageCompat(paramWebMessage);
  }
  
  private WebMessagePortBoundaryInterface getBoundaryInterface() {
    if (this.mBoundaryInterface == null)
      this.mBoundaryInterface = (WebMessagePortBoundaryInterface)BoundaryInterfaceReflectionUtil.castToSuppLibClass(WebMessagePortBoundaryInterface.class, WebViewGlueCommunicator.getCompatConverter().convertWebMessagePort(this.mFrameworksImpl)); 
    return this.mBoundaryInterface;
  }
  
  private WebMessagePort getFrameworksImpl() {
    if (this.mFrameworksImpl == null)
      this.mFrameworksImpl = WebViewGlueCommunicator.getCompatConverter().convertWebMessagePort(Proxy.getInvocationHandler(this.mBoundaryInterface)); 
    return this.mFrameworksImpl;
  }
  
  public static WebMessagePortCompat[] portsToCompat(WebMessagePort[] paramArrayOfWebMessagePort) {
    if (paramArrayOfWebMessagePort == null)
      return null; 
    WebMessagePortCompat[] arrayOfWebMessagePortCompat = new WebMessagePortCompat[paramArrayOfWebMessagePort.length];
    for (int i = 0; i < paramArrayOfWebMessagePort.length; i++)
      arrayOfWebMessagePortCompat[i] = new WebMessagePortImpl(paramArrayOfWebMessagePort[i]); 
    return arrayOfWebMessagePortCompat;
  }
  
  public void close() {
    ApiFeature.M m = WebViewFeatureInternal.WEB_MESSAGE_PORT_CLOSE;
    if (m.isSupportedByFramework()) {
      ApiHelperForM.close(getFrameworksImpl());
      return;
    } 
    if (m.isSupportedByWebView()) {
      getBoundaryInterface().close();
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public WebMessagePort getFrameworkPort() {
    return getFrameworksImpl();
  }
  
  public InvocationHandler getInvocationHandler() {
    return Proxy.getInvocationHandler(getBoundaryInterface());
  }
  
  public void postMessage(WebMessageCompat paramWebMessageCompat) {
    ApiFeature.M m = WebViewFeatureInternal.WEB_MESSAGE_PORT_POST_MESSAGE;
    if (m.isSupportedByFramework() && paramWebMessageCompat.getType() == 0) {
      ApiHelperForM.postMessage(getFrameworksImpl(), compatToFrameworkMessage(paramWebMessageCompat));
      return;
    } 
    if (m.isSupportedByWebView() && WebMessageAdapter.isMessagePayloadTypeSupportedByWebView(paramWebMessageCompat.getType())) {
      getBoundaryInterface().postMessage(BoundaryInterfaceReflectionUtil.createInvocationHandlerFor(new WebMessageAdapter(paramWebMessageCompat)));
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public void setWebMessageCallback(Handler paramHandler, WebMessagePortCompat.WebMessageCallbackCompat paramWebMessageCallbackCompat) {
    ApiFeature.M m = WebViewFeatureInternal.CREATE_WEB_MESSAGE_CHANNEL;
    if (m.isSupportedByWebView()) {
      getBoundaryInterface().setWebMessageCallback(BoundaryInterfaceReflectionUtil.createInvocationHandlerFor(new WebMessageCallbackAdapter(paramWebMessageCallbackCompat)), paramHandler);
      return;
    } 
    if (m.isSupportedByFramework()) {
      ApiHelperForM.setWebMessageCallback(getFrameworksImpl(), paramWebMessageCallbackCompat, paramHandler);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
  
  public void setWebMessageCallback(WebMessagePortCompat.WebMessageCallbackCompat paramWebMessageCallbackCompat) {
    ApiFeature.M m = WebViewFeatureInternal.WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK;
    if (m.isSupportedByWebView()) {
      getBoundaryInterface().setWebMessageCallback(BoundaryInterfaceReflectionUtil.createInvocationHandlerFor(new WebMessageCallbackAdapter(paramWebMessageCallbackCompat)));
      return;
    } 
    if (m.isSupportedByFramework()) {
      ApiHelperForM.setWebMessageCallback(getFrameworksImpl(), paramWebMessageCallbackCompat);
      return;
    } 
    throw WebViewFeatureInternal.getUnsupportedOperationException();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\webkit\internal\WebMessagePortImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */