package com.applovin.impl.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.view.ViewGroup;
import androidx.lifecycle.Lifecycle;
import com.applovin.impl.mediation.MaxErrorImpl;
import com.applovin.impl.mediation.d;
import com.applovin.impl.mediation.i;
import com.applovin.impl.sdk.ad.g;
import com.applovin.impl.sdk.b;
import com.applovin.impl.sdk.f;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.i;
import com.applovin.impl.sdk.utils.o;
import com.applovin.impl.sdk.utils.w;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.sdk.AppLovinSdkUtils;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;

public class MaxFullscreenAdImpl extends a implements b.a, f.a {
  private final a a;
  
  private final com.applovin.impl.mediation.b b;
  
  private final Object c = new Object();
  
  private com.applovin.impl.mediation.a.c d = null;
  
  private c e = c.a;
  
  private final AtomicBoolean f = new AtomicBoolean();
  
  private boolean g;
  
  private boolean h;
  
  private WeakReference<Activity> i = new WeakReference<Activity>(null);
  
  private WeakReference<ViewGroup> j = new WeakReference<ViewGroup>(null);
  
  private WeakReference<Lifecycle> k = new WeakReference<Lifecycle>(null);
  
  protected final b listenerWrapper;
  
  public MaxFullscreenAdImpl(String paramString1, MaxAdFormat paramMaxAdFormat, a parama, String paramString2, o paramo) {
    super(paramString1, paramMaxAdFormat, paramString2, paramo);
    this.a = parama;
    b b1 = new b();
    this.listenerWrapper = b1;
    this.b = new com.applovin.impl.mediation.b(paramo, b1);
    paramo.aj().a(this);
    StringBuilder stringBuilder = new StringBuilder("Created new ");
    stringBuilder.append(paramString2);
    stringBuilder.append(" (");
    stringBuilder.append(this);
    stringBuilder.append(")");
    y.f(paramString2, stringBuilder.toString());
  }
  
  private void a() {
    Activity activity = this.i.get();
    if (activity == null)
      activity = this.sdk.at(); 
    if (this.g) {
      showAd(this.d.getPlacement(), this.d.aq(), this.j.get(), this.k.get(), activity);
      return;
    } 
    showAd(this.d.getPlacement(), this.d.aq(), activity);
  }
  
  private void a(com.applovin.impl.mediation.a.c paramc) {
    if (this.sdk.R().a((g)paramc, this)) {
      y y1 = this.logger;
      if (y.a()) {
        y1 = this.logger;
        String str = this.tag;
        StringBuilder stringBuilder = new StringBuilder("Handle ad loaded for regular ad: ");
        stringBuilder.append(paramc);
        y1.b(str, stringBuilder.toString());
      } 
      this.d = paramc;
      return;
    } 
    y y = this.logger;
    if (y.a())
      this.logger.b(this.tag, "Loaded an expired ad, running expire logic..."); 
    onAdExpired((g)paramc);
  }
  
  private void a(c paramc, Runnable paramRunnable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   4: astore #5
    //   6: aload_0
    //   7: getfield c : Ljava/lang/Object;
    //   10: astore #4
    //   12: aload #4
    //   14: monitorenter
    //   15: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   18: astore #6
    //   20: iconst_1
    //   21: istore_3
    //   22: aload #5
    //   24: aload #6
    //   26: if_acmpne -> 125
    //   29: aload_1
    //   30: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   33: if_acmpne -> 39
    //   36: goto -> 645
    //   39: aload_1
    //   40: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   43: if_acmpne -> 49
    //   46: goto -> 645
    //   49: aload_1
    //   50: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   53: if_acmpne -> 68
    //   56: aload_0
    //   57: getfield tag : Ljava/lang/String;
    //   60: ldc 'No ad is loading or loaded'
    //   62: invokestatic j : (Ljava/lang/String;Ljava/lang/String;)V
    //   65: goto -> 834
    //   68: aload_0
    //   69: getfield logger : Lcom/applovin/impl/sdk/y;
    //   72: astore #5
    //   74: invokestatic a : ()Z
    //   77: ifeq -> 834
    //   80: aload_0
    //   81: getfield logger : Lcom/applovin/impl/sdk/y;
    //   84: astore #5
    //   86: aload_0
    //   87: getfield tag : Ljava/lang/String;
    //   90: astore #6
    //   92: new java/lang/StringBuilder
    //   95: dup
    //   96: ldc 'Unable to transition to: '
    //   98: invokespecial <init> : (Ljava/lang/String;)V
    //   101: astore #7
    //   103: aload #7
    //   105: aload_1
    //   106: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload #5
    //   112: aload #6
    //   114: aload #7
    //   116: invokevirtual toString : ()Ljava/lang/String;
    //   119: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   122: goto -> 834
    //   125: aload #5
    //   127: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   130: if_acmpne -> 258
    //   133: aload_1
    //   134: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   137: if_acmpne -> 143
    //   140: goto -> 645
    //   143: aload_1
    //   144: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   147: if_acmpne -> 162
    //   150: aload_0
    //   151: getfield tag : Ljava/lang/String;
    //   154: ldc 'An ad is already loading'
    //   156: invokestatic j : (Ljava/lang/String;Ljava/lang/String;)V
    //   159: goto -> 834
    //   162: aload_1
    //   163: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   166: if_acmpne -> 172
    //   169: goto -> 645
    //   172: aload_1
    //   173: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   176: if_acmpne -> 191
    //   179: aload_0
    //   180: getfield tag : Ljava/lang/String;
    //   183: ldc 'An ad is not ready to be shown yet'
    //   185: invokestatic j : (Ljava/lang/String;Ljava/lang/String;)V
    //   188: goto -> 834
    //   191: aload_1
    //   192: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   195: if_acmpne -> 201
    //   198: goto -> 645
    //   201: aload_0
    //   202: getfield logger : Lcom/applovin/impl/sdk/y;
    //   205: astore #5
    //   207: invokestatic a : ()Z
    //   210: ifeq -> 834
    //   213: aload_0
    //   214: getfield logger : Lcom/applovin/impl/sdk/y;
    //   217: astore #5
    //   219: aload_0
    //   220: getfield tag : Ljava/lang/String;
    //   223: astore #6
    //   225: new java/lang/StringBuilder
    //   228: dup
    //   229: ldc 'Unable to transition to: '
    //   231: invokespecial <init> : (Ljava/lang/String;)V
    //   234: astore #7
    //   236: aload #7
    //   238: aload_1
    //   239: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: aload #5
    //   245: aload #6
    //   247: aload #7
    //   249: invokevirtual toString : ()Ljava/lang/String;
    //   252: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   255: goto -> 834
    //   258: aload #5
    //   260: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   263: if_acmpne -> 407
    //   266: aload_1
    //   267: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   270: if_acmpne -> 276
    //   273: goto -> 645
    //   276: aload_1
    //   277: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   280: if_acmpne -> 295
    //   283: aload_0
    //   284: getfield tag : Ljava/lang/String;
    //   287: ldc 'An ad is already loaded'
    //   289: invokestatic j : (Ljava/lang/String;Ljava/lang/String;)V
    //   292: goto -> 834
    //   295: aload_1
    //   296: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   299: if_acmpne -> 330
    //   302: aload_0
    //   303: getfield logger : Lcom/applovin/impl/sdk/y;
    //   306: astore #5
    //   308: invokestatic a : ()Z
    //   311: ifeq -> 834
    //   314: aload_0
    //   315: getfield logger : Lcom/applovin/impl/sdk/y;
    //   318: aload_0
    //   319: getfield tag : Ljava/lang/String;
    //   322: ldc 'An ad is already marked as ready'
    //   324: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   327: goto -> 834
    //   330: aload_1
    //   331: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   334: if_acmpne -> 340
    //   337: goto -> 645
    //   340: aload_1
    //   341: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   344: if_acmpne -> 350
    //   347: goto -> 645
    //   350: aload_0
    //   351: getfield logger : Lcom/applovin/impl/sdk/y;
    //   354: astore #5
    //   356: invokestatic a : ()Z
    //   359: ifeq -> 834
    //   362: aload_0
    //   363: getfield logger : Lcom/applovin/impl/sdk/y;
    //   366: astore #5
    //   368: aload_0
    //   369: getfield tag : Ljava/lang/String;
    //   372: astore #6
    //   374: new java/lang/StringBuilder
    //   377: dup
    //   378: ldc 'Unable to transition to: '
    //   380: invokespecial <init> : (Ljava/lang/String;)V
    //   383: astore #7
    //   385: aload #7
    //   387: aload_1
    //   388: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   391: pop
    //   392: aload #5
    //   394: aload #6
    //   396: aload #7
    //   398: invokevirtual toString : ()Ljava/lang/String;
    //   401: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   404: goto -> 834
    //   407: aload #5
    //   409: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   412: if_acmpne -> 565
    //   415: aload_1
    //   416: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   419: if_acmpne -> 425
    //   422: goto -> 645
    //   425: aload_1
    //   426: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   429: if_acmpne -> 444
    //   432: aload_0
    //   433: getfield tag : Ljava/lang/String;
    //   436: ldc 'Can not load another ad while the ad is showing'
    //   438: invokestatic j : (Ljava/lang/String;Ljava/lang/String;)V
    //   441: goto -> 834
    //   444: aload_1
    //   445: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   448: if_acmpne -> 479
    //   451: aload_0
    //   452: getfield logger : Lcom/applovin/impl/sdk/y;
    //   455: astore #5
    //   457: invokestatic a : ()Z
    //   460: ifeq -> 834
    //   463: aload_0
    //   464: getfield logger : Lcom/applovin/impl/sdk/y;
    //   467: aload_0
    //   468: getfield tag : Ljava/lang/String;
    //   471: ldc 'An ad is already showing, ignoring'
    //   473: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   476: goto -> 834
    //   479: aload_1
    //   480: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   483: if_acmpne -> 498
    //   486: aload_0
    //   487: getfield tag : Ljava/lang/String;
    //   490: ldc 'The ad is already showing, not showing another one'
    //   492: invokestatic j : (Ljava/lang/String;Ljava/lang/String;)V
    //   495: goto -> 834
    //   498: aload_1
    //   499: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   502: if_acmpne -> 508
    //   505: goto -> 645
    //   508: aload_0
    //   509: getfield logger : Lcom/applovin/impl/sdk/y;
    //   512: astore #5
    //   514: invokestatic a : ()Z
    //   517: ifeq -> 834
    //   520: aload_0
    //   521: getfield logger : Lcom/applovin/impl/sdk/y;
    //   524: astore #5
    //   526: aload_0
    //   527: getfield tag : Ljava/lang/String;
    //   530: astore #6
    //   532: new java/lang/StringBuilder
    //   535: dup
    //   536: ldc 'Unable to transition to: '
    //   538: invokespecial <init> : (Ljava/lang/String;)V
    //   541: astore #7
    //   543: aload #7
    //   545: aload_1
    //   546: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   549: pop
    //   550: aload #5
    //   552: aload #6
    //   554: aload #7
    //   556: invokevirtual toString : ()Ljava/lang/String;
    //   559: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   562: goto -> 834
    //   565: aload #5
    //   567: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   570: if_acmpne -> 585
    //   573: aload_0
    //   574: getfield tag : Ljava/lang/String;
    //   577: ldc 'No operations are allowed on a destroyed instance'
    //   579: invokestatic j : (Ljava/lang/String;Ljava/lang/String;)V
    //   582: goto -> 834
    //   585: aload_0
    //   586: getfield logger : Lcom/applovin/impl/sdk/y;
    //   589: astore #5
    //   591: invokestatic a : ()Z
    //   594: ifeq -> 834
    //   597: aload_0
    //   598: getfield logger : Lcom/applovin/impl/sdk/y;
    //   601: astore #5
    //   603: aload_0
    //   604: getfield tag : Ljava/lang/String;
    //   607: astore #6
    //   609: new java/lang/StringBuilder
    //   612: dup
    //   613: ldc 'Unknown state: '
    //   615: invokespecial <init> : (Ljava/lang/String;)V
    //   618: astore #7
    //   620: aload #7
    //   622: aload_0
    //   623: getfield e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   626: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   629: pop
    //   630: aload #5
    //   632: aload #6
    //   634: aload #7
    //   636: invokevirtual toString : ()Ljava/lang/String;
    //   639: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   642: goto -> 834
    //   645: iload_3
    //   646: ifeq -> 737
    //   649: aload_0
    //   650: getfield logger : Lcom/applovin/impl/sdk/y;
    //   653: astore #5
    //   655: invokestatic a : ()Z
    //   658: ifeq -> 729
    //   661: aload_0
    //   662: getfield logger : Lcom/applovin/impl/sdk/y;
    //   665: astore #5
    //   667: aload_0
    //   668: getfield tag : Ljava/lang/String;
    //   671: astore #6
    //   673: new java/lang/StringBuilder
    //   676: dup
    //   677: ldc 'Transitioning from '
    //   679: invokespecial <init> : (Ljava/lang/String;)V
    //   682: astore #7
    //   684: aload #7
    //   686: aload_0
    //   687: getfield e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   690: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   693: pop
    //   694: aload #7
    //   696: ldc ' to '
    //   698: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   701: pop
    //   702: aload #7
    //   704: aload_1
    //   705: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   708: pop
    //   709: aload #7
    //   711: ldc '...'
    //   713: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   716: pop
    //   717: aload #5
    //   719: aload #6
    //   721: aload #7
    //   723: invokevirtual toString : ()Ljava/lang/String;
    //   726: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   729: aload_0
    //   730: aload_1
    //   731: putfield e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   734: goto -> 810
    //   737: aload_0
    //   738: getfield logger : Lcom/applovin/impl/sdk/y;
    //   741: astore #5
    //   743: invokestatic a : ()Z
    //   746: ifeq -> 810
    //   749: aload_0
    //   750: getfield logger : Lcom/applovin/impl/sdk/y;
    //   753: astore #5
    //   755: aload_0
    //   756: getfield tag : Ljava/lang/String;
    //   759: astore #6
    //   761: new java/lang/StringBuilder
    //   764: dup
    //   765: ldc_w 'Not allowed transition from '
    //   768: invokespecial <init> : (Ljava/lang/String;)V
    //   771: astore #7
    //   773: aload #7
    //   775: aload_0
    //   776: getfield e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   779: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   782: pop
    //   783: aload #7
    //   785: ldc ' to '
    //   787: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   790: pop
    //   791: aload #7
    //   793: aload_1
    //   794: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   797: pop
    //   798: aload #5
    //   800: aload #6
    //   802: aload #7
    //   804: invokevirtual toString : ()Ljava/lang/String;
    //   807: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;)V
    //   810: aload #4
    //   812: monitorexit
    //   813: iload_3
    //   814: ifeq -> 827
    //   817: aload_2
    //   818: ifnull -> 827
    //   821: aload_2
    //   822: invokeinterface run : ()V
    //   827: return
    //   828: astore_1
    //   829: aload #4
    //   831: monitorexit
    //   832: aload_1
    //   833: athrow
    //   834: iconst_0
    //   835: istore_3
    //   836: goto -> 645
    // Exception table:
    //   from	to	target	type
    //   15	20	828	finally
    //   29	36	828	finally
    //   39	46	828	finally
    //   49	65	828	finally
    //   68	122	828	finally
    //   125	140	828	finally
    //   143	159	828	finally
    //   162	169	828	finally
    //   172	188	828	finally
    //   191	198	828	finally
    //   201	255	828	finally
    //   258	273	828	finally
    //   276	292	828	finally
    //   295	327	828	finally
    //   330	337	828	finally
    //   340	347	828	finally
    //   350	404	828	finally
    //   407	422	828	finally
    //   425	441	828	finally
    //   444	476	828	finally
    //   479	495	828	finally
    //   498	505	828	finally
    //   508	562	828	finally
    //   565	582	828	finally
    //   585	642	828	finally
    //   649	729	828	finally
    //   729	734	828	finally
    //   737	810	828	finally
    //   810	813	828	finally
    //   829	832	828	finally
  }
  
  private void a(MaxAd paramMaxAd) {
    this.sdk.R().a((g)paramMaxAd);
    b();
    this.sdk.aq().b((com.applovin.impl.mediation.a.a)paramMaxAd);
  }
  
  private void a(String paramString1, String paramString2) {
    this.b.b(this.d);
    this.d.e(paramString1);
    this.d.f(paramString2);
    this.sdk.ac().a(this.d);
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      paramString2 = this.tag;
      StringBuilder stringBuilder = new StringBuilder("Showing ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("'; loaded ad: ");
      stringBuilder.append(this.d);
      stringBuilder.append("...");
      y.b(paramString2, stringBuilder.toString());
    } 
    a((com.applovin.impl.mediation.a.a)this.d);
  }
  
  private boolean a(Activity paramActivity, String paramString) {
    if (paramActivity != null || MaxAdFormat.APP_OPEN == this.adFormat) {
      MaxErrorImpl maxErrorImpl;
      boolean bool;
      if (!isReady()) {
        StringBuilder stringBuilder = new StringBuilder("Attempting to show ad before it is ready - please check ad readiness using ");
        stringBuilder.append(this.tag);
        stringBuilder.append("#isReady()");
        String str = stringBuilder.toString();
        y.j(this.tag, str);
        this.sdk.V().a(this.adUnitId);
        maxErrorImpl = new MaxErrorImpl(-24, str);
        i i = new i(this.adUnitId, this.adFormat, paramString);
        y y = this.logger;
        if (y.a()) {
          y = this.logger;
          String str1 = this.tag;
          StringBuilder stringBuilder1 = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder1.append(i);
          stringBuilder1.append(", error=");
          stringBuilder1.append(maxErrorImpl);
          stringBuilder1.append("), listener=");
          stringBuilder1.append(this.adListener);
          y.b(str1, stringBuilder1.toString());
        } 
        o.a(this.adListener, (MaxAd)i, (MaxError)maxErrorImpl, true, true);
        if (this.d != null)
          this.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.d); 
        return false;
      } 
      if (w.e(o.au()) != 0 && this.sdk.ay().shouldFailAdDisplayIfDontKeepActivitiesIsEnabled())
        if (!w.a(o.au(), this.sdk)) {
          if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.S)).booleanValue()) {
            y.j(this.tag, "Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
            maxErrorImpl = new MaxErrorImpl(-5602, "Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
            y y = this.logger;
            if (y.a()) {
              y = this.logger;
              String str = this.tag;
              StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
              stringBuilder.append(this.d);
              stringBuilder.append(", error=");
              stringBuilder.append(maxErrorImpl);
              stringBuilder.append("), listener=");
              stringBuilder.append(this.adListener);
              y.b(str, stringBuilder.toString());
            } 
            o.a(this.adListener, (MaxAd)this.d, (MaxError)maxErrorImpl, true, true);
            this.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.d);
            return false;
          } 
        } else {
          throw new IllegalStateException("Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
        }  
      if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.z)).booleanValue() && (this.sdk.V().a() || this.sdk.V().b())) {
        y.j(this.tag, "Attempting to show ad when another fullscreen ad is already showing");
        maxErrorImpl = new MaxErrorImpl(-23, "Attempting to show ad when another fullscreen ad is already showing");
        y y = this.logger;
        if (y.a()) {
          y = this.logger;
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder.append(this.d);
          stringBuilder.append(", error=");
          stringBuilder.append(maxErrorImpl);
          stringBuilder.append("), listener=");
          stringBuilder.append(this.adListener);
          y.b(str, stringBuilder.toString());
        } 
        o.a(this.adListener, (MaxAd)this.d, (MaxError)maxErrorImpl, true, true);
        this.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.d);
        return false;
      } 
      if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.A)).booleanValue() && !i.a(o.au())) {
        y.j(this.tag, "Attempting to show ad with no internet connection");
        maxErrorImpl = new MaxErrorImpl(-1009);
        y y = this.logger;
        if (y.a()) {
          y = this.logger;
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder.append(this.d);
          stringBuilder.append(", error=");
          stringBuilder.append(maxErrorImpl);
          stringBuilder.append("), listener=");
          stringBuilder.append(this.adListener);
          y.b(str, stringBuilder.toString());
        } 
        o.a(this.adListener, (MaxAd)this.d, (MaxError)maxErrorImpl, true, true);
        this.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.d);
        return false;
      } 
      paramString = (String)this.sdk.ay().getExtraParameters().get("fullscreen_ads_block_showing_if_activity_is_finishing");
      if (StringUtils.isValidString(paramString) && Boolean.valueOf(paramString).booleanValue()) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool || ((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.B)).booleanValue()) && maxErrorImpl != null && maxErrorImpl.isFinishing()) {
        y.j(this.tag, "Attempting to show ad when activity is finishing");
        maxErrorImpl = new MaxErrorImpl(-5601, "Attempting to show ad when activity is finishing");
        y y = this.logger;
        if (y.a()) {
          y = this.logger;
          String str = this.tag;
          StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder.append(this.d);
          stringBuilder.append(", error=");
          stringBuilder.append(maxErrorImpl);
          stringBuilder.append("), listener=");
          stringBuilder.append(this.adListener);
          y.b(str, stringBuilder.toString());
        } 
        o.a(this.adListener, (MaxAd)this.d, (MaxError)maxErrorImpl, true, true);
        this.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.d);
        return false;
      } 
      return true;
    } 
    throw new IllegalArgumentException("Attempting to show ad without a valid activity.");
  }
  
  private void b() {
    synchronized (this.c) {
      com.applovin.impl.mediation.a.c c1 = this.d;
      this.d = null;
      this.sdk.am().destroyAd((MaxAd)c1);
      return;
    } 
  }
  
  private void c() {
    if (this.f.compareAndSet(true, false))
      synchronized (this.c) {
        com.applovin.impl.mediation.a.c c1 = this.d;
        this.d = null;
        this.sdk.am().destroyAd((MaxAd)c1);
        this.extraParameters.remove("expired_ad_ad_unit_id");
        return;
      }  
  }
  
  public void destroy() {
    a(c.e, new Runnable(this) {
          public void run() {
            synchronized (MaxFullscreenAdImpl.a(this.a)) {
              if (MaxFullscreenAdImpl.b(this.a) != null) {
                y y = this.a.logger;
                if (y.a()) {
                  y = this.a.logger;
                  String str = this.a.tag;
                  StringBuilder stringBuilder = new StringBuilder("Destroying ad for '");
                  stringBuilder.append(this.a.adUnitId);
                  stringBuilder.append("'; current ad: ");
                  stringBuilder.append(MaxFullscreenAdImpl.b(this.a));
                  stringBuilder.append("...");
                  y.b(str, stringBuilder.toString());
                } 
                this.a.sdk.am().destroyAd((MaxAd)MaxFullscreenAdImpl.b(this.a));
              } 
              this.a.sdk.aj().b(this.a);
              MaxFullscreenAdImpl.c(this.a);
              return;
            } 
          }
        });
  }
  
  public boolean isReady() {
    synchronized (this.c) {
      boolean bool;
      com.applovin.impl.mediation.a.c c1 = this.d;
      if (c1 != null && c1.l() && this.e == c.c) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool)
        this.sdk.V().a(this.adUnitId); 
      return bool;
    } 
  }
  
  public void loadAd(Activity paramActivity) {
    loadAd(paramActivity, d.a.a);
  }
  
  public void loadAd(Activity paramActivity, d.a parama) {
    y y1;
    String str;
    y y2 = this.logger;
    if (y.a()) {
      y2 = this.logger;
      String str1 = this.tag;
      StringBuilder stringBuilder = new StringBuilder("Loading ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("'...");
      y2.b(str1, stringBuilder.toString());
    } 
    if (isReady()) {
      y1 = this.logger;
      if (y.a()) {
        y1 = this.logger;
        str = this.tag;
        StringBuilder stringBuilder = new StringBuilder("An ad is already loaded for '");
        stringBuilder.append(this.adUnitId);
        stringBuilder.append("'");
        y1.b(str, stringBuilder.toString());
      } 
      y1 = this.logger;
      if (y.a()) {
        y1 = this.logger;
        str = this.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdLoaded(ad=");
        stringBuilder.append(this.d);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.adListener);
        y1.b(str, stringBuilder.toString());
      } 
      o.a(this.adListener, (MaxAd)this.d, true, true);
      return;
    } 
    a(c.b, new Runnable(this, (Activity)y1, (d.a)str) {
          public void run() {
            Context context;
            Activity activity = this.a;
            if (activity == null)
              if (this.c.sdk.at() != null) {
                activity = this.c.sdk.at();
              } else {
                context = o.au();
              }  
            this.c.sdk.am().loadAd(this.c.adUnitId, null, this.c.adFormat, this.b, this.c.localExtraParameters, this.c.extraParameters, context, this.c.listenerWrapper);
          }
        });
  }
  
  public void onAdExpired(g paramg) {
    Activity activity;
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder("Ad expired ");
      stringBuilder.append(getAdUnitId());
      y.b(str, stringBuilder.toString());
    } 
    this.f.set(true);
    a a1 = this.a;
    if (a1 != null) {
      Activity activity1 = a1.getActivity();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null) {
      Activity activity1 = this.sdk.E().a();
      activity = activity1;
      if (activity1 == null) {
        c();
        this.listenerWrapper.onAdLoadFailed(this.adUnitId, (MaxError)MaxAdapterError.MISSING_ACTIVITY);
        return;
      } 
    } 
    this.extraParameters.put("expired_ad_ad_unit_id", getAdUnitId());
    this.sdk.am().loadAd(this.adUnitId, null, this.adFormat, d.a.e, this.localExtraParameters, this.extraParameters, (Context)activity, this.listenerWrapper);
  }
  
  public void onCreativeIdGenerated(String paramString1, String paramString2) {
    com.applovin.impl.mediation.a.c c1 = this.d;
    if (c1 != null && c1.j().equalsIgnoreCase(paramString1)) {
      this.d.b(paramString2);
      o.a(this.adReviewListener, paramString2, (MaxAd)this.d);
    } 
  }
  
  public void showAd(String paramString1, String paramString2, Activity paramActivity) {
    String str1;
    String str2 = this.sdk.as().c();
    if (this.sdk.as().b() && str2 != null && !str2.equals(this.d.ac())) {
      StringBuilder stringBuilder = new StringBuilder("Attempting to show ad from <");
      stringBuilder.append(this.d.ac());
      stringBuilder.append("> which does not match selected ad network <");
      stringBuilder.append(str2);
      stringBuilder.append(">");
      str1 = stringBuilder.toString();
      y.j(this.tag, str1);
      a(c.a, new Runnable(this, str1) {
            public void run() {
              com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.b);
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.b;
              MaxFullscreenAdImpl.a(maxFullscreenAdImpl, (MaxAd)MaxFullscreenAdImpl.b(maxFullscreenAdImpl));
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-4205, this.a);
              y y = this.b.logger;
              if (y.a()) {
                y = this.b.logger;
                String str = this.b.tag;
                StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(c);
                stringBuilder.append(", error=");
                stringBuilder.append(maxErrorImpl);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.adListener);
                y.b(str, stringBuilder.toString());
              } 
              o.a(this.b.adListener, (MaxAd)c, (MaxError)maxErrorImpl, true, true);
              this.b.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)c);
            }
          });
      return;
    } 
    if (paramActivity == null)
      paramActivity = this.sdk.at(); 
    if (!a(paramActivity, str1))
      return; 
    a(c.d, new Runnable(this, str1, paramString2, paramActivity) {
          public void run() {
            MaxFullscreenAdImpl.a(this.d, this.a, this.b);
            MaxFullscreenAdImpl.a(this.d, false);
            MaxFullscreenAdImpl.a(this.d, new WeakReference<Activity>(this.c));
            this.d.sdk.am().showFullscreenAd(MaxFullscreenAdImpl.b(this.d), this.c, this.d.listenerWrapper);
          }
        });
  }
  
  public void showAd(String paramString1, String paramString2, ViewGroup paramViewGroup, Lifecycle paramLifecycle, Activity paramActivity) {
    String str1;
    y y;
    String str2;
    StringBuilder stringBuilder;
    if (paramViewGroup == null || paramLifecycle == null) {
      y.j(this.tag, "Attempting to show ad with null containerView or lifecycle.");
      MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, "Attempting to show ad with null containerView or lifecycle.");
      y = this.logger;
      if (y.a()) {
        y = this.logger;
        str2 = this.tag;
        stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
        stringBuilder.append(this.d);
        stringBuilder.append(", error=");
        stringBuilder.append(maxErrorImpl);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.adListener);
        y.b(str2, stringBuilder.toString());
      } 
      o.a(this.adListener, (MaxAd)this.d, (MaxError)maxErrorImpl, true, true);
      this.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.d);
      return;
    } 
    if (!str2.isShown() && ((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.T)).booleanValue()) {
      y.j(this.tag, "Attempting to show ad when containerView and/or its ancestors are not visible");
      MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, "Attempting to show ad when containerView and/or its ancestors are not visible");
      o.a(this.adListener, (MaxAd)this.d, (MaxError)maxErrorImpl, true, true);
      this.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.d);
      return;
    } 
    String str3 = this.sdk.as().c();
    if (this.sdk.as().b() && str3 != null && !str3.equals(this.d.ac())) {
      StringBuilder stringBuilder1 = new StringBuilder("Attempting to show ad from <");
      stringBuilder1.append(this.d.ac());
      stringBuilder1.append("> which does not match selected ad network <");
      stringBuilder1.append(str3);
      stringBuilder1.append(">");
      str1 = stringBuilder1.toString();
      y.j(this.tag, str1);
      a(c.a, new Runnable(this, str1) {
            public void run() {
              com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.b);
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.b;
              MaxFullscreenAdImpl.a(maxFullscreenAdImpl, (MaxAd)MaxFullscreenAdImpl.b(maxFullscreenAdImpl));
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-4205, this.a);
              y y = this.b.logger;
              if (y.a()) {
                y = this.b.logger;
                String str = this.b.tag;
                StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(c);
                stringBuilder.append(", error=");
                stringBuilder.append(maxErrorImpl);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.adListener);
                y.b(str, stringBuilder.toString());
              } 
              o.a(this.b.adListener, (MaxAd)c, (MaxError)maxErrorImpl, true, true);
              this.b.sdk.am().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)c);
            }
          });
      return;
    } 
    if (paramActivity == null)
      paramActivity = this.sdk.at(); 
    if (!a(paramActivity, str1))
      return; 
    a(c.d, new Runnable(this, str1, (String)y, paramActivity, (ViewGroup)str2, (Lifecycle)stringBuilder) {
          public void run() {
            MaxFullscreenAdImpl.a(this.f, this.a, this.b);
            MaxFullscreenAdImpl.a(this.f, true);
            MaxFullscreenAdImpl.a(this.f, new WeakReference<Activity>(this.c));
            MaxFullscreenAdImpl.b(this.f, new WeakReference<ViewGroup>(this.d));
            MaxFullscreenAdImpl.c(this.f, new WeakReference<Lifecycle>(this.e));
            this.f.sdk.am().showFullscreenAd(MaxFullscreenAdImpl.b(this.f), this.d, this.e, this.c, this.f.listenerWrapper);
          }
        });
  }
  
  public String toString() {
    MaxAdListener maxAdListener;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.tag);
    stringBuilder.append("{adUnitId='");
    stringBuilder.append(this.adUnitId);
    stringBuilder.append("', adListener=");
    if (this.adListener == this.a) {
      String str = "this";
    } else {
      maxAdListener = this.adListener;
    } 
    stringBuilder.append(maxAdListener);
    stringBuilder.append(", revenueListener=");
    stringBuilder.append(this.revenueListener);
    stringBuilder.append(", requestListener");
    stringBuilder.append(this.requestListener);
    stringBuilder.append(", adReviewListener");
    stringBuilder.append(this.adReviewListener);
    stringBuilder.append(", isReady=");
    stringBuilder.append(isReady());
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public static interface a {
    Activity getActivity();
  }
  
  private class b implements a.a, MaxAdListener, MaxAdRevenueListener, MaxRewardedAdListener {
    private b(MaxFullscreenAdImpl this$0) {}
    
    public void onAdClicked(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdClicked(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.d(this.a.adListener, param1MaxAd, true, true);
    }
    
    public void onAdDisplayFailed(MaxAd param1MaxAd, MaxError param1MaxError) {
      boolean bool = MaxFullscreenAdImpl.e(this.a);
      MaxFullscreenAdImpl.b(this.a, false);
      com.applovin.impl.mediation.a.c c = (com.applovin.impl.mediation.a.c)param1MaxAd;
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1MaxAd, bool, c, param1MaxError) {
            public void run() {
              MaxFullscreenAdImpl.a(this.e.a, this.a);
              if (!this.b && this.c.O() && this.e.a.sdk.ar().a(this.e.a.adUnitId)) {
                AppLovinSdkUtils.runOnUiThread(true, new Runnable(this) {
                      public void run() {
                        Activity activity;
                        MaxFullscreenAdImpl.b(this.a.e.a, true);
                        if (MaxFullscreenAdImpl.i(this.a.e.a) != null) {
                          activity = MaxFullscreenAdImpl.i(this.a.e.a).getActivity();
                        } else {
                          activity = null;
                        } 
                        this.a.e.a.loadAd(activity);
                      }
                    });
                return;
              } 
              y y = this.e.a.logger;
              if (y.a()) {
                y = this.e.a.logger;
                String str = this.e.a.tag;
                StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append(", error=");
                stringBuilder.append(this.d);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.e.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              o.a(this.e.a.adListener, this.a, this.d, true, true);
            }
          });
    }
    
    public void onAdDisplayed(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.b(this.a, false);
      this.a.sdk.R().a((g)param1MaxAd);
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayed(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.b(this.a.adListener, param1MaxAd, true, true);
    }
    
    public void onAdHidden(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.b(this.a, false);
      MaxFullscreenAdImpl.h(this.a).a(param1MaxAd);
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1MaxAd) {
            public void run() {
              MaxFullscreenAdImpl.a(this.b.a, this.a);
              y y = this.b.a.logger;
              if (y.a()) {
                y = this.b.a.logger;
                String str = this.b.a.tag;
                StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdHidden(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              o.c(this.b.a.adListener, this.a, true, true);
            }
          });
    }
    
    public void onAdLoadFailed(String param1String, MaxError param1MaxError) {
      MaxFullscreenAdImpl.g(this.a);
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1String, param1MaxError) {
            public void run() {
              y y = this.c.a.logger;
              if (y.a()) {
                y = this.c.a.logger;
                String str = this.c.a.tag;
                StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdLoadFailed(adUnitId=");
                stringBuilder.append(this.a);
                stringBuilder.append(", error=");
                stringBuilder.append(this.b);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.c.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              o.a(this.c.a.adListener, this.a, this.b, true, true);
            }
          });
    }
    
    public void onAdLoaded(MaxAd param1MaxAd) {
      this.a.sdk.V().c(this.a.adUnitId);
      MaxFullscreenAdImpl.a(this.a, (com.applovin.impl.mediation.a.c)param1MaxAd);
      if (MaxFullscreenAdImpl.d(this.a).compareAndSet(true, false)) {
        this.a.extraParameters.remove("expired_ad_ad_unit_id");
        return;
      } 
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.c, new Runnable(this, param1MaxAd) {
            public void run() {
              if (MaxFullscreenAdImpl.e(this.b.a)) {
                MaxFullscreenAdImpl.f(this.b.a);
                return;
              } 
              y y = this.b.a.logger;
              if (y.a()) {
                y = this.b.a.logger;
                String str = this.b.a.tag;
                StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdLoaded(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              o.a(this.b.a.adListener, this.a, true, true);
            }
          });
    }
    
    public void onAdRequestStarted(String param1String) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdRequestListener.onAdRequestStarted(adUnitId=");
        stringBuilder.append(param1String);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.requestListener);
        y.b(str, stringBuilder.toString());
      } 
      o.a(this.a.requestListener, param1String, true, true);
    }
    
    public void onAdRevenuePaid(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdRevenueListener.onAdRevenuePaid(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.revenueListener);
        y.b(str, stringBuilder.toString());
      } 
      o.a(this.a.revenueListener, param1MaxAd, true);
    }
    
    public void onRewardedVideoCompleted(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxRewardedAdListener.onRewardedVideoCompleted(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.f(this.a.adListener, param1MaxAd, true, true);
    }
    
    public void onRewardedVideoStarted(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxRewardedAdListener.onRewardedVideoStarted(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.e(this.a.adListener, param1MaxAd, true, true);
    }
    
    public void onUserRewarded(MaxAd param1MaxAd, MaxReward param1MaxReward) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxRewardedAdListener.onUserRewarded(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append(", reward=");
        stringBuilder.append(param1MaxReward);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.a(this.a.adListener, param1MaxAd, param1MaxReward, true, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      if (MaxFullscreenAdImpl.e(this.b.a)) {
        MaxFullscreenAdImpl.f(this.b.a);
        return;
      } 
      y y = this.b.a.logger;
      if (y.a()) {
        y = this.b.a.logger;
        String str = this.b.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdLoaded(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.b.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.a(this.b.a.adListener, this.a, true, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, String param1String, MaxError param1MaxError) {}
    
    public void run() {
      y y = this.c.a.logger;
      if (y.a()) {
        y = this.c.a.logger;
        String str = this.c.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdLoadFailed(adUnitId=");
        stringBuilder.append(this.a);
        stringBuilder.append(", error=");
        stringBuilder.append(this.b);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.c.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.a(this.c.a.adListener, this.a, this.b, true, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      MaxFullscreenAdImpl.a(this.b.a, this.a);
      y y = this.b.a.logger;
      if (y.a()) {
        y = this.b.a.logger;
        String str = this.b.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdHidden(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.b.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.c(this.b.a.adListener, this.a, true, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd, boolean param1Boolean, com.applovin.impl.mediation.a.c param1c, MaxError param1MaxError) {}
    
    public void run() {
      MaxFullscreenAdImpl.a(this.e.a, this.a);
      if (!this.b && this.c.O() && this.e.a.sdk.ar().a(this.e.a.adUnitId)) {
        AppLovinSdkUtils.runOnUiThread(true, new Runnable(this) {
              public void run() {
                Activity activity;
                MaxFullscreenAdImpl.b(this.a.e.a, true);
                if (MaxFullscreenAdImpl.i(this.a.e.a) != null) {
                  activity = MaxFullscreenAdImpl.i(this.a.e.a).getActivity();
                } else {
                  activity = null;
                } 
                this.a.e.a.loadAd(activity);
              }
            });
        return;
      } 
      y y = this.e.a.logger;
      if (y.a()) {
        y = this.e.a.logger;
        String str = this.e.a.tag;
        StringBuilder stringBuilder = new StringBuilder("MaxAdListener.onAdDisplayFailed(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append(", error=");
        stringBuilder.append(this.d);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.e.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      o.a(this.e.a.adListener, this.a, this.d, true, true);
    }
  }
  
  class null implements Runnable {
    public void run() {
      Activity activity;
      MaxFullscreenAdImpl.b(this.a.e.a, true);
      if (MaxFullscreenAdImpl.i(this.a.e.a) != null) {
        activity = MaxFullscreenAdImpl.i(this.a.e.a).getActivity();
      } else {
        activity = null;
      } 
      this.a.e.a.loadAd(activity);
    }
  }
  
  public enum c {
    a, b, c, d, e;
    
    static {
      c c1 = new c("IDLE", 0);
      a = c1;
      c c2 = new c("LOADING", 1);
      b = c2;
      c c3 = new c("READY", 2);
      c = c3;
      c c4 = new c("SHOWING", 3);
      d = c4;
      c c5 = new c("DESTROYED", 4);
      e = c5;
      f = new c[] { c1, c2, c3, c4, c5 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\mediation\ads\MaxFullscreenAdImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */