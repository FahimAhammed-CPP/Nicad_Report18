package androidx.browser.browseractions;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

@Deprecated
public class BrowserActionsFallbackMenuView extends LinearLayout {
  public final int 怖 = getResources().getDimensionPixelOffset(2131099735);
  
  public final int 淋 = getResources().getDimensionPixelOffset(2131099736);
  
  public BrowserActionsFallbackMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(Math.min((getResources().getDisplayMetrics()).widthPixels - this.淋 * 2, this.怖), 1073741824), paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\browser\browseractions\BrowserActionsFallbackMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */