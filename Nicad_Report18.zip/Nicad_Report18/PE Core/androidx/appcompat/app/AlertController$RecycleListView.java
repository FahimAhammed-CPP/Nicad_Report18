package androidx.appcompat.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ListView;
import y.td;

public class AlertController$RecycleListView extends ListView {
  public final int 怖;
  
  public final int 淋;
  
  public AlertController$RecycleListView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, td.키);
    this.怖 = typedArray.getDimensionPixelOffset(0, -1);
    this.淋 = typedArray.getDimensionPixelOffset(1, -1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\app\AlertController$RecycleListView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */