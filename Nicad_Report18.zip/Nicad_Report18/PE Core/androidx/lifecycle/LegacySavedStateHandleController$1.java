package androidx.lifecycle;

import y.fj;
import y.p31;
import y.尻;
import y.心;
import y.肉;
import y.腰;

class LegacySavedStateHandleController$1 implements 肉 {
  public LegacySavedStateHandleController$1(p31 paramp31, fj paramfj) {}
  
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 == 尻.ON_START) {
      this.淋.興((心)this);
      this.怖.暑();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\LegacySavedStateHandleController$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */