package com.applovin.impl.sdk.a;

import android.content.Context;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.iab.omid.library.applovin.Omid;
import com.iab.omid.library.applovin.ScriptInjector;
import com.iab.omid.library.applovin.adsession.Partner;

public class f {
  private final o a;
  
  private final Context b;
  
  private String c;
  
  public f(o paramo) {
    this.a = paramo;
    this.b = o.au();
  }
  
  public String a(String paramString) {
    try {
      return ScriptInjector.injectScriptContentIntoHtml(this.c, paramString);
    } finally {
      Exception exception = null;
      this.a.F();
      if (y.a())
        this.a.F().b("OpenMeasurementService", "Failed to inject JavaScript SDK into HTML", exception); 
    } 
  }
  
  public void a() {
    if (((Boolean)this.a.a(b.aF)).booleanValue()) {
      this.a.F();
      if (y.a()) {
        y y = this.a.F();
        StringBuilder stringBuilder = new StringBuilder("Initializing Open Measurement SDK v");
        stringBuilder.append(c());
        stringBuilder.append("...");
        y.b("OpenMeasurementService", stringBuilder.toString());
      } 
      AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
            public void run() {
              // Byte code:
              //   0: invokestatic currentTimeMillis : ()J
              //   3: lstore_1
              //   4: aload_0
              //   5: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   8: invokestatic a : (Lcom/applovin/impl/sdk/a/f;)Landroid/content/Context;
              //   11: invokestatic activate : (Landroid/content/Context;)V
              //   14: aload_0
              //   15: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   18: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/o;
              //   21: invokevirtual F : ()Lcom/applovin/impl/sdk/y;
              //   24: pop
              //   25: invokestatic a : ()Z
              //   28: ifeq -> 119
              //   31: aload_0
              //   32: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   35: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/o;
              //   38: invokevirtual F : ()Lcom/applovin/impl/sdk/y;
              //   41: astore #4
              //   43: new java/lang/StringBuilder
              //   46: dup
              //   47: ldc 'Init '
              //   49: invokespecial <init> : (Ljava/lang/String;)V
              //   52: astore #5
              //   54: aload_0
              //   55: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   58: invokevirtual b : ()Z
              //   61: ifeq -> 70
              //   64: ldc 'succeeded'
              //   66: astore_3
              //   67: goto -> 73
              //   70: ldc 'failed'
              //   72: astore_3
              //   73: aload #5
              //   75: aload_3
              //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   79: pop
              //   80: aload #5
              //   82: ldc ' and took '
              //   84: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   87: pop
              //   88: aload #5
              //   90: invokestatic currentTimeMillis : ()J
              //   93: lload_1
              //   94: lsub
              //   95: invokevirtual append : (J)Ljava/lang/StringBuilder;
              //   98: pop
              //   99: aload #5
              //   101: ldc 'ms'
              //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   106: pop
              //   107: aload #4
              //   109: ldc 'OpenMeasurementService'
              //   111: aload #5
              //   113: invokevirtual toString : ()Ljava/lang/String;
              //   116: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
              //   119: new java/io/BufferedReader
              //   122: dup
              //   123: new java/io/InputStreamReader
              //   126: dup
              //   127: aload_0
              //   128: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   131: invokestatic a : (Lcom/applovin/impl/sdk/a/f;)Landroid/content/Context;
              //   134: invokevirtual getResources : ()Landroid/content/res/Resources;
              //   137: getstatic com/applovin/sdk/R$raw.omsdk_v_1_0 : I
              //   140: invokevirtual openRawResource : (I)Ljava/io/InputStream;
              //   143: invokespecial <init> : (Ljava/io/InputStream;)V
              //   146: invokespecial <init> : (Ljava/io/Reader;)V
              //   149: astore_3
              //   150: new java/lang/StringBuilder
              //   153: dup
              //   154: invokespecial <init> : ()V
              //   157: astore #4
              //   159: aload_3
              //   160: invokevirtual readLine : ()Ljava/lang/String;
              //   163: astore #5
              //   165: aload #5
              //   167: ifnull -> 181
              //   170: aload #4
              //   172: aload #5
              //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   177: pop
              //   178: goto -> 159
              //   181: aload_0
              //   182: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   185: aload #4
              //   187: invokevirtual toString : ()Ljava/lang/String;
              //   190: invokestatic a : (Lcom/applovin/impl/sdk/a/f;Ljava/lang/String;)Ljava/lang/String;
              //   193: pop
              //   194: aload_3
              //   195: invokevirtual close : ()V
              //   198: return
              //   199: astore #4
              //   201: ldc 'OpenMeasurementService'
              //   203: ldc 'Failed to load JavaScript Open Measurement SDK'
              //   205: aload #4
              //   207: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   210: pop
              //   211: aload_3
              //   212: invokevirtual close : ()V
              //   215: return
              //   216: astore_3
              //   217: ldc 'OpenMeasurementService'
              //   219: ldc 'Failed to close the BufferReader for reading JavaScript Open Measurement SDK'
              //   221: aload_3
              //   222: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   225: pop
              //   226: return
              //   227: astore #4
              //   229: aload_3
              //   230: invokevirtual close : ()V
              //   233: goto -> 246
              //   236: astore_3
              //   237: ldc 'OpenMeasurementService'
              //   239: ldc 'Failed to close the BufferReader for reading JavaScript Open Measurement SDK'
              //   241: aload_3
              //   242: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   245: pop
              //   246: aload #4
              //   248: athrow
              //   249: astore_3
              //   250: aload_0
              //   251: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   254: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/o;
              //   257: invokevirtual F : ()Lcom/applovin/impl/sdk/y;
              //   260: pop
              //   261: invokestatic a : ()Z
              //   264: ifeq -> 285
              //   267: aload_0
              //   268: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   271: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/o;
              //   274: invokevirtual F : ()Lcom/applovin/impl/sdk/y;
              //   277: ldc 'OpenMeasurementService'
              //   279: ldc 'Failed to retrieve resource omskd_v_1_0.js'
              //   281: aload_3
              //   282: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
              //   285: return
              // Exception table:
              //   from	to	target	type
              //   119	150	249	finally
              //   150	159	199	finally
              //   159	165	199	finally
              //   170	178	199	finally
              //   181	194	199	finally
              //   194	198	216	java/io/IOException
              //   201	211	227	finally
              //   211	215	216	java/io/IOException
              //   229	233	236	java/io/IOException
            }
          });
    } 
  }
  
  public boolean b() {
    return Omid.isActive();
  }
  
  public String c() {
    return Omid.getVersion();
  }
  
  public Partner d() {
    return Partner.createPartner((String)this.a.a(b.aG), AppLovinSdk.VERSION);
  }
  
  public String e() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\sdk\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */