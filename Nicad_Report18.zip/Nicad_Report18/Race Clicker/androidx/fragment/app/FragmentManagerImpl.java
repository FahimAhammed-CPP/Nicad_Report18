package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.OnBackPressedDispatcherOwner;
import androidx.collection.ArraySet;
import androidx.core.util.DebugUtils;
import androidx.core.util.LogWriter;
import androidx.core.view.OneShotPreDrawListener;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class FragmentManagerImpl extends FragmentManager implements LayoutInflater.Factory2 {
  static final int ANIM_DUR = 220;
  
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static boolean DEBUG = false;
  
  static final Interpolator DECELERATE_CUBIC;
  
  static final Interpolator DECELERATE_QUINT = (Interpolator)new DecelerateInterpolator(2.5F);
  
  static final String TAG = "FragmentManager";
  
  static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
  
  static final String TARGET_STATE_TAG = "android:target_state";
  
  static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
  
  static final String VIEW_STATE_TAG = "android:view_state";
  
  final HashMap<String, Fragment> mActive = new HashMap<String, Fragment>();
  
  final ArrayList<Fragment> mAdded = new ArrayList<Fragment>();
  
  ArrayList<Integer> mAvailBackStackIndices;
  
  ArrayList<BackStackRecord> mBackStack;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
  
  ArrayList<BackStackRecord> mBackStackIndices;
  
  FragmentContainer mContainer;
  
  ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = 0;
  
  boolean mDestroyed;
  
  Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManagerImpl.this.execPendingActions();
      }
    };
  
  boolean mExecutingActions;
  
  boolean mHavePendingDeferredStart;
  
  FragmentHostCallback mHost;
  
  private final CopyOnWriteArrayList<FragmentLifecycleCallbacksHolder> mLifecycleCallbacks = new CopyOnWriteArrayList<FragmentLifecycleCallbacksHolder>();
  
  boolean mNeedMenuInvalidate;
  
  int mNextFragmentIndex = 0;
  
  private FragmentManagerViewModel mNonConfig;
  
  private final OnBackPressedCallback mOnBackPressedCallback = new OnBackPressedCallback(false) {
      public void handleOnBackPressed() {
        FragmentManagerImpl.this.handleOnBackPressed();
      }
    };
  
  private OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  Fragment mParent;
  
  ArrayList<OpGenerator> mPendingActions;
  
  ArrayList<StartEnterTransitionListener> mPostponedTransactions;
  
  Fragment mPrimaryNav;
  
  SparseArray<Parcelable> mStateArray = null;
  
  Bundle mStateBundle = null;
  
  boolean mStateSaved;
  
  boolean mStopped;
  
  ArrayList<Fragment> mTmpAddedFragments;
  
  ArrayList<Boolean> mTmpIsPop;
  
  ArrayList<BackStackRecord> mTmpRecords;
  
  static {
    DECELERATE_CUBIC = (Interpolator)new DecelerateInterpolator(1.5F);
  }
  
  private void addAddedFragments(ArraySet<Fragment> paramArraySet) {
    int i = this.mCurState;
    if (i < 1)
      return; 
    int j = Math.min(i, 3);
    int k = this.mAdded.size();
    for (i = 0; i < k; i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment.mState < j) {
        moveToState(fragment, j, fragment.getNextAnim(), fragment.getNextTransition(), false);
        if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
          paramArraySet.add(fragment); 
      } 
    } 
  }
  
  private void animateRemoveFragment(final Fragment fragment, AnimationOrAnimator paramAnimationOrAnimator, int paramInt) {
    EndViewTransitionAnimation endViewTransitionAnimation;
    final View viewToAnimate = fragment.mView;
    final ViewGroup container = fragment.mContainer;
    viewGroup.startViewTransition(view);
    fragment.setStateAfterAnimating(paramInt);
    if (paramAnimationOrAnimator.animation != null) {
      endViewTransitionAnimation = new EndViewTransitionAnimation(paramAnimationOrAnimator.animation, viewGroup, view);
      fragment.setAnimatingAway(fragment.mView);
      endViewTransitionAnimation.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationEnd(Animation param1Animation) {
              container.post(new Runnable() {
                    public void run() {
                      if (fragment.getAnimatingAway() != null) {
                        fragment.setAnimatingAway(null);
                        FragmentManagerImpl.this.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
                      } 
                    }
                  });
            }
            
            public void onAnimationRepeat(Animation param1Animation) {}
            
            public void onAnimationStart(Animation param1Animation) {}
          });
      fragment.mView.startAnimation((Animation)endViewTransitionAnimation);
      return;
    } 
    Animator animator = ((AnimationOrAnimator)endViewTransitionAnimation).animator;
    fragment.setAnimator(((AnimationOrAnimator)endViewTransitionAnimation).animator);
    animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
          public void onAnimationEnd(Animator param1Animator) {
            container.endViewTransition(viewToAnimate);
            param1Animator = fragment.getAnimator();
            fragment.setAnimator(null);
            if (param1Animator != null && container.indexOfChild(viewToAnimate) < 0) {
              FragmentManagerImpl fragmentManagerImpl = FragmentManagerImpl.this;
              Fragment fragment = fragment;
              fragmentManagerImpl.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
            } 
          }
        });
    animator.setTarget(fragment.mView);
    animator.start();
  }
  
  private void burpActive() {
    this.mActive.values().removeAll(Collections.singleton(null));
  }
  
  private void checkStateLoss() {
    if (!isStateSaved())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private void cleanupExec() {
    this.mExecutingActions = false;
    this.mTmpIsPop.clear();
    this.mTmpRecords.clear();
  }
  
  private void dispatchParentPrimaryNavigationFragmentChanged(Fragment paramFragment) {
    if (paramFragment != null && this.mActive.get(paramFragment.mWho) == paramFragment)
      paramFragment.performPrimaryNavigationFragmentChanged(); 
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.mExecutingActions = true;
      moveToState(paramInt, false);
      this.mExecutingActions = false;
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private void endAnimatingAwayFragments() {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null) {
        if (fragment.getAnimatingAway() != null) {
          int i = fragment.getStateAfterAnimating();
          View view = fragment.getAnimatingAway();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.setAnimatingAway(null);
          moveToState(fragment, i, 0, 0, false);
          continue;
        } 
        if (fragment.getAnimator() != null)
          fragment.getAnimator().end(); 
      } 
    } 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (!this.mExecutingActions) {
      if (this.mHost != null) {
        if (Looper.myLooper() == this.mHost.getHandler().getLooper()) {
          if (!paramBoolean)
            checkStateLoss(); 
          if (this.mTmpRecords == null) {
            this.mTmpRecords = new ArrayList<BackStackRecord>();
            this.mTmpIsPop = new ArrayList<Boolean>();
          } 
          this.mExecutingActions = true;
          try {
            executePostponedTransaction((ArrayList<BackStackRecord>)null, (ArrayList<Boolean>)null);
            return;
          } finally {
            this.mExecutingActions = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void executeOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        backStackRecord.bumpBackStackNesting(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        backStackRecord.executePopOps(bool);
      } else {
        backStackRecord.bumpBackStackNesting(1);
        backStackRecord.executeOps();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    int i = paramInt1;
    boolean bool1 = ((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed;
    ArrayList<Fragment> arrayList = this.mTmpAddedFragments;
    if (arrayList == null) {
      this.mTmpAddedFragments = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.mTmpAddedFragments.addAll(this.mAdded);
    Fragment fragment = getPrimaryNavigationFragment();
    int j = i;
    boolean bool = false;
    while (j < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(j);
      if (!((Boolean)paramArrayList1.get(j)).booleanValue()) {
        fragment = backStackRecord.expandOps(this.mTmpAddedFragments, fragment);
      } else {
        fragment = backStackRecord.trackAddedFragmentsInPop(this.mTmpAddedFragments, fragment);
      } 
      if (bool || backStackRecord.mAddToBackStack) {
        bool = true;
      } else {
        bool = false;
      } 
      j++;
    } 
    this.mTmpAddedFragments.clear();
    if (!bool1)
      FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (bool1) {
      ArraySet<Fragment> arraySet = new ArraySet();
      addAddedFragments(arraySet);
      j = postponePostponableTransactions(paramArrayList, paramArrayList1, paramInt1, paramInt2, arraySet);
      makeRemovedFragmentsInvisible(arraySet);
    } else {
      j = paramInt2;
    } 
    int k = i;
    if (j != i) {
      k = i;
      if (bool1) {
        FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, j, true);
        moveToState(this.mCurState, true);
        k = i;
      } 
    } 
    while (k < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(k);
      if (((Boolean)paramArrayList1.get(k)).booleanValue() && backStackRecord.mIndex >= 0) {
        freeBackStackIndex(backStackRecord.mIndex);
        backStackRecord.mIndex = -1;
      } 
      backStackRecord.runOnCommitRunnables();
      k++;
    } 
    if (bool)
      reportBackStackChanged(); 
  }
  
  private void executePostponedTransaction(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 16
    //   11: iconst_0
    //   12: istore_3
    //   13: goto -> 22
    //   16: aload #7
    //   18: invokevirtual size : ()I
    //   21: istore_3
    //   22: iconst_0
    //   23: istore #4
    //   25: iload_3
    //   26: istore #6
    //   28: iload #4
    //   30: iload #6
    //   32: if_icmpge -> 252
    //   35: aload_0
    //   36: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   39: iload #4
    //   41: invokevirtual get : (I)Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/FragmentManagerImpl$StartEnterTransitionListener
    //   47: astore #7
    //   49: aload_1
    //   50: ifnull -> 119
    //   53: aload #7
    //   55: getfield mIsBack : Z
    //   58: ifne -> 119
    //   61: aload_1
    //   62: aload #7
    //   64: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   67: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   70: istore_3
    //   71: iload_3
    //   72: iconst_m1
    //   73: if_icmpeq -> 119
    //   76: aload_2
    //   77: iload_3
    //   78: invokevirtual get : (I)Ljava/lang/Object;
    //   81: checkcast java/lang/Boolean
    //   84: invokevirtual booleanValue : ()Z
    //   87: ifeq -> 119
    //   90: aload_0
    //   91: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   94: iload #4
    //   96: invokevirtual remove : (I)Ljava/lang/Object;
    //   99: pop
    //   100: iload #4
    //   102: iconst_1
    //   103: isub
    //   104: istore #5
    //   106: iload #6
    //   108: iconst_1
    //   109: isub
    //   110: istore_3
    //   111: aload #7
    //   113: invokevirtual cancelTransaction : ()V
    //   116: goto -> 240
    //   119: aload #7
    //   121: invokevirtual isReady : ()Z
    //   124: ifne -> 162
    //   127: iload #6
    //   129: istore_3
    //   130: iload #4
    //   132: istore #5
    //   134: aload_1
    //   135: ifnull -> 240
    //   138: iload #6
    //   140: istore_3
    //   141: iload #4
    //   143: istore #5
    //   145: aload #7
    //   147: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   150: aload_1
    //   151: iconst_0
    //   152: aload_1
    //   153: invokevirtual size : ()I
    //   156: invokevirtual interactsWith : (Ljava/util/ArrayList;II)Z
    //   159: ifeq -> 240
    //   162: aload_0
    //   163: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   166: iload #4
    //   168: invokevirtual remove : (I)Ljava/lang/Object;
    //   171: pop
    //   172: iload #4
    //   174: iconst_1
    //   175: isub
    //   176: istore #5
    //   178: iload #6
    //   180: iconst_1
    //   181: isub
    //   182: istore_3
    //   183: aload_1
    //   184: ifnull -> 235
    //   187: aload #7
    //   189: getfield mIsBack : Z
    //   192: ifne -> 235
    //   195: aload_1
    //   196: aload #7
    //   198: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   201: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   204: istore #4
    //   206: iload #4
    //   208: iconst_m1
    //   209: if_icmpeq -> 235
    //   212: aload_2
    //   213: iload #4
    //   215: invokevirtual get : (I)Ljava/lang/Object;
    //   218: checkcast java/lang/Boolean
    //   221: invokevirtual booleanValue : ()Z
    //   224: ifeq -> 235
    //   227: aload #7
    //   229: invokevirtual cancelTransaction : ()V
    //   232: goto -> 240
    //   235: aload #7
    //   237: invokevirtual completeTransaction : ()V
    //   240: iload #5
    //   242: iconst_1
    //   243: iadd
    //   244: istore #4
    //   246: iload_3
    //   247: istore #6
    //   249: goto -> 28
    //   252: return
  }
  
  private Fragment findFragmentUnder(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    View view = paramFragment.mView;
    if (viewGroup != null) {
      if (view == null)
        return null; 
      for (int i = this.mAdded.indexOf(paramFragment) - 1; i >= 0; i--) {
        paramFragment = this.mAdded.get(i);
        if (paramFragment.mContainer == viewGroup && paramFragment.mView != null)
          return paramFragment; 
      } 
    } 
    return null;
  }
  
  private void forcePostponedTransactions() {
    if (this.mPostponedTransactions != null)
      while (!this.mPostponedTransactions.isEmpty())
        ((StartEnterTransitionListener)this.mPostponedTransactions.remove(0)).completeTransaction();  
  }
  
  private boolean generateOpsForPendingActions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mPendingActions : Ljava/util/ArrayList;
    //   6: astore #6
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #6
    //   12: ifnull -> 100
    //   15: aload #6
    //   17: invokevirtual size : ()I
    //   20: ifne -> 26
    //   23: goto -> 100
    //   26: aload_0
    //   27: getfield mPendingActions : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: istore #4
    //   35: iconst_0
    //   36: istore #5
    //   38: iload_3
    //   39: iload #4
    //   41: if_icmpge -> 74
    //   44: iload #5
    //   46: aload_0
    //   47: getfield mPendingActions : Ljava/util/ArrayList;
    //   50: iload_3
    //   51: invokevirtual get : (I)Ljava/lang/Object;
    //   54: checkcast androidx/fragment/app/FragmentManagerImpl$OpGenerator
    //   57: aload_1
    //   58: aload_2
    //   59: invokeinterface generateOps : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   64: ior
    //   65: istore #5
    //   67: iload_3
    //   68: iconst_1
    //   69: iadd
    //   70: istore_3
    //   71: goto -> 38
    //   74: aload_0
    //   75: getfield mPendingActions : Ljava/util/ArrayList;
    //   78: invokevirtual clear : ()V
    //   81: aload_0
    //   82: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   85: invokevirtual getHandler : ()Landroid/os/Handler;
    //   88: aload_0
    //   89: getfield mExecCommit : Ljava/lang/Runnable;
    //   92: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   95: aload_0
    //   96: monitorexit
    //   97: iload #5
    //   99: ireturn
    //   100: aload_0
    //   101: monitorexit
    //   102: iconst_0
    //   103: ireturn
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	104	finally
    //   15	23	104	finally
    //   26	35	104	finally
    //   44	67	104	finally
    //   74	97	104	finally
    //   100	102	104	finally
    //   105	107	104	finally
  }
  
  private boolean isMenuAvailable(Fragment paramFragment) {
    return ((paramFragment.mHasMenu && paramFragment.mMenuVisible) || paramFragment.mChildFragmentManager.checkForMenus());
  }
  
  static AnimationOrAnimator makeFadeAnimation(float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    return new AnimationOrAnimator((Animation)alphaAnimation);
  }
  
  static AnimationOrAnimator makeOpenCloseAnimation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(DECELERATE_QUINT);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new AnimationOrAnimator((Animation)animationSet);
  }
  
  private void makeRemovedFragmentsInvisible(ArraySet<Fragment> paramArraySet) {
    int j = paramArraySet.size();
    for (int i = 0; i < j; i++) {
      Fragment fragment = (Fragment)paramArraySet.valueAt(i);
      if (!fragment.mAdded) {
        View view = fragment.requireView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  private boolean popBackStackImmediate(String paramString, int paramInt1, int paramInt2) {
    execPendingActions();
    ensureExecReady(true);
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.getChildFragmentManager().popBackStackImmediate())
      return true; 
    boolean bool = popBackStackState(this.mTmpRecords, this.mTmpIsPop, paramString, paramInt1, paramInt2);
    if (bool) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  private int postponePostponableTransactions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, ArraySet<Fragment> paramArraySet) {
    int i = paramInt2 - 1;
    int j;
    for (j = paramInt2; i >= paramInt1; j = k) {
      boolean bool;
      BackStackRecord backStackRecord = paramArrayList.get(i);
      boolean bool1 = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (backStackRecord.isPostponed() && !backStackRecord.interactsWith(paramArrayList, i + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = j;
      if (bool) {
        if (this.mPostponedTransactions == null)
          this.mPostponedTransactions = new ArrayList<StartEnterTransitionListener>(); 
        StartEnterTransitionListener startEnterTransitionListener = new StartEnterTransitionListener(backStackRecord, bool1);
        this.mPostponedTransactions.add(startEnterTransitionListener);
        backStackRecord.setOnStartPostponedListener(startEnterTransitionListener);
        if (bool1) {
          backStackRecord.executeOps();
        } else {
          backStackRecord.executePopOps(false);
        } 
        k = j - 1;
        if (i != k) {
          paramArrayList.remove(i);
          paramArrayList.add(k, backStackRecord);
        } 
        addAddedFragments(paramArraySet);
      } 
      i--;
    } 
    return j;
  }
  
  private void removeRedundantOperationsAndExecute(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList != null) {
      if (paramArrayList.isEmpty())
        return; 
      if (paramArrayList1 != null && paramArrayList.size() == paramArrayList1.size()) {
        executePostponedTransaction(paramArrayList, paramArrayList1);
        int k = paramArrayList.size();
        int i = 0;
        int j;
        for (j = 0; i < k; j = m) {
          int n = i;
          int m = j;
          if (!((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed) {
            if (j != i)
              executeOpsTogether(paramArrayList, paramArrayList1, j, i); 
            j = i + 1;
            m = j;
            if (((Boolean)paramArrayList1.get(i)).booleanValue())
              while (true) {
                m = j;
                if (j < k) {
                  m = j;
                  if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                    m = j;
                    if (!((BackStackRecord)paramArrayList.get(j)).mReorderingAllowed) {
                      j++;
                      continue;
                    } 
                  } 
                } 
                break;
              }  
            executeOpsTogether(paramArrayList, paramArrayList1, i, m);
            n = m - 1;
          } 
          i = n + 1;
        } 
        if (j != k)
          executeOpsTogether(paramArrayList, paramArrayList1, j, k); 
        return;
      } 
      throw new IllegalStateException("Internal error with the back stack records");
    } 
  }
  
  public static int reverseTransit(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    FragmentHostCallback fragmentHostCallback = this.mHost;
    if (fragmentHostCallback != null) {
      try {
        fragmentHostCallback.onDump("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        dump("  ", (FileDescriptor)null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? 3 : 4)) : (paramBoolean ? 5 : 6)) : (paramBoolean ? 1 : 2);
  }
  
  private void updateOnBackPressedCallbackEnabled() {
    ArrayList<OpGenerator> arrayList = this.mPendingActions;
    boolean bool = true;
    if (arrayList != null && !arrayList.isEmpty()) {
      this.mOnBackPressedCallback.setEnabled(true);
      return;
    } 
    OnBackPressedCallback onBackPressedCallback = this.mOnBackPressedCallback;
    if (getBackStackEntryCount() <= 0 || !isPrimaryNavigation(this.mParent))
      bool = false; 
    onBackPressedCallback.setEnabled(bool);
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    makeActive(paramFragment);
    if (!paramFragment.mDetached)
      if (!this.mAdded.contains(paramFragment)) {
        synchronized (this.mAdded) {
          this.mAdded.add(paramFragment);
          paramFragment.mAdded = true;
          paramFragment.mRemoving = false;
          if (paramFragment.mView == null)
            paramFragment.mHiddenChanged = false; 
          if (isMenuAvailable(paramFragment))
            this.mNeedMenuInvalidate = true; 
          if (paramBoolean) {
            moveToState(paramFragment);
            return;
          } 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  void addRetainedFragment(Fragment paramFragment) {
    if (isStateSaved()) {
      if (DEBUG)
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.mNonConfig.addRetainedFragment(paramFragment) && DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 104
    //   11: aload_3
    //   12: invokevirtual size : ()I
    //   15: ifgt -> 21
    //   18: goto -> 104
    //   21: aload_0
    //   22: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   25: astore_3
    //   26: aload_3
    //   27: aload_3
    //   28: invokevirtual size : ()I
    //   31: iconst_1
    //   32: isub
    //   33: invokevirtual remove : (I)Ljava/lang/Object;
    //   36: checkcast java/lang/Integer
    //   39: invokevirtual intValue : ()I
    //   42: istore_2
    //   43: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   46: ifeq -> 90
    //   49: new java/lang/StringBuilder
    //   52: dup
    //   53: ldc_w 'Adding back stack index '
    //   56: invokespecial <init> : (Ljava/lang/String;)V
    //   59: astore_3
    //   60: aload_3
    //   61: iload_2
    //   62: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   65: pop
    //   66: aload_3
    //   67: ldc_w ' with '
    //   70: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: pop
    //   74: aload_3
    //   75: aload_1
    //   76: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   79: pop
    //   80: ldc 'FragmentManager'
    //   82: aload_3
    //   83: invokevirtual toString : ()Ljava/lang/String;
    //   86: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   89: pop
    //   90: aload_0
    //   91: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   94: iload_2
    //   95: aload_1
    //   96: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   99: pop
    //   100: aload_0
    //   101: monitorexit
    //   102: iload_2
    //   103: ireturn
    //   104: aload_0
    //   105: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   108: ifnonnull -> 122
    //   111: aload_0
    //   112: new java/util/ArrayList
    //   115: dup
    //   116: invokespecial <init> : ()V
    //   119: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   122: aload_0
    //   123: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   126: invokevirtual size : ()I
    //   129: istore_2
    //   130: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   133: ifeq -> 177
    //   136: new java/lang/StringBuilder
    //   139: dup
    //   140: ldc_w 'Setting back stack index '
    //   143: invokespecial <init> : (Ljava/lang/String;)V
    //   146: astore_3
    //   147: aload_3
    //   148: iload_2
    //   149: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   152: pop
    //   153: aload_3
    //   154: ldc_w ' to '
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: pop
    //   161: aload_3
    //   162: aload_1
    //   163: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   166: pop
    //   167: ldc 'FragmentManager'
    //   169: aload_3
    //   170: invokevirtual toString : ()Ljava/lang/String;
    //   173: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   176: pop
    //   177: aload_0
    //   178: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   181: aload_1
    //   182: invokevirtual add : (Ljava/lang/Object;)Z
    //   185: pop
    //   186: aload_0
    //   187: monitorexit
    //   188: iload_2
    //   189: ireturn
    //   190: astore_1
    //   191: aload_0
    //   192: monitorexit
    //   193: aload_1
    //   194: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	190	finally
    //   11	18	190	finally
    //   21	90	190	finally
    //   90	102	190	finally
    //   104	122	190	finally
    //   122	177	190	finally
    //   177	188	190	finally
    //   191	193	190	finally
  }
  
  public void attachController(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.mHost == null) {
      this.mHost = paramFragmentHostCallback;
      this.mContainer = paramFragmentContainer;
      this.mParent = paramFragment;
      if (paramFragment != null)
        updateOnBackPressedCallbackEnabled(); 
      if (paramFragmentHostCallback instanceof OnBackPressedDispatcherOwner) {
        Fragment fragment;
        OnBackPressedDispatcherOwner onBackPressedDispatcherOwner = (OnBackPressedDispatcherOwner)paramFragmentHostCallback;
        OnBackPressedDispatcher onBackPressedDispatcher = onBackPressedDispatcherOwner.getOnBackPressedDispatcher();
        this.mOnBackPressedDispatcher = onBackPressedDispatcher;
        if (paramFragment != null)
          fragment = paramFragment; 
        onBackPressedDispatcher.addCallback((LifecycleOwner)fragment, this.mOnBackPressedCallback);
      } 
      if (paramFragment != null) {
        this.mNonConfig = paramFragment.mFragmentManager.getChildNonConfig(paramFragment);
        return;
      } 
      if (paramFragmentHostCallback instanceof ViewModelStoreOwner) {
        this.mNonConfig = FragmentManagerViewModel.getInstance(((ViewModelStoreOwner)paramFragmentHostCallback).getViewModelStore());
        return;
      } 
      this.mNonConfig = new FragmentManagerViewModel(false);
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void attachFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded)
        if (!this.mAdded.contains(paramFragment)) {
          if (DEBUG) {
            StringBuilder stringBuilder = new StringBuilder("add from attach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.mAdded) {
            this.mAdded.add(paramFragment);
            paramFragment.mAdded = true;
            if (isMenuAvailable(paramFragment)) {
              this.mNeedMenuInvalidate = true;
              return;
            } 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder("Fragment already added: ");
          stringBuilder.append(paramFragment);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return (FragmentTransaction)new BackStackRecord(this);
  }
  
  boolean checkForMenus() {
    Iterator<Fragment> iterator = this.mActive.values().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = isMenuAvailable(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  void completeExecute(BackStackRecord paramBackStackRecord, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramBackStackRecord.executePopOps(paramBoolean3);
    } else {
      paramBackStackRecord.executeOps();
    } 
    ArrayList<BackStackRecord> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramBackStackRecord);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      FragmentTransition.startTransitions(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      moveToState(this.mCurState, true); 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && paramBackStackRecord.interactsWith(fragment.mContainerId)) {
        if (fragment.mPostponedAlpha > 0.0F)
          fragment.mView.setAlpha(fragment.mPostponedAlpha); 
        if (paramBoolean3) {
          fragment.mPostponedAlpha = 0.0F;
          continue;
        } 
        fragment.mPostponedAlpha = -1.0F;
        fragment.mIsNewlyAdded = false;
      } 
    } 
  }
  
  void completeShowHideFragment(final Fragment fragment) {
    if (fragment.mView != null) {
      AnimationOrAnimator animationOrAnimator = loadAnimation(fragment, fragment.getNextTransition(), fragment.mHidden ^ true, fragment.getNextTransitionStyle());
      if (animationOrAnimator != null && animationOrAnimator.animator != null) {
        animationOrAnimator.animator.setTarget(fragment.mView);
        if (fragment.mHidden) {
          if (fragment.isHideReplaced()) {
            fragment.setHideReplaced(false);
          } else {
            final ViewGroup container = fragment.mContainer;
            final View animatingView = fragment.mView;
            viewGroup.startViewTransition(view);
            animationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
                  public void onAnimationEnd(Animator param1Animator) {
                    container.endViewTransition(animatingView);
                    param1Animator.removeListener((Animator.AnimatorListener)this);
                    if (fragment.mView != null && fragment.mHidden)
                      fragment.mView.setVisibility(8); 
                  }
                });
          } 
        } else {
          fragment.mView.setVisibility(0);
        } 
        animationOrAnimator.animator.start();
      } else {
        boolean bool;
        if (animationOrAnimator != null) {
          fragment.mView.startAnimation(animationOrAnimator.animation);
          animationOrAnimator.animation.start();
        } 
        if (fragment.mHidden && !fragment.isHideReplaced()) {
          bool = true;
        } else {
          bool = false;
        } 
        fragment.mView.setVisibility(bool);
        if (fragment.isHideReplaced())
          fragment.setHideReplaced(false); 
      } 
    } 
    if (fragment.mAdded && isMenuAvailable(fragment))
      this.mNeedMenuInvalidate = true; 
    fragment.mHiddenChanged = false;
    fragment.onHiddenChanged(fragment.mHidden);
  }
  
  public void detachFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.mAdded) {
          this.mAdded.remove(paramFragment);
          if (isMenuAvailable(paramFragment))
            this.mNeedMenuInvalidate = true; 
          paramFragment.mAdded = false;
          return;
        } 
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(2);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchCreate() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(1);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i = this.mCurState;
    boolean bool1 = false;
    if (i < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    i = 0;
    boolean bool2;
    for (bool2 = false; i < this.mAdded.size(); bool2 = bool) {
      Fragment fragment = this.mAdded.get(i);
      ArrayList<Fragment> arrayList1 = arrayList;
      boolean bool = bool2;
      if (fragment != null) {
        arrayList1 = arrayList;
        bool = bool2;
        if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
          bool = true;
        } 
      } 
      i++;
      arrayList = arrayList1;
    } 
    if (this.mCreatedMenus != null)
      for (i = bool1; i < this.mCreatedMenus.size(); i++) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.mCreatedMenus = arrayList;
    return bool2;
  }
  
  public void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions();
    dispatchStateChange(0);
    this.mHost = null;
    this.mContainer = null;
    this.mParent = null;
    if (this.mOnBackPressedDispatcher != null) {
      this.mOnBackPressedCallback.remove();
      this.mOnBackPressedDispatcher = null;
    } 
  }
  
  public void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  public void dispatchLowMemory() {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  void dispatchOnFragmentActivityCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentActivityCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentActivityCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentAttached(paramFragment, paramContext, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentDestroyed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDestroyed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentDestroyed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentDetached(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDetached(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentDetached(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPaused(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPaused(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPaused(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPreAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreAttached(paramFragment, paramContext, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPreAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentPreCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPreCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentResumed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentResumed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentResumed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentSaveInstanceState(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentSaveInstanceState(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentSaveInstanceState(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentStarted(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStarted(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentStarted(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentStopped(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStopped(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentStopped(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentViewCreated(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewCreated(paramFragment, paramView, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentViewCreated(this, paramFragment, paramView, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentViewDestroyed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewDestroyed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentViewDestroyed(this, paramFragment); 
    } 
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.mCurState < 1)
      return; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  public void dispatchPause() {
    dispatchStateChange(3);
  }
  
  public void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    int j = this.mCurState;
    int i = 0;
    if (j < 1)
      return false; 
    boolean bool;
    for (bool = false; i < this.mAdded.size(); bool = bool1) {
      Fragment fragment = this.mAdded.get(i);
      boolean bool1 = bool;
      if (fragment != null) {
        bool1 = bool;
        if (fragment.performPrepareOptionsMenu(paramMenu))
          bool1 = true; 
      } 
      i++;
    } 
    return bool;
  }
  
  void dispatchPrimaryNavigationFragmentChanged() {
    updateOnBackPressedCallbackEnabled();
    dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
  }
  
  public void dispatchResume() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(4);
  }
  
  public void dispatchStart() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(3);
  }
  
  public void dispatchStop() {
    this.mStopped = true;
    dispatchStateChange(2);
  }
  
  void doPendingDeferredStart() {
    if (this.mHavePendingDeferredStart) {
      this.mHavePendingDeferredStart = false;
      startPendingDeferredFragments();
    } 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #8
    //   9: aload #8
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #8
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #8
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #8
    //   32: aload_0
    //   33: getfield mActive : Ljava/util/HashMap;
    //   36: invokevirtual isEmpty : ()Z
    //   39: ifne -> 138
    //   42: aload_3
    //   43: aload_1
    //   44: invokevirtual print : (Ljava/lang/String;)V
    //   47: aload_3
    //   48: ldc_w 'Active Fragments in '
    //   51: invokevirtual print : (Ljava/lang/String;)V
    //   54: aload_3
    //   55: aload_0
    //   56: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   59: invokestatic toHexString : (I)Ljava/lang/String;
    //   62: invokevirtual print : (Ljava/lang/String;)V
    //   65: aload_3
    //   66: ldc_w ':'
    //   69: invokevirtual println : (Ljava/lang/String;)V
    //   72: aload_0
    //   73: getfield mActive : Ljava/util/HashMap;
    //   76: invokevirtual values : ()Ljava/util/Collection;
    //   79: invokeinterface iterator : ()Ljava/util/Iterator;
    //   84: astore #9
    //   86: aload #9
    //   88: invokeinterface hasNext : ()Z
    //   93: ifeq -> 138
    //   96: aload #9
    //   98: invokeinterface next : ()Ljava/lang/Object;
    //   103: checkcast androidx/fragment/app/Fragment
    //   106: astore #10
    //   108: aload_3
    //   109: aload_1
    //   110: invokevirtual print : (Ljava/lang/String;)V
    //   113: aload_3
    //   114: aload #10
    //   116: invokevirtual println : (Ljava/lang/Object;)V
    //   119: aload #10
    //   121: ifnull -> 86
    //   124: aload #10
    //   126: aload #8
    //   128: aload_2
    //   129: aload_3
    //   130: aload #4
    //   132: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   135: goto -> 86
    //   138: aload_0
    //   139: getfield mAdded : Ljava/util/ArrayList;
    //   142: invokevirtual size : ()I
    //   145: istore #7
    //   147: iconst_0
    //   148: istore #6
    //   150: iload #7
    //   152: ifle -> 232
    //   155: aload_3
    //   156: aload_1
    //   157: invokevirtual print : (Ljava/lang/String;)V
    //   160: aload_3
    //   161: ldc_w 'Added Fragments:'
    //   164: invokevirtual println : (Ljava/lang/String;)V
    //   167: iconst_0
    //   168: istore #5
    //   170: iload #5
    //   172: iload #7
    //   174: if_icmpge -> 232
    //   177: aload_0
    //   178: getfield mAdded : Ljava/util/ArrayList;
    //   181: iload #5
    //   183: invokevirtual get : (I)Ljava/lang/Object;
    //   186: checkcast androidx/fragment/app/Fragment
    //   189: astore_2
    //   190: aload_3
    //   191: aload_1
    //   192: invokevirtual print : (Ljava/lang/String;)V
    //   195: aload_3
    //   196: ldc_w '  #'
    //   199: invokevirtual print : (Ljava/lang/String;)V
    //   202: aload_3
    //   203: iload #5
    //   205: invokevirtual print : (I)V
    //   208: aload_3
    //   209: ldc_w ': '
    //   212: invokevirtual print : (Ljava/lang/String;)V
    //   215: aload_3
    //   216: aload_2
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: invokevirtual println : (Ljava/lang/String;)V
    //   223: iload #5
    //   225: iconst_1
    //   226: iadd
    //   227: istore #5
    //   229: goto -> 170
    //   232: aload_0
    //   233: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   236: astore_2
    //   237: aload_2
    //   238: ifnull -> 329
    //   241: aload_2
    //   242: invokevirtual size : ()I
    //   245: istore #7
    //   247: iload #7
    //   249: ifle -> 329
    //   252: aload_3
    //   253: aload_1
    //   254: invokevirtual print : (Ljava/lang/String;)V
    //   257: aload_3
    //   258: ldc_w 'Fragments Created Menus:'
    //   261: invokevirtual println : (Ljava/lang/String;)V
    //   264: iconst_0
    //   265: istore #5
    //   267: iload #5
    //   269: iload #7
    //   271: if_icmpge -> 329
    //   274: aload_0
    //   275: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   278: iload #5
    //   280: invokevirtual get : (I)Ljava/lang/Object;
    //   283: checkcast androidx/fragment/app/Fragment
    //   286: astore_2
    //   287: aload_3
    //   288: aload_1
    //   289: invokevirtual print : (Ljava/lang/String;)V
    //   292: aload_3
    //   293: ldc_w '  #'
    //   296: invokevirtual print : (Ljava/lang/String;)V
    //   299: aload_3
    //   300: iload #5
    //   302: invokevirtual print : (I)V
    //   305: aload_3
    //   306: ldc_w ': '
    //   309: invokevirtual print : (Ljava/lang/String;)V
    //   312: aload_3
    //   313: aload_2
    //   314: invokevirtual toString : ()Ljava/lang/String;
    //   317: invokevirtual println : (Ljava/lang/String;)V
    //   320: iload #5
    //   322: iconst_1
    //   323: iadd
    //   324: istore #5
    //   326: goto -> 267
    //   329: aload_0
    //   330: getfield mBackStack : Ljava/util/ArrayList;
    //   333: astore_2
    //   334: aload_2
    //   335: ifnull -> 433
    //   338: aload_2
    //   339: invokevirtual size : ()I
    //   342: istore #7
    //   344: iload #7
    //   346: ifle -> 433
    //   349: aload_3
    //   350: aload_1
    //   351: invokevirtual print : (Ljava/lang/String;)V
    //   354: aload_3
    //   355: ldc_w 'Back Stack:'
    //   358: invokevirtual println : (Ljava/lang/String;)V
    //   361: iconst_0
    //   362: istore #5
    //   364: iload #5
    //   366: iload #7
    //   368: if_icmpge -> 433
    //   371: aload_0
    //   372: getfield mBackStack : Ljava/util/ArrayList;
    //   375: iload #5
    //   377: invokevirtual get : (I)Ljava/lang/Object;
    //   380: checkcast androidx/fragment/app/BackStackRecord
    //   383: astore_2
    //   384: aload_3
    //   385: aload_1
    //   386: invokevirtual print : (Ljava/lang/String;)V
    //   389: aload_3
    //   390: ldc_w '  #'
    //   393: invokevirtual print : (Ljava/lang/String;)V
    //   396: aload_3
    //   397: iload #5
    //   399: invokevirtual print : (I)V
    //   402: aload_3
    //   403: ldc_w ': '
    //   406: invokevirtual print : (Ljava/lang/String;)V
    //   409: aload_3
    //   410: aload_2
    //   411: invokevirtual toString : ()Ljava/lang/String;
    //   414: invokevirtual println : (Ljava/lang/String;)V
    //   417: aload_2
    //   418: aload #8
    //   420: aload_3
    //   421: invokevirtual dump : (Ljava/lang/String;Ljava/io/PrintWriter;)V
    //   424: iload #5
    //   426: iconst_1
    //   427: iadd
    //   428: istore #5
    //   430: goto -> 364
    //   433: aload_0
    //   434: monitorenter
    //   435: aload_0
    //   436: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   439: astore_2
    //   440: aload_2
    //   441: ifnull -> 529
    //   444: aload_2
    //   445: invokevirtual size : ()I
    //   448: istore #7
    //   450: iload #7
    //   452: ifle -> 529
    //   455: aload_3
    //   456: aload_1
    //   457: invokevirtual print : (Ljava/lang/String;)V
    //   460: aload_3
    //   461: ldc_w 'Back Stack Indices:'
    //   464: invokevirtual println : (Ljava/lang/String;)V
    //   467: iconst_0
    //   468: istore #5
    //   470: iload #5
    //   472: iload #7
    //   474: if_icmpge -> 529
    //   477: aload_0
    //   478: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   481: iload #5
    //   483: invokevirtual get : (I)Ljava/lang/Object;
    //   486: checkcast androidx/fragment/app/BackStackRecord
    //   489: astore_2
    //   490: aload_3
    //   491: aload_1
    //   492: invokevirtual print : (Ljava/lang/String;)V
    //   495: aload_3
    //   496: ldc_w '  #'
    //   499: invokevirtual print : (Ljava/lang/String;)V
    //   502: aload_3
    //   503: iload #5
    //   505: invokevirtual print : (I)V
    //   508: aload_3
    //   509: ldc_w ': '
    //   512: invokevirtual print : (Ljava/lang/String;)V
    //   515: aload_3
    //   516: aload_2
    //   517: invokevirtual println : (Ljava/lang/Object;)V
    //   520: iload #5
    //   522: iconst_1
    //   523: iadd
    //   524: istore #5
    //   526: goto -> 470
    //   529: aload_0
    //   530: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   533: astore_2
    //   534: aload_2
    //   535: ifnull -> 571
    //   538: aload_2
    //   539: invokevirtual size : ()I
    //   542: ifle -> 571
    //   545: aload_3
    //   546: aload_1
    //   547: invokevirtual print : (Ljava/lang/String;)V
    //   550: aload_3
    //   551: ldc_w 'mAvailBackStackIndices: '
    //   554: invokevirtual print : (Ljava/lang/String;)V
    //   557: aload_3
    //   558: aload_0
    //   559: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   562: invokevirtual toArray : ()[Ljava/lang/Object;
    //   565: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   568: invokevirtual println : (Ljava/lang/String;)V
    //   571: aload_0
    //   572: monitorexit
    //   573: aload_0
    //   574: getfield mPendingActions : Ljava/util/ArrayList;
    //   577: astore_2
    //   578: aload_2
    //   579: ifnull -> 668
    //   582: aload_2
    //   583: invokevirtual size : ()I
    //   586: istore #7
    //   588: iload #7
    //   590: ifle -> 668
    //   593: aload_3
    //   594: aload_1
    //   595: invokevirtual print : (Ljava/lang/String;)V
    //   598: aload_3
    //   599: ldc_w 'Pending Actions:'
    //   602: invokevirtual println : (Ljava/lang/String;)V
    //   605: iload #6
    //   607: istore #5
    //   609: iload #5
    //   611: iload #7
    //   613: if_icmpge -> 668
    //   616: aload_0
    //   617: getfield mPendingActions : Ljava/util/ArrayList;
    //   620: iload #5
    //   622: invokevirtual get : (I)Ljava/lang/Object;
    //   625: checkcast androidx/fragment/app/FragmentManagerImpl$OpGenerator
    //   628: astore_2
    //   629: aload_3
    //   630: aload_1
    //   631: invokevirtual print : (Ljava/lang/String;)V
    //   634: aload_3
    //   635: ldc_w '  #'
    //   638: invokevirtual print : (Ljava/lang/String;)V
    //   641: aload_3
    //   642: iload #5
    //   644: invokevirtual print : (I)V
    //   647: aload_3
    //   648: ldc_w ': '
    //   651: invokevirtual print : (Ljava/lang/String;)V
    //   654: aload_3
    //   655: aload_2
    //   656: invokevirtual println : (Ljava/lang/Object;)V
    //   659: iload #5
    //   661: iconst_1
    //   662: iadd
    //   663: istore #5
    //   665: goto -> 609
    //   668: aload_3
    //   669: aload_1
    //   670: invokevirtual print : (Ljava/lang/String;)V
    //   673: aload_3
    //   674: ldc_w 'FragmentManager misc state:'
    //   677: invokevirtual println : (Ljava/lang/String;)V
    //   680: aload_3
    //   681: aload_1
    //   682: invokevirtual print : (Ljava/lang/String;)V
    //   685: aload_3
    //   686: ldc_w '  mHost='
    //   689: invokevirtual print : (Ljava/lang/String;)V
    //   692: aload_3
    //   693: aload_0
    //   694: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   697: invokevirtual println : (Ljava/lang/Object;)V
    //   700: aload_3
    //   701: aload_1
    //   702: invokevirtual print : (Ljava/lang/String;)V
    //   705: aload_3
    //   706: ldc_w '  mContainer='
    //   709: invokevirtual print : (Ljava/lang/String;)V
    //   712: aload_3
    //   713: aload_0
    //   714: getfield mContainer : Landroidx/fragment/app/FragmentContainer;
    //   717: invokevirtual println : (Ljava/lang/Object;)V
    //   720: aload_0
    //   721: getfield mParent : Landroidx/fragment/app/Fragment;
    //   724: ifnull -> 747
    //   727: aload_3
    //   728: aload_1
    //   729: invokevirtual print : (Ljava/lang/String;)V
    //   732: aload_3
    //   733: ldc_w '  mParent='
    //   736: invokevirtual print : (Ljava/lang/String;)V
    //   739: aload_3
    //   740: aload_0
    //   741: getfield mParent : Landroidx/fragment/app/Fragment;
    //   744: invokevirtual println : (Ljava/lang/Object;)V
    //   747: aload_3
    //   748: aload_1
    //   749: invokevirtual print : (Ljava/lang/String;)V
    //   752: aload_3
    //   753: ldc_w '  mCurState='
    //   756: invokevirtual print : (Ljava/lang/String;)V
    //   759: aload_3
    //   760: aload_0
    //   761: getfield mCurState : I
    //   764: invokevirtual print : (I)V
    //   767: aload_3
    //   768: ldc_w ' mStateSaved='
    //   771: invokevirtual print : (Ljava/lang/String;)V
    //   774: aload_3
    //   775: aload_0
    //   776: getfield mStateSaved : Z
    //   779: invokevirtual print : (Z)V
    //   782: aload_3
    //   783: ldc_w ' mStopped='
    //   786: invokevirtual print : (Ljava/lang/String;)V
    //   789: aload_3
    //   790: aload_0
    //   791: getfield mStopped : Z
    //   794: invokevirtual print : (Z)V
    //   797: aload_3
    //   798: ldc_w ' mDestroyed='
    //   801: invokevirtual print : (Ljava/lang/String;)V
    //   804: aload_3
    //   805: aload_0
    //   806: getfield mDestroyed : Z
    //   809: invokevirtual println : (Z)V
    //   812: aload_0
    //   813: getfield mNeedMenuInvalidate : Z
    //   816: ifeq -> 839
    //   819: aload_3
    //   820: aload_1
    //   821: invokevirtual print : (Ljava/lang/String;)V
    //   824: aload_3
    //   825: ldc_w '  mNeedMenuInvalidate='
    //   828: invokevirtual print : (Ljava/lang/String;)V
    //   831: aload_3
    //   832: aload_0
    //   833: getfield mNeedMenuInvalidate : Z
    //   836: invokevirtual println : (Z)V
    //   839: return
    //   840: astore_1
    //   841: aload_0
    //   842: monitorexit
    //   843: aload_1
    //   844: athrow
    // Exception table:
    //   from	to	target	type
    //   435	440	840	finally
    //   444	450	840	finally
    //   455	467	840	finally
    //   477	520	840	finally
    //   529	534	840	finally
    //   538	571	840	finally
    //   571	573	840	finally
    //   841	843	840	finally
  }
  
  public void enqueueAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield mDestroyed : Z
    //   14: ifne -> 61
    //   17: aload_0
    //   18: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   21: ifnonnull -> 27
    //   24: goto -> 61
    //   27: aload_0
    //   28: getfield mPendingActions : Ljava/util/ArrayList;
    //   31: ifnonnull -> 45
    //   34: aload_0
    //   35: new java/util/ArrayList
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: putfield mPendingActions : Ljava/util/ArrayList;
    //   45: aload_0
    //   46: getfield mPendingActions : Ljava/util/ArrayList;
    //   49: aload_1
    //   50: invokevirtual add : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload_0
    //   55: invokevirtual scheduleCommit : ()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: iload_2
    //   62: ifeq -> 68
    //   65: aload_0
    //   66: monitorexit
    //   67: return
    //   68: new java/lang/IllegalStateException
    //   71: dup
    //   72: ldc_w 'Activity has been destroyed'
    //   75: invokespecial <init> : (Ljava/lang/String;)V
    //   78: athrow
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	79	finally
    //   27	45	79	finally
    //   45	60	79	finally
    //   65	67	79	finally
    //   68	79	79	finally
    //   80	82	79	finally
  }
  
  void ensureInflatedFragmentView(Fragment paramFragment) {
    if (paramFragment.mFromLayout && !paramFragment.mPerformedCreateView) {
      paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), null, paramFragment.mSavedFragmentState);
      if (paramFragment.mView != null) {
        paramFragment.mInnerView = paramFragment.mView;
        paramFragment.mView.setSaveFromParentEnabled(false);
        if (paramFragment.mHidden)
          paramFragment.mView.setVisibility(8); 
        paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
        dispatchOnFragmentViewCreated(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
        return;
      } 
      paramFragment.mInnerView = null;
    } 
  }
  
  public boolean execPendingActions() {
    ensureExecReady(true);
    boolean bool = false;
    while (generateOpsForPendingActions(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  public void execSingleAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.mHost == null || this.mDestroyed))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    updateOnBackPressedCallbackEnabled();
    doPendingDeferredStart();
    burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions();
    forcePostponedTransactions();
    return bool;
  }
  
  public Fragment findFragmentById(int paramInt) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    return null;
  }
  
  public Fragment findFragmentByTag(String paramString) {
    if (paramString != null)
      for (int i = this.mAdded.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    if (paramString != null)
      for (Fragment fragment : this.mActive.values()) {
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByWho(String paramString) {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null) {
        fragment = fragment.findFragmentByWho(paramString);
        if (fragment != null)
          return fragment; 
      } 
    } 
    return null;
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   33: ifeq -> 63
    //   36: new java/lang/StringBuilder
    //   39: dup
    //   40: ldc_w 'Freeing back stack index '
    //   43: invokespecial <init> : (Ljava/lang/String;)V
    //   46: astore_2
    //   47: aload_2
    //   48: iload_1
    //   49: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   52: pop
    //   53: ldc 'FragmentManager'
    //   55: aload_2
    //   56: invokevirtual toString : ()Ljava/lang/String;
    //   59: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   62: pop
    //   63: aload_0
    //   64: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   67: iload_1
    //   68: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   71: invokevirtual add : (Ljava/lang/Object;)Z
    //   74: pop
    //   75: aload_0
    //   76: monitorexit
    //   77: return
    //   78: astore_2
    //   79: aload_0
    //   80: monitorexit
    //   81: aload_2
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	78	finally
    //   30	63	78	finally
    //   63	77	78	finally
    //   79	81	78	finally
  }
  
  int getActiveFragmentCount() {
    return this.mActive.size();
  }
  
  List<Fragment> getActiveFragments() {
    return new ArrayList<Fragment>(this.mActive.values());
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return (FragmentManager.BackStackEntry)this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  FragmentManagerViewModel getChildNonConfig(Fragment paramFragment) {
    return this.mNonConfig.getChildNonConfig(paramFragment);
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    String str = paramBundle.getString(paramString);
    if (str == null)
      return null; 
    Fragment fragment = this.mActive.get(str);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": unique id ");
      stringBuilder.append(str);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public FragmentFactory getFragmentFactory() {
    if (super.getFragmentFactory() == DEFAULT_FACTORY) {
      Fragment fragment = this.mParent;
      if (fragment != null)
        return fragment.mFragmentManager.getFragmentFactory(); 
      setFragmentFactory(new FragmentFactory() {
            public Fragment instantiate(ClassLoader param1ClassLoader, String param1String) {
              return FragmentManagerImpl.this.mHost.instantiate(FragmentManagerImpl.this.mHost.getContext(), param1String, null);
            }
          });
    } 
    return super.getFragmentFactory();
  }
  
  public List<Fragment> getFragments() {
    if (this.mAdded.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.mAdded) {
      return (List)this.mAdded.clone();
    } 
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return this;
  }
  
  public Fragment getPrimaryNavigationFragment() {
    return this.mPrimaryNav;
  }
  
  ViewModelStore getViewModelStore(Fragment paramFragment) {
    return this.mNonConfig.getViewModelStore(paramFragment);
  }
  
  void handleOnBackPressed() {
    execPendingActions();
    if (this.mOnBackPressedCallback.isEnabled()) {
      popBackStackImmediate();
      return;
    } 
    this.mOnBackPressedDispatcher.onBackPressed();
  }
  
  public void hideFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
    } 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  boolean isPrimaryNavigation(Fragment paramFragment) {
    if (paramFragment == null)
      return true; 
    FragmentManagerImpl fragmentManagerImpl = paramFragment.mFragmentManager;
    return (paramFragment == fragmentManagerImpl.getPrimaryNavigationFragment() && isPrimaryNavigation(fragmentManagerImpl.mParent));
  }
  
  boolean isStateAtLeast(int paramInt) {
    return (this.mCurState >= paramInt);
  }
  
  public boolean isStateSaved() {
    return (this.mStateSaved || this.mStopped);
  }
  
  AnimationOrAnimator loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    int i = paramFragment.getNextAnim();
    boolean bool = false;
    paramFragment.setNextAnim(0);
    if (paramFragment.mContainer != null && paramFragment.mContainer.getLayoutTransition() != null)
      return null; 
    Animation animation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, i);
    if (animation != null)
      return new AnimationOrAnimator(animation); 
    Animator animator = paramFragment.onCreateAnimator(paramInt1, paramBoolean, i);
    if (animator != null)
      return new AnimationOrAnimator(animator); 
    if (i != 0) {
      boolean bool2 = "anim".equals(this.mHost.getContext().getResources().getResourceTypeName(i));
      boolean bool1 = bool;
      if (bool2)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
          if (animation1 != null)
            return new AnimationOrAnimator(animation1); 
          bool1 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool1 = bool;
        }  
      if (!bool1)
        try {
          animator = AnimatorInflater.loadAnimator(this.mHost.getContext(), i);
          if (animator != null)
            return new AnimationOrAnimator(animator); 
        } catch (RuntimeException runtimeException) {
          Animation animation1;
          if (!bool2) {
            animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
            if (animation1 != null)
              return new AnimationOrAnimator(animation1); 
          } else {
            throw animation1;
          } 
        }  
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        if (paramInt2 == 0 && this.mHost.onHasWindowAnimations()) {
          this.mHost.onGetWindowAnimations();
          return null;
        } 
        return null;
      case 6:
        return makeFadeAnimation(1.0F, 0.0F);
      case 5:
        return makeFadeAnimation(0.0F, 1.0F);
      case 4:
        return makeOpenCloseAnimation(1.0F, 1.075F, 1.0F, 0.0F);
      case 3:
        return makeOpenCloseAnimation(0.975F, 1.0F, 0.0F, 1.0F);
      case 2:
        return makeOpenCloseAnimation(1.0F, 0.975F, 1.0F, 0.0F);
      case 1:
        break;
    } 
    return makeOpenCloseAnimation(1.125F, 1.0F, 0.0F, 1.0F);
  }
  
  void makeActive(Fragment paramFragment) {
    if (this.mActive.get(paramFragment.mWho) != null)
      return; 
    this.mActive.put(paramFragment.mWho, paramFragment);
    if (paramFragment.mRetainInstanceChangedWhileDetached) {
      if (paramFragment.mRetainInstance) {
        addRetainedFragment(paramFragment);
      } else {
        removeRetainedFragment(paramFragment);
      } 
      paramFragment.mRetainInstanceChangedWhileDetached = false;
    } 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("Added fragment to active set ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void makeInactive(Fragment paramFragment) {
    if (this.mActive.get(paramFragment.mWho) == null)
      return; 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("Removed fragment from active set ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null && paramFragment.mWho.equals(fragment.mTargetWho)) {
        fragment.mTarget = paramFragment;
        fragment.mTargetWho = null;
      } 
    } 
    this.mActive.put(paramFragment.mWho, null);
    removeRetainedFragment(paramFragment);
    if (paramFragment.mTargetWho != null)
      paramFragment.mTarget = this.mActive.get(paramFragment.mTargetWho); 
    paramFragment.initState();
  }
  
  void moveFragmentToExpectedState(Fragment paramFragment) {
    if (paramFragment == null)
      return; 
    if (!this.mActive.containsKey(paramFragment.mWho)) {
      if (DEBUG) {
        StringBuilder stringBuilder = new StringBuilder("Ignoring moving ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(" to state ");
        stringBuilder.append(this.mCurState);
        stringBuilder.append("since it is not added to ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    int j = this.mCurState;
    int i = j;
    if (paramFragment.mRemoving)
      if (paramFragment.isInBackStack()) {
        i = Math.min(j, 1);
      } else {
        i = Math.min(j, 0);
      }  
    moveToState(paramFragment, i, paramFragment.getNextTransition(), paramFragment.getNextTransitionStyle(), false);
    if (paramFragment.mView != null) {
      Fragment fragment = findFragmentUnder(paramFragment);
      if (fragment != null) {
        View view = fragment.mView;
        ViewGroup viewGroup = paramFragment.mContainer;
        i = viewGroup.indexOfChild(view);
        j = viewGroup.indexOfChild(paramFragment.mView);
        if (j < i) {
          viewGroup.removeViewAt(j);
          viewGroup.addView(paramFragment.mView, i);
        } 
      } 
      if (paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
        if (paramFragment.mPostponedAlpha > 0.0F)
          paramFragment.mView.setAlpha(paramFragment.mPostponedAlpha); 
        paramFragment.mPostponedAlpha = 0.0F;
        paramFragment.mIsNewlyAdded = false;
        AnimationOrAnimator animationOrAnimator = loadAnimation(paramFragment, paramFragment.getNextTransition(), true, paramFragment.getNextTransitionStyle());
        if (animationOrAnimator != null)
          if (animationOrAnimator.animation != null) {
            paramFragment.mView.startAnimation(animationOrAnimator.animation);
          } else {
            animationOrAnimator.animator.setTarget(paramFragment.mView);
            animationOrAnimator.animator.start();
          }  
      } 
    } 
    if (paramFragment.mHiddenChanged)
      completeShowHideFragment(paramFragment); 
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    if (this.mHost != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.mCurState)
        return; 
      this.mCurState = paramInt;
      int i = this.mAdded.size();
      for (paramInt = 0; paramInt < i; paramInt++)
        moveFragmentToExpectedState(this.mAdded.get(paramInt)); 
      for (Fragment fragment : this.mActive.values()) {
        if (fragment != null && (fragment.mRemoving || fragment.mDetached) && !fragment.mIsNewlyAdded)
          moveFragmentToExpectedState(fragment); 
      } 
      startPendingDeferredFragments();
      if (this.mNeedMenuInvalidate) {
        FragmentHostCallback fragmentHostCallback = this.mHost;
        if (fragmentHostCallback != null && this.mCurState == 4) {
          fragmentHostCallback.onSupportInvalidateOptionsMenu();
          this.mNeedMenuInvalidate = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: istore #10
    //   6: iconst_1
    //   7: istore #9
    //   9: iconst_1
    //   10: istore #7
    //   12: iconst_1
    //   13: istore #8
    //   15: iload #10
    //   17: ifeq -> 33
    //   20: aload_1
    //   21: getfield mDetached : Z
    //   24: ifeq -> 30
    //   27: goto -> 33
    //   30: goto -> 47
    //   33: iload_2
    //   34: istore #6
    //   36: iload #6
    //   38: istore_2
    //   39: iload #6
    //   41: iconst_1
    //   42: if_icmple -> 47
    //   45: iconst_1
    //   46: istore_2
    //   47: iload_2
    //   48: istore #6
    //   50: aload_1
    //   51: getfield mRemoving : Z
    //   54: ifeq -> 94
    //   57: iload_2
    //   58: istore #6
    //   60: iload_2
    //   61: aload_1
    //   62: getfield mState : I
    //   65: if_icmple -> 94
    //   68: aload_1
    //   69: getfield mState : I
    //   72: ifne -> 88
    //   75: aload_1
    //   76: invokevirtual isInBackStack : ()Z
    //   79: ifeq -> 88
    //   82: iconst_1
    //   83: istore #6
    //   85: goto -> 94
    //   88: aload_1
    //   89: getfield mState : I
    //   92: istore #6
    //   94: iload #6
    //   96: istore_2
    //   97: aload_1
    //   98: getfield mDeferStart : Z
    //   101: ifeq -> 126
    //   104: iload #6
    //   106: istore_2
    //   107: aload_1
    //   108: getfield mState : I
    //   111: iconst_3
    //   112: if_icmpge -> 126
    //   115: iload #6
    //   117: istore_2
    //   118: iload #6
    //   120: iconst_2
    //   121: if_icmple -> 126
    //   124: iconst_2
    //   125: istore_2
    //   126: aload_1
    //   127: getfield mMaxState : Landroidx/lifecycle/Lifecycle$State;
    //   130: getstatic androidx/lifecycle/Lifecycle$State.CREATED : Landroidx/lifecycle/Lifecycle$State;
    //   133: if_acmpne -> 145
    //   136: iload_2
    //   137: iconst_1
    //   138: invokestatic min : (II)I
    //   141: istore_2
    //   142: goto -> 157
    //   145: iload_2
    //   146: aload_1
    //   147: getfield mMaxState : Landroidx/lifecycle/Lifecycle$State;
    //   150: invokevirtual ordinal : ()I
    //   153: invokestatic min : (II)I
    //   156: istore_2
    //   157: aload_1
    //   158: getfield mState : I
    //   161: iload_2
    //   162: if_icmpgt -> 1446
    //   165: aload_1
    //   166: getfield mFromLayout : Z
    //   169: ifeq -> 180
    //   172: aload_1
    //   173: getfield mInLayout : Z
    //   176: ifne -> 180
    //   179: return
    //   180: aload_1
    //   181: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   184: ifnonnull -> 194
    //   187: aload_1
    //   188: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   191: ifnull -> 216
    //   194: aload_1
    //   195: aconst_null
    //   196: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   199: aload_1
    //   200: aconst_null
    //   201: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   204: aload_0
    //   205: aload_1
    //   206: aload_1
    //   207: invokevirtual getStateAfterAnimating : ()I
    //   210: iconst_0
    //   211: iconst_0
    //   212: iconst_1
    //   213: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   216: aload_1
    //   217: getfield mState : I
    //   220: istore #6
    //   222: iload #6
    //   224: ifeq -> 264
    //   227: iload_2
    //   228: istore_3
    //   229: iload #6
    //   231: iconst_1
    //   232: if_icmpeq -> 867
    //   235: iload_2
    //   236: istore #4
    //   238: iload #6
    //   240: iconst_2
    //   241: if_icmpeq -> 261
    //   244: iload_2
    //   245: istore_3
    //   246: iload #6
    //   248: iconst_3
    //   249: if_icmpeq -> 258
    //   252: iload_2
    //   253: istore #6
    //   255: goto -> 2217
    //   258: goto -> 1376
    //   261: goto -> 1315
    //   264: iload_2
    //   265: istore_3
    //   266: iload_2
    //   267: ifle -> 867
    //   270: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   273: ifeq -> 306
    //   276: new java/lang/StringBuilder
    //   279: dup
    //   280: ldc_w 'moveto CREATED: '
    //   283: invokespecial <init> : (Ljava/lang/String;)V
    //   286: astore #11
    //   288: aload #11
    //   290: aload_1
    //   291: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   294: pop
    //   295: ldc 'FragmentManager'
    //   297: aload #11
    //   299: invokevirtual toString : ()Ljava/lang/String;
    //   302: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   305: pop
    //   306: iload_2
    //   307: istore_3
    //   308: aload_1
    //   309: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   312: ifnull -> 465
    //   315: aload_1
    //   316: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   319: aload_0
    //   320: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   323: invokevirtual getContext : ()Landroid/content/Context;
    //   326: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   329: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   332: aload_1
    //   333: aload_1
    //   334: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   337: ldc 'android:view_state'
    //   339: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   342: putfield mSavedViewState : Landroid/util/SparseArray;
    //   345: aload_0
    //   346: aload_1
    //   347: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   350: ldc 'android:target_state'
    //   352: invokevirtual getFragment : (Landroid/os/Bundle;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   355: astore #11
    //   357: aload #11
    //   359: ifnull -> 372
    //   362: aload #11
    //   364: getfield mWho : Ljava/lang/String;
    //   367: astore #11
    //   369: goto -> 375
    //   372: aconst_null
    //   373: astore #11
    //   375: aload_1
    //   376: aload #11
    //   378: putfield mTargetWho : Ljava/lang/String;
    //   381: aload_1
    //   382: getfield mTargetWho : Ljava/lang/String;
    //   385: ifnull -> 402
    //   388: aload_1
    //   389: aload_1
    //   390: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   393: ldc 'android:target_req_state'
    //   395: iconst_0
    //   396: invokevirtual getInt : (Ljava/lang/String;I)I
    //   399: putfield mTargetRequestCode : I
    //   402: aload_1
    //   403: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   406: ifnull -> 428
    //   409: aload_1
    //   410: aload_1
    //   411: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   414: invokevirtual booleanValue : ()Z
    //   417: putfield mUserVisibleHint : Z
    //   420: aload_1
    //   421: aconst_null
    //   422: putfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   425: goto -> 442
    //   428: aload_1
    //   429: aload_1
    //   430: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   433: ldc 'android:user_visible_hint'
    //   435: iconst_1
    //   436: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   439: putfield mUserVisibleHint : Z
    //   442: iload_2
    //   443: istore_3
    //   444: aload_1
    //   445: getfield mUserVisibleHint : Z
    //   448: ifne -> 465
    //   451: aload_1
    //   452: iconst_1
    //   453: putfield mDeferStart : Z
    //   456: iload_2
    //   457: istore_3
    //   458: iload_2
    //   459: iconst_2
    //   460: if_icmple -> 465
    //   463: iconst_2
    //   464: istore_3
    //   465: aload_1
    //   466: aload_0
    //   467: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   470: putfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   473: aload_1
    //   474: aload_0
    //   475: getfield mParent : Landroidx/fragment/app/Fragment;
    //   478: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   481: aload_0
    //   482: getfield mParent : Landroidx/fragment/app/Fragment;
    //   485: astore #11
    //   487: aload #11
    //   489: ifnull -> 502
    //   492: aload #11
    //   494: getfield mChildFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   497: astore #11
    //   499: goto -> 511
    //   502: aload_0
    //   503: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   506: getfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   509: astore #11
    //   511: aload_1
    //   512: aload #11
    //   514: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   517: aload_1
    //   518: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   521: ifnull -> 650
    //   524: aload_0
    //   525: getfield mActive : Ljava/util/HashMap;
    //   528: aload_1
    //   529: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   532: getfield mWho : Ljava/lang/String;
    //   535: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   538: aload_1
    //   539: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   542: if_acmpne -> 590
    //   545: aload_1
    //   546: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   549: getfield mState : I
    //   552: iconst_1
    //   553: if_icmpge -> 571
    //   556: aload_0
    //   557: aload_1
    //   558: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   561: iconst_1
    //   562: iconst_0
    //   563: iconst_0
    //   564: iconst_1
    //   565: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   568: goto -> 571
    //   571: aload_1
    //   572: aload_1
    //   573: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   576: getfield mWho : Ljava/lang/String;
    //   579: putfield mTargetWho : Ljava/lang/String;
    //   582: aload_1
    //   583: aconst_null
    //   584: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   587: goto -> 650
    //   590: new java/lang/StringBuilder
    //   593: dup
    //   594: ldc_w 'Fragment '
    //   597: invokespecial <init> : (Ljava/lang/String;)V
    //   600: astore #11
    //   602: aload #11
    //   604: aload_1
    //   605: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   608: pop
    //   609: aload #11
    //   611: ldc_w ' declared target fragment '
    //   614: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   617: pop
    //   618: aload #11
    //   620: aload_1
    //   621: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   624: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   627: pop
    //   628: aload #11
    //   630: ldc_w ' that does not belong to this FragmentManager!'
    //   633: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   636: pop
    //   637: new java/lang/IllegalStateException
    //   640: dup
    //   641: aload #11
    //   643: invokevirtual toString : ()Ljava/lang/String;
    //   646: invokespecial <init> : (Ljava/lang/String;)V
    //   649: athrow
    //   650: aload_1
    //   651: getfield mTargetWho : Ljava/lang/String;
    //   654: ifnull -> 760
    //   657: aload_0
    //   658: getfield mActive : Ljava/util/HashMap;
    //   661: aload_1
    //   662: getfield mTargetWho : Ljava/lang/String;
    //   665: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   668: checkcast androidx/fragment/app/Fragment
    //   671: astore #11
    //   673: aload #11
    //   675: ifnull -> 700
    //   678: aload #11
    //   680: getfield mState : I
    //   683: iconst_1
    //   684: if_icmpge -> 760
    //   687: aload_0
    //   688: aload #11
    //   690: iconst_1
    //   691: iconst_0
    //   692: iconst_0
    //   693: iconst_1
    //   694: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   697: goto -> 760
    //   700: new java/lang/StringBuilder
    //   703: dup
    //   704: ldc_w 'Fragment '
    //   707: invokespecial <init> : (Ljava/lang/String;)V
    //   710: astore #11
    //   712: aload #11
    //   714: aload_1
    //   715: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   718: pop
    //   719: aload #11
    //   721: ldc_w ' declared target fragment '
    //   724: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   727: pop
    //   728: aload #11
    //   730: aload_1
    //   731: getfield mTargetWho : Ljava/lang/String;
    //   734: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   737: pop
    //   738: aload #11
    //   740: ldc_w ' that does not belong to this FragmentManager!'
    //   743: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   746: pop
    //   747: new java/lang/IllegalStateException
    //   750: dup
    //   751: aload #11
    //   753: invokevirtual toString : ()Ljava/lang/String;
    //   756: invokespecial <init> : (Ljava/lang/String;)V
    //   759: athrow
    //   760: aload_0
    //   761: aload_1
    //   762: aload_0
    //   763: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   766: invokevirtual getContext : ()Landroid/content/Context;
    //   769: iconst_0
    //   770: invokevirtual dispatchOnFragmentPreAttached : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   773: aload_1
    //   774: invokevirtual performAttach : ()V
    //   777: aload_1
    //   778: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   781: ifnonnull -> 795
    //   784: aload_0
    //   785: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   788: aload_1
    //   789: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   792: goto -> 803
    //   795: aload_1
    //   796: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   799: aload_1
    //   800: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   803: aload_0
    //   804: aload_1
    //   805: aload_0
    //   806: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   809: invokevirtual getContext : ()Landroid/content/Context;
    //   812: iconst_0
    //   813: invokevirtual dispatchOnFragmentAttached : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   816: aload_1
    //   817: getfield mIsCreated : Z
    //   820: ifne -> 854
    //   823: aload_0
    //   824: aload_1
    //   825: aload_1
    //   826: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   829: iconst_0
    //   830: invokevirtual dispatchOnFragmentPreCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   833: aload_1
    //   834: aload_1
    //   835: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   838: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   841: aload_0
    //   842: aload_1
    //   843: aload_1
    //   844: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   847: iconst_0
    //   848: invokevirtual dispatchOnFragmentCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   851: goto -> 867
    //   854: aload_1
    //   855: aload_1
    //   856: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   859: invokevirtual restoreChildFragmentState : (Landroid/os/Bundle;)V
    //   862: aload_1
    //   863: iconst_1
    //   864: putfield mState : I
    //   867: iload_3
    //   868: ifle -> 876
    //   871: aload_0
    //   872: aload_1
    //   873: invokevirtual ensureInflatedFragmentView : (Landroidx/fragment/app/Fragment;)V
    //   876: iload_3
    //   877: istore #4
    //   879: iload_3
    //   880: iconst_1
    //   881: if_icmple -> 261
    //   884: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   887: ifeq -> 920
    //   890: new java/lang/StringBuilder
    //   893: dup
    //   894: ldc_w 'moveto ACTIVITY_CREATED: '
    //   897: invokespecial <init> : (Ljava/lang/String;)V
    //   900: astore #11
    //   902: aload #11
    //   904: aload_1
    //   905: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   908: pop
    //   909: ldc 'FragmentManager'
    //   911: aload #11
    //   913: invokevirtual toString : ()Ljava/lang/String;
    //   916: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   919: pop
    //   920: aload_1
    //   921: getfield mFromLayout : Z
    //   924: ifne -> 1271
    //   927: aload_1
    //   928: getfield mContainerId : I
    //   931: ifeq -> 1124
    //   934: aload_1
    //   935: getfield mContainerId : I
    //   938: iconst_m1
    //   939: if_icmpne -> 986
    //   942: new java/lang/StringBuilder
    //   945: dup
    //   946: ldc_w 'Cannot create fragment '
    //   949: invokespecial <init> : (Ljava/lang/String;)V
    //   952: astore #11
    //   954: aload #11
    //   956: aload_1
    //   957: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   960: pop
    //   961: aload #11
    //   963: ldc_w ' for a container view with no id'
    //   966: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   969: pop
    //   970: aload_0
    //   971: new java/lang/IllegalArgumentException
    //   974: dup
    //   975: aload #11
    //   977: invokevirtual toString : ()Ljava/lang/String;
    //   980: invokespecial <init> : (Ljava/lang/String;)V
    //   983: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   986: aload_0
    //   987: getfield mContainer : Landroidx/fragment/app/FragmentContainer;
    //   990: aload_1
    //   991: getfield mContainerId : I
    //   994: invokevirtual onFindViewById : (I)Landroid/view/View;
    //   997: checkcast android/view/ViewGroup
    //   1000: astore #12
    //   1002: aload #12
    //   1004: astore #11
    //   1006: aload #12
    //   1008: ifnonnull -> 1127
    //   1011: aload #12
    //   1013: astore #11
    //   1015: aload_1
    //   1016: getfield mRestored : Z
    //   1019: ifne -> 1127
    //   1022: aload_1
    //   1023: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1026: aload_1
    //   1027: getfield mContainerId : I
    //   1030: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   1033: astore #11
    //   1035: goto -> 1043
    //   1038: ldc_w 'unknown'
    //   1041: astore #11
    //   1043: new java/lang/StringBuilder
    //   1046: dup
    //   1047: ldc_w 'No view found for id 0x'
    //   1050: invokespecial <init> : (Ljava/lang/String;)V
    //   1053: astore #13
    //   1055: aload #13
    //   1057: aload_1
    //   1058: getfield mContainerId : I
    //   1061: invokestatic toHexString : (I)Ljava/lang/String;
    //   1064: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1067: pop
    //   1068: aload #13
    //   1070: ldc_w ' ('
    //   1073: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1076: pop
    //   1077: aload #13
    //   1079: aload #11
    //   1081: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1084: pop
    //   1085: aload #13
    //   1087: ldc_w ') for fragment '
    //   1090: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1093: pop
    //   1094: aload #13
    //   1096: aload_1
    //   1097: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1100: pop
    //   1101: aload_0
    //   1102: new java/lang/IllegalArgumentException
    //   1105: dup
    //   1106: aload #13
    //   1108: invokevirtual toString : ()Ljava/lang/String;
    //   1111: invokespecial <init> : (Ljava/lang/String;)V
    //   1114: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   1117: aload #12
    //   1119: astore #11
    //   1121: goto -> 1127
    //   1124: aconst_null
    //   1125: astore #11
    //   1127: aload_1
    //   1128: aload #11
    //   1130: putfield mContainer : Landroid/view/ViewGroup;
    //   1133: aload_1
    //   1134: aload_1
    //   1135: aload_1
    //   1136: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1139: invokevirtual performGetLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   1142: aload #11
    //   1144: aload_1
    //   1145: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1148: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   1151: aload_1
    //   1152: getfield mView : Landroid/view/View;
    //   1155: ifnull -> 1266
    //   1158: aload_1
    //   1159: aload_1
    //   1160: getfield mView : Landroid/view/View;
    //   1163: putfield mInnerView : Landroid/view/View;
    //   1166: aload_1
    //   1167: getfield mView : Landroid/view/View;
    //   1170: iconst_0
    //   1171: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1174: aload #11
    //   1176: ifnull -> 1188
    //   1179: aload #11
    //   1181: aload_1
    //   1182: getfield mView : Landroid/view/View;
    //   1185: invokevirtual addView : (Landroid/view/View;)V
    //   1188: aload_1
    //   1189: getfield mHidden : Z
    //   1192: ifeq -> 1204
    //   1195: aload_1
    //   1196: getfield mView : Landroid/view/View;
    //   1199: bipush #8
    //   1201: invokevirtual setVisibility : (I)V
    //   1204: aload_1
    //   1205: aload_1
    //   1206: getfield mView : Landroid/view/View;
    //   1209: aload_1
    //   1210: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1213: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1216: aload_0
    //   1217: aload_1
    //   1218: aload_1
    //   1219: getfield mView : Landroid/view/View;
    //   1222: aload_1
    //   1223: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1226: iconst_0
    //   1227: invokevirtual dispatchOnFragmentViewCreated : (Landroidx/fragment/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1230: aload_1
    //   1231: getfield mView : Landroid/view/View;
    //   1234: invokevirtual getVisibility : ()I
    //   1237: ifne -> 1254
    //   1240: aload_1
    //   1241: getfield mContainer : Landroid/view/ViewGroup;
    //   1244: ifnull -> 1254
    //   1247: iload #8
    //   1249: istore #5
    //   1251: goto -> 1257
    //   1254: iconst_0
    //   1255: istore #5
    //   1257: aload_1
    //   1258: iload #5
    //   1260: putfield mIsNewlyAdded : Z
    //   1263: goto -> 1271
    //   1266: aload_1
    //   1267: aconst_null
    //   1268: putfield mInnerView : Landroid/view/View;
    //   1271: aload_1
    //   1272: aload_1
    //   1273: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1276: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   1279: aload_0
    //   1280: aload_1
    //   1281: aload_1
    //   1282: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1285: iconst_0
    //   1286: invokevirtual dispatchOnFragmentActivityCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   1289: aload_1
    //   1290: getfield mView : Landroid/view/View;
    //   1293: ifnull -> 1304
    //   1296: aload_1
    //   1297: aload_1
    //   1298: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1301: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   1304: aload_1
    //   1305: aconst_null
    //   1306: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1309: iload_3
    //   1310: istore #4
    //   1312: goto -> 261
    //   1315: iload #4
    //   1317: istore_3
    //   1318: iload #4
    //   1320: iconst_2
    //   1321: if_icmple -> 258
    //   1324: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1327: ifeq -> 1360
    //   1330: new java/lang/StringBuilder
    //   1333: dup
    //   1334: ldc_w 'moveto STARTED: '
    //   1337: invokespecial <init> : (Ljava/lang/String;)V
    //   1340: astore #11
    //   1342: aload #11
    //   1344: aload_1
    //   1345: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1348: pop
    //   1349: ldc 'FragmentManager'
    //   1351: aload #11
    //   1353: invokevirtual toString : ()Ljava/lang/String;
    //   1356: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1359: pop
    //   1360: aload_1
    //   1361: invokevirtual performStart : ()V
    //   1364: aload_0
    //   1365: aload_1
    //   1366: iconst_0
    //   1367: invokevirtual dispatchOnFragmentStarted : (Landroidx/fragment/app/Fragment;Z)V
    //   1370: iload #4
    //   1372: istore_3
    //   1373: goto -> 258
    //   1376: iload_3
    //   1377: istore #6
    //   1379: iload_3
    //   1380: iconst_3
    //   1381: if_icmple -> 2217
    //   1384: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1387: ifeq -> 1420
    //   1390: new java/lang/StringBuilder
    //   1393: dup
    //   1394: ldc_w 'moveto RESUMED: '
    //   1397: invokespecial <init> : (Ljava/lang/String;)V
    //   1400: astore #11
    //   1402: aload #11
    //   1404: aload_1
    //   1405: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1408: pop
    //   1409: ldc 'FragmentManager'
    //   1411: aload #11
    //   1413: invokevirtual toString : ()Ljava/lang/String;
    //   1416: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1419: pop
    //   1420: aload_1
    //   1421: invokevirtual performResume : ()V
    //   1424: aload_0
    //   1425: aload_1
    //   1426: iconst_0
    //   1427: invokevirtual dispatchOnFragmentResumed : (Landroidx/fragment/app/Fragment;Z)V
    //   1430: aload_1
    //   1431: aconst_null
    //   1432: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1435: aload_1
    //   1436: aconst_null
    //   1437: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1440: iload_3
    //   1441: istore #6
    //   1443: goto -> 2217
    //   1446: iload_2
    //   1447: istore #6
    //   1449: aload_1
    //   1450: getfield mState : I
    //   1453: iload_2
    //   1454: if_icmple -> 2217
    //   1457: aload_1
    //   1458: getfield mState : I
    //   1461: istore #6
    //   1463: iload #6
    //   1465: iconst_1
    //   1466: if_icmpeq -> 1837
    //   1469: iload #6
    //   1471: iconst_2
    //   1472: if_icmpeq -> 1595
    //   1475: iload #6
    //   1477: iconst_3
    //   1478: if_icmpeq -> 1544
    //   1481: iload #6
    //   1483: iconst_4
    //   1484: if_icmpeq -> 1493
    //   1487: iload_2
    //   1488: istore #6
    //   1490: goto -> 2217
    //   1493: iload_2
    //   1494: iconst_4
    //   1495: if_icmpge -> 1544
    //   1498: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1501: ifeq -> 1534
    //   1504: new java/lang/StringBuilder
    //   1507: dup
    //   1508: ldc_w 'movefrom RESUMED: '
    //   1511: invokespecial <init> : (Ljava/lang/String;)V
    //   1514: astore #11
    //   1516: aload #11
    //   1518: aload_1
    //   1519: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1522: pop
    //   1523: ldc 'FragmentManager'
    //   1525: aload #11
    //   1527: invokevirtual toString : ()Ljava/lang/String;
    //   1530: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1533: pop
    //   1534: aload_1
    //   1535: invokevirtual performPause : ()V
    //   1538: aload_0
    //   1539: aload_1
    //   1540: iconst_0
    //   1541: invokevirtual dispatchOnFragmentPaused : (Landroidx/fragment/app/Fragment;Z)V
    //   1544: iload_2
    //   1545: iconst_3
    //   1546: if_icmpge -> 1595
    //   1549: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1552: ifeq -> 1585
    //   1555: new java/lang/StringBuilder
    //   1558: dup
    //   1559: ldc_w 'movefrom STARTED: '
    //   1562: invokespecial <init> : (Ljava/lang/String;)V
    //   1565: astore #11
    //   1567: aload #11
    //   1569: aload_1
    //   1570: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1573: pop
    //   1574: ldc 'FragmentManager'
    //   1576: aload #11
    //   1578: invokevirtual toString : ()Ljava/lang/String;
    //   1581: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1584: pop
    //   1585: aload_1
    //   1586: invokevirtual performStop : ()V
    //   1589: aload_0
    //   1590: aload_1
    //   1591: iconst_0
    //   1592: invokevirtual dispatchOnFragmentStopped : (Landroidx/fragment/app/Fragment;Z)V
    //   1595: iload_2
    //   1596: iconst_2
    //   1597: if_icmpge -> 1837
    //   1600: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1603: ifeq -> 1636
    //   1606: new java/lang/StringBuilder
    //   1609: dup
    //   1610: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1613: invokespecial <init> : (Ljava/lang/String;)V
    //   1616: astore #11
    //   1618: aload #11
    //   1620: aload_1
    //   1621: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1624: pop
    //   1625: ldc 'FragmentManager'
    //   1627: aload #11
    //   1629: invokevirtual toString : ()Ljava/lang/String;
    //   1632: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1635: pop
    //   1636: aload_1
    //   1637: getfield mView : Landroid/view/View;
    //   1640: ifnull -> 1666
    //   1643: aload_0
    //   1644: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   1647: aload_1
    //   1648: invokevirtual onShouldSaveFragmentState : (Landroidx/fragment/app/Fragment;)Z
    //   1651: ifeq -> 1666
    //   1654: aload_1
    //   1655: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1658: ifnonnull -> 1666
    //   1661: aload_0
    //   1662: aload_1
    //   1663: invokevirtual saveFragmentViewState : (Landroidx/fragment/app/Fragment;)V
    //   1666: aload_1
    //   1667: invokevirtual performDestroyView : ()V
    //   1670: aload_0
    //   1671: aload_1
    //   1672: iconst_0
    //   1673: invokevirtual dispatchOnFragmentViewDestroyed : (Landroidx/fragment/app/Fragment;Z)V
    //   1676: aload_1
    //   1677: getfield mView : Landroid/view/View;
    //   1680: ifnull -> 1804
    //   1683: aload_1
    //   1684: getfield mContainer : Landroid/view/ViewGroup;
    //   1687: ifnull -> 1804
    //   1690: aload_1
    //   1691: getfield mContainer : Landroid/view/ViewGroup;
    //   1694: aload_1
    //   1695: getfield mView : Landroid/view/View;
    //   1698: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1701: aload_1
    //   1702: getfield mView : Landroid/view/View;
    //   1705: invokevirtual clearAnimation : ()V
    //   1708: aload_1
    //   1709: invokevirtual getParentFragment : ()Landroidx/fragment/app/Fragment;
    //   1712: ifnull -> 1725
    //   1715: aload_1
    //   1716: invokevirtual getParentFragment : ()Landroidx/fragment/app/Fragment;
    //   1719: getfield mRemoving : Z
    //   1722: ifne -> 1804
    //   1725: aload_0
    //   1726: getfield mCurState : I
    //   1729: ifle -> 1772
    //   1732: aload_0
    //   1733: getfield mDestroyed : Z
    //   1736: ifne -> 1772
    //   1739: aload_1
    //   1740: getfield mView : Landroid/view/View;
    //   1743: invokevirtual getVisibility : ()I
    //   1746: ifne -> 1772
    //   1749: aload_1
    //   1750: getfield mPostponedAlpha : F
    //   1753: fconst_0
    //   1754: fcmpl
    //   1755: iflt -> 1772
    //   1758: aload_0
    //   1759: aload_1
    //   1760: iload_3
    //   1761: iconst_0
    //   1762: iload #4
    //   1764: invokevirtual loadAnimation : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/FragmentManagerImpl$AnimationOrAnimator;
    //   1767: astore #11
    //   1769: goto -> 1775
    //   1772: aconst_null
    //   1773: astore #11
    //   1775: aload_1
    //   1776: fconst_0
    //   1777: putfield mPostponedAlpha : F
    //   1780: aload #11
    //   1782: ifnull -> 1793
    //   1785: aload_0
    //   1786: aload_1
    //   1787: aload #11
    //   1789: iload_2
    //   1790: invokespecial animateRemoveFragment : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/FragmentManagerImpl$AnimationOrAnimator;I)V
    //   1793: aload_1
    //   1794: getfield mContainer : Landroid/view/ViewGroup;
    //   1797: aload_1
    //   1798: getfield mView : Landroid/view/View;
    //   1801: invokevirtual removeView : (Landroid/view/View;)V
    //   1804: aload_1
    //   1805: aconst_null
    //   1806: putfield mContainer : Landroid/view/ViewGroup;
    //   1809: aload_1
    //   1810: aconst_null
    //   1811: putfield mView : Landroid/view/View;
    //   1814: aload_1
    //   1815: aconst_null
    //   1816: putfield mViewLifecycleOwner : Landroidx/fragment/app/FragmentViewLifecycleOwner;
    //   1819: aload_1
    //   1820: getfield mViewLifecycleOwnerLiveData : Landroidx/lifecycle/MutableLiveData;
    //   1823: aconst_null
    //   1824: invokevirtual setValue : (Ljava/lang/Object;)V
    //   1827: aload_1
    //   1828: aconst_null
    //   1829: putfield mInnerView : Landroid/view/View;
    //   1832: aload_1
    //   1833: iconst_0
    //   1834: putfield mInLayout : Z
    //   1837: iload_2
    //   1838: istore #6
    //   1840: iload_2
    //   1841: iconst_1
    //   1842: if_icmpge -> 2217
    //   1845: aload_0
    //   1846: getfield mDestroyed : Z
    //   1849: ifeq -> 1901
    //   1852: aload_1
    //   1853: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1856: ifnull -> 1878
    //   1859: aload_1
    //   1860: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1863: astore #11
    //   1865: aload_1
    //   1866: aconst_null
    //   1867: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   1870: aload #11
    //   1872: invokevirtual clearAnimation : ()V
    //   1875: goto -> 1901
    //   1878: aload_1
    //   1879: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1882: ifnull -> 1901
    //   1885: aload_1
    //   1886: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1889: astore #11
    //   1891: aload_1
    //   1892: aconst_null
    //   1893: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   1896: aload #11
    //   1898: invokevirtual cancel : ()V
    //   1901: aload_1
    //   1902: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1905: ifnonnull -> 2205
    //   1908: aload_1
    //   1909: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1912: ifnull -> 1918
    //   1915: goto -> 2205
    //   1918: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1921: ifeq -> 1954
    //   1924: new java/lang/StringBuilder
    //   1927: dup
    //   1928: ldc_w 'movefrom CREATED: '
    //   1931: invokespecial <init> : (Ljava/lang/String;)V
    //   1934: astore #11
    //   1936: aload #11
    //   1938: aload_1
    //   1939: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1942: pop
    //   1943: ldc 'FragmentManager'
    //   1945: aload #11
    //   1947: invokevirtual toString : ()Ljava/lang/String;
    //   1950: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1953: pop
    //   1954: aload_1
    //   1955: getfield mRemoving : Z
    //   1958: ifeq -> 1973
    //   1961: aload_1
    //   1962: invokevirtual isInBackStack : ()Z
    //   1965: ifne -> 1973
    //   1968: iconst_1
    //   1969: istore_3
    //   1970: goto -> 1975
    //   1973: iconst_0
    //   1974: istore_3
    //   1975: iload_3
    //   1976: ifne -> 2001
    //   1979: aload_0
    //   1980: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   1983: aload_1
    //   1984: invokevirtual shouldDestroy : (Landroidx/fragment/app/Fragment;)Z
    //   1987: ifeq -> 1993
    //   1990: goto -> 2001
    //   1993: aload_1
    //   1994: iconst_0
    //   1995: putfield mState : I
    //   1998: goto -> 2086
    //   2001: aload_0
    //   2002: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2005: astore #11
    //   2007: aload #11
    //   2009: instanceof androidx/lifecycle/ViewModelStoreOwner
    //   2012: ifeq -> 2027
    //   2015: aload_0
    //   2016: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2019: invokevirtual isCleared : ()Z
    //   2022: istore #8
    //   2024: goto -> 2059
    //   2027: iload #9
    //   2029: istore #8
    //   2031: aload #11
    //   2033: invokevirtual getContext : ()Landroid/content/Context;
    //   2036: instanceof android/app/Activity
    //   2039: ifeq -> 2059
    //   2042: iconst_1
    //   2043: aload_0
    //   2044: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2047: invokevirtual getContext : ()Landroid/content/Context;
    //   2050: checkcast android/app/Activity
    //   2053: invokevirtual isChangingConfigurations : ()Z
    //   2056: ixor
    //   2057: istore #8
    //   2059: iload_3
    //   2060: ifne -> 2068
    //   2063: iload #8
    //   2065: ifeq -> 2076
    //   2068: aload_0
    //   2069: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2072: aload_1
    //   2073: invokevirtual clearNonConfigState : (Landroidx/fragment/app/Fragment;)V
    //   2076: aload_1
    //   2077: invokevirtual performDestroy : ()V
    //   2080: aload_0
    //   2081: aload_1
    //   2082: iconst_0
    //   2083: invokevirtual dispatchOnFragmentDestroyed : (Landroidx/fragment/app/Fragment;Z)V
    //   2086: aload_1
    //   2087: invokevirtual performDetach : ()V
    //   2090: aload_0
    //   2091: aload_1
    //   2092: iconst_0
    //   2093: invokevirtual dispatchOnFragmentDetached : (Landroidx/fragment/app/Fragment;Z)V
    //   2096: iload_2
    //   2097: istore #6
    //   2099: iload #5
    //   2101: ifne -> 2217
    //   2104: iload_3
    //   2105: ifne -> 2194
    //   2108: aload_0
    //   2109: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   2112: aload_1
    //   2113: invokevirtual shouldDestroy : (Landroidx/fragment/app/Fragment;)Z
    //   2116: ifeq -> 2122
    //   2119: goto -> 2194
    //   2122: aload_1
    //   2123: aconst_null
    //   2124: putfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   2127: aload_1
    //   2128: aconst_null
    //   2129: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   2132: aload_1
    //   2133: aconst_null
    //   2134: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   2137: iload_2
    //   2138: istore #6
    //   2140: aload_1
    //   2141: getfield mTargetWho : Ljava/lang/String;
    //   2144: ifnull -> 2217
    //   2147: aload_0
    //   2148: getfield mActive : Ljava/util/HashMap;
    //   2151: aload_1
    //   2152: getfield mTargetWho : Ljava/lang/String;
    //   2155: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2158: checkcast androidx/fragment/app/Fragment
    //   2161: astore #11
    //   2163: iload_2
    //   2164: istore #6
    //   2166: aload #11
    //   2168: ifnull -> 2217
    //   2171: iload_2
    //   2172: istore #6
    //   2174: aload #11
    //   2176: invokevirtual getRetainInstance : ()Z
    //   2179: ifeq -> 2217
    //   2182: aload_1
    //   2183: aload #11
    //   2185: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   2188: iload_2
    //   2189: istore #6
    //   2191: goto -> 2217
    //   2194: aload_0
    //   2195: aload_1
    //   2196: invokevirtual makeInactive : (Landroidx/fragment/app/Fragment;)V
    //   2199: iload_2
    //   2200: istore #6
    //   2202: goto -> 2217
    //   2205: aload_1
    //   2206: iload_2
    //   2207: invokevirtual setStateAfterAnimating : (I)V
    //   2210: iload #7
    //   2212: istore #6
    //   2214: goto -> 2217
    //   2217: aload_1
    //   2218: getfield mState : I
    //   2221: iload #6
    //   2223: if_icmpeq -> 2298
    //   2226: new java/lang/StringBuilder
    //   2229: dup
    //   2230: ldc_w 'moveToState: Fragment state for '
    //   2233: invokespecial <init> : (Ljava/lang/String;)V
    //   2236: astore #11
    //   2238: aload #11
    //   2240: aload_1
    //   2241: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2244: pop
    //   2245: aload #11
    //   2247: ldc_w ' not updated inline; expected state '
    //   2250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2253: pop
    //   2254: aload #11
    //   2256: iload #6
    //   2258: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2261: pop
    //   2262: aload #11
    //   2264: ldc_w ' found '
    //   2267: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2270: pop
    //   2271: aload #11
    //   2273: aload_1
    //   2274: getfield mState : I
    //   2277: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2280: pop
    //   2281: ldc 'FragmentManager'
    //   2283: aload #11
    //   2285: invokevirtual toString : ()Ljava/lang/String;
    //   2288: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2291: pop
    //   2292: aload_1
    //   2293: iload #6
    //   2295: putfield mState : I
    //   2298: return
    //   2299: astore #11
    //   2301: goto -> 1038
    // Exception table:
    //   from	to	target	type
    //   1022	1035	2299	android/content/res/Resources$NotFoundException
  }
  
  public void noteStateNotSaved() {
    int i = 0;
    this.mStateSaved = false;
    this.mStopped = false;
    int j = this.mAdded.size();
    while (i < j) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.noteStateNotSaved(); 
      i++;
    } 
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    boolean bool = "fragment".equals(paramString);
    paramString = null;
    if (!bool)
      return null; 
    String str2 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    int i = 0;
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(0); 
    int j = typedArray.getResourceId(1, -1);
    str2 = typedArray.getString(2);
    typedArray.recycle();
    if (str1 != null) {
      if (!FragmentFactory.isFragmentClass(paramContext.getClassLoader(), str1))
        return null; 
      if (paramView != null)
        i = paramView.getId(); 
      if (i != -1 || j != -1 || str2 != null) {
        if (j != -1)
          fragment2 = findFragmentById(j); 
        Fragment fragment1 = fragment2;
        if (fragment2 == null) {
          fragment1 = fragment2;
          if (str2 != null)
            fragment1 = findFragmentByTag(str2); 
        } 
        Fragment fragment2 = fragment1;
        if (fragment1 == null) {
          fragment2 = fragment1;
          if (i != -1)
            fragment2 = findFragmentById(i); 
        } 
        if (DEBUG) {
          StringBuilder stringBuilder2 = new StringBuilder("onCreateView: id=0x");
          stringBuilder2.append(Integer.toHexString(j));
          stringBuilder2.append(" fname=");
          stringBuilder2.append(str1);
          stringBuilder2.append(" existing=");
          stringBuilder2.append(fragment2);
          Log.v("FragmentManager", stringBuilder2.toString());
        } 
        if (fragment2 == null) {
          int k;
          fragment2 = getFragmentFactory().instantiate(paramContext.getClassLoader(), str1);
          fragment2.mFromLayout = true;
          if (j != 0) {
            k = j;
          } else {
            k = i;
          } 
          fragment2.mFragmentId = k;
          fragment2.mContainerId = i;
          fragment2.mTag = str2;
          fragment2.mInLayout = true;
          fragment2.mFragmentManager = this;
          fragment2.mHost = this.mHost;
          fragment2.onInflate(this.mHost.getContext(), paramAttributeSet, fragment2.mSavedFragmentState);
          addFragment(fragment2, true);
        } else if (!fragment2.mInLayout) {
          fragment2.mInLayout = true;
          fragment2.mHost = this.mHost;
          fragment2.onInflate(this.mHost.getContext(), paramAttributeSet, fragment2.mSavedFragmentState);
        } else {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append(paramAttributeSet.getPositionDescription());
          stringBuilder2.append(": Duplicate id 0x");
          stringBuilder2.append(Integer.toHexString(j));
          stringBuilder2.append(", tag ");
          stringBuilder2.append(str2);
          stringBuilder2.append(", or parent id 0x");
          stringBuilder2.append(Integer.toHexString(i));
          stringBuilder2.append(" with another fragment for ");
          stringBuilder2.append(str1);
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
        if (this.mCurState < 1 && fragment2.mFromLayout) {
          moveToState(fragment2, 1, 0, 0, false);
        } else {
          moveToState(fragment2);
        } 
        if (fragment2.mView != null) {
          if (j != 0)
            fragment2.mView.setId(j); 
          if (fragment2.mView.getTag() == null)
            fragment2.mView.setTag(str2); 
          return fragment2.mView;
        } 
        StringBuilder stringBuilder1 = new StringBuilder("Fragment ");
        stringBuilder1.append(str1);
        stringBuilder1.append(" did not create a view.");
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramAttributeSet.getPositionDescription());
      stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
      stringBuilder.append(str1);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return null;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView((View)null, paramString, paramContext, paramAttributeSet);
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
      paramFragment.mDeferStart = false;
      moveToState(paramFragment, this.mCurState, 0, 0, false);
    } 
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      enqueueAction(new PopBackStackState(null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void popBackStack(String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    return popBackStackImmediate((String)null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    execPendingActions();
    if (paramInt1 >= 0)
      return popBackStackImmediate((String)null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  boolean popBackStackState(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mBackStack : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 70
    //   17: iload #4
    //   19: ifge -> 70
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 70
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield mBackStack : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: iconst_1
    //   61: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   64: invokevirtual add : (Ljava/lang/Object;)Z
    //   67: pop
    //   68: iconst_1
    //   69: ireturn
    //   70: aload_3
    //   71: ifnonnull -> 88
    //   74: iload #4
    //   76: iflt -> 82
    //   79: goto -> 88
    //   82: iconst_m1
    //   83: istore #4
    //   85: goto -> 263
    //   88: aload #8
    //   90: invokevirtual size : ()I
    //   93: iconst_1
    //   94: isub
    //   95: istore #6
    //   97: iload #6
    //   99: iflt -> 162
    //   102: aload_0
    //   103: getfield mBackStack : Ljava/util/ArrayList;
    //   106: iload #6
    //   108: invokevirtual get : (I)Ljava/lang/Object;
    //   111: checkcast androidx/fragment/app/BackStackRecord
    //   114: astore #8
    //   116: aload_3
    //   117: ifnull -> 135
    //   120: aload_3
    //   121: aload #8
    //   123: invokevirtual getName : ()Ljava/lang/String;
    //   126: invokevirtual equals : (Ljava/lang/Object;)Z
    //   129: ifeq -> 135
    //   132: goto -> 162
    //   135: iload #4
    //   137: iflt -> 153
    //   140: iload #4
    //   142: aload #8
    //   144: getfield mIndex : I
    //   147: if_icmpne -> 153
    //   150: goto -> 162
    //   153: iload #6
    //   155: iconst_1
    //   156: isub
    //   157: istore #6
    //   159: goto -> 97
    //   162: iload #6
    //   164: ifge -> 169
    //   167: iconst_0
    //   168: ireturn
    //   169: iload #6
    //   171: istore #7
    //   173: iload #5
    //   175: iconst_1
    //   176: iand
    //   177: ifeq -> 259
    //   180: iload #6
    //   182: iconst_1
    //   183: isub
    //   184: istore #5
    //   186: iload #5
    //   188: istore #7
    //   190: iload #5
    //   192: iflt -> 259
    //   195: aload_0
    //   196: getfield mBackStack : Ljava/util/ArrayList;
    //   199: iload #5
    //   201: invokevirtual get : (I)Ljava/lang/Object;
    //   204: checkcast androidx/fragment/app/BackStackRecord
    //   207: astore #8
    //   209: aload_3
    //   210: ifnull -> 229
    //   213: iload #5
    //   215: istore #6
    //   217: aload_3
    //   218: aload #8
    //   220: invokevirtual getName : ()Ljava/lang/String;
    //   223: invokevirtual equals : (Ljava/lang/Object;)Z
    //   226: ifne -> 180
    //   229: iload #5
    //   231: istore #7
    //   233: iload #4
    //   235: iflt -> 259
    //   238: iload #5
    //   240: istore #7
    //   242: iload #4
    //   244: aload #8
    //   246: getfield mIndex : I
    //   249: if_icmpne -> 259
    //   252: iload #5
    //   254: istore #6
    //   256: goto -> 180
    //   259: iload #7
    //   261: istore #4
    //   263: iload #4
    //   265: aload_0
    //   266: getfield mBackStack : Ljava/util/ArrayList;
    //   269: invokevirtual size : ()I
    //   272: iconst_1
    //   273: isub
    //   274: if_icmpne -> 279
    //   277: iconst_0
    //   278: ireturn
    //   279: aload_0
    //   280: getfield mBackStack : Ljava/util/ArrayList;
    //   283: invokevirtual size : ()I
    //   286: iconst_1
    //   287: isub
    //   288: istore #5
    //   290: iload #5
    //   292: iload #4
    //   294: if_icmple -> 329
    //   297: aload_1
    //   298: aload_0
    //   299: getfield mBackStack : Ljava/util/ArrayList;
    //   302: iload #5
    //   304: invokevirtual remove : (I)Ljava/lang/Object;
    //   307: invokevirtual add : (Ljava/lang/Object;)Z
    //   310: pop
    //   311: aload_2
    //   312: iconst_1
    //   313: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   316: invokevirtual add : (Ljava/lang/Object;)Z
    //   319: pop
    //   320: iload #5
    //   322: iconst_1
    //   323: isub
    //   324: istore #5
    //   326: goto -> 290
    //   329: iconst_1
    //   330: ireturn
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putString(paramString, paramFragment.mWho);
  }
  
  public void registerFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacks.add(new FragmentLifecycleCallbacksHolder(paramFragmentLifecycleCallbacks, paramBoolean));
  }
  
  public void removeFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || (bool ^ true) != 0)
      synchronized (this.mAdded) {
        this.mAdded.remove(paramFragment);
        if (isMenuAvailable(paramFragment))
          this.mNeedMenuInvalidate = true; 
        paramFragment.mAdded = false;
        paramFragment.mRemoving = true;
        return;
      }  
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    ArrayList<FragmentManager.OnBackStackChangedListener> arrayList = this.mBackStackChangeListeners;
    if (arrayList != null)
      arrayList.remove(paramOnBackStackChangedListener); 
  }
  
  void removeRetainedFragment(Fragment paramFragment) {
    if (isStateSaved()) {
      if (DEBUG)
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.mNonConfig.removeRetainedFragment(paramFragment) && DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (int i = 0; i < this.mBackStackChangeListeners.size(); i++)
        ((FragmentManager.OnBackStackChangedListener)this.mBackStackChangeListeners.get(i)).onBackStackChanged();  
  }
  
  void restoreAllState(Parcelable paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You must use restoreSaveState when your FragmentHostCallback implements ViewModelStoreOwner")); 
    this.mNonConfig.restoreFromSnapshot(paramFragmentManagerNonConfig);
    restoreSaveState(paramParcelable);
  }
  
  void restoreSaveState(Parcelable paramParcelable) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: checkcast androidx/fragment/app/FragmentManagerState
    //   9: astore #4
    //   11: aload #4
    //   13: getfield mActive : Ljava/util/ArrayList;
    //   16: ifnonnull -> 20
    //   19: return
    //   20: aload_0
    //   21: getfield mNonConfig : Landroidx/fragment/app/FragmentManagerViewModel;
    //   24: invokevirtual getRetainedFragments : ()Ljava/util/Collection;
    //   27: invokeinterface iterator : ()Ljava/util/Iterator;
    //   32: astore #5
    //   34: aload #5
    //   36: invokeinterface hasNext : ()Z
    //   41: ifeq -> 337
    //   44: aload #5
    //   46: invokeinterface next : ()Ljava/lang/Object;
    //   51: checkcast androidx/fragment/app/Fragment
    //   54: astore #6
    //   56: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   59: ifeq -> 90
    //   62: new java/lang/StringBuilder
    //   65: dup
    //   66: ldc_w 'restoreSaveState: re-attaching retained '
    //   69: invokespecial <init> : (Ljava/lang/String;)V
    //   72: astore_1
    //   73: aload_1
    //   74: aload #6
    //   76: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   79: pop
    //   80: ldc 'FragmentManager'
    //   82: aload_1
    //   83: invokevirtual toString : ()Ljava/lang/String;
    //   86: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   89: pop
    //   90: aload #4
    //   92: getfield mActive : Ljava/util/ArrayList;
    //   95: invokevirtual iterator : ()Ljava/util/Iterator;
    //   98: astore_3
    //   99: aload_3
    //   100: invokeinterface hasNext : ()Z
    //   105: ifeq -> 136
    //   108: aload_3
    //   109: invokeinterface next : ()Ljava/lang/Object;
    //   114: checkcast androidx/fragment/app/FragmentState
    //   117: astore_1
    //   118: aload_1
    //   119: getfield mWho : Ljava/lang/String;
    //   122: aload #6
    //   124: getfield mWho : Ljava/lang/String;
    //   127: invokevirtual equals : (Ljava/lang/Object;)Z
    //   130: ifeq -> 99
    //   133: goto -> 138
    //   136: aconst_null
    //   137: astore_1
    //   138: aload_1
    //   139: ifnonnull -> 223
    //   142: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   145: ifeq -> 194
    //   148: new java/lang/StringBuilder
    //   151: dup
    //   152: ldc_w 'Discarding retained Fragment '
    //   155: invokespecial <init> : (Ljava/lang/String;)V
    //   158: astore_1
    //   159: aload_1
    //   160: aload #6
    //   162: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: aload_1
    //   167: ldc_w ' that was not found in the set of active Fragments '
    //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: pop
    //   174: aload_1
    //   175: aload #4
    //   177: getfield mActive : Ljava/util/ArrayList;
    //   180: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   183: pop
    //   184: ldc 'FragmentManager'
    //   186: aload_1
    //   187: invokevirtual toString : ()Ljava/lang/String;
    //   190: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   193: pop
    //   194: aload_0
    //   195: aload #6
    //   197: iconst_1
    //   198: iconst_0
    //   199: iconst_0
    //   200: iconst_0
    //   201: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   204: aload #6
    //   206: iconst_1
    //   207: putfield mRemoving : Z
    //   210: aload_0
    //   211: aload #6
    //   213: iconst_0
    //   214: iconst_0
    //   215: iconst_0
    //   216: iconst_0
    //   217: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   220: goto -> 34
    //   223: aload_1
    //   224: aload #6
    //   226: putfield mInstance : Landroidx/fragment/app/Fragment;
    //   229: aload #6
    //   231: aconst_null
    //   232: putfield mSavedViewState : Landroid/util/SparseArray;
    //   235: aload #6
    //   237: iconst_0
    //   238: putfield mBackStackNesting : I
    //   241: aload #6
    //   243: iconst_0
    //   244: putfield mInLayout : Z
    //   247: aload #6
    //   249: iconst_0
    //   250: putfield mAdded : Z
    //   253: aload #6
    //   255: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   258: ifnull -> 273
    //   261: aload #6
    //   263: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   266: getfield mWho : Ljava/lang/String;
    //   269: astore_3
    //   270: goto -> 275
    //   273: aconst_null
    //   274: astore_3
    //   275: aload #6
    //   277: aload_3
    //   278: putfield mTargetWho : Ljava/lang/String;
    //   281: aload #6
    //   283: aconst_null
    //   284: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   287: aload_1
    //   288: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   291: ifnull -> 34
    //   294: aload_1
    //   295: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   298: aload_0
    //   299: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   302: invokevirtual getContext : ()Landroid/content/Context;
    //   305: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   308: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   311: aload #6
    //   313: aload_1
    //   314: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   317: ldc 'android:view_state'
    //   319: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   322: putfield mSavedViewState : Landroid/util/SparseArray;
    //   325: aload #6
    //   327: aload_1
    //   328: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   331: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   334: goto -> 34
    //   337: aload_0
    //   338: getfield mActive : Ljava/util/HashMap;
    //   341: invokevirtual clear : ()V
    //   344: aload #4
    //   346: getfield mActive : Ljava/util/ArrayList;
    //   349: invokevirtual iterator : ()Ljava/util/Iterator;
    //   352: astore_1
    //   353: aload_1
    //   354: invokeinterface hasNext : ()Z
    //   359: ifeq -> 482
    //   362: aload_1
    //   363: invokeinterface next : ()Ljava/lang/Object;
    //   368: checkcast androidx/fragment/app/FragmentState
    //   371: astore_3
    //   372: aload_3
    //   373: ifnull -> 353
    //   376: aload_3
    //   377: aload_0
    //   378: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   381: invokevirtual getContext : ()Landroid/content/Context;
    //   384: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   387: aload_0
    //   388: invokevirtual getFragmentFactory : ()Landroidx/fragment/app/FragmentFactory;
    //   391: invokevirtual instantiate : (Ljava/lang/ClassLoader;Landroidx/fragment/app/FragmentFactory;)Landroidx/fragment/app/Fragment;
    //   394: astore #5
    //   396: aload #5
    //   398: aload_0
    //   399: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   402: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   405: ifeq -> 459
    //   408: new java/lang/StringBuilder
    //   411: dup
    //   412: ldc_w 'restoreSaveState: active ('
    //   415: invokespecial <init> : (Ljava/lang/String;)V
    //   418: astore #6
    //   420: aload #6
    //   422: aload #5
    //   424: getfield mWho : Ljava/lang/String;
    //   427: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   430: pop
    //   431: aload #6
    //   433: ldc_w '): '
    //   436: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   439: pop
    //   440: aload #6
    //   442: aload #5
    //   444: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   447: pop
    //   448: ldc 'FragmentManager'
    //   450: aload #6
    //   452: invokevirtual toString : ()Ljava/lang/String;
    //   455: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   458: pop
    //   459: aload_0
    //   460: getfield mActive : Ljava/util/HashMap;
    //   463: aload #5
    //   465: getfield mWho : Ljava/lang/String;
    //   468: aload #5
    //   470: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   473: pop
    //   474: aload_3
    //   475: aconst_null
    //   476: putfield mInstance : Landroidx/fragment/app/Fragment;
    //   479: goto -> 353
    //   482: aload_0
    //   483: getfield mAdded : Ljava/util/ArrayList;
    //   486: invokevirtual clear : ()V
    //   489: aload #4
    //   491: getfield mAdded : Ljava/util/ArrayList;
    //   494: ifnull -> 716
    //   497: aload #4
    //   499: getfield mAdded : Ljava/util/ArrayList;
    //   502: invokevirtual iterator : ()Ljava/util/Iterator;
    //   505: astore_3
    //   506: aload_3
    //   507: invokeinterface hasNext : ()Z
    //   512: ifeq -> 716
    //   515: aload_3
    //   516: invokeinterface next : ()Ljava/lang/Object;
    //   521: checkcast java/lang/String
    //   524: astore #5
    //   526: aload_0
    //   527: getfield mActive : Ljava/util/HashMap;
    //   530: aload #5
    //   532: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   535: checkcast androidx/fragment/app/Fragment
    //   538: astore_1
    //   539: aload_1
    //   540: ifnonnull -> 588
    //   543: new java/lang/StringBuilder
    //   546: dup
    //   547: ldc_w 'No instantiated fragment for ('
    //   550: invokespecial <init> : (Ljava/lang/String;)V
    //   553: astore #6
    //   555: aload #6
    //   557: aload #5
    //   559: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   562: pop
    //   563: aload #6
    //   565: ldc_w ')'
    //   568: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   571: pop
    //   572: aload_0
    //   573: new java/lang/IllegalStateException
    //   576: dup
    //   577: aload #6
    //   579: invokevirtual toString : ()Ljava/lang/String;
    //   582: invokespecial <init> : (Ljava/lang/String;)V
    //   585: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   588: aload_1
    //   589: iconst_1
    //   590: putfield mAdded : Z
    //   593: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   596: ifeq -> 646
    //   599: new java/lang/StringBuilder
    //   602: dup
    //   603: ldc_w 'restoreSaveState: added ('
    //   606: invokespecial <init> : (Ljava/lang/String;)V
    //   609: astore #6
    //   611: aload #6
    //   613: aload #5
    //   615: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   618: pop
    //   619: aload #6
    //   621: ldc_w '): '
    //   624: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   627: pop
    //   628: aload #6
    //   630: aload_1
    //   631: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   634: pop
    //   635: ldc 'FragmentManager'
    //   637: aload #6
    //   639: invokevirtual toString : ()Ljava/lang/String;
    //   642: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   645: pop
    //   646: aload_0
    //   647: getfield mAdded : Ljava/util/ArrayList;
    //   650: aload_1
    //   651: invokevirtual contains : (Ljava/lang/Object;)Z
    //   654: ifne -> 687
    //   657: aload_0
    //   658: getfield mAdded : Ljava/util/ArrayList;
    //   661: astore #5
    //   663: aload #5
    //   665: monitorenter
    //   666: aload_0
    //   667: getfield mAdded : Ljava/util/ArrayList;
    //   670: aload_1
    //   671: invokevirtual add : (Ljava/lang/Object;)Z
    //   674: pop
    //   675: aload #5
    //   677: monitorexit
    //   678: goto -> 506
    //   681: astore_1
    //   682: aload #5
    //   684: monitorexit
    //   685: aload_1
    //   686: athrow
    //   687: new java/lang/StringBuilder
    //   690: dup
    //   691: ldc_w 'Already added '
    //   694: invokespecial <init> : (Ljava/lang/String;)V
    //   697: astore_3
    //   698: aload_3
    //   699: aload_1
    //   700: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   703: pop
    //   704: new java/lang/IllegalStateException
    //   707: dup
    //   708: aload_3
    //   709: invokevirtual toString : ()Ljava/lang/String;
    //   712: invokespecial <init> : (Ljava/lang/String;)V
    //   715: athrow
    //   716: aload #4
    //   718: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   721: ifnull -> 891
    //   724: aload_0
    //   725: new java/util/ArrayList
    //   728: dup
    //   729: aload #4
    //   731: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   734: arraylength
    //   735: invokespecial <init> : (I)V
    //   738: putfield mBackStack : Ljava/util/ArrayList;
    //   741: iconst_0
    //   742: istore_2
    //   743: iload_2
    //   744: aload #4
    //   746: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   749: arraylength
    //   750: if_icmpge -> 896
    //   753: aload #4
    //   755: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   758: iload_2
    //   759: aaload
    //   760: aload_0
    //   761: invokevirtual instantiate : (Landroidx/fragment/app/FragmentManagerImpl;)Landroidx/fragment/app/BackStackRecord;
    //   764: astore_1
    //   765: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   768: ifeq -> 859
    //   771: new java/lang/StringBuilder
    //   774: dup
    //   775: ldc_w 'restoreAllState: back stack #'
    //   778: invokespecial <init> : (Ljava/lang/String;)V
    //   781: astore_3
    //   782: aload_3
    //   783: iload_2
    //   784: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   787: pop
    //   788: aload_3
    //   789: ldc_w ' (index '
    //   792: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   795: pop
    //   796: aload_3
    //   797: aload_1
    //   798: getfield mIndex : I
    //   801: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   804: pop
    //   805: aload_3
    //   806: ldc_w '): '
    //   809: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   812: pop
    //   813: aload_3
    //   814: aload_1
    //   815: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   818: pop
    //   819: ldc 'FragmentManager'
    //   821: aload_3
    //   822: invokevirtual toString : ()Ljava/lang/String;
    //   825: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   828: pop
    //   829: new java/io/PrintWriter
    //   832: dup
    //   833: new androidx/core/util/LogWriter
    //   836: dup
    //   837: ldc 'FragmentManager'
    //   839: invokespecial <init> : (Ljava/lang/String;)V
    //   842: invokespecial <init> : (Ljava/io/Writer;)V
    //   845: astore_3
    //   846: aload_1
    //   847: ldc_w '  '
    //   850: aload_3
    //   851: iconst_0
    //   852: invokevirtual dump : (Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    //   855: aload_3
    //   856: invokevirtual close : ()V
    //   859: aload_0
    //   860: getfield mBackStack : Ljava/util/ArrayList;
    //   863: aload_1
    //   864: invokevirtual add : (Ljava/lang/Object;)Z
    //   867: pop
    //   868: aload_1
    //   869: getfield mIndex : I
    //   872: iflt -> 884
    //   875: aload_0
    //   876: aload_1
    //   877: getfield mIndex : I
    //   880: aload_1
    //   881: invokevirtual setBackStackIndex : (ILandroidx/fragment/app/BackStackRecord;)V
    //   884: iload_2
    //   885: iconst_1
    //   886: iadd
    //   887: istore_2
    //   888: goto -> 743
    //   891: aload_0
    //   892: aconst_null
    //   893: putfield mBackStack : Ljava/util/ArrayList;
    //   896: aload #4
    //   898: getfield mPrimaryNavActiveWho : Ljava/lang/String;
    //   901: ifnull -> 930
    //   904: aload_0
    //   905: getfield mActive : Ljava/util/HashMap;
    //   908: aload #4
    //   910: getfield mPrimaryNavActiveWho : Ljava/lang/String;
    //   913: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   916: checkcast androidx/fragment/app/Fragment
    //   919: astore_1
    //   920: aload_0
    //   921: aload_1
    //   922: putfield mPrimaryNav : Landroidx/fragment/app/Fragment;
    //   925: aload_0
    //   926: aload_1
    //   927: invokespecial dispatchParentPrimaryNavigationFragmentChanged : (Landroidx/fragment/app/Fragment;)V
    //   930: aload_0
    //   931: aload #4
    //   933: getfield mNextFragmentIndex : I
    //   936: putfield mNextFragmentIndex : I
    //   939: return
    // Exception table:
    //   from	to	target	type
    //   666	678	681	finally
    //   682	685	681	finally
  }
  
  @Deprecated
  FragmentManagerNonConfig retainNonConfig() {
    if (this.mHost instanceof ViewModelStoreOwner)
      throwException(new IllegalStateException("You cannot use retainNonConfig when your FragmentHostCallback implements ViewModelStoreOwner.")); 
    return this.mNonConfig.getSnapshot();
  }
  
  Parcelable saveAllState() {
    StringBuilder stringBuilder;
    forcePostponedTransactions();
    endAnimatingAwayFragments();
    execPendingActions();
    this.mStateSaved = true;
    boolean bool1 = this.mActive.isEmpty();
    BackStackState[] arrayOfBackStackState2 = null;
    if (bool1)
      return null; 
    ArrayList<FragmentState> arrayList = new ArrayList(this.mActive.size());
    Iterator<Fragment> iterator = this.mActive.values().iterator();
    boolean bool = false;
    int i = 0;
    while (iterator.hasNext()) {
      Fragment fragment1 = iterator.next();
      if (fragment1 != null) {
        if (fragment1.mFragmentManager != this) {
          StringBuilder stringBuilder1 = new StringBuilder("Failure saving state: active ");
          stringBuilder1.append(fragment1);
          stringBuilder1.append(" was removed from the FragmentManager");
          throwException(new IllegalStateException(stringBuilder1.toString()));
        } 
        FragmentState fragmentState = new FragmentState(fragment1);
        arrayList.add(fragmentState);
        if (fragment1.mState > 0 && fragmentState.mSavedFragmentState == null) {
          fragmentState.mSavedFragmentState = saveFragmentBasicState(fragment1);
          if (fragment1.mTargetWho != null) {
            Fragment fragment2 = this.mActive.get(fragment1.mTargetWho);
            if (fragment2 == null) {
              StringBuilder stringBuilder1 = new StringBuilder("Failure saving state: ");
              stringBuilder1.append(fragment1);
              stringBuilder1.append(" has target not in fragment manager: ");
              stringBuilder1.append(fragment1.mTargetWho);
              throwException(new IllegalStateException(stringBuilder1.toString()));
            } 
            if (fragmentState.mSavedFragmentState == null)
              fragmentState.mSavedFragmentState = new Bundle(); 
            putFragment(fragmentState.mSavedFragmentState, "android:target_state", fragment2);
            if (fragment1.mTargetRequestCode != 0)
              fragmentState.mSavedFragmentState.putInt("android:target_req_state", fragment1.mTargetRequestCode); 
          } 
        } else {
          fragmentState.mSavedFragmentState = fragment1.mSavedFragmentState;
        } 
        if (DEBUG) {
          StringBuilder stringBuilder1 = new StringBuilder("Saved state of ");
          stringBuilder1.append(fragment1);
          stringBuilder1.append(": ");
          stringBuilder1.append(fragmentState.mSavedFragmentState);
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        i = 1;
      } 
    } 
    if (!i) {
      if (DEBUG)
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    i = this.mAdded.size();
    if (i > 0) {
      ArrayList<String> arrayList2 = new ArrayList(i);
      Iterator<Fragment> iterator1 = this.mAdded.iterator();
      while (true) {
        ArrayList<String> arrayList3 = arrayList2;
        if (iterator1.hasNext()) {
          Fragment fragment1 = iterator1.next();
          arrayList2.add(fragment1.mWho);
          if (fragment1.mFragmentManager != this) {
            StringBuilder stringBuilder1 = new StringBuilder("Failure saving state: active ");
            stringBuilder1.append(fragment1);
            stringBuilder1.append(" was removed from the FragmentManager");
            throwException(new IllegalStateException(stringBuilder1.toString()));
          } 
          if (DEBUG) {
            StringBuilder stringBuilder1 = new StringBuilder("saveAllState: adding fragment (");
            stringBuilder1.append(fragment1.mWho);
            stringBuilder1.append("): ");
            stringBuilder1.append(fragment1);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          continue;
        } 
        break;
      } 
    } else {
      iterator = null;
    } 
    ArrayList<BackStackRecord> arrayList1 = this.mBackStack;
    BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState2;
    if (arrayList1 != null) {
      int j = arrayList1.size();
      arrayOfBackStackState1 = arrayOfBackStackState2;
      if (j > 0) {
        arrayOfBackStackState2 = new BackStackState[j];
        i = bool;
        while (true) {
          arrayOfBackStackState1 = arrayOfBackStackState2;
          if (i < j) {
            arrayOfBackStackState2[i] = new BackStackState(this.mBackStack.get(i));
            if (DEBUG) {
              stringBuilder = new StringBuilder("saveAllState: adding back stack #");
              stringBuilder.append(i);
              stringBuilder.append(": ");
              stringBuilder.append(this.mBackStack.get(i));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            i++;
            continue;
          } 
          break;
        } 
      } 
    } 
    FragmentManagerState fragmentManagerState = new FragmentManagerState();
    fragmentManagerState.mActive = arrayList;
    fragmentManagerState.mAdded = (ArrayList)iterator;
    fragmentManagerState.mBackStack = (BackStackState[])stringBuilder;
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null)
      fragmentManagerState.mPrimaryNavActiveWho = fragment.mWho; 
    fragmentManagerState.mNextFragmentIndex = this.mNextFragmentIndex;
    return (Parcelable)fragmentManagerState;
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment) {
    if (this.mStateBundle == null)
      this.mStateBundle = new Bundle(); 
    paramFragment.performSaveInstanceState(this.mStateBundle);
    dispatchOnFragmentSaveInstanceState(paramFragment, this.mStateBundle, false);
    boolean bool = this.mStateBundle.isEmpty();
    Bundle bundle2 = null;
    if (!bool) {
      bundle2 = this.mStateBundle;
      this.mStateBundle = null;
    } 
    if (paramFragment.mView != null)
      saveFragmentViewState(paramFragment); 
    Bundle bundle1 = bundle2;
    if (paramFragment.mSavedViewState != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    bundle2 = bundle1;
    if (!paramFragment.mUserVisibleHint) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle2;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    int i = paramFragment.mState;
    Fragment.SavedState savedState2 = null;
    Fragment.SavedState savedState1 = savedState2;
    if (i > 0) {
      Bundle bundle = saveFragmentBasicState(paramFragment);
      savedState1 = savedState2;
      if (bundle != null)
        savedState1 = new Fragment.SavedState(bundle); 
    } 
    return savedState1;
  }
  
  void saveFragmentViewState(Fragment paramFragment) {
    if (paramFragment.mInnerView == null)
      return; 
    SparseArray<Parcelable> sparseArray = this.mStateArray;
    if (sparseArray == null) {
      this.mStateArray = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramFragment.mInnerView.saveHierarchyState(this.mStateArray);
    if (this.mStateArray.size() > 0) {
      paramFragment.mSavedViewState = this.mStateArray;
      this.mStateArray = null;
    } 
  }
  
  void scheduleCommit() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   6: astore #4
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #4
    //   12: ifnull -> 100
    //   15: aload #4
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 100
    //   23: iconst_1
    //   24: istore_1
    //   25: goto -> 28
    //   28: aload_0
    //   29: getfield mPendingActions : Ljava/util/ArrayList;
    //   32: astore #4
    //   34: iload_3
    //   35: istore_2
    //   36: aload #4
    //   38: ifnull -> 105
    //   41: iload_3
    //   42: istore_2
    //   43: aload #4
    //   45: invokevirtual size : ()I
    //   48: iconst_1
    //   49: if_icmpne -> 105
    //   52: iconst_1
    //   53: istore_2
    //   54: goto -> 105
    //   57: aload_0
    //   58: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   61: invokevirtual getHandler : ()Landroid/os/Handler;
    //   64: aload_0
    //   65: getfield mExecCommit : Ljava/lang/Runnable;
    //   68: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   71: aload_0
    //   72: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   75: invokevirtual getHandler : ()Landroid/os/Handler;
    //   78: aload_0
    //   79: getfield mExecCommit : Ljava/lang/Runnable;
    //   82: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   85: pop
    //   86: aload_0
    //   87: invokespecial updateOnBackPressedCallbackEnabled : ()V
    //   90: aload_0
    //   91: monitorexit
    //   92: return
    //   93: astore #4
    //   95: aload_0
    //   96: monitorexit
    //   97: aload #4
    //   99: athrow
    //   100: iconst_0
    //   101: istore_1
    //   102: goto -> 28
    //   105: iload_1
    //   106: ifne -> 57
    //   109: iload_2
    //   110: ifeq -> 90
    //   113: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   2	8	93	finally
    //   15	23	93	finally
    //   28	34	93	finally
    //   43	52	93	finally
    //   57	90	93	finally
    //   90	92	93	finally
    //   95	97	93	finally
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload #4
    //   31: istore_3
    //   32: iload_1
    //   33: iload #4
    //   35: if_icmpge -> 103
    //   38: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   41: ifeq -> 90
    //   44: new java/lang/StringBuilder
    //   47: dup
    //   48: ldc_w 'Setting back stack index '
    //   51: invokespecial <init> : (Ljava/lang/String;)V
    //   54: astore #5
    //   56: aload #5
    //   58: iload_1
    //   59: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   62: pop
    //   63: aload #5
    //   65: ldc_w ' to '
    //   68: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: pop
    //   72: aload #5
    //   74: aload_2
    //   75: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   78: pop
    //   79: ldc 'FragmentManager'
    //   81: aload #5
    //   83: invokevirtual toString : ()Ljava/lang/String;
    //   86: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   89: pop
    //   90: aload_0
    //   91: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   94: iload_1
    //   95: aload_2
    //   96: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   99: pop
    //   100: goto -> 263
    //   103: iload_3
    //   104: iload_1
    //   105: if_icmpge -> 196
    //   108: aload_0
    //   109: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   112: aconst_null
    //   113: invokevirtual add : (Ljava/lang/Object;)Z
    //   116: pop
    //   117: aload_0
    //   118: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   121: ifnonnull -> 135
    //   124: aload_0
    //   125: new java/util/ArrayList
    //   128: dup
    //   129: invokespecial <init> : ()V
    //   132: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   135: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   138: ifeq -> 177
    //   141: new java/lang/StringBuilder
    //   144: dup
    //   145: invokespecial <init> : ()V
    //   148: astore #5
    //   150: aload #5
    //   152: ldc_w 'Adding available back stack index '
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: pop
    //   159: aload #5
    //   161: iload_3
    //   162: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: ldc 'FragmentManager'
    //   168: aload #5
    //   170: invokevirtual toString : ()Ljava/lang/String;
    //   173: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   176: pop
    //   177: aload_0
    //   178: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   181: iload_3
    //   182: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   185: invokevirtual add : (Ljava/lang/Object;)Z
    //   188: pop
    //   189: iload_3
    //   190: iconst_1
    //   191: iadd
    //   192: istore_3
    //   193: goto -> 103
    //   196: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   199: ifeq -> 254
    //   202: new java/lang/StringBuilder
    //   205: dup
    //   206: invokespecial <init> : ()V
    //   209: astore #5
    //   211: aload #5
    //   213: ldc_w 'Adding back stack index '
    //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: pop
    //   220: aload #5
    //   222: iload_1
    //   223: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload #5
    //   229: ldc_w ' with '
    //   232: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   235: pop
    //   236: aload #5
    //   238: aload_2
    //   239: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: ldc 'FragmentManager'
    //   245: aload #5
    //   247: invokevirtual toString : ()Ljava/lang/String;
    //   250: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   253: pop
    //   254: aload_0
    //   255: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   258: aload_2
    //   259: invokevirtual add : (Ljava/lang/Object;)Z
    //   262: pop
    //   263: aload_0
    //   264: monitorexit
    //   265: return
    //   266: astore_2
    //   267: aload_0
    //   268: monitorexit
    //   269: aload_2
    //   270: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	266	finally
    //   20	29	266	finally
    //   38	90	266	finally
    //   90	100	266	finally
    //   108	135	266	finally
    //   135	177	266	finally
    //   177	189	266	finally
    //   196	254	266	finally
    //   254	263	266	finally
    //   263	265	266	finally
    //   267	269	266	finally
  }
  
  public void setMaxLifecycle(Fragment paramFragment, Lifecycle.State paramState) {
    if (this.mActive.get(paramFragment.mWho) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this)) {
      paramFragment.mMaxState = paramState;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setPrimaryNavigationFragment(Fragment paramFragment) {
    if (paramFragment == null || (this.mActive.get(paramFragment.mWho) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this))) {
      Fragment fragment = this.mPrimaryNav;
      this.mPrimaryNav = paramFragment;
      dispatchParentPrimaryNavigationFragmentChanged(fragment);
      dispatchParentPrimaryNavigationFragmentChanged(this.mPrimaryNav);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void showFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  void startPendingDeferredFragments() {
    for (Fragment fragment : this.mActive.values()) {
      if (fragment != null)
        performPendingDeferredStart(fragment); 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.mParent;
    if (fragment != null) {
      DebugUtils.buildShortClassTag(fragment, stringBuilder);
    } else {
      DebugUtils.buildShortClassTag(this.mHost, stringBuilder);
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    synchronized (this.mLifecycleCallbacks) {
      int j = this.mLifecycleCallbacks.size();
      int i = 0;
      while (true) {
        if (i < j)
          if (((FragmentLifecycleCallbacksHolder)this.mLifecycleCallbacks.get(i)).mCallback == paramFragmentLifecycleCallbacks) {
            this.mLifecycleCallbacks.remove(i);
          } else {
            i++;
            continue;
          }  
        return;
      } 
    } 
  }
  
  private static class AnimationOrAnimator {
    public final Animation animation = null;
    
    public final Animator animator;
    
    AnimationOrAnimator(Animator param1Animator) {
      this.animator = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    AnimationOrAnimator(Animation param1Animation) {
      this.animator = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  private static class EndViewTransitionAnimation extends AnimationSet implements Runnable {
    private boolean mAnimating = true;
    
    private final View mChild;
    
    private boolean mEnded;
    
    private final ViewGroup mParent;
    
    private boolean mTransitionEnded;
    
    EndViewTransitionAnimation(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.mParent = param1ViewGroup;
      this.mChild = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.mAnimating = true;
      if (this.mEnded)
        return this.mTransitionEnded ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.mAnimating = true;
      if (this.mEnded)
        return this.mTransitionEnded ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.mEnded && this.mAnimating) {
        this.mAnimating = false;
        this.mParent.post(this);
        return;
      } 
      this.mParent.endViewTransition(this.mChild);
      this.mTransitionEnded = true;
    }
  }
  
  private static final class FragmentLifecycleCallbacksHolder {
    final FragmentManager.FragmentLifecycleCallbacks mCallback;
    
    final boolean mRecursive;
    
    FragmentLifecycleCallbacksHolder(FragmentManager.FragmentLifecycleCallbacks param1FragmentLifecycleCallbacks, boolean param1Boolean) {
      this.mCallback = param1FragmentLifecycleCallbacks;
      this.mRecursive = param1Boolean;
    }
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static interface OpGenerator {
    boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final int mFlags;
    
    final int mId;
    
    final String mName;
    
    PopBackStackState(String param1String, int param1Int1, int param1Int2) {
      this.mName = param1String;
      this.mId = param1Int1;
      this.mFlags = param1Int2;
    }
    
    public boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      return (FragmentManagerImpl.this.mPrimaryNav != null && this.mId < 0 && this.mName == null && FragmentManagerImpl.this.mPrimaryNav.getChildFragmentManager().popBackStackImmediate()) ? false : FragmentManagerImpl.this.popBackStackState(param1ArrayList, param1ArrayList1, this.mName, this.mId, this.mFlags);
    }
  }
  
  static class StartEnterTransitionListener implements Fragment.OnStartEnterTransitionListener {
    final boolean mIsBack;
    
    private int mNumPostponed;
    
    final BackStackRecord mRecord;
    
    StartEnterTransitionListener(BackStackRecord param1BackStackRecord, boolean param1Boolean) {
      this.mIsBack = param1Boolean;
      this.mRecord = param1BackStackRecord;
    }
    
    public void cancelTransaction() {
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, false, false);
    }
    
    public void completeTransaction() {
      int i = this.mNumPostponed;
      int j = 0;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      FragmentManagerImpl fragmentManagerImpl = this.mRecord.mManager;
      int k = fragmentManagerImpl.mAdded.size();
      while (j < k) {
        Fragment fragment = fragmentManagerImpl.mAdded.get(j);
        fragment.setOnStartEnterTransitionListener(null);
        if (i != 0 && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
        j++;
      } 
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, i ^ 0x1, true);
    }
    
    public boolean isReady() {
      return (this.mNumPostponed == 0);
    }
    
    public void onStartEnterTransition() {
      int i = this.mNumPostponed - 1;
      this.mNumPostponed = i;
      if (i != 0)
        return; 
      this.mRecord.mManager.scheduleCommit();
    }
    
    public void startListening() {
      this.mNumPostponed++;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\fragment\app\FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */