package com.facebook.appevents.ondeviceprocessing;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEvent;
import com.facebook.appevents.internal.AppEventUtility;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\004\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020 \n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\bÇ\002\030\0002\0020\001:\003\031\032\033B\007\b\002¢\006\002\020\002J\022\020\013\032\004\030\0010\f2\006\020\r\032\0020\016H\002J\b\020\b\032\0020\tH\007J\036\020\017\032\0020\0202\006\020\021\032\0020\0042\f\020\022\032\b\022\004\022\0020\0240\023H\007J&\020\025\032\0020\0202\006\020\026\032\0020\0272\006\020\021\032\0020\0042\f\020\022\032\b\022\004\022\0020\0240\023H\002J\020\020\030\032\0020\0202\006\020\021\032\0020\004H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\016\020\007\032\0020\004X\004¢\006\002\n\000R\022\020\b\032\004\030\0010\tX\016¢\006\004\n\002\020\n¨\006\034"}, d2 = {"Lcom/facebook/appevents/ondeviceprocessing/RemoteServiceWrapper;", "", "()V", "RECEIVER_SERVICE_ACTION", "", "RECEIVER_SERVICE_PACKAGE", "RECEIVER_SERVICE_PACKAGE_WAKIZASHI", "TAG", "isServiceAvailable", "", "Ljava/lang/Boolean;", "getVerifiedServiceIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "sendCustomEvents", "Lcom/facebook/appevents/ondeviceprocessing/RemoteServiceWrapper$ServiceResult;", "applicationId", "appEvents", "", "Lcom/facebook/appevents/AppEvent;", "sendEvents", "eventType", "Lcom/facebook/appevents/ondeviceprocessing/RemoteServiceWrapper$EventType;", "sendInstallEvent", "EventType", "RemoteServiceConnection", "ServiceResult", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class RemoteServiceWrapper {
  public static final RemoteServiceWrapper INSTANCE = new RemoteServiceWrapper();
  
  public static final String RECEIVER_SERVICE_ACTION = "ReceiverService";
  
  public static final String RECEIVER_SERVICE_PACKAGE = "com.facebook.katana";
  
  public static final String RECEIVER_SERVICE_PACKAGE_WAKIZASHI = "com.facebook.wakizashi";
  
  private static final String TAG = "RemoteServiceWrapper";
  
  private static Boolean isServiceAvailable;
  
  private final Intent getVerifiedServiceIntent(Context paramContext) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return null;
    } finally {
      paramContext = null;
      CrashShieldHandler.handleThrowable((Throwable)paramContext, this);
    } 
  }
  
  @JvmStatic
  public static final boolean isServiceAvailable() {
    boolean bool = CrashShieldHandler.isObjectCrashing(RemoteServiceWrapper.class);
    boolean bool1 = false;
    if (bool)
      return false; 
    try {
      if (isServiceAvailable == null) {
        Context context = FacebookSdk.getApplicationContext();
        if (INSTANCE.getVerifiedServiceIntent(context) != null) {
          bool = true;
        } else {
          bool = false;
        } 
        isServiceAvailable = Boolean.valueOf(bool);
      } 
      Boolean bool2 = isServiceAvailable;
      return bool;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, RemoteServiceWrapper.class);
    } 
  }
  
  @JvmStatic
  public static final ServiceResult sendCustomEvents(String paramString, List<AppEvent> paramList) {
    if (CrashShieldHandler.isObjectCrashing(RemoteServiceWrapper.class))
      return null; 
    try {
      return INSTANCE.sendEvents(EventType.CUSTOM_APP_EVENTS, paramString, paramList);
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, RemoteServiceWrapper.class);
    } 
  }
  
  private final ServiceResult sendEvents(EventType paramEventType, String paramString, List<AppEvent> paramList) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      ServiceResult serviceResult = ServiceResult.SERVICE_NOT_AVAILABLE;
      AppEventUtility.assertIsNotMainThread();
      Context context = FacebookSdk.getApplicationContext();
      return serviceResult;
    } finally {
      paramEventType = null;
      CrashShieldHandler.handleThrowable((Throwable)paramEventType, this);
    } 
  }
  
  @JvmStatic
  public static final ServiceResult sendInstallEvent(String paramString) {
    if (CrashShieldHandler.isObjectCrashing(RemoteServiceWrapper.class))
      return null; 
    try {
      return INSTANCE.sendEvents(EventType.MOBILE_APP_INSTALL, paramString, CollectionsKt.emptyList());
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, RemoteServiceWrapper.class);
    } 
  }
  
  static {
    Intrinsics.checkNotNullExpressionValue("RemoteServiceWrapper", "RemoteServiceWrapper::class.java.simpleName");
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\020\n\000\n\002\020\016\n\002\b\005\b\001\030\0002\b\022\004\022\0020\0000\001B\017\b\002\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020\005\032\0020\003H\026R\016\020\002\032\0020\003X\004¢\006\002\n\000j\002\b\006j\002\b\007¨\006\b"}, d2 = {"Lcom/facebook/appevents/ondeviceprocessing/RemoteServiceWrapper$EventType;", "", "eventType", "", "(Ljava/lang/String;ILjava/lang/String;)V", "toString", "MOBILE_APP_INSTALL", "CUSTOM_APP_EVENTS", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public enum EventType {
    CUSTOM_APP_EVENTS, MOBILE_APP_INSTALL;
    
    private final String eventType;
    
    static {
      EventType eventType1 = new EventType("MOBILE_APP_INSTALL", 0, "MOBILE_APP_INSTALL");
      MOBILE_APP_INSTALL = eventType1;
      EventType eventType2 = new EventType("CUSTOM_APP_EVENTS", 1, "CUSTOM_APP_EVENTS");
      CUSTOM_APP_EVENTS = eventType2;
      $VALUES = new EventType[] { eventType1, eventType2 };
    }
    
    EventType(String param1String1) {
      this.eventType = param1String1;
    }
    
    public String toString() {
      return this.eventType;
    }
  }
  
  @Metadata(d1 = {"\000(\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\002\b\004\b\000\030\0002\0020\001B\005¢\006\002\020\002J\b\020\007\032\004\030\0010\004J\020\020\b\032\0020\t2\006\020\n\032\0020\013H\026J\030\020\f\032\0020\t2\006\020\n\032\0020\0132\006\020\r\032\0020\004H\026J\020\020\016\032\0020\t2\006\020\n\032\0020\013H\026R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000¨\006\017"}, d2 = {"Lcom/facebook/appevents/ondeviceprocessing/RemoteServiceWrapper$RemoteServiceConnection;", "Landroid/content/ServiceConnection;", "()V", "binder", "Landroid/os/IBinder;", "latch", "Ljava/util/concurrent/CountDownLatch;", "getBinder", "onNullBinding", "", "name", "Landroid/content/ComponentName;", "onServiceConnected", "serviceBinder", "onServiceDisconnected", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class RemoteServiceConnection implements ServiceConnection {
    private IBinder binder;
    
    private final CountDownLatch latch = new CountDownLatch(1);
    
    public final IBinder getBinder() throws InterruptedException {
      this.latch.await(5L, TimeUnit.SECONDS);
      return this.binder;
    }
    
    public void onNullBinding(ComponentName param1ComponentName) {
      Intrinsics.checkNotNullParameter(param1ComponentName, "name");
      this.latch.countDown();
    }
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      Intrinsics.checkNotNullParameter(param1ComponentName, "name");
      Intrinsics.checkNotNullParameter(param1IBinder, "serviceBinder");
      this.binder = param1IBinder;
      this.latch.countDown();
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      Intrinsics.checkNotNullParameter(param1ComponentName, "name");
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\005\b\001\030\0002\b\022\004\022\0020\0000\001B\007\b\002¢\006\002\020\002j\002\b\003j\002\b\004j\002\b\005¨\006\006"}, d2 = {"Lcom/facebook/appevents/ondeviceprocessing/RemoteServiceWrapper$ServiceResult;", "", "(Ljava/lang/String;I)V", "OPERATION_SUCCESS", "SERVICE_NOT_AVAILABLE", "SERVICE_ERROR", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public enum ServiceResult {
    OPERATION_SUCCESS, SERVICE_ERROR, SERVICE_NOT_AVAILABLE;
    
    static {
      ServiceResult serviceResult1 = new ServiceResult("OPERATION_SUCCESS", 0);
      OPERATION_SUCCESS = serviceResult1;
      ServiceResult serviceResult2 = new ServiceResult("SERVICE_NOT_AVAILABLE", 1);
      SERVICE_NOT_AVAILABLE = serviceResult2;
      ServiceResult serviceResult3 = new ServiceResult("SERVICE_ERROR", 2);
      SERVICE_ERROR = serviceResult3;
      $VALUES = new ServiceResult[] { serviceResult1, serviceResult2, serviceResult3 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\ondeviceprocessing\RemoteServiceWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */