package androidx.fragment.app;

import y.尻;
import y.肉;
import y.腰;

class FragmentManager$6 implements 肉 {
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 != 尻.ON_START) {
      if (param尻 != 尻.ON_DESTROY)
        return; 
      throw null;
    } 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\fragment\app\FragmentManager$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */