package androidx.work.impl.foreground;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import java.util.UUID;
import y.np;
import y.op;
import y.z00;
import y.中;
import y.寝;
import y.帰;
import y.獅;
import y.茎;
import y.법;

public class SystemForegroundService extends 中 implements np {
  public Handler 怖;
  
  public boolean 恐;
  
  public NotificationManager 痒;
  
  public op 痛;
  
  static {
    獅.苦("SystemFgService");
  }
  
  public final void onCreate() {
    super.onCreate();
    堅();
  }
  
  public final void onDestroy() {
    super.onDestroy();
    null = this.痛;
    null.産 = null;
    synchronized (null.恐) {
      null.興.暑();
      null.淋.投.寒((법)null);
      return;
    } 
  }
  
  public final int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.恐) {
      獅.辛().ぱ(new Throwable[0]);
      op op1 = this.痛;
      op1.産 = null;
      synchronized (op1.恐) {
        op1.興.暑();
        op1.淋.投.寒((법)op1);
        堅();
        this.恐 = false;
      } 
    } 
    if (paramIntent != null) {
      帰 帰;
      op op1 = this.痛;
      op1.getClass();
      String str = paramIntent.getAction();
      boolean bool = "ACTION_START_FOREGROUND".equals(str);
      paramInt1 = op.死;
      z00 z00 = op1.淋;
      if (bool) {
        獅 獅 = 獅.辛();
        String.format("Started foreground service %s", new Object[] { paramIntent });
        獅.ぱ(new Throwable[0]);
        str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
        帰 = new 帰(op1, z00.寝, str, 8);
        ((茎)op1.怖).不((Runnable)帰);
        op1.寒(paramIntent);
      } else if ("ACTION_NOTIFY".equals(str)) {
        op1.寒(paramIntent);
      } else {
        獅 獅;
        if ("ACTION_CANCEL_WORK".equals(str)) {
          獅 = 獅.辛();
          String.format("Stopping foreground work for %s", new Object[] { paramIntent });
          獅.ぱ(new Throwable[0]);
          String str1 = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
          if (str1 != null && !TextUtils.isEmpty(str1)) {
            UUID uUID = UUID.fromString(str1);
            帰.getClass();
            寝 寝 = new 寝((z00)帰, uUID, 0);
            ((茎)((z00)帰).噛).不((Runnable)寝);
          } 
        } else if ("ACTION_STOP_FOREGROUND".equals(str)) {
          獅.辛().ぱ(new Throwable[0]);
          np np1 = ((op)獅).産;
          if (np1 != null) {
            np1 = np1;
            ((SystemForegroundService)np1).恐 = true;
            獅.辛().寒(new Throwable[0]);
            if (Build.VERSION.SDK_INT >= 26)
              np1.stopForeground(true); 
            np1.stopSelf();
          } 
        } 
      } 
    } 
    return 3;
  }
  
  public final void 堅() {
    this.怖 = new Handler(Looper.getMainLooper());
    this.痒 = (NotificationManager)getApplicationContext().getSystemService("notification");
    op op1 = new op(getApplicationContext());
    this.痛 = op1;
    if (op1.産 != null) {
      獅.辛().不(new Throwable[0]);
      return;
    } 
    op1.産 = this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\foreground\SystemForegroundService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */