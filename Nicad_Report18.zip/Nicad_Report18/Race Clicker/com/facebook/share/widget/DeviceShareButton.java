package com.facebook.share.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.facebook.CallbackManager;
import com.facebook.FacebookButtonBase;
import com.facebook.FacebookCallback;
import com.facebook.FacebookSdk;
import com.facebook.internal.CallbackManagerImpl;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import com.facebook.share.DeviceShareDialog;
import com.facebook.share.R;
import com.facebook.share.model.ShareContent;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;

@Deprecated
public final class DeviceShareButton extends FacebookButtonBase {
  private DeviceShareDialog dialog = null;
  
  private boolean enabledExplicitlySet = false;
  
  private int requestCode = 0;
  
  private ShareContent shareContent;
  
  public DeviceShareButton(Context paramContext) {
    this(paramContext, (AttributeSet)null, 0);
  }
  
  public DeviceShareButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  private DeviceShareButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt, 0, "fb_device_share_button_create", "fb_device_share_button_did_tap");
    if (isInEditMode()) {
      paramInt = 0;
    } else {
      paramInt = getDefaultRequestCode();
    } 
    this.requestCode = paramInt;
    internalSetEnabled(false);
  }
  
  private boolean canShare() {
    return (new DeviceShareDialog(getActivity())).canShow(getShareContent());
  }
  
  private DeviceShareDialog getDialog() {
    DeviceShareDialog deviceShareDialog = this.dialog;
    if (deviceShareDialog != null)
      return deviceShareDialog; 
    if (getFragment() != null) {
      this.dialog = new DeviceShareDialog(getFragment());
    } else if (getNativeFragment() != null) {
      this.dialog = new DeviceShareDialog(getNativeFragment());
    } else {
      this.dialog = new DeviceShareDialog(getActivity());
    } 
    return this.dialog;
  }
  
  private void internalSetEnabled(boolean paramBoolean) {
    setEnabled(paramBoolean);
    this.enabledExplicitlySet = false;
  }
  
  private void setRequestCode(int paramInt) {
    if (!FacebookSdk.isFacebookRequestCode(paramInt)) {
      this.requestCode = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Request code ");
    stringBuilder.append(paramInt);
    stringBuilder.append(" cannot be within the range reserved by the Facebook SDK.");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  protected void configureButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super.configureButton(paramContext, paramAttributeSet, paramInt1, paramInt2);
    setInternalOnClickListener(getShareOnClickListener());
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.viewOnTouch("com.facebook", (View)this, paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  protected int getDefaultRequestCode() {
    return CallbackManagerImpl.RequestCodeOffset.Share.toRequestCode();
  }
  
  protected int getDefaultStyleResource() {
    return R.style.com_facebook_button_share;
  }
  
  public int getRequestCode() {
    return this.requestCode;
  }
  
  public ShareContent getShareContent() {
    return this.shareContent;
  }
  
  protected View.OnClickListener getShareOnClickListener() {
    return new View.OnClickListener() {
        public void onClick(View param1View) {
          if (CrashShieldHandler.isObjectCrashing(this))
            return; 
          try {
            return;
          } finally {
            param1View = null;
            CrashShieldHandler.handleThrowable((Throwable)param1View, this);
          } 
        }
      };
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void registerCallback(CallbackManager paramCallbackManager, FacebookCallback<DeviceShareDialog.Result> paramFacebookCallback) {
    getDialog().registerCallback(paramCallbackManager, paramFacebookCallback);
  }
  
  public void registerCallback(CallbackManager paramCallbackManager, FacebookCallback<DeviceShareDialog.Result> paramFacebookCallback, int paramInt) {
    setRequestCode(paramInt);
    getDialog().registerCallback(paramCallbackManager, paramFacebookCallback, paramInt);
  }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    this.enabledExplicitlySet = true;
  }
  
  public void setShareContent(ShareContent paramShareContent) {
    this.shareContent = paramShareContent;
    if (!this.enabledExplicitlySet)
      internalSetEnabled(canShare()); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\widget\DeviceShareButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */