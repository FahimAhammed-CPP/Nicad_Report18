package com.appsflyer.internal;

import android.content.Context;
import android.os.Build;
import com.appsflyer.AppsFlyerProperties;
import com.appsflyer.PurchaseHandler;
import com.appsflyer.attribution.AppsFlyerRequestListener;
import com.appsflyer.internal.components.network.http.ResponseNetwork;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public abstract class AFd1lSDK extends AFd1iSDK<String> {
  private final Map<String, Object> AFVersionDeclaration;
  
  private final AFc1xSDK afErrorLogForExcManagerOnly;
  
  private final AFb1bSDK afRDLog;
  
  private final PurchaseHandler.PurchaseValidationCallback afWarnLog;
  
  public AFd1lSDK(AFd1sSDK paramAFd1sSDK, AFd1sSDK[] paramArrayOfAFd1sSDK, AFc1vSDK paramAFc1vSDK, String paramString, Map<String, Object> paramMap, PurchaseHandler.PurchaseValidationCallback paramPurchaseValidationCallback) {
    super(paramAFd1sSDK, paramArrayOfAFd1sSDK, paramAFc1vSDK, paramString);
    String str1;
    AFb1bSDK aFb1bSDK = paramAFc1vSDK.AFInAppEventParameterName();
    this.afRDLog = aFb1bSDK;
    AFc1xSDK aFc1xSDK = paramAFc1vSDK.afErrorLog();
    this.afErrorLogForExcManagerOnly = aFc1xSDK;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(new HashMap<Object, Object>(paramMap));
    hashMap.put("app_id", aFb1bSDK.values.AFKeystoreWrapper.getPackageName());
    String str2 = AFb1bSDK.valueOf();
    if (str2 != null)
      hashMap.put("cuid", str2); 
    hashMap.put("app_version_name", AFa1cSDK.AFInAppEventParameterName(aFb1bSDK.values.AFKeystoreWrapper, aFb1bSDK.values.AFKeystoreWrapper.getPackageName()));
    paramMap = new HashMap<String, Object>();
    AFc1qSDK.AFa1vSDK aFa1vSDK1 = AFa1bSDK.AFInAppEventType(aFb1bSDK.values.AFKeystoreWrapper, new HashMap<String, Object>());
    paramArrayOfAFd1sSDK = null;
    if (aFa1vSDK1 != null) {
      str1 = aFa1vSDK1.AFInAppEventParameterName;
    } else {
      aFa1vSDK1 = null;
    } 
    if (!AFb1pSDK.valueOf((String)aFa1vSDK1))
      paramMap.put("advertising_id", aFa1vSDK1); 
    aFa1vSDK1 = AFa1bSDK.values(aFb1bSDK.values.AFKeystoreWrapper.getContentResolver());
    if (aFa1vSDK1 != null) {
      str1 = aFa1vSDK1.AFInAppEventParameterName;
    } else {
      aFa1vSDK1 = null;
    } 
    if (!AFb1pSDK.valueOf((String)aFa1vSDK1))
      paramMap.put("oaid", aFa1vSDK1); 
    AFc1qSDK.AFa1vSDK aFa1vSDK2 = AFa1bSDK.values(aFb1bSDK.values.AFKeystoreWrapper.getContentResolver());
    AFd1sSDK[] arrayOfAFd1sSDK = paramArrayOfAFd1sSDK;
    if (aFa1vSDK2 != null)
      str1 = aFa1vSDK2.AFInAppEventParameterName; 
    if (!AFb1pSDK.valueOf(str1))
      paramMap.put("amazon_aid", str1); 
    if (!AppsFlyerProperties.getInstance().getBoolean("deviceTrackingDisabled", false)) {
      str1 = this.AFLogger.AFKeystoreWrapper(aFc1xSDK);
      if (!AFb1pSDK.valueOf(str1))
        paramMap.put("imei", str1); 
    } 
    paramMap.put("appsflyer_id", AFb1wSDK.AFInAppEventParameterName(new WeakReference<Context>(aFb1bSDK.values.AFKeystoreWrapper)));
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Build.VERSION.SDK_INT);
    paramMap.put("os_version", stringBuilder.toString());
    paramMap.put("sdk_version", AFb1xSDK.AFKeystoreWrapper);
    hashMap.put("device_data", paramMap);
    this.AFVersionDeclaration = (Map)hashMap;
    this.afWarnLog = paramPurchaseValidationCallback;
  }
  
  public final void AFKeystoreWrapper() {
    super.AFKeystoreWrapper();
    Throwable throwable = afRDLog();
    if (throwable != null) {
      PurchaseHandler.PurchaseValidationCallback purchaseValidationCallback = this.afWarnLog;
      if (purchaseValidationCallback != null)
        purchaseValidationCallback.onFailure(throwable); 
    } 
    AFc1aSDK aFc1aSDK = this.afInfoLog;
    if (aFc1aSDK != null) {
      PurchaseHandler.PurchaseValidationCallback purchaseValidationCallback = this.afWarnLog;
      if (purchaseValidationCallback != null)
        purchaseValidationCallback.onResponse((ResponseNetwork)aFc1aSDK); 
    } 
  }
  
  protected final AppsFlyerRequestListener AFLogger() {
    return null;
  }
  
  protected final Map<String, Object> AFLogger$LogLevel() {
    return this.AFVersionDeclaration;
  }
  
  protected final boolean afDebugLog() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFd1lSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */