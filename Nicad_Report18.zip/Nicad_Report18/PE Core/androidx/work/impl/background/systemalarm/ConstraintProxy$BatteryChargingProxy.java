package androidx.work.impl.background.systemalarm;

import y.촌;

public class ConstraintProxy$BatteryChargingProxy extends 촌 {}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\background\systemalarm\ConstraintProxy$BatteryChargingProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */