package androidx.fragment.app;

import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;
import y.bm;
import y.gm;
import y.hj;
import y.im;
import y.jm;
import y.lm;
import y.oy;
import y.p31;
import y.po;
import y.rw;
import y.ts;
import y.ぞ;
import y.タ;
import y.ㅇ;
import y.尻;
import y.心;
import y.背;
import y.茎;
import y.실;
import y.싱;
import y.쑥;
import y.암;
import y.앵;
import y.약;
import y.양;
import y.어;
import y.억;
import y.언;
import y.얼;
import y.엄;
import y.올;

public final class do {
  public int 冷 = -1;
  
  public final ts 堅;
  
  public boolean 暑 = false;
  
  public final 싱 熱;
  
  public final ㅇ 硬;
  
  public do(ㅇ paramㅇ, ts paramts, ClassLoader paramClassLoader, 암 param암, 어 param어) {
    this.硬 = paramㅇ;
    this.堅 = paramts;
    싱 싱1 = param암.硬(param어.淋);
    Bundle bundle = param어.死;
    if (bundle != null)
      bundle.setClassLoader(paramClassLoader); 
    싱1.投(bundle);
    싱1.痒 = param어.怖;
    싱1.返 = param어.恐;
    싱1.泳 = true;
    싱1.か = param어.痛;
    싱1.ち = param어.痒;
    싱1.ゃ = param어.臭;
    싱1.も = param어.起;
    싱1.帰 = param어.興;
    싱1.わ = param어.産;
    싱1.赤 = param어.壊;
    싱1.탈 = ぞ.values()[param어.帰];
    bundle = param어.返;
    if (bundle != null) {
      싱1.怖 = bundle;
    } else {
      싱1.怖 = new Bundle();
    } 
    this.熱 = 싱1;
    if (앵.噛(2))
      Objects.toString(싱1); 
  }
  
  public do(ㅇ paramㅇ, ts paramts, 싱 param싱) {
    this.硬 = paramㅇ;
    this.堅 = paramts;
    this.熱 = param싱;
  }
  
  public do(ㅇ paramㅇ, ts paramts, 싱 param싱, 어 param어) {
    this.硬 = paramㅇ;
    this.堅 = paramts;
    this.熱 = param싱;
    param싱.恐 = null;
    param싱.痛 = null;
    param싱.寝 = 0;
    param싱.歩 = false;
    param싱.壊 = false;
    싱 싱1 = param싱.起;
    if (싱1 != null) {
      String str = 싱1.痒;
    } else {
      싱1 = null;
    } 
    param싱.興 = (String)싱1;
    param싱.起 = null;
    Bundle bundle = param어.返;
    if (bundle != null) {
      param싱.怖 = bundle;
      return;
    } 
    param싱.怖 = new Bundle();
  }
  
  public final void ぱ() {
    ts ts1 = this.堅;
    boolean bool = this.暑;
    null = this.熱;
    if (bool) {
      if (앵.噛(2))
        Objects.toString(null); 
      return;
    } 
    try {
      this.暑 = true;
    } finally {
      this.暑 = false;
    } 
  }
  
  public final void 不() {
    boolean bool1 = 앵.噛(3);
    싱 싱1 = this.熱;
    if (bool1)
      Objects.toString(싱1); 
    싱1.淋 = -1;
    boolean bool = false;
    싱1.코 = false;
    싱1.産();
    if (싱1.코) {
      앵 앵 = 싱1.投;
      if (!앵.噛) {
        앵.苦();
        싱1.投 = new 앵();
      } 
      this.硬.冷(false);
      싱1.淋 = -1;
      싱1.触 = null;
      싱1.あ = null;
      싱1.噛 = null;
      boolean bool3 = 싱1.帰;
      bool1 = true;
      boolean bool2 = bool;
      if (bool3) {
        bool2 = bool;
        if (!싱1.寂())
          bool2 = true; 
      } 
      if (!bool2) {
        약 약 = (약)this.堅.暑;
        if (약.熱.containsKey(싱1.痒) && 약.寒)
          bool1 = 약.美; 
        if (bool1) {
          if (앵.噛(3))
            Objects.toString(싱1); 
          싱1.苦();
          return;
        } 
        return;
      } 
    } else {
      StringBuilder stringBuilder = new StringBuilder("Fragment ");
      stringBuilder.append(싱1);
      stringBuilder.append(" did not call through to super.onDetach()");
      throw new po(stringBuilder.toString());
    } 
    if (앵.噛(3))
      Objects.toString(싱1); 
    싱1.苦();
  }
  
  public final void 冷() {
    boolean bool = 앵.噛(3);
    싱 싱1 = this.熱;
    if (bool)
      Objects.toString(싱1); 
    if (!싱1.탁) {
      ㅇ ㅇ1 = this.硬;
      ㅇ1.旨(false);
      Bundle bundle1 = 싱1.怖;
      싱1.投.ゃ();
      싱1.淋 = 1;
      싱1.코 = false;
      int i = Build.VERSION.SDK_INT;
      싱1.탐.硬((心)new Fragment$6(싱1));
      싱1.태.堅(bundle1);
      싱1.痛(bundle1);
      싱1.탁 = true;
      if (싱1.코) {
        싱1.탐.消(尻.ON_CREATE);
        ㅇ1.熱(false);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder("Fragment ");
      stringBuilder.append(싱1);
      stringBuilder.append(" did not call through to super.onCreate()");
      throw new po(stringBuilder.toString());
    } 
    Bundle bundle = 싱1.怖;
    if (bundle != null) {
      Parcelable parcelable = bundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        싱1.投.쾌(parcelable);
        앵 앵 = 싱1.投;
        앵.踊 = false;
        앵.寝 = false;
        앵.ち.旨 = false;
        앵.臭(1);
      } 
    } 
    싱1.淋 = 1;
  }
  
  public final void 堅() {
    int i;
    ts ts1 = this.堅;
    ts1.getClass();
    싱 싱1 = this.熱;
    ViewGroup viewGroup = 싱1.쾌;
    byte b = -1;
    if (viewGroup == null) {
      i = b;
    } else {
      int k = ((ArrayList)ts1.硬).indexOf(싱1);
      int j = k - 1;
      while (true) {
        i = k;
        if (j >= 0) {
          싱 싱2 = ((ArrayList<싱>)ts1.硬).get(j);
          if (싱2.쾌 == viewGroup) {
            View view = 싱2.크;
            if (view != null) {
              i = viewGroup.indexOfChild(view) + 1;
              break;
            } 
          } 
          j--;
          continue;
        } 
        while (true) {
          j = i + 1;
          i = b;
          if (j < ((ArrayList)ts1.硬).size()) {
            싱 싱2 = ((ArrayList<싱>)ts1.硬).get(j);
            i = j;
            if (싱2.쾌 == viewGroup) {
              View view = 싱2.크;
              i = j;
              if (view != null) {
                i = viewGroup.indexOfChild(view);
                break;
              } 
            } 
            continue;
          } 
          break;
        } 
        break;
      } 
    } 
    싱1.쾌.addView(싱1.크, i);
  }
  
  public final void 嬉(ClassLoader paramClassLoader) {
    싱 싱1 = this.熱;
    Bundle bundle = 싱1.怖;
    if (bundle == null)
      return; 
    bundle.setClassLoader(paramClassLoader);
    싱1.恐 = 싱1.怖.getSparseParcelableArray("android:view_state");
    싱1.痛 = 싱1.怖.getBundle("android:view_registry_state");
    String str = 싱1.怖.getString("android:target_state");
    싱1.興 = str;
    if (str != null)
      싱1.産 = 싱1.怖.getInt("android:target_req_state", 0); 
    boolean bool = 싱1.怖.getBoolean("android:user_visible_hint", true);
    싱1.키 = bool;
    if (!bool)
      싱1.큰 = true; 
  }
  
  public final void 寂() {
    싱 싱1 = this.熱;
    어 어 = new 어(싱1);
    if (싱1.淋 > -1 && 어.返 == null) {
      Bundle bundle2 = new Bundle();
      싱1.帰(bundle2);
      싱1.태.熱(bundle2);
      bundle2.putParcelable("android:support:fragments", (Parcelable)싱1.投.크());
      this.硬.辛(false);
      Bundle bundle1 = bundle2;
      if (bundle2.isEmpty())
        bundle1 = null; 
      if (싱1.크 != null)
        淋(); 
      bundle2 = bundle1;
      if (싱1.恐 != null) {
        bundle2 = bundle1;
        if (bundle1 == null)
          bundle2 = new Bundle(); 
        bundle2.putSparseParcelableArray("android:view_state", 싱1.恐);
      } 
      bundle1 = bundle2;
      if (싱1.痛 != null) {
        bundle1 = bundle2;
        if (bundle2 == null)
          bundle1 = new Bundle(); 
        bundle1.putBundle("android:view_registry_state", 싱1.痛);
      } 
      bundle2 = bundle1;
      if (!싱1.키) {
        bundle2 = bundle1;
        if (bundle1 == null)
          bundle2 = new Bundle(); 
        bundle2.putBoolean("android:user_visible_hint", 싱1.키);
      } 
      어.返 = bundle2;
      if (싱1.興 != null) {
        if (bundle2 == null)
          어.返 = new Bundle(); 
        어.返.putString("android:target_state", 싱1.興);
        int i = 싱1.産;
        if (i != 0)
          어.返.putInt("android:target_req_state", i); 
      } 
    } else {
      어.返 = 싱1.怖;
    } 
    this.堅.興(싱1.痒, 어);
  }
  
  public final void 寒() {
    싱 싱1 = this.熱;
    if (싱1.返)
      return; 
    if (앵.噛(3))
      Objects.toString(싱1); 
    LayoutInflater layoutInflater = 싱1.死(싱1.怖);
    ViewGroup viewGroup = 싱1.쾌;
    if (viewGroup == null) {
      int i = 싱1.ち;
      if (i != 0) {
        if (i != -1) {
          StringBuilder stringBuilder;
          ViewGroup viewGroup1 = (ViewGroup)싱1.噛.臭.寒(i);
          if (viewGroup1 == null) {
            if (싱1.泳) {
              viewGroup = viewGroup1;
            } else {
              String str;
              try {
                str = 싱1.寝().getResources().getResourceName(싱1.ち);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                str = "unknown";
              } 
              stringBuilder = new StringBuilder("No view found for id 0x");
              stringBuilder.append(Integer.toHexString(싱1.ち));
              stringBuilder.append(" (");
              stringBuilder.append(str);
              stringBuilder.append(") for fragment ");
              stringBuilder.append(싱1);
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
          } else {
            StringBuilder stringBuilder1 = stringBuilder;
            if (!(stringBuilder instanceof FragmentContainerView)) {
              StringBuilder stringBuilder2;
              언 언 = 얼.硬;
              엄 엄 = new 엄(싱1, (ViewGroup)stringBuilder, 1);
              if (앵.噛(3))
                ((oy)엄).淋.getClass(); 
              얼.硬(싱1).getClass();
              억 억 = 억.恐;
              if (!(억 instanceof Void)) {
                stringBuilder2 = stringBuilder;
              } else {
                Void void_ = (Void)stringBuilder2;
                StringBuilder stringBuilder3 = stringBuilder;
              } 
            } 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder("Cannot create fragment ");
          stringBuilder.append(싱1);
          stringBuilder.append(" for a container view with no id");
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        viewGroup = null;
      } 
    } 
    싱1.쾌 = viewGroup;
    싱1.踊(layoutInflater, viewGroup, 싱1.怖);
    View view = 싱1.크;
    if (view != null) {
      view.setSaveFromParentEnabled(false);
      싱1.크.setTag(2131231074, 싱1);
      if (viewGroup != null)
        堅(); 
      if (싱1.赤)
        싱1.크.setVisibility(8); 
      if (rw.悲(싱1.크)) {
        rw.死(싱1.크);
      } else {
        View view1 = 싱1.크;
        view1.addOnAttachStateChangeListener((View.OnAttachStateChangeListener)new 쑥(this, view1));
      } 
      싱1.投.臭(2);
      this.硬.嬉(false);
      int i = 싱1.크.getVisibility();
      float f = 싱1.크.getAlpha();
      (싱1.冷()).苦 = f;
      if (싱1.쾌 != null && i == 0) {
        View view1 = 싱1.크.findFocus();
        if (view1 != null) {
          (싱1.冷()).嬉 = view1;
          if (앵.噛(2)) {
            view1.toString();
            Objects.toString(싱1);
          } 
        } 
        싱1.크.setAlpha(0.0F);
      } 
    } 
    싱1.淋 = 2;
  }
  
  public final void 怖() {
    앵 앵;
    boolean bool = 앵.噛(3);
    싱 싱1 = this.熱;
    if (bool)
      Objects.toString(싱1); 
    싱1.投.ゃ();
    싱1.投.死(true);
    싱1.淋 = 5;
    싱1.코 = false;
    싱1.返();
    if (싱1.코) {
      背 背 = 싱1.탐;
      尻 尻 = 尻.ON_START;
      背.消(尻);
      if (싱1.크 != null)
        싱1.탑.堅(尻); 
      앵 = 싱1.投;
      앵.踊 = false;
      앵.寝 = false;
      앵.ち.旨 = false;
      앵.臭(5);
      this.硬.ぱ(false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Fragment ");
    stringBuilder.append(앵);
    stringBuilder.append(" did not call through to super.onStart()");
    throw new po(stringBuilder.toString());
  }
  
  public final void 恐() {
    boolean bool = 앵.噛(3);
    싱 싱1 = this.熱;
    if (bool)
      Objects.toString(싱1); 
    앵 앵 = 싱1.投;
    앵.寝 = true;
    앵.ち.旨 = true;
    앵.臭(4);
    if (싱1.크 != null)
      싱1.탑.堅(尻.ON_STOP); 
    싱1.탐.消(尻.ON_STOP);
    싱1.淋 = 4;
    싱1.코 = false;
    싱1.歩();
    if (싱1.코) {
      this.硬.苦(false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Fragment ");
    stringBuilder.append(싱1);
    stringBuilder.append(" did not call through to super.onStop()");
    throw new po(stringBuilder.toString());
  }
  
  public final void 悲() {
    // Byte code:
    //   0: iconst_3
    //   1: invokestatic 噛 : (I)Z
    //   4: istore_2
    //   5: aload_0
    //   6: getfield 熱 : Ly/싱;
    //   9: astore #5
    //   11: iload_2
    //   12: ifeq -> 21
    //   15: aload #5
    //   17: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
    //   20: pop
    //   21: aload #5
    //   23: getfield ㅌ : Ly/십;
    //   26: astore_3
    //   27: aload_3
    //   28: ifnonnull -> 36
    //   31: aconst_null
    //   32: astore_3
    //   33: goto -> 41
    //   36: aload_3
    //   37: getfield 嬉 : Landroid/view/View;
    //   40: astore_3
    //   41: aload_3
    //   42: ifnull -> 136
    //   45: aload_3
    //   46: aload #5
    //   48: getfield 크 : Landroid/view/View;
    //   51: if_acmpne -> 57
    //   54: goto -> 78
    //   57: aload_3
    //   58: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   61: astore #4
    //   63: aload #4
    //   65: ifnull -> 95
    //   68: aload #4
    //   70: aload #5
    //   72: getfield 크 : Landroid/view/View;
    //   75: if_acmpne -> 83
    //   78: iconst_1
    //   79: istore_1
    //   80: goto -> 97
    //   83: aload #4
    //   85: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   90: astore #4
    //   92: goto -> 63
    //   95: iconst_0
    //   96: istore_1
    //   97: iload_1
    //   98: ifeq -> 136
    //   101: aload_3
    //   102: invokevirtual requestFocus : ()Z
    //   105: pop
    //   106: iconst_2
    //   107: invokestatic 噛 : (I)Z
    //   110: ifeq -> 136
    //   113: aload_3
    //   114: invokevirtual toString : ()Ljava/lang/String;
    //   117: pop
    //   118: aload #5
    //   120: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
    //   123: pop
    //   124: aload #5
    //   126: getfield 크 : Landroid/view/View;
    //   129: invokevirtual findFocus : ()Landroid/view/View;
    //   132: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
    //   135: pop
    //   136: aload #5
    //   138: invokevirtual 冷 : ()Ly/십;
    //   141: aconst_null
    //   142: putfield 嬉 : Landroid/view/View;
    //   145: aload #5
    //   147: getfield 投 : Ly/앵;
    //   150: invokevirtual ゃ : ()V
    //   153: aload #5
    //   155: getfield 投 : Ly/앵;
    //   158: iconst_1
    //   159: invokevirtual 死 : (Z)Z
    //   162: pop
    //   163: aload #5
    //   165: bipush #7
    //   167: putfield 淋 : I
    //   170: aload #5
    //   172: iconst_0
    //   173: putfield 코 : Z
    //   176: aload #5
    //   178: invokevirtual 壊 : ()V
    //   181: aload #5
    //   183: getfield 코 : Z
    //   186: ifeq -> 281
    //   189: aload #5
    //   191: getfield 탐 : Ly/背;
    //   194: astore_3
    //   195: getstatic y/尻.ON_RESUME : Ly/尻;
    //   198: astore #4
    //   200: aload_3
    //   201: aload #4
    //   203: invokevirtual 消 : (Ly/尻;)V
    //   206: aload #5
    //   208: getfield 크 : Landroid/view/View;
    //   211: ifnull -> 224
    //   214: aload #5
    //   216: getfield 탑 : Ly/올;
    //   219: aload #4
    //   221: invokevirtual 堅 : (Ly/尻;)V
    //   224: aload #5
    //   226: getfield 投 : Ly/앵;
    //   229: astore_3
    //   230: aload_3
    //   231: iconst_0
    //   232: putfield 踊 : Z
    //   235: aload_3
    //   236: iconst_0
    //   237: putfield 寝 : Z
    //   240: aload_3
    //   241: getfield ち : Ly/약;
    //   244: iconst_0
    //   245: putfield 旨 : Z
    //   248: aload_3
    //   249: bipush #7
    //   251: invokevirtual 臭 : (I)V
    //   254: aload_0
    //   255: getfield 硬 : Ly/ㅇ;
    //   258: iconst_0
    //   259: invokevirtual 不 : (Z)V
    //   262: aload #5
    //   264: aconst_null
    //   265: putfield 怖 : Landroid/os/Bundle;
    //   268: aload #5
    //   270: aconst_null
    //   271: putfield 恐 : Landroid/util/SparseArray;
    //   274: aload #5
    //   276: aconst_null
    //   277: putfield 痛 : Landroid/os/Bundle;
    //   280: return
    //   281: new java/lang/StringBuilder
    //   284: dup
    //   285: ldc_w 'Fragment '
    //   288: invokespecial <init> : (Ljava/lang/String;)V
    //   291: astore_3
    //   292: aload_3
    //   293: aload #5
    //   295: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   298: pop
    //   299: aload_3
    //   300: ldc_w ' did not call through to super.onResume()'
    //   303: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: pop
    //   307: new y/po
    //   310: dup
    //   311: aload_3
    //   312: invokevirtual toString : ()Ljava/lang/String;
    //   315: invokespecial <init> : (Ljava/lang/String;)V
    //   318: athrow
  }
  
  public final void 旨() {
    boolean bool = 앵.噛(3);
    싱 싱1 = this.熱;
    if (bool)
      Objects.toString(싱1); 
    ViewGroup viewGroup = 싱1.쾌;
    if (viewGroup != null) {
      View view = 싱1.크;
      if (view != null)
        viewGroup.removeView(view); 
    } 
    싱1.投.臭(1);
    if (싱1.크 != null) {
      올 올 = 싱1.탑;
      올.熱();
      if (올.恐.興.硬(ぞ.恐))
        싱1.탑.堅(尻.ON_DESTROY); 
    } 
    싱1.淋 = 1;
    싱1.코 = false;
    싱1.興();
    if (싱1.코) {
      gm gm = ((タ)(new 茎(싱1.悲(), タ.暑, 0)).辛(タ.class)).熱;
      if (gm.恐 <= 0) {
        싱1.踊 = false;
        this.硬.悲(false);
        싱1.쾌 = null;
        싱1.크 = null;
        싱1.탑 = null;
        싱1.탕.美(null);
        싱1.歩 = false;
        return;
      } 
      bm.悲(gm.怖[0]);
      throw null;
    } 
    StringBuilder stringBuilder = new StringBuilder("Fragment ");
    stringBuilder.append(싱1);
    stringBuilder.append(" did not call through to super.onDestroyView()");
    throw new po(stringBuilder.toString());
  }
  
  public final int 暑() {
    int i;
    jm jm;
    싱 싱1 = this.熱;
    if (싱1.噛 == null)
      return 싱1.淋; 
    int j = this.冷;
    int k = 싱1.탈.ordinal();
    if (k != 1) {
      if (k != 2) {
        if (k != 3) {
          i = j;
          if (k != 4)
            i = Math.min(j, -1); 
        } else {
          i = Math.min(j, 5);
        } 
      } else {
        i = Math.min(j, 1);
      } 
    } else {
      i = Math.min(j, 0);
    } 
    j = i;
    if (싱1.返)
      if (싱1.歩) {
        i = Math.max(this.冷, 2);
        View view = 싱1.크;
        j = i;
        if (view != null) {
          j = i;
          if (view.getParent() == null)
            j = Math.min(i, 2); 
        } 
      } else if (this.冷 < 4) {
        j = Math.min(i, 싱1.淋);
      } else {
        j = Math.min(i, 1);
      }  
    k = j;
    if (!싱1.壊)
      k = Math.min(j, 1); 
    ViewGroup viewGroup = 싱1.쾌;
    im im = null;
    lm lm = null;
    if (viewGroup != null) {
      im im1;
      lm lm1 = lm.寒(viewGroup, 싱1.辛().寝());
      lm1.getClass();
      im = lm1.暑(싱1);
      if (im != null) {
        jm = im.堅;
      } else {
        im = null;
      } 
      Iterator<im> iterator = lm1.熱.iterator();
      while (true) {
        lm1 = lm;
        if (iterator.hasNext()) {
          im1 = iterator.next();
          if (im1.熱.equals(싱1) && !im1.寒)
            break; 
          continue;
        } 
        break;
      } 
      if (im1 != null && (im == null || im == jm.淋))
        jm = im1.堅; 
    } 
    if (jm == jm.怖) {
      i = Math.min(k, 6);
    } else if (jm == jm.恐) {
      i = Math.max(k, 3);
    } else {
      i = k;
      if (싱1.帰)
        if (싱1.寂()) {
          i = Math.min(k, 1);
        } else {
          i = Math.min(k, -1);
        }  
    } 
    j = i;
    if (싱1.큰) {
      j = i;
      if (싱1.淋 < 5)
        j = Math.min(i, 4); 
    } 
    if (앵.噛(2))
      Objects.toString(싱1); 
    return j;
  }
  
  public final void 淋() {
    싱 싱1 = this.熱;
    if (싱1.크 == null)
      return; 
    if (앵.噛(2)) {
      Objects.toString(싱1);
      Objects.toString(싱1.크);
    } 
    SparseArray sparseArray = new SparseArray();
    싱1.크.saveHierarchyState(sparseArray);
    if (sparseArray.size() > 0)
      싱1.恐 = sparseArray; 
    Bundle bundle = new Bundle();
    싱1.탑.痛.熱(bundle);
    if (!bundle.isEmpty())
      싱1.痛 = bundle; 
  }
  
  public final void 熱() {
    StringBuilder stringBuilder2;
    앵 앵2;
    boolean bool = 앵.噛(3);
    싱 싱1 = this.熱;
    if (bool)
      Objects.toString(싱1); 
    싱 싱2 = 싱1.起;
    String str = null;
    ts ts1 = this.堅;
    if (싱2 != null) {
      str = 싱2.痒;
      do do1 = (do)((HashMap)ts1.堅).get(str);
      if (do1 != null) {
        싱1.興 = 싱1.起.痒;
        싱1.起 = null;
      } else {
        stringBuilder2 = new StringBuilder("Fragment ");
        stringBuilder2.append(싱1);
        stringBuilder2.append(" declared target fragment ");
        stringBuilder2.append(싱1.起);
        stringBuilder2.append(" that does not belong to this FragmentManager!");
        throw new IllegalStateException(stringBuilder2.toString());
      } 
    } else {
      String str1 = 싱1.興;
      if (str1 != null) {
        do do1 = (do)((HashMap)ts1.堅).get(str1);
        if (do1 == null) {
          stringBuilder2 = new StringBuilder("Fragment ");
          stringBuilder2.append(싱1);
          stringBuilder2.append(" declared target fragment ");
          throw new IllegalStateException(bm.旨(stringBuilder2, 싱1.興, " that does not belong to this FragmentManager!"));
        } 
      } 
    } 
    if (stringBuilder2 != null)
      stringBuilder2.ぱ(); 
    앵 앵1 = 싱1.噛;
    싱1.触 = 앵1.痒;
    싱1.あ = 앵1.起;
    ㅇ ㅇ1 = this.硬;
    ㅇ1.美(false);
    ArrayList arrayList = 싱1.택;
    Iterator iterator = arrayList.iterator();
    while (iterator.hasNext()) {
      싱 싱3 = ((실)iterator.next()).硬;
      싱3.태.硬();
      p31.暑((hj)싱3);
    } 
    arrayList.clear();
    싱1.投.堅(싱1.触, 싱1.熱(), 싱1);
    싱1.淋 = 0;
    싱1.코 = false;
    싱1.恐(싱1.触.큰);
    if (싱1.코) {
      Iterator<양> iterator1 = 싱1.噛.嬉.iterator();
      while (iterator1.hasNext())
        ((양)iterator1.next()).堅(); 
      앵2 = 싱1.投;
      앵2.踊 = false;
      앵2.寝 = false;
      앵2.ち.旨 = false;
      앵2.臭(0);
      ㅇ1.堅(false);
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder("Fragment ");
    stringBuilder1.append(앵2);
    stringBuilder1.append(" did not call through to super.onAttach()");
    throw new po(stringBuilder1.toString());
  }
  
  public final void 硬() {
    boolean bool = 앵.噛(3);
    싱 싱1 = this.熱;
    if (bool)
      Objects.toString(싱1); 
    Bundle bundle = 싱1.怖;
    싱1.投.ゃ();
    싱1.淋 = 3;
    싱1.코 = false;
    싱1.淋();
    if (싱1.코) {
      if (앵.噛(3))
        싱1.toString(); 
      View view = 싱1.크;
      if (view != null) {
        bundle = 싱1.怖;
        SparseArray sparseArray = 싱1.恐;
        if (sparseArray != null) {
          view.restoreHierarchyState(sparseArray);
          싱1.恐 = null;
        } 
        if (싱1.크 != null) {
          올 올 = 싱1.탑;
          Bundle bundle1 = 싱1.痛;
          올.痛.堅(bundle1);
          싱1.痛 = null;
        } 
        싱1.코 = false;
        싱1.泳(bundle);
        if (싱1.코) {
          if (싱1.크 != null)
            싱1.탑.堅(尻.ON_CREATE); 
        } else {
          StringBuilder stringBuilder1 = new StringBuilder("Fragment ");
          stringBuilder1.append(싱1);
          stringBuilder1.append(" did not call through to super.onViewStateRestored()");
          throw new po(stringBuilder1.toString());
        } 
      } 
      싱1.怖 = null;
      싱1.投.旨();
      this.硬.硬(false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Fragment ");
    stringBuilder.append(싱1);
    stringBuilder.append(" did not call through to super.onActivityCreated()");
    throw new po(stringBuilder.toString());
  }
  
  public final void 美() {
    // Byte code:
    //   0: iconst_3
    //   1: invokestatic 噛 : (I)Z
    //   4: istore_3
    //   5: aload_0
    //   6: getfield 熱 : Ly/싱;
    //   9: astore #5
    //   11: iload_3
    //   12: ifeq -> 21
    //   15: aload #5
    //   17: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
    //   20: pop
    //   21: aload #5
    //   23: getfield 帰 : Z
    //   26: istore_3
    //   27: iconst_1
    //   28: istore #4
    //   30: iload_3
    //   31: ifeq -> 47
    //   34: aload #5
    //   36: invokevirtual 寂 : ()Z
    //   39: ifne -> 47
    //   42: iconst_1
    //   43: istore_1
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_1
    //   49: aload_0
    //   50: getfield 堅 : Ly/ts;
    //   53: astore #6
    //   55: iload_1
    //   56: ifeq -> 71
    //   59: aload #6
    //   61: aload #5
    //   63: getfield 痒 : Ljava/lang/String;
    //   66: aconst_null
    //   67: invokevirtual 興 : (Ljava/lang/String;Ly/어;)Ly/어;
    //   70: pop
    //   71: iload_1
    //   72: ifne -> 132
    //   75: aload #6
    //   77: getfield 暑 : Ljava/lang/Object;
    //   80: checkcast y/약
    //   83: astore #7
    //   85: aload #7
    //   87: getfield 熱 : Ljava/util/HashMap;
    //   90: aload #5
    //   92: getfield 痒 : Ljava/lang/String;
    //   95: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   98: ifne -> 106
    //   101: iconst_1
    //   102: istore_3
    //   103: goto -> 120
    //   106: aload #7
    //   108: getfield 寒 : Z
    //   111: ifeq -> 101
    //   114: aload #7
    //   116: getfield 美 : Z
    //   119: istore_3
    //   120: iload_3
    //   121: ifeq -> 127
    //   124: goto -> 132
    //   127: iconst_0
    //   128: istore_2
    //   129: goto -> 134
    //   132: iconst_1
    //   133: istore_2
    //   134: iload_2
    //   135: ifeq -> 458
    //   138: aload #5
    //   140: getfield 触 : Ly/싸;
    //   143: astore #7
    //   145: aload #7
    //   147: instanceof y/rx
    //   150: ifeq -> 168
    //   153: aload #6
    //   155: getfield 暑 : Ljava/lang/Object;
    //   158: checkcast y/약
    //   161: getfield 美 : Z
    //   164: istore_3
    //   165: goto -> 197
    //   168: aload #7
    //   170: getfield 큰 : Landroid/content/Context;
    //   173: astore #7
    //   175: iload #4
    //   177: istore_3
    //   178: aload #7
    //   180: instanceof android/app/Activity
    //   183: ifeq -> 197
    //   186: iconst_1
    //   187: aload #7
    //   189: checkcast android/app/Activity
    //   192: invokevirtual isChangingConfigurations : ()Z
    //   195: ixor
    //   196: istore_3
    //   197: iload_1
    //   198: ifeq -> 204
    //   201: goto -> 208
    //   204: iload_3
    //   205: ifeq -> 247
    //   208: aload #6
    //   210: getfield 暑 : Ljava/lang/Object;
    //   213: checkcast y/약
    //   216: astore #7
    //   218: aload #7
    //   220: invokevirtual getClass : ()Ljava/lang/Class;
    //   223: pop
    //   224: iconst_3
    //   225: invokestatic 噛 : (I)Z
    //   228: ifeq -> 237
    //   231: aload #5
    //   233: invokestatic toString : (Ljava/lang/Object;)Ljava/lang/String;
    //   236: pop
    //   237: aload #7
    //   239: aload #5
    //   241: getfield 痒 : Ljava/lang/String;
    //   244: invokevirtual 熱 : (Ljava/lang/String;)V
    //   247: aload #5
    //   249: getfield 投 : Ly/앵;
    //   252: invokevirtual 苦 : ()V
    //   255: aload #5
    //   257: getfield 탐 : Ly/背;
    //   260: getstatic y/尻.ON_DESTROY : Ly/尻;
    //   263: invokevirtual 消 : (Ly/尻;)V
    //   266: aload #5
    //   268: iconst_0
    //   269: putfield 淋 : I
    //   272: aload #5
    //   274: iconst_0
    //   275: putfield 코 : Z
    //   278: aload #5
    //   280: iconst_0
    //   281: putfield 탁 : Z
    //   284: aload #5
    //   286: invokevirtual 起 : ()V
    //   289: aload #5
    //   291: getfield 코 : Z
    //   294: ifeq -> 416
    //   297: aload_0
    //   298: getfield 硬 : Ly/ㅇ;
    //   301: iconst_0
    //   302: invokevirtual 暑 : (Z)V
    //   305: aload #6
    //   307: invokevirtual 嬉 : ()Ljava/util/ArrayList;
    //   310: invokevirtual iterator : ()Ljava/util/Iterator;
    //   313: astore #7
    //   315: aload #7
    //   317: invokeinterface hasNext : ()Z
    //   322: ifeq -> 385
    //   325: aload #7
    //   327: invokeinterface next : ()Ljava/lang/Object;
    //   332: checkcast androidx/fragment/app/do
    //   335: astore #9
    //   337: aload #9
    //   339: ifnull -> 315
    //   342: aload #5
    //   344: getfield 痒 : Ljava/lang/String;
    //   347: astore #8
    //   349: aload #9
    //   351: getfield 熱 : Ly/싱;
    //   354: astore #9
    //   356: aload #8
    //   358: aload #9
    //   360: getfield 興 : Ljava/lang/String;
    //   363: invokevirtual equals : (Ljava/lang/Object;)Z
    //   366: ifeq -> 315
    //   369: aload #9
    //   371: aload #5
    //   373: putfield 起 : Ly/싱;
    //   376: aload #9
    //   378: aconst_null
    //   379: putfield 興 : Ljava/lang/String;
    //   382: goto -> 315
    //   385: aload #5
    //   387: getfield 興 : Ljava/lang/String;
    //   390: astore #7
    //   392: aload #7
    //   394: ifnull -> 409
    //   397: aload #5
    //   399: aload #6
    //   401: aload #7
    //   403: invokevirtual 辛 : (Ljava/lang/String;)Ly/싱;
    //   406: putfield 起 : Ly/싱;
    //   409: aload #6
    //   411: aload_0
    //   412: invokevirtual 臭 : (Landroidx/fragment/app/do;)V
    //   415: return
    //   416: new java/lang/StringBuilder
    //   419: dup
    //   420: ldc_w 'Fragment '
    //   423: invokespecial <init> : (Ljava/lang/String;)V
    //   426: astore #6
    //   428: aload #6
    //   430: aload #5
    //   432: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   435: pop
    //   436: aload #6
    //   438: ldc_w ' did not call through to super.onDestroy()'
    //   441: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: pop
    //   445: new y/po
    //   448: dup
    //   449: aload #6
    //   451: invokevirtual toString : ()Ljava/lang/String;
    //   454: invokespecial <init> : (Ljava/lang/String;)V
    //   457: athrow
    //   458: aload #5
    //   460: getfield 興 : Ljava/lang/String;
    //   463: astore #7
    //   465: aload #7
    //   467: ifnull -> 499
    //   470: aload #6
    //   472: aload #7
    //   474: invokevirtual 辛 : (Ljava/lang/String;)Ly/싱;
    //   477: astore #6
    //   479: aload #6
    //   481: ifnull -> 499
    //   484: aload #6
    //   486: getfield も : Z
    //   489: ifeq -> 499
    //   492: aload #5
    //   494: aload #6
    //   496: putfield 起 : Ly/싱;
    //   499: aload #5
    //   501: iconst_0
    //   502: putfield 淋 : I
    //   505: return
  }
  
  public final void 苦() {
    boolean bool = 앵.噛(3);
    싱 싱1 = this.熱;
    if (bool)
      Objects.toString(싱1); 
    싱1.投.臭(5);
    if (싱1.크 != null)
      싱1.탑.堅(尻.ON_PAUSE); 
    싱1.탐.消(尻.ON_PAUSE);
    싱1.淋 = 6;
    싱1.코 = true;
    this.硬.寒(false);
  }
  
  public final void 辛() {
    싱 싱1 = this.熱;
    if (싱1.返 && 싱1.歩 && !싱1.踊) {
      if (앵.噛(3))
        Objects.toString(싱1); 
      싱1.踊(싱1.死(싱1.怖), null, 싱1.怖);
      View view = 싱1.크;
      if (view != null) {
        view.setSaveFromParentEnabled(false);
        싱1.크.setTag(2131231074, 싱1);
        if (싱1.赤)
          싱1.크.setVisibility(8); 
        싱1.投.臭(2);
        this.硬.嬉(false);
        싱1.淋 = 2;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\fragment\app\do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */