package androidx.recyclerview.widget;

public class RecyclerView$LayoutManager$Properties {
  public int 堅;
  
  public boolean 暑;
  
  public boolean 熱;
  
  public int 硬;
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\recyclerview\widget\RecyclerView$LayoutManager$Properties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */