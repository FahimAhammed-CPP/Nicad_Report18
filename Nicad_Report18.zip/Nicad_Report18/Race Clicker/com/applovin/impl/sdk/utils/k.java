package com.applovin.impl.sdk.utils;

import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import com.applovin.impl.sdk.AppLovinBroadcastManager;
import com.applovin.impl.sdk.o;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class k implements SensorEventListener, AppLovinBroadcastManager.Receiver {
  private final o a;
  
  private final SensorManager b;
  
  private final Sensor c;
  
  private final a d;
  
  private float e;
  
  public k(o paramo, a parama) {
    this.a = paramo;
    SensorManager sensorManager = (SensorManager)o.au().getSystemService("sensor");
    this.b = sensorManager;
    this.c = sensorManager.getDefaultSensor(1);
    this.d = parama;
  }
  
  public void a() {
    this.b.unregisterListener(this);
    this.b.registerListener(this, this.c, (int)TimeUnit.MILLISECONDS.toMicros(50L));
    AppLovinBroadcastManager.unregisterReceiver(this);
    AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.application_paused"));
    AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.application_resumed"));
  }
  
  public void b() {
    AppLovinBroadcastManager.unregisterReceiver(this);
    this.b.unregisterListener(this);
  }
  
  public void onAccuracyChanged(Sensor paramSensor, int paramInt) {}
  
  public void onReceive(Intent paramIntent, Map<String, Object> paramMap) {
    String str = paramIntent.getAction();
    if ("com.applovin.application_paused".equals(str)) {
      this.b.unregisterListener(this);
      return;
    } 
    if ("com.applovin.application_resumed".equals(str))
      a(); 
  }
  
  public void onSensorChanged(SensorEvent paramSensorEvent) {
    if (paramSensorEvent.sensor.getType() == 1) {
      float f2 = Math.max(Math.min(paramSensorEvent.values[2] / 9.81F, 1.0F), -1.0F);
      float f1 = this.e;
      f2 = f1 * 0.5F + f2 * 0.5F;
      this.e = f2;
      if (f1 < 0.8F && f2 > 0.8F) {
        this.d.f();
        return;
      } 
      if (f1 > -0.8F && f2 < -0.8F)
        this.d.e(); 
    } 
  }
  
  public static interface a {
    void e();
    
    void f();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\sd\\utils\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */