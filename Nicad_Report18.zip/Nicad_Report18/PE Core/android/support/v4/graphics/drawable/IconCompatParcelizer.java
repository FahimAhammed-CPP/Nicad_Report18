package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import androidx.core.graphics.drawable.IconCompatParcelizer;
import y.ov;

public final class IconCompatParcelizer extends IconCompatParcelizer {
  public static IconCompat read(ov paramov) {
    return IconCompatParcelizer.read(paramov);
  }
  
  public static void write(IconCompat paramIconCompat, ov paramov) {
    IconCompatParcelizer.write(paramIconCompat, paramov);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\android\support\v4\graphics\drawable\IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */