package com.appsflyer.internal;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public final class AFf1aSDK extends FilterInputStream {
  private static final byte[] AFInAppEventParameterName = AFg1ySDK.values;
  
  private static final int[] AFInAppEventType;
  
  private static final int[] AFKeystoreWrapper;
  
  private static final int[] valueOf = AFg1ySDK.AFKeystoreWrapper;
  
  private static final int[] values = AFg1ySDK.AFInAppEventType;
  
  private final byte[] AFLogger = new byte[16];
  
  private int AFLogger$LogLevel = 16;
  
  private final byte[] AFVersionDeclaration = new byte[16];
  
  private final int[] afDebugLog;
  
  private final int[] afErrorLog = new int[4];
  
  private int afErrorLogForExcManagerOnly = 16;
  
  private final byte[][] afInfoLog;
  
  private final int afRDLog;
  
  private int afWarnLog = Integer.MAX_VALUE;
  
  static {
    AFKeystoreWrapper = AFg1ySDK.valueOf;
    AFInAppEventType = AFg1ySDK.AFInAppEventParameterName;
  }
  
  public AFf1aSDK(InputStream paramInputStream, int paramInt, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1) {
    super(paramInputStream);
    this.afRDLog = paramInt;
    this.afDebugLog = AFg1ySDK.valueOf(paramArrayOfbyte, paramInt);
    this.afInfoLog = AFKeystoreWrapper(paramArrayOfbyte1);
  }
  
  private int AFKeystoreWrapper() throws IOException {
    if (this.afWarnLog == Integer.MAX_VALUE)
      this.afWarnLog = this.in.read(); 
    int i = this.afErrorLogForExcManagerOnly;
    byte b = 16;
    if (i == 16) {
      byte[] arrayOfByte = this.AFLogger;
      i = this.afWarnLog;
      arrayOfByte[0] = (byte)i;
      if (i >= 0) {
        int j;
        i = 1;
        while (true) {
          int k = this.in.read(this.AFLogger, i, 16 - i);
          j = i;
          if (k > 0) {
            j = i + k;
            i = j;
            if (j >= 16)
              break; 
            continue;
          } 
          break;
        } 
        if (j >= 16) {
          AFKeystoreWrapper(this.AFLogger, this.AFVersionDeclaration);
          j = this.in.read();
          this.afWarnLog = j;
          this.afErrorLogForExcManagerOnly = 0;
          i = b;
          if (j < 0)
            i = 16 - (this.AFVersionDeclaration[15] & 0xFF); 
          this.AFLogger$LogLevel = i;
        } else {
          throw new IllegalStateException("unexpected block size");
        } 
      } else {
        throw new IllegalStateException("unexpected block size");
      } 
    } 
    return this.AFLogger$LogLevel;
  }
  
  private void AFKeystoreWrapper(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    int[] arrayOfInt2 = this.afErrorLog;
    int i = paramArrayOfbyte1[0];
    byte b1 = paramArrayOfbyte1[1];
    byte b2 = paramArrayOfbyte1[2];
    byte b3 = paramArrayOfbyte1[3];
    int[] arrayOfInt3 = this.afDebugLog;
    arrayOfInt2[0] = (i << 24 | (b1 & 0xFF) << 16 | (b2 & 0xFF) << 8 | b3 & 0xFF) ^ arrayOfInt3[0];
    arrayOfInt2[1] = (paramArrayOfbyte1[4] << 24 | (paramArrayOfbyte1[5] & 0xFF) << 16 | (paramArrayOfbyte1[6] & 0xFF) << 8 | paramArrayOfbyte1[7] & 0xFF) ^ arrayOfInt3[1];
    arrayOfInt2[2] = (paramArrayOfbyte1[8] << 24 | (paramArrayOfbyte1[9] & 0xFF) << 16 | (paramArrayOfbyte1[10] & 0xFF) << 8 | paramArrayOfbyte1[11] & 0xFF) ^ arrayOfInt3[2];
    i = paramArrayOfbyte1[12];
    b1 = paramArrayOfbyte1[13];
    b2 = paramArrayOfbyte1[14];
    b3 = paramArrayOfbyte1[15];
    arrayOfInt2[3] = arrayOfInt3[3] ^ ((b1 & 0xFF) << 16 | i << 24 | (b2 & 0xFF) << 8 | b3 & 0xFF);
    b1 = 1;
    i = 4;
    while (b1 < this.afRDLog) {
      int[] arrayOfInt4 = valueOf;
      arrayOfInt2 = this.afErrorLog;
      byte[][] arrayOfByte10 = this.afInfoLog;
      byte[] arrayOfByte6 = arrayOfByte10[0];
      int m = arrayOfInt4[arrayOfInt2[arrayOfByte6[0]] >>> 24];
      int[] arrayOfInt5 = values;
      byte[] arrayOfByte7 = arrayOfByte10[1];
      int n = arrayOfInt5[arrayOfInt2[arrayOfByte7[0]] >>> 16 & 0xFF];
      int[] arrayOfInt6 = AFKeystoreWrapper;
      byte[] arrayOfByte8 = arrayOfByte10[2];
      int i1 = arrayOfInt6[arrayOfInt2[arrayOfByte8[0]] >>> 8 & 0xFF];
      int[] arrayOfInt7 = AFInAppEventType;
      byte[] arrayOfByte9 = arrayOfByte10[3];
      int i2 = arrayOfInt7[arrayOfInt2[arrayOfByte9[0]] & 0xFF];
      int[] arrayOfInt8 = this.afDebugLog;
      int i3 = arrayOfInt8[i];
      int i4 = arrayOfInt4[arrayOfInt2[arrayOfByte6[1]] >>> 24];
      int i5 = arrayOfInt5[arrayOfInt2[arrayOfByte7[1]] >>> 16 & 0xFF];
      int i6 = arrayOfInt6[arrayOfInt2[arrayOfByte8[1]] >>> 8 & 0xFF];
      int i7 = arrayOfInt7[arrayOfInt2[arrayOfByte9[1]] & 0xFF];
      int i8 = arrayOfInt8[i + 1];
      int i9 = arrayOfInt4[arrayOfInt2[arrayOfByte6[2]] >>> 24];
      int i10 = arrayOfInt5[arrayOfInt2[arrayOfByte7[2]] >>> 16 & 0xFF];
      int i11 = arrayOfInt6[arrayOfInt2[arrayOfByte8[2]] >>> 8 & 0xFF];
      int i12 = arrayOfInt7[arrayOfInt2[arrayOfByte9[2]] & 0xFF];
      int i13 = arrayOfInt8[i + 2];
      int i14 = arrayOfInt4[arrayOfInt2[arrayOfByte6[3]] >>> 24];
      int i15 = arrayOfInt5[arrayOfInt2[arrayOfByte7[3]] >>> 16 & 0xFF];
      int i16 = arrayOfInt6[arrayOfInt2[arrayOfByte8[3]] >>> 8 & 0xFF];
      int i17 = arrayOfInt7[arrayOfInt2[arrayOfByte9[3]] & 0xFF];
      int i18 = arrayOfInt8[i + 3];
      arrayOfInt2[0] = i2 ^ i1 ^ m ^ n ^ i3;
      arrayOfInt2[1] = i6 ^ i4 ^ i5 ^ i7 ^ i8;
      arrayOfInt2[2] = i10 ^ i9 ^ i11 ^ i12 ^ i13;
      arrayOfInt2[3] = i14 ^ i15 ^ i16 ^ i17 ^ i18;
      int k = b1 + 1;
      i = i + 4;
    } 
    int[] arrayOfInt1 = this.afDebugLog;
    int j = arrayOfInt1[i];
    byte[] arrayOfByte1 = AFInAppEventParameterName;
    arrayOfInt3 = this.afErrorLog;
    byte[][] arrayOfByte = this.afInfoLog;
    byte[] arrayOfByte2 = arrayOfByte[0];
    paramArrayOfbyte2[0] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte2[0]] >>> 24] ^ j >>> 24);
    byte[] arrayOfByte3 = arrayOfByte[1];
    paramArrayOfbyte2[1] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte3[0]] >>> 16 & 0xFF] ^ j >>> 16);
    byte[] arrayOfByte4 = arrayOfByte[2];
    paramArrayOfbyte2[2] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte4[0]] >>> 8 & 0xFF] ^ j >>> 8);
    byte[] arrayOfByte5 = arrayOfByte[3];
    paramArrayOfbyte2[3] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte5[0]] & 0xFF] ^ j);
    j = arrayOfInt1[i + 1];
    paramArrayOfbyte2[4] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte2[1]] >>> 24] ^ j >>> 24);
    paramArrayOfbyte2[5] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte3[1]] >>> 16 & 0xFF] ^ j >>> 16);
    paramArrayOfbyte2[6] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte4[1]] >>> 8 & 0xFF] ^ j >>> 8);
    paramArrayOfbyte2[7] = (byte)(j ^ arrayOfByte1[arrayOfInt3[arrayOfByte5[1]] & 0xFF]);
    j = arrayOfInt1[i + 2];
    paramArrayOfbyte2[8] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte2[2]] >>> 24] ^ j >>> 24);
    paramArrayOfbyte2[9] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte3[2]] >>> 16 & 0xFF] ^ j >>> 16);
    paramArrayOfbyte2[10] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte4[2]] >>> 8 & 0xFF] ^ j >>> 8);
    paramArrayOfbyte2[11] = (byte)(j ^ arrayOfByte1[arrayOfInt3[arrayOfByte5[2]] & 0xFF]);
    i = arrayOfInt1[i + 3];
    paramArrayOfbyte2[12] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte2[3]] >>> 24] ^ i >>> 24);
    paramArrayOfbyte2[13] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte3[3]] >>> 16 & 0xFF] ^ i >>> 16);
    paramArrayOfbyte2[14] = (byte)(arrayOfByte1[arrayOfInt3[arrayOfByte4[3]] >>> 8 & 0xFF] ^ i >>> 8);
    paramArrayOfbyte2[15] = (byte)(i ^ arrayOfByte1[arrayOfInt3[arrayOfByte5[3]] & 0xFF]);
  }
  
  private static byte[][] AFKeystoreWrapper(byte[][] paramArrayOfbyte) {
    byte[][] arrayOfByte = new byte[paramArrayOfbyte.length][];
    int i = 0;
    while (i < paramArrayOfbyte.length) {
      arrayOfByte[i] = new byte[(paramArrayOfbyte[i]).length];
      int j = 0;
      while (true) {
        byte[] arrayOfByte1 = paramArrayOfbyte[i];
        if (j < arrayOfByte1.length) {
          arrayOfByte[i][arrayOfByte1[j]] = (byte)j;
          j++;
          continue;
        } 
        i++;
      } 
    } 
    return arrayOfByte;
  }
  
  public final int available() throws IOException {
    AFKeystoreWrapper();
    return this.AFLogger$LogLevel - this.afErrorLogForExcManagerOnly;
  }
  
  public final void close() throws IOException {
    super.close();
  }
  
  public final void mark(int paramInt) {
    /* monitor enter ThisExpression{ObjectType{com/appsflyer/internal/AFf1aSDK}} */
    /* monitor exit ThisExpression{ObjectType{com/appsflyer/internal/AFf1aSDK}} */
  }
  
  public final boolean markSupported() {
    return false;
  }
  
  public final int read() throws IOException {
    AFKeystoreWrapper();
    int i = this.afErrorLogForExcManagerOnly;
    if (i >= this.AFLogger$LogLevel)
      return -1; 
    byte[] arrayOfByte = this.AFVersionDeclaration;
    this.afErrorLogForExcManagerOnly = i + 1;
    return arrayOfByte[i] & 0xFF;
  }
  
  public final int read(byte[] paramArrayOfbyte) throws IOException {
    return super.read(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }
  
  public final int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    int j = paramInt1 + paramInt2;
    int i;
    for (i = paramInt1; i < j; i++) {
      AFKeystoreWrapper();
      int k = this.afErrorLogForExcManagerOnly;
      if (k >= this.AFLogger$LogLevel)
        return (i == paramInt1) ? -1 : (paramInt2 - j - i); 
      byte[] arrayOfByte = this.AFVersionDeclaration;
      this.afErrorLogForExcManagerOnly = k + 1;
      paramArrayOfbyte[i] = arrayOfByte[k];
    } 
    return paramInt2;
  }
  
  public final void reset() throws IOException {
    /* monitor enter ThisExpression{ObjectType{com/appsflyer/internal/AFf1aSDK}} */
    /* monitor exit ThisExpression{ObjectType{com/appsflyer/internal/AFf1aSDK}} */
  }
  
  public final long skip(long paramLong) throws IOException {
    long l;
    for (l = 0L; l < paramLong && super.read() != -1; l++);
    return l;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFf1aSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */