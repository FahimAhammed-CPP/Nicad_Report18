package androidx.work.impl;

import java.util.concurrent.TimeUnit;
import y.g41;
import y.kh;
import y.ts;
import y.茎;
import y.독;

public abstract class WorkDatabase extends kh {
  public static final long 嬉 = TimeUnit.DAYS.toMillis(1L);
  
  public abstract 독 恐();
  
  public abstract 독 産();
  
  public abstract 茎 痒();
  
  public abstract 독 痛();
  
  public abstract 독 臭();
  
  public abstract g41 興();
  
  public abstract ts 起();
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\WorkDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */