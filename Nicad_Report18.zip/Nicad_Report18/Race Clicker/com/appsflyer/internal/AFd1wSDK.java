package com.appsflyer.internal;

public interface AFd1wSDK {
  void AFInAppEventParameterName(AFd1qSDK<?> paramAFd1qSDK);
  
  void AFInAppEventType(AFd1qSDK<?> paramAFd1qSDK);
  
  void valueOf(AFd1qSDK<?> paramAFd1qSDK, AFd1tSDK paramAFd1tSDK);
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFd1wSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */