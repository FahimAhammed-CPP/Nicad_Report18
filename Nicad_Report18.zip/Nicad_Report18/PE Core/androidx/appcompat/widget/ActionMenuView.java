package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import y.h3;
import y.hy;
import y.o3;
import y.p2;
import y.p3;
import y.q2;
import y.r2;
import y.r3;
import y.x2;
import y.ほ;
import y.ツ;
import y.ナ;
import y.ム;
import y.皮;
import y.蚊;
import y.蝸;
import y.蠊;
import y.륵;
import y.혹;

public class ActionMenuView extends ほ implements q2, r3 {
  public o3 あ;
  
  public p2 か;
  
  public boolean ち;
  
  public ナ も;
  
  public int ゃ;
  
  public final int わ;
  
  public int 噛;
  
  public Context 寝;
  
  public ツ 投;
  
  public boolean 触;
  
  public final int 赤;
  
  public r2 踊;
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.赤 = (int)(56.0F * f);
    this.わ = (int)(f * 4.0F);
    this.寝 = paramContext;
    this.噛 = 0;
  }
  
  public static 蝸 辛(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      蝸 蝸1;
      if (paramLayoutParams instanceof 蝸) {
        蝸1 = new 蝸((蝸)paramLayoutParams);
      } else {
        蝸1 = new 蝸((ViewGroup.LayoutParams)蝸1);
      } 
      if (((LinearLayout.LayoutParams)蝸1).gravity <= 0)
        ((LinearLayout.LayoutParams)蝸1).gravity = 16; 
      return 蝸1;
    } 
    蝸 蝸 = new 蝸();
    ((LinearLayout.LayoutParams)蝸).gravity = 16;
    return 蝸;
  }
  
  public final boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof 蝸;
  }
  
  public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
    蝸 蝸 = new 蝸();
    ((LinearLayout.LayoutParams)蝸).gravity = 16;
    return (ViewGroup.LayoutParams)蝸;
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new 蝸(getContext(), paramAttributeSet);
  }
  
  public Menu getMenu() {
    if (this.踊 == null) {
      륵 륵;
      Context context = getContext();
      r2 r21 = new r2(context);
      this.踊 = r21;
      r21.冷 = (p2)new 혹(3, this);
      ツ ツ2 = new ツ(context);
      this.投 = ツ2;
      ツ2.帰 = true;
      ツ2.返 = true;
      o3 o31 = this.あ;
      if (o31 == null)
        륵 = new 륵(2, null); 
      ツ2.痒 = (o3)륵;
      this.踊.堅((p3)ツ2, this.寝);
      ツ ツ1 = this.投;
      ツ1.興 = this;
      this.踊 = ツ1.恐;
    } 
    return (Menu)this.踊;
  }
  
  public Drawable getOverflowIcon() {
    getMenu();
    ツ ツ1 = this.投;
    蠊 蠊 = ツ1.産;
    return (蠊 != null) ? 蠊.getDrawable() : (ツ1.壊 ? ツ1.死 : null);
  }
  
  public int getPopupTheme() {
    return this.噛;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    ツ ツ1 = this.投;
    if (ツ1 != null) {
      ツ1.冷();
      if (this.投.寒()) {
        this.投.暑();
        this.投.苦();
      } 
    } 
  }
  
  public final void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    ツ ツ1 = this.投;
    if (ツ1 != null) {
      ツ1.暑();
      蚊 蚊 = ツ1.投;
      if (蚊 != null && 蚊.堅())
        ((h3)蚊).辛.dismiss(); 
    } 
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.ち) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int j = getChildCount();
    int i = (paramInt4 - paramInt2) / 2;
    int k = getDividerWidth();
    int m = paramInt3 - paramInt1;
    paramInt1 = m - getPaddingRight() - getPaddingLeft();
    paramBoolean = hy.硬((View)this);
    paramInt2 = 0;
    paramInt4 = 0;
    paramInt3 = 0;
    while (paramInt2 < j) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        蝸 蝸 = (蝸)view.getLayoutParams();
        if (蝸.硬) {
          int i1;
          int n = view.getMeasuredWidth();
          paramInt4 = n;
          if (ぱ(paramInt2))
            paramInt4 = n + k; 
          int i2 = view.getMeasuredHeight();
          if (paramBoolean) {
            i1 = getPaddingLeft() + ((LinearLayout.LayoutParams)蝸).leftMargin;
            n = i1 + paramInt4;
          } else {
            n = getWidth() - getPaddingRight() - ((LinearLayout.LayoutParams)蝸).rightMargin;
            i1 = n - paramInt4;
          } 
          int i3 = i - i2 / 2;
          view.layout(i1, i3, n, i2 + i3);
          paramInt1 -= paramInt4;
          paramInt4 = 1;
        } else {
          paramInt1 -= view.getMeasuredWidth() + ((LinearLayout.LayoutParams)蝸).leftMargin + ((LinearLayout.LayoutParams)蝸).rightMargin;
          ぱ(paramInt2);
          paramInt3++;
        } 
      } 
      paramInt2++;
    } 
    if (j == 1 && paramInt4 == 0) {
      View view = getChildAt(0);
      paramInt1 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt3 = m / 2 - paramInt1 / 2;
      paramInt4 = i - paramInt2 / 2;
      view.layout(paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
      return;
    } 
    paramInt2 = paramInt3 - (paramInt4 ^ 0x1);
    if (paramInt2 > 0) {
      paramInt1 /= paramInt2;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt2 = getWidth() - getPaddingRight();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        蝸 蝸 = (蝸)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (蝸.硬) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 -= ((LinearLayout.LayoutParams)蝸).rightMargin;
            paramInt3 = view.getMeasuredWidth();
            int n = view.getMeasuredHeight();
            int i1 = i - n / 2;
            view.layout(paramInt2 - paramInt3, i1, paramInt2, n + i1);
            paramInt3 = paramInt2 - paramInt3 + ((LinearLayout.LayoutParams)蝸).leftMargin + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } else {
      paramInt2 = getPaddingLeft();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        蝸 蝸 = (蝸)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (蝸.硬) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 += ((LinearLayout.LayoutParams)蝸).leftMargin;
            paramInt3 = view.getMeasuredWidth();
            int n = view.getMeasuredHeight();
            int i1 = i - n / 2;
            view.layout(paramInt2, i1, paramInt2 + paramInt3, n + i1);
            paramInt3 = paramInt3 + ((LinearLayout.LayoutParams)蝸).rightMargin + paramInt4 + paramInt2;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    boolean bool1;
    boolean bool2 = this.ち;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.ち = bool1;
    if (bool2 != bool1)
      this.ゃ = 0; 
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.ち) {
      r2 r21 = this.踊;
      if (r21 != null && i != this.ゃ) {
        this.ゃ = i;
        r21.淋(true);
      } 
    } 
    int j = getChildCount();
    if (this.ち && j > 0) {
      int i2 = View.MeasureSpec.getMode(paramInt2);
      paramInt1 = View.MeasureSpec.getSize(paramInt1);
      int k = View.MeasureSpec.getSize(paramInt2);
      i = getPaddingLeft();
      j = getPaddingRight();
      int m = getPaddingTop();
      int i5 = getPaddingBottom() + m;
      int i6 = ViewGroup.getChildMeasureSpec(paramInt2, i5, -2);
      int i1 = paramInt1 - j + i;
      paramInt2 = this.赤;
      paramInt1 = i1 / paramInt2;
      if (paramInt1 == 0) {
        setMeasuredDimension(i1, 0);
        return;
      } 
      int i8 = i1 % paramInt2 / paramInt1 + paramInt2;
      int i7 = getChildCount();
      m = 0;
      int i3 = 0;
      int i4 = 0;
      int n = 0;
      i = 0;
      long l = 0L;
      j = 0;
      paramInt2 = k;
      k = m;
      while (true) {
        int i11 = this.わ;
        if (n < i7) {
          View view = getChildAt(n);
          if (view.getVisibility() != 8) {
            boolean bool;
            ActionMenuItemView actionMenuItemView;
            bool2 = view instanceof ActionMenuItemView;
            if (bool2)
              view.setPadding(i11, 0, i11, 0); 
            蝸 蝸1 = (蝸)view.getLayoutParams();
            蝸1.寒 = false;
            蝸1.熱 = 0;
            蝸1.堅 = 0;
            蝸1.暑 = false;
            ((LinearLayout.LayoutParams)蝸1).leftMargin = 0;
            ((LinearLayout.LayoutParams)蝸1).rightMargin = 0;
            if (bool2 && ((ActionMenuItemView)view).起()) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            蝸1.冷 = bool1;
            if (蝸1.硬) {
              m = 1;
            } else {
              m = paramInt1;
            } 
            蝸 蝸2 = (蝸)view.getLayoutParams();
            int i13 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i6) - i5, View.MeasureSpec.getMode(i6));
            if (bool2) {
              actionMenuItemView = (ActionMenuItemView)view;
            } else {
              actionMenuItemView = null;
            } 
            if (actionMenuItemView != null && actionMenuItemView.起()) {
              bool = true;
            } else {
              bool = false;
            } 
            if (m > 0 && (!bool || m >= 2)) {
              view.measure(View.MeasureSpec.makeMeasureSpec(m * i8, -2147483648), i13);
              int i15 = view.getMeasuredWidth();
              m = i15 / i8;
              int i14 = m;
              if (i15 % i8 != 0)
                i14 = m + 1; 
              m = i14;
              if (bool) {
                m = i14;
                if (i14 < 2)
                  m = 2; 
              } 
            } else {
              m = 0;
            } 
            if (!蝸2.硬 && bool) {
              bool1 = true;
            } else {
              bool1 = false;
            } 
            蝸2.暑 = bool1;
            蝸2.堅 = m;
            view.measure(View.MeasureSpec.makeMeasureSpec(i8 * m, 1073741824), i13);
            i4 = Math.max(i4, m);
            int i12 = j;
            if (蝸1.暑)
              i12 = j + 1; 
            if (蝸1.硬)
              i = 1; 
            paramInt1 -= m;
            k = Math.max(k, view.getMeasuredHeight());
            long l1 = l;
            if (m == 1)
              l1 = l | (1 << n); 
            i3++;
            j = i12;
            l = l1;
          } 
          n++;
          continue;
        } 
        if (i != 0 && i3 == 2) {
          i5 = 1;
        } else {
          i5 = 0;
        } 
        n = 0;
        int i10 = paramInt1;
        m = i7;
        int i9 = i6;
        for (paramInt1 = n; j > 0 && i10 > 0; paramInt1 = 1) {
          i6 = Integer.MAX_VALUE;
          int i12 = 0;
          i7 = 0;
          long l1;
          for (l1 = 0L; i7 < m; l1 = l2) {
            int i13;
            long l2;
            蝸 蝸 = (蝸)getChildAt(i7).getLayoutParams();
            if (!蝸.暑) {
              i13 = i6;
              n = i12;
              l2 = l1;
            } else {
              int i14 = 蝸.堅;
              if (i14 < i6) {
                l2 = 1L << i7;
                i13 = i14;
                n = 1;
              } else {
                i13 = i6;
                n = i12;
                l2 = l1;
                if (i14 == i6) {
                  l2 = l1 | 1L << i7;
                  n = i12 + 1;
                  i13 = i6;
                } 
              } 
            } 
            i7++;
            i6 = i13;
            i12 = n;
          } 
          l |= l1;
          if (i12 > i10)
            break; 
          paramInt1 = 0;
          while (paramInt1 < m) {
            long l2;
            View view = getChildAt(paramInt1);
            蝸 蝸 = (蝸)view.getLayoutParams();
            long l3 = (1 << paramInt1);
            if ((l1 & l3) == 0L) {
              n = i10;
              l2 = l;
              if (蝸.堅 == i6 + 1) {
                l2 = l | l3;
                n = i10;
              } 
            } else {
              if (i5 != 0 && 蝸.冷 && i10 == 1)
                view.setPadding(i11 + i8, 0, i11, 0); 
              蝸.堅++;
              蝸.寒 = true;
              n = i10 - 1;
              l2 = l;
            } 
            paramInt1++;
            i10 = n;
            l = l2;
          } 
        } 
        if (i == 0 && i3 == 1) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i10 > 0 && l != 0L && (i10 < i3 - 1 || i != 0 || i4 > 1)) {
          float f2 = Long.bitCount(l);
          float f1 = f2;
          if (i == 0) {
            float f = f2;
            if ((l & 0x1L) != 0L) {
              f = f2;
              if (!((蝸)getChildAt(0).getLayoutParams()).冷)
                f = f2 - 0.5F; 
            } 
            i = m - 1;
            f1 = f;
            if ((l & (1 << i)) != 0L) {
              f1 = f;
              if (!((蝸)getChildAt(i).getLayoutParams()).冷)
                f1 = f - 0.5F; 
            } 
          } 
          if (f1 > 0.0F) {
            i = (int)((i10 * i8) / f1);
          } else {
            i = 0;
          } 
          i3 = m;
          j = 0;
          while (true) {
            if (j < i3) {
              if ((l & (1 << j)) == 0L) {
                n = paramInt1;
              } else {
                View view = getChildAt(j);
                蝸 蝸 = (蝸)view.getLayoutParams();
                if (view instanceof ActionMenuItemView) {
                  蝸.熱 = i;
                  蝸.寒 = true;
                  if (j == 0 && !蝸.冷)
                    ((LinearLayout.LayoutParams)蝸).leftMargin = -i / 2; 
                } else if (蝸.硬) {
                  蝸.熱 = i;
                  蝸.寒 = true;
                  ((LinearLayout.LayoutParams)蝸).rightMargin = -i / 2;
                } else {
                  if (j != 0)
                    ((LinearLayout.LayoutParams)蝸).leftMargin = i / 2; 
                  n = paramInt1;
                  if (j != i3 - 1) {
                    ((LinearLayout.LayoutParams)蝸).rightMargin = i / 2;
                    n = paramInt1;
                  } 
                  j++;
                  paramInt1 = n;
                } 
                n = 1;
              } 
            } else {
              break;
            } 
            j++;
            paramInt1 = n;
          } 
        } 
        if (paramInt1 != 0)
          for (paramInt1 = 0; paramInt1 < m; paramInt1++) {
            View view = getChildAt(paramInt1);
            蝸 蝸 = (蝸)view.getLayoutParams();
            if (蝸.寒)
              view.measure(View.MeasureSpec.makeMeasureSpec(蝸.堅 * i8 + 蝸.熱, 1073741824), i9); 
          }  
        if (i2 != 1073741824)
          paramInt2 = k; 
        setMeasuredDimension(i1, paramInt2);
        return;
      } 
    } 
    for (i = 0; i < j; i++) {
      蝸 蝸 = (蝸)getChildAt(i).getLayoutParams();
      ((LinearLayout.LayoutParams)蝸).rightMargin = 0;
      ((LinearLayout.LayoutParams)蝸).leftMargin = 0;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.投.寝 = paramBoolean;
  }
  
  public void setOnMenuItemClickListener(ナ paramナ) {
    this.も = paramナ;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    getMenu();
    ツ ツ1 = this.投;
    蠊 蠊 = ツ1.産;
    if (蠊 != null) {
      蠊.setImageDrawable(paramDrawable);
      return;
    } 
    ツ1.壊 = true;
    ツ1.死 = paramDrawable;
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.触 = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.噛 != paramInt) {
      this.噛 = paramInt;
      if (paramInt == 0) {
        this.寝 = getContext();
        return;
      } 
      this.寝 = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setPresenter(ツ paramツ) {
    this.投 = paramツ;
    paramツ.興 = this;
    this.踊 = paramツ.恐;
  }
  
  public final boolean ぱ(int paramInt) {
    boolean bool;
    int j = 0;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = j;
    if (paramInt < getChildCount()) {
      i = j;
      if (view1 instanceof ム)
        i = false | ((ム)view1).硬(); 
    } 
    j = i;
    if (paramInt > 0) {
      j = i;
      if (view2 instanceof ム)
        bool = i | ((ム)view2).堅(); 
    } 
    return bool;
  }
  
  public final void 堅(r2 paramr2) {
    this.踊 = paramr2;
  }
  
  public final 皮 寒() {
    蝸 蝸 = new 蝸();
    ((LinearLayout.LayoutParams)蝸).gravity = 16;
    return (皮)蝸;
  }
  
  public final boolean 硬(x2 paramx2) {
    return this.踊.怖((MenuItem)paramx2, null, 0);
  }
  
  public final 皮 美(AttributeSet paramAttributeSet) {
    return (皮)new 蝸(getContext(), paramAttributeSet);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */