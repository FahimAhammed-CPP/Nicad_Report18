package androidx.work;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import y.z3;
import y.俺;
import y.급;

public final class OverwritingInputMerger extends 俺 {
  public final 급 硬(ArrayList paramArrayList) {
    z3 z3 = new z3();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator iterator = paramArrayList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(Collections.unmodifiableMap(((급)iterator.next()).硬)); 
    z3.硬(hashMap);
    급 급 = new 급(z3.硬);
    급.堅(급);
    return 급;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */