package androidx.work.impl.model;

import android.database.Cursor;
import androidx.collection.ArrayMap;
import androidx.lifecycle.LiveData;
import androidx.room.EntityInsertionAdapter;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.StringUtil;
import androidx.sqlite.db.SupportSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteStatement;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.WorkInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;

public final class WorkSpecDao_Impl implements WorkSpecDao {
  private final RoomDatabase __db;
  
  private final EntityInsertionAdapter<WorkSpec> __insertionAdapterOfWorkSpec;
  
  private final SharedSQLiteStatement __preparedStmtOfDelete;
  
  private final SharedSQLiteStatement __preparedStmtOfIncrementWorkSpecRunAttemptCount;
  
  private final SharedSQLiteStatement __preparedStmtOfMarkWorkSpecScheduled;
  
  private final SharedSQLiteStatement __preparedStmtOfPruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast;
  
  private final SharedSQLiteStatement __preparedStmtOfResetScheduledState;
  
  private final SharedSQLiteStatement __preparedStmtOfResetWorkSpecRunAttemptCount;
  
  private final SharedSQLiteStatement __preparedStmtOfSetOutput;
  
  private final SharedSQLiteStatement __preparedStmtOfSetPeriodStartTime;
  
  public WorkSpecDao_Impl(RoomDatabase paramRoomDatabase) {
    this.__db = paramRoomDatabase;
    this.__insertionAdapterOfWorkSpec = new EntityInsertionAdapter<WorkSpec>(paramRoomDatabase) {
        public void bind(SupportSQLiteStatement param1SupportSQLiteStatement, WorkSpec param1WorkSpec) {
          throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:539)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
        }
        
        public String createQuery() {
          return "INSERT OR IGNORE INTO `WorkSpec` (`id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`period_start_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`out_of_quota_policy`,`required_network_type`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        }
      };
    this.__preparedStmtOfDelete = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "DELETE FROM workspec WHERE id=?";
        }
      };
    this.__preparedStmtOfSetOutput = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET output=? WHERE id=?";
        }
      };
    this.__preparedStmtOfSetPeriodStartTime = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET period_start_time=? WHERE id=?";
        }
      };
    this.__preparedStmtOfIncrementWorkSpecRunAttemptCount = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET run_attempt_count=run_attempt_count+1 WHERE id=?";
        }
      };
    this.__preparedStmtOfResetWorkSpecRunAttemptCount = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET run_attempt_count=0 WHERE id=?";
        }
      };
    this.__preparedStmtOfMarkWorkSpecScheduled = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET schedule_requested_at=? WHERE id=?";
        }
      };
    this.__preparedStmtOfResetScheduledState = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "UPDATE workspec SET schedule_requested_at=-1 WHERE state NOT IN (2, 3, 5)";
        }
      };
    this.__preparedStmtOfPruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast = new SharedSQLiteStatement(paramRoomDatabase) {
        public String createQuery() {
          return "DELETE FROM workspec WHERE state IN (2, 3, 5) AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))";
        }
      };
  }
  
  private void __fetchRelationshipWorkProgressAsandroidxWorkData(ArrayMap<String, ArrayList<Data>> paramArrayMap) {
    Set set = paramArrayMap.keySet();
    if (set.isEmpty())
      return; 
    if (paramArrayMap.size() > 999) {
      ArrayMap<String, ArrayList<Data>> arrayMap = new ArrayMap(999);
      int k = paramArrayMap.size();
      int j = 0;
      while (true) {
        int m = 0;
        while (j < k) {
          arrayMap.put(paramArrayMap.keyAt(j), paramArrayMap.valueAt(j));
          int n = j + 1;
          int i1 = m + 1;
          j = n;
          m = i1;
          if (i1 == 999) {
            __fetchRelationshipWorkProgressAsandroidxWorkData(arrayMap);
            arrayMap = new ArrayMap(999);
            j = n;
          } 
        } 
        if (m > 0)
          __fetchRelationshipWorkProgressAsandroidxWorkData(arrayMap); 
        return;
      } 
    } 
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT `progress`,`work_spec_id` FROM `WorkProgress` WHERE `work_spec_id` IN (");
    int i = set.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    Iterator<String> iterator = set.iterator();
    for (i = 1; iterator.hasNext(); i++) {
      String str = iterator.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      i = CursorUtil.getColumnIndex(cursor, "work_spec_id");
      if (i == -1)
        return; 
      while (cursor.moveToNext()) {
        if (!cursor.isNull(i)) {
          ArrayList<Data> arrayList = (ArrayList)paramArrayMap.get(cursor.getString(i));
          if (arrayList != null)
            arrayList.add(Data.fromByteArray(cursor.getBlob(0))); 
        } 
      } 
      return;
    } finally {
      cursor.close();
    } 
  }
  
  private void __fetchRelationshipWorkTagAsjavaLangString(ArrayMap<String, ArrayList<String>> paramArrayMap) {
    Set set = paramArrayMap.keySet();
    if (set.isEmpty())
      return; 
    if (paramArrayMap.size() > 999) {
      ArrayMap<String, ArrayList<String>> arrayMap = new ArrayMap(999);
      int k = paramArrayMap.size();
      int j = 0;
      while (true) {
        int m = 0;
        while (j < k) {
          arrayMap.put(paramArrayMap.keyAt(j), paramArrayMap.valueAt(j));
          int n = j + 1;
          int i1 = m + 1;
          j = n;
          m = i1;
          if (i1 == 999) {
            __fetchRelationshipWorkTagAsjavaLangString(arrayMap);
            arrayMap = new ArrayMap(999);
            j = n;
          } 
        } 
        if (m > 0)
          __fetchRelationshipWorkTagAsjavaLangString(arrayMap); 
        return;
      } 
    } 
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT `tag`,`work_spec_id` FROM `WorkTag` WHERE `work_spec_id` IN (");
    int i = set.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    Iterator<String> iterator = set.iterator();
    for (i = 1; iterator.hasNext(); i++) {
      String str = iterator.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      i = CursorUtil.getColumnIndex(cursor, "work_spec_id");
      if (i == -1)
        return; 
      while (cursor.moveToNext()) {
        if (!cursor.isNull(i)) {
          ArrayList<String> arrayList = (ArrayList)paramArrayMap.get(cursor.getString(i));
          if (arrayList != null)
            arrayList.add(cursor.getString(0)); 
        } 
      } 
      return;
    } finally {
      cursor.close();
    } 
  }
  
  public void delete(String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfDelete.acquire();
    if (paramString == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindString(1, paramString);
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfDelete.release(supportSQLiteStatement);
    } 
  }
  
  public List<WorkSpec> getAllEligibleWorkSpecsForScheduling(int paramInt) {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 ORDER BY period_start_time LIMIT ?", 1);
    roomSQLiteQuery.bindLong(1, paramInt);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      try {
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
        paramInt = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "period_start_time");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            Constraints constraints = new Constraints();
            constraints.setRequiredNetworkType(WorkTypeConverters.intToNetworkType(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresCharging(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresDeviceIdle(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresBatteryNotLow(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresStorageNotLow(bool);
            constraints.setTriggerContentUpdateDelay(cursor.getLong(i5));
            constraints.setTriggerMaxContentDelay(cursor.getLong(i6));
            constraints.setContentUriTriggers(WorkTypeConverters.byteArrayToContentUriTriggers(cursor.getBlob(i7)));
            WorkSpec workSpec = new WorkSpec(str1, str2);
            workSpec.state = WorkTypeConverters.intToState(cursor.getInt(i8));
            workSpec.inputMergerClassName = cursor.getString(i1);
            workSpec.input = Data.fromByteArray(cursor.getBlob(i9));
            workSpec.output = Data.fromByteArray(cursor.getBlob(i3));
            workSpec.initialDelay = cursor.getLong(i16);
            workSpec.intervalDuration = cursor.getLong(i15);
            workSpec.flexDuration = cursor.getLong(i19);
            workSpec.runAttemptCount = cursor.getInt(i14);
            workSpec.backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(paramInt));
            workSpec.backoffDelayDuration = cursor.getLong(i11);
            workSpec.periodStartTime = cursor.getLong(i18);
            workSpec.minimumRetentionDuration = cursor.getLong(i12);
            workSpec.scheduleRequestedAt = cursor.getLong(i13);
            if (cursor.getInt(i10) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            workSpec.expedited = bool;
            workSpec.outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i17));
            workSpec.constraints = constraints;
            arrayList.add(workSpec);
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public List<String> getAllUnfinishedWork() {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5)", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public List<String> getAllWorkSpecIds() {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id FROM workspec", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public LiveData<List<String>> getAllWorkSpecIdsLiveData() {
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT id FROM workspec", 0);
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<List<String>> callable = new Callable<List<String>>() {
        public List<String> call() throws Exception {
          WorkSpecDao_Impl.this.__db.beginTransaction();
          try {
            Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, false, null);
          } finally {
            WorkSpecDao_Impl.this.__db.endTransaction();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "workspec" }, true, callable);
  }
  
  public List<WorkSpec> getEligibleWorkForScheduling(int paramInt) {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY period_start_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND state NOT IN (2, 3, 5))", 1);
    roomSQLiteQuery.bindLong(1, paramInt);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      try {
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
        paramInt = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "period_start_time");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            Constraints constraints = new Constraints();
            constraints.setRequiredNetworkType(WorkTypeConverters.intToNetworkType(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresCharging(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresDeviceIdle(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresBatteryNotLow(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresStorageNotLow(bool);
            constraints.setTriggerContentUpdateDelay(cursor.getLong(i5));
            constraints.setTriggerMaxContentDelay(cursor.getLong(i6));
            constraints.setContentUriTriggers(WorkTypeConverters.byteArrayToContentUriTriggers(cursor.getBlob(i7)));
            WorkSpec workSpec = new WorkSpec(str1, str2);
            workSpec.state = WorkTypeConverters.intToState(cursor.getInt(i8));
            workSpec.inputMergerClassName = cursor.getString(i1);
            workSpec.input = Data.fromByteArray(cursor.getBlob(i9));
            workSpec.output = Data.fromByteArray(cursor.getBlob(i3));
            workSpec.initialDelay = cursor.getLong(i16);
            workSpec.intervalDuration = cursor.getLong(i15);
            workSpec.flexDuration = cursor.getLong(i19);
            workSpec.runAttemptCount = cursor.getInt(i14);
            workSpec.backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(paramInt));
            workSpec.backoffDelayDuration = cursor.getLong(i11);
            workSpec.periodStartTime = cursor.getLong(i18);
            workSpec.minimumRetentionDuration = cursor.getLong(i12);
            workSpec.scheduleRequestedAt = cursor.getLong(i13);
            if (cursor.getInt(i10) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            workSpec.expedited = bool;
            workSpec.outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i17));
            workSpec.constraints = constraints;
            arrayList.add(workSpec);
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public List<Data> getInputsFromPrerequisites(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT output FROM workspec WHERE id IN (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<Data> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(Data.fromByteArray(cursor.getBlob(0))); 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public List<WorkSpec> getRecentlyCompletedWork(long paramLong) {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE period_start_time >= ? AND state IN (2, 3, 5) ORDER BY period_start_time DESC", 1);
    roomSQLiteQuery.bindLong(1, paramLong);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      try {
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "period_start_time");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            Constraints constraints = new Constraints();
            constraints.setRequiredNetworkType(WorkTypeConverters.intToNetworkType(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresCharging(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresDeviceIdle(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresBatteryNotLow(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresStorageNotLow(bool);
            constraints.setTriggerContentUpdateDelay(cursor.getLong(i5));
            constraints.setTriggerMaxContentDelay(cursor.getLong(i6));
            constraints.setContentUriTriggers(WorkTypeConverters.byteArrayToContentUriTriggers(cursor.getBlob(i7)));
            WorkSpec workSpec = new WorkSpec(str1, str2);
            workSpec.state = WorkTypeConverters.intToState(cursor.getInt(i8));
            workSpec.inputMergerClassName = cursor.getString(i1);
            workSpec.input = Data.fromByteArray(cursor.getBlob(i9));
            workSpec.output = Data.fromByteArray(cursor.getBlob(i3));
            workSpec.initialDelay = cursor.getLong(i15);
            workSpec.intervalDuration = cursor.getLong(i18);
            workSpec.flexDuration = cursor.getLong(i20);
            workSpec.runAttemptCount = cursor.getInt(i16);
            workSpec.backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i10));
            workSpec.backoffDelayDuration = cursor.getLong(i12);
            workSpec.periodStartTime = cursor.getLong(i19);
            workSpec.minimumRetentionDuration = cursor.getLong(i13);
            workSpec.scheduleRequestedAt = cursor.getLong(i14);
            if (cursor.getInt(i11) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            workSpec.expedited = bool;
            workSpec.outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i17));
            workSpec.constraints = constraints;
            arrayList.add(workSpec);
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public List<WorkSpec> getRunningWork() {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=1", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      try {
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "period_start_time");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            Constraints constraints = new Constraints();
            constraints.setRequiredNetworkType(WorkTypeConverters.intToNetworkType(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresCharging(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresDeviceIdle(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresBatteryNotLow(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresStorageNotLow(bool);
            constraints.setTriggerContentUpdateDelay(cursor.getLong(i5));
            constraints.setTriggerMaxContentDelay(cursor.getLong(i6));
            constraints.setContentUriTriggers(WorkTypeConverters.byteArrayToContentUriTriggers(cursor.getBlob(i7)));
            WorkSpec workSpec = new WorkSpec(str1, str2);
            workSpec.state = WorkTypeConverters.intToState(cursor.getInt(i8));
            workSpec.inputMergerClassName = cursor.getString(i9);
            workSpec.input = Data.fromByteArray(cursor.getBlob(i1));
            workSpec.output = Data.fromByteArray(cursor.getBlob(i3));
            workSpec.initialDelay = cursor.getLong(i17);
            workSpec.intervalDuration = cursor.getLong(i16);
            workSpec.flexDuration = cursor.getLong(i20);
            workSpec.runAttemptCount = cursor.getInt(i15);
            workSpec.backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i10));
            workSpec.backoffDelayDuration = cursor.getLong(i12);
            workSpec.periodStartTime = cursor.getLong(i19);
            workSpec.minimumRetentionDuration = cursor.getLong(i13);
            workSpec.scheduleRequestedAt = cursor.getLong(i14);
            if (cursor.getInt(i11) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            workSpec.expedited = bool;
            workSpec.outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i18));
            workSpec.constraints = constraints;
            arrayList.add(workSpec);
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public LiveData<Long> getScheduleRequestedAtLiveData(String paramString) {
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT schedule_requested_at FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<Long> callable = new Callable<Long>() {
        public Long call() throws Exception {
          null = WorkSpecDao_Impl.this.__db;
          RoomSQLiteQuery roomSQLiteQuery = _statement;
          RoomDatabase roomDatabase = null;
          Cursor cursor = DBUtil.query(null, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
          null = roomDatabase;
          try {
            Long long_;
            if (cursor.moveToFirst())
              if (cursor.isNull(0)) {
                null = roomDatabase;
              } else {
                long_ = Long.valueOf(cursor.getLong(0));
              }  
            return long_;
          } finally {
            cursor.close();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "workspec" }, false, callable);
  }
  
  public List<WorkSpec> getScheduledWork() {
    Exception exception;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at<>-1", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      try {
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "period_start_time");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        ArrayList<WorkSpec> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            Constraints constraints = new Constraints();
            constraints.setRequiredNetworkType(WorkTypeConverters.intToNetworkType(cursor.getInt(n)));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresCharging(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresDeviceIdle(bool);
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresBatteryNotLow(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresStorageNotLow(bool);
            constraints.setTriggerContentUpdateDelay(cursor.getLong(i5));
            constraints.setTriggerMaxContentDelay(cursor.getLong(i6));
            constraints.setContentUriTriggers(WorkTypeConverters.byteArrayToContentUriTriggers(cursor.getBlob(i7)));
            WorkSpec workSpec = new WorkSpec(str1, str2);
            workSpec.state = WorkTypeConverters.intToState(cursor.getInt(i8));
            workSpec.inputMergerClassName = cursor.getString(i9);
            workSpec.input = Data.fromByteArray(cursor.getBlob(i1));
            workSpec.output = Data.fromByteArray(cursor.getBlob(i3));
            workSpec.initialDelay = cursor.getLong(i17);
            workSpec.intervalDuration = cursor.getLong(i16);
            workSpec.flexDuration = cursor.getLong(i20);
            workSpec.runAttemptCount = cursor.getInt(i15);
            workSpec.backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i10));
            workSpec.backoffDelayDuration = cursor.getLong(i12);
            workSpec.periodStartTime = cursor.getLong(i19);
            workSpec.minimumRetentionDuration = cursor.getLong(i13);
            workSpec.scheduleRequestedAt = cursor.getLong(i14);
            if (cursor.getInt(i11) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            workSpec.expedited = bool;
            workSpec.outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i18));
            workSpec.constraints = constraints;
            arrayList.add(workSpec);
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw exception;
  }
  
  public WorkInfo.State getState(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT state FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    RoomDatabase roomDatabase = this.__db;
    paramString = null;
    Cursor cursor = DBUtil.query(roomDatabase, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      WorkInfo.State state;
      if (cursor.moveToFirst())
        state = WorkTypeConverters.intToState(cursor.getInt(0)); 
      return state;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public List<String> getUnfinishedWorkWithName(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public List<String> getUnfinishedWorkWithTag(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM worktag WHERE tag=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public WorkSpec getWorkSpec(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      try {
        int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "period_start_time");
        int i17 = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        if (cursor.moveToFirst()) {
          boolean bool;
          paramString = cursor.getString(i4);
          String str = cursor.getString(i6);
          Constraints constraints = new Constraints();
          constraints.setRequiredNetworkType(WorkTypeConverters.intToNetworkType(cursor.getInt(i)));
          if (cursor.getInt(j) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          constraints.setRequiresCharging(bool);
          if (cursor.getInt(k) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          constraints.setRequiresDeviceIdle(bool);
          if (cursor.getInt(m) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          constraints.setRequiresBatteryNotLow(bool);
          if (cursor.getInt(n) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          constraints.setRequiresStorageNotLow(bool);
          constraints.setTriggerContentUpdateDelay(cursor.getLong(i1));
          constraints.setTriggerMaxContentDelay(cursor.getLong(i2));
          constraints.setContentUriTriggers(WorkTypeConverters.byteArrayToContentUriTriggers(cursor.getBlob(i3)));
          WorkSpec workSpec = new WorkSpec(paramString, str);
          workSpec.state = WorkTypeConverters.intToState(cursor.getInt(i5));
          workSpec.inputMergerClassName = cursor.getString(i7);
          workSpec.input = Data.fromByteArray(cursor.getBlob(i8));
          workSpec.output = Data.fromByteArray(cursor.getBlob(i9));
          workSpec.initialDelay = cursor.getLong(i10);
          workSpec.intervalDuration = cursor.getLong(i11);
          workSpec.flexDuration = cursor.getLong(i12);
          workSpec.runAttemptCount = cursor.getInt(i13);
          workSpec.backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i14));
          workSpec.backoffDelayDuration = cursor.getLong(i15);
          workSpec.periodStartTime = cursor.getLong(i16);
          workSpec.minimumRetentionDuration = cursor.getLong(i17);
          workSpec.scheduleRequestedAt = cursor.getLong(i18);
          if (cursor.getInt(i19) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          workSpec.expedited = bool;
          workSpec.outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i20));
          workSpec.constraints = constraints;
        } else {
          paramString = null;
        } 
        cursor.close();
        roomSQLiteQuery.release();
        return (WorkSpec)paramString;
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw paramString;
  }
  
  public List<WorkSpec.IdAndState> getWorkSpecIdAndStatesForName(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int i = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      ArrayList<WorkSpec.IdAndState> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        WorkSpec.IdAndState idAndState = new WorkSpec.IdAndState();
        idAndState.id = cursor.getString(i);
        idAndState.state = WorkTypeConverters.intToState(cursor.getInt(j));
        arrayList.add(idAndState);
      } 
      return arrayList;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public WorkSpec[] getWorkSpecs(List<String> paramList) {
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT ");
    stringBuilder.append("*");
    stringBuilder.append(" FROM workspec WHERE id IN (");
    int i = paramList.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    Iterator<String> iterator = paramList.iterator();
    for (i = 1; iterator.hasNext(); i++) {
      String str = iterator.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    try {
      int i2 = CursorUtil.getColumnIndexOrThrow(cursor, "required_network_type");
      int i3 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_charging");
      int j = CursorUtil.getColumnIndexOrThrow(cursor, "requires_device_idle");
      int i4 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_battery_not_low");
      int i5 = CursorUtil.getColumnIndexOrThrow(cursor, "requires_storage_not_low");
      int i6 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_content_update_delay");
      int i7 = CursorUtil.getColumnIndexOrThrow(cursor, "trigger_max_content_delay");
      int i8 = CursorUtil.getColumnIndexOrThrow(cursor, "content_uri_triggers");
      int i1 = CursorUtil.getColumnIndexOrThrow(cursor, "id");
      int i9 = CursorUtil.getColumnIndexOrThrow(cursor, "state");
      int m = CursorUtil.getColumnIndexOrThrow(cursor, "worker_class_name");
      int k = CursorUtil.getColumnIndexOrThrow(cursor, "input_merger_class_name");
      int i10 = CursorUtil.getColumnIndexOrThrow(cursor, "input");
      int n = CursorUtil.getColumnIndexOrThrow(cursor, "output");
      try {
        int i21 = CursorUtil.getColumnIndexOrThrow(cursor, "initial_delay");
        int i13 = CursorUtil.getColumnIndexOrThrow(cursor, "interval_duration");
        int i20 = CursorUtil.getColumnIndexOrThrow(cursor, "flex_duration");
        int i11 = CursorUtil.getColumnIndexOrThrow(cursor, "run_attempt_count");
        i = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_policy");
        int i14 = CursorUtil.getColumnIndexOrThrow(cursor, "backoff_delay_duration");
        int i19 = CursorUtil.getColumnIndexOrThrow(cursor, "period_start_time");
        int i18 = CursorUtil.getColumnIndexOrThrow(cursor, "minimum_retention_duration");
        int i15 = CursorUtil.getColumnIndexOrThrow(cursor, "schedule_requested_at");
        int i12 = CursorUtil.getColumnIndexOrThrow(cursor, "run_in_foreground");
        int i16 = CursorUtil.getColumnIndexOrThrow(cursor, "out_of_quota_policy");
        WorkSpec[] arrayOfWorkSpec = new WorkSpec[cursor.getCount()];
        int i17 = 0;
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(i1);
            String str2 = cursor.getString(m);
            Constraints constraints = new Constraints();
            constraints.setRequiredNetworkType(WorkTypeConverters.intToNetworkType(cursor.getInt(i2)));
            if (cursor.getInt(i3) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresCharging(bool);
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresDeviceIdle(bool);
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresBatteryNotLow(bool);
            if (cursor.getInt(i5) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            constraints.setRequiresStorageNotLow(bool);
            constraints.setTriggerContentUpdateDelay(cursor.getLong(i6));
            constraints.setTriggerMaxContentDelay(cursor.getLong(i7));
            constraints.setContentUriTriggers(WorkTypeConverters.byteArrayToContentUriTriggers(cursor.getBlob(i8)));
            WorkSpec workSpec = new WorkSpec(str1, str2);
            workSpec.state = WorkTypeConverters.intToState(cursor.getInt(i9));
            workSpec.inputMergerClassName = cursor.getString(k);
            workSpec.input = Data.fromByteArray(cursor.getBlob(i10));
            workSpec.output = Data.fromByteArray(cursor.getBlob(n));
            workSpec.initialDelay = cursor.getLong(i21);
            workSpec.intervalDuration = cursor.getLong(i13);
            workSpec.flexDuration = cursor.getLong(i20);
            workSpec.runAttemptCount = cursor.getInt(i11);
            workSpec.backoffPolicy = WorkTypeConverters.intToBackoffPolicy(cursor.getInt(i));
            workSpec.backoffDelayDuration = cursor.getLong(i14);
            workSpec.periodStartTime = cursor.getLong(i19);
            workSpec.minimumRetentionDuration = cursor.getLong(i18);
            workSpec.scheduleRequestedAt = cursor.getLong(i15);
            if (cursor.getInt(i12) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            workSpec.expedited = bool;
            workSpec.outOfQuotaPolicy = WorkTypeConverters.intToOutOfQuotaPolicy(cursor.getInt(i16));
            workSpec.constraints = constraints;
            arrayOfWorkSpec[i17] = workSpec;
            i17++;
            continue;
          } 
          cursor.close();
          roomSQLiteQuery.release();
          return arrayOfWorkSpec;
        } 
      } finally {}
    } finally {}
    cursor.close();
    roomSQLiteQuery.release();
    throw iterator;
  }
  
  public WorkSpec.WorkInfoPojo getWorkStatusPojoForId(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      RoomDatabase roomDatabase = this.__db;
      paramString = null;
      String str = null;
      Cursor cursor = DBUtil.query(roomDatabase, (SupportSQLiteQuery)roomSQLiteQuery, true, null);
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public List<WorkSpec.WorkInfoPojo> getWorkStatusPojoForIds(List<String> paramList) {
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT id, state, output, run_attempt_count FROM workspec WHERE id IN (");
    int i = paramList.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    null = paramList.iterator();
    for (i = 1; null.hasNext(); i++) {
      String str = null.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, true, null);
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public List<WorkSpec.WorkInfoPojo> getWorkStatusPojoForName(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, true, null);
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public List<WorkSpec.WorkInfoPojo> getWorkStatusPojoForTag(String paramString) {
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count FROM workspec WHERE id IN (SELECT work_spec_id FROM worktag WHERE tag=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, true, null);
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public LiveData<List<WorkSpec.WorkInfoPojo>> getWorkStatusPojoLiveDataForIds(List<String> paramList) {
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("SELECT id, state, output, run_attempt_count FROM workspec WHERE id IN (");
    int i = paramList.size();
    StringUtil.appendPlaceholders(stringBuilder, i);
    stringBuilder.append(")");
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(stringBuilder.toString(), i + 0);
    Iterator<String> iterator = paramList.iterator();
    for (i = 1; iterator.hasNext(); i++) {
      String str = iterator.next();
      if (str == null) {
        roomSQLiteQuery.bindNull(i);
      } else {
        roomSQLiteQuery.bindString(i, str);
      } 
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<List<WorkSpec.WorkInfoPojo>> callable = new Callable<List<WorkSpec.WorkInfoPojo>>() {
        public List<WorkSpec.WorkInfoPojo> call() throws Exception {
          WorkSpecDao_Impl.this.__db.beginTransaction();
          try {
            Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, true, null);
          } finally {
            WorkSpecDao_Impl.this.__db.endTransaction();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "WorkTag", "WorkProgress", "workspec" }, true, callable);
  }
  
  public LiveData<List<WorkSpec.WorkInfoPojo>> getWorkStatusPojoLiveDataForName(String paramString) {
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<List<WorkSpec.WorkInfoPojo>> callable = new Callable<List<WorkSpec.WorkInfoPojo>>() {
        public List<WorkSpec.WorkInfoPojo> call() throws Exception {
          WorkSpecDao_Impl.this.__db.beginTransaction();
          try {
            Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, true, null);
          } finally {
            WorkSpecDao_Impl.this.__db.endTransaction();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "WorkTag", "WorkProgress", "workspec", "workname" }, true, callable);
  }
  
  public LiveData<List<WorkSpec.WorkInfoPojo>> getWorkStatusPojoLiveDataForTag(String paramString) {
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT id, state, output, run_attempt_count FROM workspec WHERE id IN (SELECT work_spec_id FROM worktag WHERE tag=?)", 1);
    if (paramString == null) {
      roomSQLiteQuery.bindNull(1);
    } else {
      roomSQLiteQuery.bindString(1, paramString);
    } 
    InvalidationTracker invalidationTracker = this.__db.getInvalidationTracker();
    Callable<List<WorkSpec.WorkInfoPojo>> callable = new Callable<List<WorkSpec.WorkInfoPojo>>() {
        public List<WorkSpec.WorkInfoPojo> call() throws Exception {
          WorkSpecDao_Impl.this.__db.beginTransaction();
          try {
            Cursor cursor = DBUtil.query(WorkSpecDao_Impl.this.__db, (SupportSQLiteQuery)_statement, true, null);
          } finally {
            WorkSpecDao_Impl.this.__db.endTransaction();
          } 
        }
        
        protected void finalize() {
          _statement.release();
        }
      };
    return invalidationTracker.createLiveData(new String[] { "WorkTag", "WorkProgress", "workspec", "worktag" }, true, callable);
  }
  
  public boolean hasUnfinishedWork() {
    boolean bool2 = false;
    RoomSQLiteQuery roomSQLiteQuery = RoomSQLiteQuery.acquire("SELECT COUNT(*) > 0 FROM workspec WHERE state NOT IN (2, 3, 5) LIMIT 1", 0);
    this.__db.assertNotSuspendingTransaction();
    Cursor cursor = DBUtil.query(this.__db, (SupportSQLiteQuery)roomSQLiteQuery, false, null);
    boolean bool1 = bool2;
    try {
      if (cursor.moveToFirst()) {
        int i = cursor.getInt(0);
        bool1 = bool2;
        if (i != 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
      roomSQLiteQuery.release();
    } 
  }
  
  public int incrementWorkSpecRunAttemptCount(String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfIncrementWorkSpecRunAttemptCount.acquire();
    if (paramString == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindString(1, paramString);
    } 
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfIncrementWorkSpecRunAttemptCount.release(supportSQLiteStatement);
    } 
  }
  
  public void insertWorkSpec(WorkSpec paramWorkSpec) {
    this.__db.assertNotSuspendingTransaction();
    this.__db.beginTransaction();
    try {
      this.__insertionAdapterOfWorkSpec.insert(paramWorkSpec);
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
    } 
  }
  
  public int markWorkSpecScheduled(String paramString, long paramLong) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfMarkWorkSpecScheduled.acquire();
    supportSQLiteStatement.bindLong(1, paramLong);
    if (paramString == null) {
      supportSQLiteStatement.bindNull(2);
    } else {
      supportSQLiteStatement.bindString(2, paramString);
    } 
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfMarkWorkSpecScheduled.release(supportSQLiteStatement);
    } 
  }
  
  public void pruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast() {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfPruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast.acquire();
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfPruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast.release(supportSQLiteStatement);
    } 
  }
  
  public int resetScheduledState() {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfResetScheduledState.acquire();
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfResetScheduledState.release(supportSQLiteStatement);
    } 
  }
  
  public int resetWorkSpecRunAttemptCount(String paramString) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfResetWorkSpecRunAttemptCount.acquire();
    if (paramString == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindString(1, paramString);
    } 
    this.__db.beginTransaction();
    try {
      int i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfResetWorkSpecRunAttemptCount.release(supportSQLiteStatement);
    } 
  }
  
  public void setOutput(String paramString, Data paramData) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfSetOutput.acquire();
    byte[] arrayOfByte = Data.toByteArrayInternal(paramData);
    if (arrayOfByte == null) {
      supportSQLiteStatement.bindNull(1);
    } else {
      supportSQLiteStatement.bindBlob(1, arrayOfByte);
    } 
    if (paramString == null) {
      supportSQLiteStatement.bindNull(2);
    } else {
      supportSQLiteStatement.bindString(2, paramString);
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfSetOutput.release(supportSQLiteStatement);
    } 
  }
  
  public void setPeriodStartTime(String paramString, long paramLong) {
    this.__db.assertNotSuspendingTransaction();
    SupportSQLiteStatement supportSQLiteStatement = this.__preparedStmtOfSetPeriodStartTime.acquire();
    supportSQLiteStatement.bindLong(1, paramLong);
    if (paramString == null) {
      supportSQLiteStatement.bindNull(2);
    } else {
      supportSQLiteStatement.bindString(2, paramString);
    } 
    this.__db.beginTransaction();
    try {
      supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return;
    } finally {
      this.__db.endTransaction();
      this.__preparedStmtOfSetPeriodStartTime.release(supportSQLiteStatement);
    } 
  }
  
  public int setState(WorkInfo.State paramState, String... paramVarArgs) {
    this.__db.assertNotSuspendingTransaction();
    StringBuilder stringBuilder = StringUtil.newStringBuilder();
    stringBuilder.append("UPDATE workspec SET state=");
    stringBuilder.append("?");
    stringBuilder.append(" WHERE id IN (");
    StringUtil.appendPlaceholders(stringBuilder, paramVarArgs.length);
    stringBuilder.append(")");
    String str = stringBuilder.toString();
    SupportSQLiteStatement supportSQLiteStatement = this.__db.compileStatement(str);
    supportSQLiteStatement.bindLong(1, WorkTypeConverters.stateToInt(paramState));
    int k = paramVarArgs.length;
    int j = 2;
    int i;
    for (i = 0; i < k; i++) {
      String str1 = paramVarArgs[i];
      if (str1 == null) {
        supportSQLiteStatement.bindNull(j);
      } else {
        supportSQLiteStatement.bindString(j, str1);
      } 
      j++;
    } 
    this.__db.beginTransaction();
    try {
      i = supportSQLiteStatement.executeUpdateDelete();
      this.__db.setTransactionSuccessful();
      return i;
    } finally {
      this.__db.endTransaction();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\work\impl\model\WorkSpecDao_Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */