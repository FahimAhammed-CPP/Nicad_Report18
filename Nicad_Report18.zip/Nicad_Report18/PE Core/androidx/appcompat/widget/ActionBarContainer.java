package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import y.sj;

public class ActionBarContainer extends FrameLayout {
  public View 怖;
  
  public View 恐;
  
  public boolean 淋;
  
  public final int 産;
  
  public Drawable 痒;
  
  public Drawable 痛;
  
  public Drawable 臭;
  
  public boolean 興;
  
  public final boolean 起;
  
  public ActionBarContainer(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   6: aload_0
    //   7: new y/モ
    //   10: dup
    //   11: aload_0
    //   12: invokespecial <init> : (Landroidx/appcompat/widget/ActionBarContainer;)V
    //   15: invokestatic 歩 : (Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    //   18: aload_1
    //   19: aload_2
    //   20: getstatic y/td.歩 : [I
    //   23: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   26: astore_1
    //   27: iconst_0
    //   28: istore #4
    //   30: aload_0
    //   31: aload_1
    //   32: iconst_0
    //   33: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   36: putfield 痛 : Landroid/graphics/drawable/Drawable;
    //   39: aload_0
    //   40: aload_1
    //   41: iconst_2
    //   42: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   45: putfield 痒 : Landroid/graphics/drawable/Drawable;
    //   48: aload_0
    //   49: aload_1
    //   50: bipush #13
    //   52: iconst_m1
    //   53: invokevirtual getDimensionPixelSize : (II)I
    //   56: putfield 産 : I
    //   59: aload_0
    //   60: invokevirtual getId : ()I
    //   63: ldc 2131231313
    //   65: if_icmpne -> 82
    //   68: aload_0
    //   69: iconst_1
    //   70: putfield 起 : Z
    //   73: aload_0
    //   74: aload_1
    //   75: iconst_1
    //   76: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   79: putfield 臭 : Landroid/graphics/drawable/Drawable;
    //   82: aload_1
    //   83: invokevirtual recycle : ()V
    //   86: aload_0
    //   87: getfield 起 : Z
    //   90: ifeq -> 108
    //   93: iload #4
    //   95: istore_3
    //   96: aload_0
    //   97: getfield 臭 : Landroid/graphics/drawable/Drawable;
    //   100: ifnonnull -> 131
    //   103: iconst_1
    //   104: istore_3
    //   105: goto -> 131
    //   108: iload #4
    //   110: istore_3
    //   111: aload_0
    //   112: getfield 痛 : Landroid/graphics/drawable/Drawable;
    //   115: ifnonnull -> 131
    //   118: iload #4
    //   120: istore_3
    //   121: aload_0
    //   122: getfield 痒 : Landroid/graphics/drawable/Drawable;
    //   125: ifnonnull -> 131
    //   128: goto -> 103
    //   131: aload_0
    //   132: iload_3
    //   133: invokevirtual setWillNotDraw : (Z)V
    //   136: return
  }
  
  public final void drawableStateChanged() {
    super.drawableStateChanged();
    Drawable drawable = this.痛;
    if (drawable != null && drawable.isStateful())
      this.痛.setState(getDrawableState()); 
    drawable = this.痒;
    if (drawable != null && drawable.isStateful())
      this.痒.setState(getDrawableState()); 
    drawable = this.臭;
    if (drawable != null && drawable.isStateful())
      this.臭.setState(getDrawableState()); 
  }
  
  public View getTabContainer() {
    return null;
  }
  
  public final void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    Drawable drawable = this.痛;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    drawable = this.痒;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    drawable = this.臭;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  public final void onFinishInflate() {
    super.onFinishInflate();
    this.怖 = findViewById(2131230771);
    this.恐 = findViewById(2131230779);
  }
  
  public final boolean onHoverEvent(MotionEvent paramMotionEvent) {
    super.onHoverEvent(paramMotionEvent);
    return true;
  }
  
  public final boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return (this.淋 || super.onInterceptTouchEvent(paramMotionEvent));
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramBoolean = this.起;
    paramInt2 = 1;
    paramInt1 = 1;
    if (paramBoolean) {
      Drawable drawable = this.臭;
      if (drawable != null) {
        drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
        paramInt1 = paramInt2;
      } else {
        paramInt1 = 0;
      } 
    } else {
      if (this.痛 != null) {
        if (this.怖.getVisibility() == 0) {
          this.痛.setBounds(this.怖.getLeft(), this.怖.getTop(), this.怖.getRight(), this.怖.getBottom());
        } else {
          View view = this.恐;
          if (view != null && view.getVisibility() == 0) {
            this.痛.setBounds(this.恐.getLeft(), this.恐.getTop(), this.恐.getRight(), this.恐.getBottom());
          } else {
            this.痛.setBounds(0, 0, 0, 0);
          } 
        } 
      } else {
        paramInt1 = 0;
      } 
      this.興 = false;
    } 
    if (paramInt1 != 0)
      invalidate(); 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    int i = paramInt2;
    if (this.怖 == null) {
      i = paramInt2;
      if (View.MeasureSpec.getMode(paramInt2) == Integer.MIN_VALUE) {
        int j = this.産;
        i = paramInt2;
        if (j >= 0)
          i = View.MeasureSpec.makeMeasureSpec(Math.min(j, View.MeasureSpec.getSize(paramInt2)), -2147483648); 
      } 
    } 
    super.onMeasure(paramInt1, i);
    if (this.怖 == null)
      return; 
    View.MeasureSpec.getMode(i);
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    super.onTouchEvent(paramMotionEvent);
    return true;
  }
  
  public void setPrimaryBackground(Drawable paramDrawable) {
    Drawable drawable = this.痛;
    if (drawable != null) {
      drawable.setCallback(null);
      unscheduleDrawable(this.痛);
    } 
    this.痛 = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this);
      View view = this.怖;
      if (view != null)
        this.痛.setBounds(view.getLeft(), this.怖.getTop(), this.怖.getRight(), this.怖.getBottom()); 
    } 
    boolean bool1 = this.起;
    boolean bool = true;
    if (bool1 ? (this.臭 == null) : (this.痛 == null && this.痒 == null))
      bool = false; 
    setWillNotDraw(bool);
    invalidate();
    int i = Build.VERSION.SDK_INT;
    invalidateOutline();
  }
  
  public void setSplitBackground(Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 臭 : Landroid/graphics/drawable/Drawable;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnull -> 25
    //   11: aload #5
    //   13: aconst_null
    //   14: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   17: aload_0
    //   18: aload_0
    //   19: getfield 臭 : Landroid/graphics/drawable/Drawable;
    //   22: invokevirtual unscheduleDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   25: aload_0
    //   26: aload_1
    //   27: putfield 臭 : Landroid/graphics/drawable/Drawable;
    //   30: aload_0
    //   31: getfield 起 : Z
    //   34: istore_3
    //   35: iconst_0
    //   36: istore #4
    //   38: aload_1
    //   39: ifnull -> 74
    //   42: aload_1
    //   43: aload_0
    //   44: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   47: iload_3
    //   48: ifeq -> 74
    //   51: aload_0
    //   52: getfield 臭 : Landroid/graphics/drawable/Drawable;
    //   55: astore_1
    //   56: aload_1
    //   57: ifnull -> 74
    //   60: aload_1
    //   61: iconst_0
    //   62: iconst_0
    //   63: aload_0
    //   64: invokevirtual getMeasuredWidth : ()I
    //   67: aload_0
    //   68: invokevirtual getMeasuredHeight : ()I
    //   71: invokevirtual setBounds : (IIII)V
    //   74: iload_3
    //   75: ifeq -> 93
    //   78: iload #4
    //   80: istore_3
    //   81: aload_0
    //   82: getfield 臭 : Landroid/graphics/drawable/Drawable;
    //   85: ifnonnull -> 116
    //   88: iconst_1
    //   89: istore_3
    //   90: goto -> 116
    //   93: iload #4
    //   95: istore_3
    //   96: aload_0
    //   97: getfield 痛 : Landroid/graphics/drawable/Drawable;
    //   100: ifnonnull -> 116
    //   103: iload #4
    //   105: istore_3
    //   106: aload_0
    //   107: getfield 痒 : Landroid/graphics/drawable/Drawable;
    //   110: ifnonnull -> 116
    //   113: goto -> 88
    //   116: aload_0
    //   117: iload_3
    //   118: invokevirtual setWillNotDraw : (Z)V
    //   121: aload_0
    //   122: invokevirtual invalidate : ()V
    //   125: getstatic android/os/Build$VERSION.SDK_INT : I
    //   128: istore_2
    //   129: aload_0
    //   130: invokevirtual invalidateOutline : ()V
    //   133: return
  }
  
  public void setStackedBackground(Drawable paramDrawable) {
    boolean bool;
    Drawable drawable = this.痒;
    if (drawable != null) {
      drawable.setCallback(null);
      unscheduleDrawable(this.痒);
    } 
    this.痒 = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this);
      if (this.興 && this.痒 != null)
        throw null; 
    } 
    if (this.起 ? (this.臭 == null) : (this.痛 == null && this.痒 == null)) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    invalidate();
    int i = Build.VERSION.SDK_INT;
    invalidateOutline();
  }
  
  public void setTabContainer(sj paramsj) {}
  
  public void setTransitioning(boolean paramBoolean) {
    int i;
    this.淋 = paramBoolean;
    if (paramBoolean) {
      i = 393216;
    } else {
      i = 262144;
    } 
    setDescendantFocusability(i);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.痛;
    if (drawable != null)
      drawable.setVisible(bool, false); 
    drawable = this.痒;
    if (drawable != null)
      drawable.setVisible(bool, false); 
    drawable = this.臭;
    if (drawable != null)
      drawable.setVisible(bool, false); 
  }
  
  public final ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback) {
    return null;
  }
  
  public final ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback, int paramInt) {
    return (paramInt != 0) ? super.startActionModeForChild(paramView, paramCallback, paramInt) : null;
  }
  
  public final boolean verifyDrawable(Drawable paramDrawable) {
    Drawable drawable = this.痛;
    boolean bool = this.起;
    return ((paramDrawable == drawable && !bool) || (paramDrawable == this.痒 && this.興) || (paramDrawable == this.臭 && bool) || super.verifyDrawable(paramDrawable));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\ActionBarContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */