package com.applovin.impl.sdk.e;

import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.f;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.y;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class r {
  private static final ExecutorService a = Executors.newFixedThreadPool(4);
  
  private final o b;
  
  private final y c;
  
  private final ScheduledThreadPoolExecutor d;
  
  private final ScheduledThreadPoolExecutor e;
  
  private final List<d> f = new ArrayList<d>(5);
  
  private final Object g = new Object();
  
  private boolean h;
  
  private final AtomicBoolean i = new AtomicBoolean();
  
  private List<String> j = new ArrayList<String>();
  
  private long k = -1L;
  
  public r(o paramo) {
    this.b = paramo;
    this.c = paramo.F();
    this.d = b("auxiliary_operations", ((Integer)paramo.a(com.applovin.impl.sdk.c.b.cv)).intValue());
    this.e = b("shared_thread_pool", ((Integer)paramo.a(com.applovin.impl.sdk.c.b.at)).intValue());
  }
  
  private void a(Runnable paramRunnable, long paramLong, boolean paramBoolean) {
    if (paramLong > 0L) {
      if (paramBoolean) {
        f.a(paramLong, this.b, new Runnable(this, paramRunnable) {
              public void run() {
                r.a(this.b).execute(this.a);
              }
            });
        return;
      } 
      this.e.schedule(paramRunnable, paramLong, TimeUnit.MILLISECONDS);
      return;
    } 
    this.e.submit(paramRunnable);
  }
  
  private boolean a(d paramd) {
    if (d.a(paramd).g())
      return false; 
    synchronized (this.g) {
      if (this.h)
        return false; 
      this.f.add(paramd);
      return true;
    } 
  }
  
  private ScheduledThreadPoolExecutor b(String paramString, int paramInt) {
    return new ScheduledThreadPoolExecutor(paramInt, new c(this, paramString));
  }
  
  private void g() {
    f.a(this.k, this.b, new Runnable(this) {
          public void run() {
            for (Thread thread : Thread.getAllStackTraces().keySet()) {
              if (thread.getPriority() <= 1 || !StringUtils.startsWithAtLeastOnePrefix(thread.getName(), r.b(this.a)))
                continue; 
              thread.setPriority(1);
            } 
            r.c(this.a);
          }
        });
  }
  
  private boolean h() {
    return ((Boolean)this.b.a(com.applovin.impl.sdk.c.b.cw)).booleanValue();
  }
  
  public List<Future<Boolean>> a(List<a> paramList, ExecutorService paramExecutorService) {
    try {
      return (List)paramExecutorService.invokeAll((Collection)paramList);
    } finally {
      paramList = null;
      if (y.a())
        this.c.b("TaskManager", "Awaiting tasks were interrupted", (Throwable)paramList); 
    } 
  }
  
  public ExecutorService a(String paramString, int paramInt) {
    return Executors.newFixedThreadPool(paramInt, new a(this, paramString));
  }
  
  public void a(d paramd) {
    if (paramd != null)
      try {
        return;
      } finally {
        Exception exception = null;
        if (y.a())
          this.c.b(paramd.e(), "Task failed execution", exception); 
        paramd.a(exception);
      }  
    throw new IllegalArgumentException("No task specified");
  }
  
  public void a(d paramd, b paramb) {
    a(paramd, paramb, 0L);
  }
  
  public void a(d paramd, b paramb, long paramLong) {
    a(paramd, paramb, paramLong, false);
  }
  
  public void a(d paramd, b paramb, long paramLong, boolean paramBoolean) {
    if (paramd != null) {
      if (paramLong >= 0L) {
        d d1;
        d d2 = new d(this.b, paramd, paramb);
        if (!a(d2)) {
          if (h())
            d1 = d2; 
          a(d1, paramLong, paramBoolean);
          return;
        } 
        if (y.a())
          this.c.c(d1.e(), "Task execution delayed until after init"); 
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder("Invalid delay (millis) specified: ");
      stringBuilder.append(paramLong);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    throw new IllegalArgumentException("No task specified");
  }
  
  public void a(Runnable paramRunnable) {
    this.d.submit(paramRunnable);
  }
  
  public boolean a() {
    return this.h;
  }
  
  public Executor b() {
    return this.e;
  }
  
  public ExecutorService c() {
    return a;
  }
  
  public void d() {
    synchronized (this.g) {
      this.h = false;
      return;
    } 
  }
  
  public void e() {
    synchronized (this.g) {
      this.h = true;
      for (d d : this.f)
        a(d.a(d), d.b(d)); 
      this.f.clear();
      return;
    } 
  }
  
  public void f() {
    long l = ((Long)this.b.a(com.applovin.impl.sdk.c.b.gQ)).longValue();
    this.k = l;
    if (l < 0L)
      return; 
    if (!this.i.compareAndSet(false, true))
      return; 
    this.j = this.b.b(com.applovin.impl.sdk.c.b.gR);
    g();
  }
  
  private class a implements ThreadFactory {
    private final String b;
    
    private final AtomicInteger c = new AtomicInteger(1);
    
    a(r this$0, String param1String) {
      this.b = param1String;
    }
    
    public Thread newThread(Runnable param1Runnable) {
      StringBuilder stringBuilder = new StringBuilder("AppLovinSdk:");
      stringBuilder.append(this.b);
      stringBuilder.append("-");
      stringBuilder.append(this.c.getAndIncrement());
      param1Runnable = new Thread(param1Runnable, stringBuilder.toString());
      param1Runnable.setDaemon(true);
      param1Runnable.setPriority(((Integer)r.d(this.a).a(com.applovin.impl.sdk.c.b.gE)).intValue());
      param1Runnable.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(this) {
            public void uncaughtException(Thread param2Thread, Throwable param2Throwable) {
              r.d(this.a.a).F();
              if (y.a())
                r.d(this.a.a).F().b("TaskManager", "Caught unhandled exception", param2Throwable); 
            }
          });
      return (Thread)param1Runnable;
    }
  }
  
  class null implements Thread.UncaughtExceptionHandler {
    null(r this$0) {}
    
    public void uncaughtException(Thread param1Thread, Throwable param1Throwable) {
      r.d(this.a.a).F();
      if (y.a())
        r.d(this.a.a).F().b("TaskManager", "Caught unhandled exception", param1Throwable); 
    }
  }
  
  public enum b {
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t;
    
    static {
      b b1 = new b("MAIN", 0);
      a = b1;
      b b2 = new b("TIMEOUT", 1);
      b = b2;
      b b3 = new b("BACKGROUND", 2);
      c = b3;
      b b4 = new b("ADVERTISING_INFO_COLLECTION", 3);
      d = b4;
      b b5 = new b("POSTBACKS", 4);
      e = b5;
      b b6 = new b("CACHING_INTERSTITIAL", 5);
      f = b6;
      b b7 = new b("CACHING_INCENTIVIZED", 6);
      g = b7;
      b b8 = new b("CACHING_NATIVE", 7);
      h = b8;
      b b9 = new b("CACHING_OTHER", 8);
      i = b9;
      b b10 = new b("REWARD", 9);
      j = b10;
      b b11 = new b("MEDIATION_MAIN", 10);
      k = b11;
      b b12 = new b("MEDIATION_TIMEOUT", 11);
      l = b12;
      b b13 = new b("MEDIATION_BACKGROUND", 12);
      m = b13;
      b b14 = new b("MEDIATION_POSTBACKS", 13);
      n = b14;
      b b15 = new b("MEDIATION_BANNER", 14);
      o = b15;
      b b16 = new b("MEDIATION_INTERSTITIAL", 15);
      p = b16;
      b b17 = new b("MEDIATION_APP_OPEN", 16);
      q = b17;
      b b18 = new b("MEDIATION_INCENTIVIZED", 17);
      r = b18;
      b b19 = new b("MEDIATION_REWARDED_INTERSTITIAL", 18);
      s = b19;
      b b20 = new b("MEDIATION_REWARD", 19);
      t = b20;
      u = new b[] { 
          b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, 
          b11, b12, b13, b14, b15, b16, b17, b18, b19, b20 };
    }
  }
  
  private class c implements ThreadFactory {
    private final String b;
    
    c(r this$0, String param1String) {
      this.b = param1String;
    }
    
    public Thread newThread(Runnable param1Runnable) {
      StringBuilder stringBuilder = new StringBuilder("AppLovinSdk:");
      stringBuilder.append(this.b);
      param1Runnable = new Thread(param1Runnable, stringBuilder.toString());
      param1Runnable.setDaemon(true);
      param1Runnable.setPriority(((Integer)r.d(this.a).a(com.applovin.impl.sdk.c.b.gE)).intValue());
      param1Runnable.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(this) {
            public void uncaughtException(Thread param2Thread, Throwable param2Throwable) {
              r.e(this.a.a);
              if (y.a())
                r.e(this.a.a).b("TaskManager", "Caught unhandled exception", param2Throwable); 
            }
          });
      return (Thread)param1Runnable;
    }
  }
  
  class null implements Thread.UncaughtExceptionHandler {
    null(r this$0) {}
    
    public void uncaughtException(Thread param1Thread, Throwable param1Throwable) {
      r.e(this.a.a);
      if (y.a())
        r.e(this.a.a).b("TaskManager", "Caught unhandled exception", param1Throwable); 
    }
  }
  
  private static class d implements Runnable {
    private final o a;
    
    private final String b;
    
    private final y c;
    
    private final d d;
    
    private final r.b e;
    
    public d(o param1o, d param1d, r.b param1b) {
      this.a = param1o;
      this.c = param1o.F();
      this.b = param1d.e();
      this.d = param1d;
      this.e = param1b;
    }
    
    public void run() {
      y y1;
      String str;
      try {
        h.a();
        if (!this.a.c() || this.d.g()) {
          this.d.run();
        } else {
          if (y.a())
            this.c.c(this.b, "Task re-scheduled..."); 
          this.a.G().a(this.d, this.e, 2000L);
        } 
      } finally {
        null = null;
      } 
      str.append(this.e);
      str.append(" queue finished task ");
      str.append(this.d.e());
      SYNTHETIC_LOCAL_VARIABLE_1.c((String)y1, str.toString());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\sdk\e\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */