package androidx.core.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.CancellationSignal;
import androidx.core.content.res.FontResourcesParserCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class FontProvider {
  private static final Comparator<byte[]> sByteArrayComparator = (Comparator<byte[]>)new FontProvider$.ExternalSyntheticLambda0();
  
  private static List<byte[]> convertToByteArrayList(Signature[] paramArrayOfSignature) {
    ArrayList<byte[]> arrayList = new ArrayList();
    int j = paramArrayOfSignature.length;
    for (int i = 0; i < j; i++)
      arrayList.add(paramArrayOfSignature[i].toByteArray()); 
    return (List<byte[]>)arrayList;
  }
  
  private static boolean equalsByteArrayList(List<byte[]> paramList1, List<byte[]> paramList2) {
    if (paramList1.size() != paramList2.size())
      return false; 
    for (int i = 0; i < paramList1.size(); i++) {
      if (!Arrays.equals(paramList1.get(i), paramList2.get(i)))
        return false; 
    } 
    return true;
  }
  
  private static List<List<byte[]>> getCertificates(FontRequest paramFontRequest, Resources paramResources) {
    return (paramFontRequest.getCertificates() != null) ? paramFontRequest.getCertificates() : FontResourcesParserCompat.readCerts(paramResources, paramFontRequest.getCertificatesArrayResId());
  }
  
  static FontsContractCompat.FontFamilyResult getFontFamilyResult(Context paramContext, FontRequest paramFontRequest, CancellationSignal paramCancellationSignal) throws PackageManager.NameNotFoundException {
    ProviderInfo providerInfo = getProvider(paramContext.getPackageManager(), paramFontRequest, paramContext.getResources());
    return (providerInfo == null) ? FontsContractCompat.FontFamilyResult.create(1, null) : FontsContractCompat.FontFamilyResult.create(0, query(paramContext, paramFontRequest, providerInfo.authority, paramCancellationSignal));
  }
  
  static ProviderInfo getProvider(PackageManager paramPackageManager, FontRequest paramFontRequest, Resources paramResources) throws PackageManager.NameNotFoundException {
    String str = paramFontRequest.getProviderAuthority();
    int i = 0;
    ProviderInfo providerInfo = paramPackageManager.resolveContentProvider(str, 0);
    if (providerInfo != null) {
      List<List<byte[]>> list;
      if (providerInfo.packageName.equals(paramFontRequest.getProviderPackage())) {
        List<byte[]> list1 = convertToByteArrayList((paramPackageManager.getPackageInfo(providerInfo.packageName, 64)).signatures);
        Collections.sort((List)list1, (Comparator)sByteArrayComparator);
        list = getCertificates(paramFontRequest, paramResources);
        while (i < list.size()) {
          ArrayList<byte> arrayList = new ArrayList(list.get(i));
          Collections.sort(arrayList, (Comparator)sByteArrayComparator);
          if (equalsByteArrayList(list1, (List)arrayList))
            return providerInfo; 
          i++;
        } 
        return null;
      } 
      StringBuilder stringBuilder1 = new StringBuilder("Found content provider ");
      stringBuilder1.append(str);
      stringBuilder1.append(", but package was not ");
      stringBuilder1.append(list.getProviderPackage());
      throw new PackageManager.NameNotFoundException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder("No package found for authority: ");
    stringBuilder.append(str);
    throw new PackageManager.NameNotFoundException(stringBuilder.toString());
  }
  
  static FontsContractCompat.FontInfo[] query(Context paramContext, FontRequest paramFontRequest, String paramString, CancellationSignal paramCancellationSignal) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #14
    //   9: new android/net/Uri$Builder
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: ldc 'content'
    //   18: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   21: aload_2
    //   22: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   25: invokevirtual build : ()Landroid/net/Uri;
    //   28: astore #16
    //   30: new android/net/Uri$Builder
    //   33: dup
    //   34: invokespecial <init> : ()V
    //   37: ldc 'content'
    //   39: invokevirtual scheme : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   42: aload_2
    //   43: invokevirtual authority : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   46: ldc 'file'
    //   48: invokevirtual appendPath : (Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   51: invokevirtual build : ()Landroid/net/Uri;
    //   54: astore #17
    //   56: aconst_null
    //   57: astore #15
    //   59: aload #15
    //   61: astore_2
    //   62: aload_0
    //   63: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   66: astore_0
    //   67: aload #15
    //   69: astore_2
    //   70: aload_1
    //   71: invokevirtual getQuery : ()Ljava/lang/String;
    //   74: astore_1
    //   75: aload #15
    //   77: astore_2
    //   78: aload_0
    //   79: aload #16
    //   81: bipush #7
    //   83: anewarray java/lang/String
    //   86: dup
    //   87: iconst_0
    //   88: ldc '_id'
    //   90: aastore
    //   91: dup
    //   92: iconst_1
    //   93: ldc 'file_id'
    //   95: aastore
    //   96: dup
    //   97: iconst_2
    //   98: ldc 'font_ttc_index'
    //   100: aastore
    //   101: dup
    //   102: iconst_3
    //   103: ldc 'font_variation_settings'
    //   105: aastore
    //   106: dup
    //   107: iconst_4
    //   108: ldc 'font_weight'
    //   110: aastore
    //   111: dup
    //   112: iconst_5
    //   113: ldc 'font_italic'
    //   115: aastore
    //   116: dup
    //   117: bipush #6
    //   119: ldc 'result_code'
    //   121: aastore
    //   122: ldc 'query = ?'
    //   124: iconst_1
    //   125: anewarray java/lang/String
    //   128: dup
    //   129: iconst_0
    //   130: aload_1
    //   131: aastore
    //   132: aconst_null
    //   133: aload_3
    //   134: invokestatic query : (Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Landroid/database/Cursor;
    //   137: astore_1
    //   138: aload #14
    //   140: astore_0
    //   141: aload_1
    //   142: ifnull -> 410
    //   145: aload #14
    //   147: astore_0
    //   148: aload_1
    //   149: astore_2
    //   150: aload_1
    //   151: invokeinterface getCount : ()I
    //   156: ifle -> 410
    //   159: aload_1
    //   160: astore_2
    //   161: aload_1
    //   162: ldc 'result_code'
    //   164: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   169: istore #7
    //   171: aload_1
    //   172: astore_2
    //   173: new java/util/ArrayList
    //   176: dup
    //   177: invokespecial <init> : ()V
    //   180: astore_3
    //   181: aload_1
    //   182: astore_2
    //   183: aload_1
    //   184: ldc '_id'
    //   186: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   191: istore #8
    //   193: aload_1
    //   194: astore_2
    //   195: aload_1
    //   196: ldc 'file_id'
    //   198: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   203: istore #9
    //   205: aload_1
    //   206: astore_2
    //   207: aload_1
    //   208: ldc 'font_ttc_index'
    //   210: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   215: istore #10
    //   217: aload_1
    //   218: astore_2
    //   219: aload_1
    //   220: ldc 'font_weight'
    //   222: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   227: istore #11
    //   229: aload_1
    //   230: astore_2
    //   231: aload_1
    //   232: ldc 'font_italic'
    //   234: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   239: istore #12
    //   241: aload_1
    //   242: astore_2
    //   243: aload_1
    //   244: invokeinterface moveToNext : ()Z
    //   249: ifeq -> 408
    //   252: iload #7
    //   254: iconst_m1
    //   255: if_icmpeq -> 445
    //   258: aload_1
    //   259: astore_2
    //   260: aload_1
    //   261: iload #7
    //   263: invokeinterface getInt : (I)I
    //   268: istore #4
    //   270: goto -> 273
    //   273: iload #10
    //   275: iconst_m1
    //   276: if_icmpeq -> 451
    //   279: aload_1
    //   280: astore_2
    //   281: aload_1
    //   282: iload #10
    //   284: invokeinterface getInt : (I)I
    //   289: istore #5
    //   291: goto -> 294
    //   294: iload #9
    //   296: iconst_m1
    //   297: if_icmpne -> 319
    //   300: aload_1
    //   301: astore_2
    //   302: aload #16
    //   304: aload_1
    //   305: iload #8
    //   307: invokeinterface getLong : (I)J
    //   312: invokestatic withAppendedId : (Landroid/net/Uri;J)Landroid/net/Uri;
    //   315: astore_0
    //   316: goto -> 335
    //   319: aload_1
    //   320: astore_2
    //   321: aload #17
    //   323: aload_1
    //   324: iload #9
    //   326: invokeinterface getLong : (I)J
    //   331: invokestatic withAppendedId : (Landroid/net/Uri;J)Landroid/net/Uri;
    //   334: astore_0
    //   335: iload #4
    //   337: istore #6
    //   339: iload #11
    //   341: iconst_m1
    //   342: if_icmpeq -> 457
    //   345: aload_1
    //   346: astore_2
    //   347: aload_1
    //   348: iload #11
    //   350: invokeinterface getInt : (I)I
    //   355: istore #4
    //   357: goto -> 360
    //   360: iload #12
    //   362: iconst_m1
    //   363: if_icmpeq -> 465
    //   366: aload_1
    //   367: astore_2
    //   368: aload_1
    //   369: iload #12
    //   371: invokeinterface getInt : (I)I
    //   376: iconst_1
    //   377: if_icmpne -> 465
    //   380: iconst_1
    //   381: istore #13
    //   383: goto -> 386
    //   386: aload_1
    //   387: astore_2
    //   388: aload_3
    //   389: aload_0
    //   390: iload #5
    //   392: iload #4
    //   394: iload #13
    //   396: iload #6
    //   398: invokestatic create : (Landroid/net/Uri;IIZI)Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   401: invokevirtual add : (Ljava/lang/Object;)Z
    //   404: pop
    //   405: goto -> 241
    //   408: aload_3
    //   409: astore_0
    //   410: aload_1
    //   411: ifnull -> 420
    //   414: aload_1
    //   415: invokeinterface close : ()V
    //   420: aload_0
    //   421: iconst_0
    //   422: anewarray androidx/core/provider/FontsContractCompat$FontInfo
    //   425: invokevirtual toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   428: checkcast [Landroidx/core/provider/FontsContractCompat$FontInfo;
    //   431: areturn
    //   432: astore_0
    //   433: aload_2
    //   434: ifnull -> 443
    //   437: aload_2
    //   438: invokeinterface close : ()V
    //   443: aload_0
    //   444: athrow
    //   445: iconst_0
    //   446: istore #4
    //   448: goto -> 273
    //   451: iconst_0
    //   452: istore #5
    //   454: goto -> 294
    //   457: sipush #400
    //   460: istore #4
    //   462: goto -> 360
    //   465: iconst_0
    //   466: istore #13
    //   468: goto -> 386
    // Exception table:
    //   from	to	target	type
    //   62	67	432	finally
    //   70	75	432	finally
    //   78	138	432	finally
    //   150	159	432	finally
    //   161	171	432	finally
    //   173	181	432	finally
    //   183	193	432	finally
    //   195	205	432	finally
    //   207	217	432	finally
    //   219	229	432	finally
    //   231	241	432	finally
    //   243	252	432	finally
    //   260	270	432	finally
    //   281	291	432	finally
    //   302	316	432	finally
    //   321	335	432	finally
    //   347	357	432	finally
    //   368	380	432	finally
    //   388	405	432	finally
  }
  
  static class Api16Impl {
    static Cursor query(ContentResolver param1ContentResolver, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2, Object param1Object) {
      return param1ContentResolver.query(param1Uri, param1ArrayOfString1, param1String1, param1ArrayOfString2, param1String2, (CancellationSignal)param1Object);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\core\provider\FontProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */