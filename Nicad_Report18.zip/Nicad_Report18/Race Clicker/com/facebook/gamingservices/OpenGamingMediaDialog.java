package com.facebook.gamingservices;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.gamingservices.cloudgaming.CloudGameLoginHandler;
import com.facebook.gamingservices.cloudgaming.DaemonRequest;
import com.facebook.gamingservices.cloudgaming.internal.SDKMessageEnum;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;
import org.json.JSONException;
import org.json.JSONObject;

public class OpenGamingMediaDialog implements GraphRequest.OnProgressCallback {
  private Context context;
  
  private GraphRequest.Callback nestedCallback;
  
  public OpenGamingMediaDialog(Context paramContext) {
    this(paramContext, null);
  }
  
  public OpenGamingMediaDialog(Context paramContext, GraphRequest.Callback paramCallback) {
    this.context = paramContext;
    this.nestedCallback = paramCallback;
  }
  
  public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context paramContext, Intent paramIntent) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.facebook");
    paramContext.startActivity(paramIntent);
  }
  
  public void onCompleted(GraphResponse paramGraphResponse) {
    GraphRequest.Callback callback = this.nestedCallback;
    if (callback != null)
      callback.onCompleted(paramGraphResponse); 
    if (paramGraphResponse != null) {
      if (paramGraphResponse.getError() != null)
        return; 
      String str2 = paramGraphResponse.getJSONObject().optString("id", null);
      String str1 = paramGraphResponse.getJSONObject().optString("video_id", null);
      if (str2 == null && str1 == null)
        return; 
      if (str2 != null)
        str1 = str2; 
      if (CloudGameLoginHandler.isRunningInCloud()) {
        JSONObject jSONObject = new JSONObject();
        try {
          jSONObject.put("id", str1);
          jSONObject.put("deepLink", "MEDIA_ASSET");
          DaemonRequest.executeAsync(this.context, jSONObject, null, SDKMessageEnum.OPEN_GAMING_SERVICES_DEEP_LINK);
          return;
        } catch (JSONException jSONException) {
          return;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder("https://fb.gg/me/media_asset/");
      stringBuilder.append((String)jSONException);
      Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(stringBuilder.toString()));
      safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(this.context, intent);
    } 
  }
  
  public void onProgress(long paramLong1, long paramLong2) {
    GraphRequest.Callback callback = this.nestedCallback;
    if (callback != null && callback instanceof GraphRequest.OnProgressCallback)
      ((GraphRequest.OnProgressCallback)callback).onProgress(paramLong1, paramLong2); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\gamingservices\OpenGamingMediaDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */