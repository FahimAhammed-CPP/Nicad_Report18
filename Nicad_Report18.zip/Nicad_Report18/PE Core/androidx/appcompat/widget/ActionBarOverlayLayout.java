package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import java.util.WeakHashMap;
import y.aw;
import y.ay;
import y.ew;
import y.gw;
import y.kz;
import y.l5;
import y.ls;
import y.m5;
import y.n5;
import y.o3;
import y.oz;
import y.p3;
import y.pz;
import y.qz;
import y.r2;
import y.rw;
import y.xz;
import y.zz;
import y.ツ;
import y.ホ;
import y.ル;
import y.少;
import y.年;
import y.蛍;
import y.蛛;
import y.꾀;
import y.꾸;
import y.홀;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements 꾀, l5, m5 {
  public static final int[] 若 = new int[] { 2130903045, 16842841 };
  
  public ル あ;
  
  public OverScroller か;
  
  public ViewPropertyAnimator ち;
  
  public final n5 も;
  
  public final 蛛 ゃ;
  
  public final ホ わ;
  
  public zz 噛;
  
  public boolean 壊;
  
  public zz 寝;
  
  public int 帰;
  
  public int 怖 = 0;
  
  public ContentFrameLayout 恐;
  
  public zz 投;
  
  public final Rect 歩 = new Rect();
  
  public boolean 死;
  
  public final Rect 泳 = new Rect();
  
  public int 淋;
  
  public boolean 産;
  
  public 꾸 痒;
  
  public ActionBarContainer 痛;
  
  public Drawable 臭;
  
  public boolean 興;
  
  public zz 触;
  
  public final ホ 赤;
  
  public boolean 起;
  
  public final Rect 踊 = new Rect();
  
  public int 返;
  
  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    new Rect();
    new Rect();
    new Rect();
    new Rect();
    zz zz1 = zz.堅;
    this.寝 = zz1;
    this.噛 = zz1;
    this.触 = zz1;
    this.投 = zz1;
    this.ゃ = new 蛛(0, this);
    this.赤 = new ホ(this, 0);
    this.わ = new ホ(this, 1);
    辛(paramContext);
    this.も = new n5(0);
  }
  
  public static boolean 美(FrameLayout paramFrameLayout, Rect paramRect, boolean paramBoolean) {
    boolean bool;
    蛍 蛍 = (蛍)paramFrameLayout.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)蛍).leftMargin;
    int j = paramRect.left;
    if (i != j) {
      ((ViewGroup.MarginLayoutParams)蛍).leftMargin = j;
      bool = true;
    } else {
      bool = false;
    } 
    i = ((ViewGroup.MarginLayoutParams)蛍).topMargin;
    j = paramRect.top;
    if (i != j) {
      ((ViewGroup.MarginLayoutParams)蛍).topMargin = j;
      bool = true;
    } 
    i = ((ViewGroup.MarginLayoutParams)蛍).rightMargin;
    j = paramRect.right;
    if (i != j) {
      ((ViewGroup.MarginLayoutParams)蛍).rightMargin = j;
      bool = true;
    } 
    if (paramBoolean) {
      i = ((ViewGroup.MarginLayoutParams)蛍).bottomMargin;
      j = paramRect.bottom;
      if (i != j) {
        ((ViewGroup.MarginLayoutParams)蛍).bottomMargin = j;
        return true;
      } 
    } 
    return bool;
  }
  
  public final boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof 蛍;
  }
  
  public final void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.臭 != null && !this.起) {
      byte b;
      if (this.痛.getVisibility() == 0) {
        float f = this.痛.getBottom();
        b = (int)(this.痛.getTranslationY() + f + 0.5F);
      } else {
        b = 0;
      } 
      this.臭.setBounds(0, b, getWidth(), this.臭.getIntrinsicHeight() + b);
      this.臭.draw(paramCanvas);
    } 
  }
  
  public final boolean fitSystemWindows(Rect paramRect) {
    int i = Build.VERSION.SDK_INT;
    return super.fitSystemWindows(paramRect);
  }
  
  public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new 蛍();
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new 蛍(getContext(), paramAttributeSet);
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new 蛍(paramLayoutParams);
  }
  
  public int getActionBarHideOffset() {
    ActionBarContainer actionBarContainer = this.痛;
    return (actionBarContainer != null) ? -((int)actionBarContainer.getTranslationY()) : 0;
  }
  
  public int getNestedScrollAxes() {
    n5 n51 = this.も;
    int i = n51.淋;
    return n51.怖 | i;
  }
  
  public CharSequence getTitle() {
    苦();
    return ((ls)this.痒).硬.getTitle();
  }
  
  public final WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    苦();
    zz zz1 = zz.美(paramWindowInsets, (View)this);
    Rect rect2 = new Rect(zz1.堅(), zz1.暑(), zz1.熱(), zz1.硬());
    boolean bool1 = 美(this.痛, rect2, false);
    WeakHashMap weakHashMap = rw.硬;
    int i = Build.VERSION.SDK_INT;
    Rect rect1 = this.歩;
    gw.堅((View)this, zz1, rect1);
    i = rect1.left;
    int j = rect1.top;
    int k = rect1.right;
    int m = rect1.bottom;
    xz xz = zz1.硬;
    zz zz2 = xz.苦(i, j, k, m);
    this.寝 = zz2;
    boolean bool2 = this.噛.equals(zz2);
    boolean bool = true;
    if (!bool2) {
      this.噛 = this.寝;
      bool1 = true;
    } 
    Rect rect3 = this.泳;
    if (!rect3.equals(rect1)) {
      rect3.set(rect1);
      bool1 = bool;
    } 
    if (bool1)
      requestLayout(); 
    return ((xz.硬()).硬.熱()).硬.堅().寒();
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    辛(getContext());
    rw.死((View)this);
  }
  
  public final void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    旨();
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = getChildCount();
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = getChildAt(paramInt1);
      if (view.getVisibility() != 8) {
        蛍 蛍 = (蛍)view.getLayoutParams();
        int i = view.getMeasuredWidth();
        int j = view.getMeasuredHeight();
        int k = ((ViewGroup.MarginLayoutParams)蛍).leftMargin + paramInt3;
        int m = ((ViewGroup.MarginLayoutParams)蛍).topMargin + paramInt4;
        view.layout(k, m, i + k, j + m);
      } 
    } 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    苦();
    measureChildWithMargins((View)this.痛, paramInt1, 0, paramInt2, 0);
    蛍 蛍2 = (蛍)this.痛.getLayoutParams();
    int i1 = Math.max(0, this.痛.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams)蛍2).leftMargin + ((ViewGroup.MarginLayoutParams)蛍2).rightMargin);
    int n = Math.max(0, this.痛.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)蛍2).topMargin + ((ViewGroup.MarginLayoutParams)蛍2).bottomMargin);
    int m = View.combineMeasuredStates(0, this.痛.getMeasuredState());
    WeakHashMap weakHashMap = rw.硬;
    int i2 = Build.VERSION.SDK_INT;
    if ((aw.美((View)this) & 0x100) != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j) {
      int i3 = this.淋;
      i = i3;
      if (this.産) {
        i = i3;
        if (this.痛.getTabContainer() != null)
          i = i3 + this.淋; 
      } 
    } else if (this.痛.getVisibility() != 8) {
      i = this.痛.getMeasuredHeight();
    } else {
      i = 0;
    } 
    Rect rect1 = this.歩;
    Rect rect2 = this.踊;
    rect2.set(rect1);
    zz zz1 = this.寝;
    this.触 = zz1;
    if (!this.興 && !j) {
      rect2.top += i;
      rect2.bottom += 0;
      this.触 = zz1.硬.苦(0, i, 0, 0);
    } else {
      qz qz;
      oz oz;
      少 少 = 少.硬(zz1.堅(), this.触.暑() + i, this.触.熱(), this.触.硬() + 0);
      zz1 = this.触;
      if (i2 >= 30) {
        qz = new qz(zz1);
      } else {
        pz pz;
        if (i2 >= 29) {
          pz = new pz((zz)qz);
        } else {
          oz = new oz((zz)pz);
        } 
      } 
      oz.暑(少);
      this.触 = oz.堅();
    } 
    美(this.恐, rect2, true);
    if (!this.投.equals(this.触)) {
      zz zz2 = this.触;
      this.投 = zz2;
      ContentFrameLayout contentFrameLayout = this.恐;
      WindowInsets windowInsets = zz2.寒();
      if (windowInsets != null) {
        WindowInsets windowInsets1 = ew.硬((View)contentFrameLayout, windowInsets);
        if (!windowInsets1.equals(windowInsets))
          zz.美(windowInsets1, (View)contentFrameLayout); 
      } 
    } 
    measureChildWithMargins((View)this.恐, paramInt1, 0, paramInt2, 0);
    蛍 蛍1 = (蛍)this.恐.getLayoutParams();
    int i = Math.max(i1, this.恐.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams)蛍1).leftMargin + ((ViewGroup.MarginLayoutParams)蛍1).rightMargin);
    int j = Math.max(n, this.恐.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)蛍1).topMargin + ((ViewGroup.MarginLayoutParams)蛍1).bottomMargin);
    int k = View.combineMeasuredStates(m, this.恐.getMeasuredState());
    m = getPaddingLeft();
    n = getPaddingRight();
    i1 = getPaddingTop();
    j = Math.max(getPaddingBottom() + i1 + j, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSizeAndState(Math.max(n + m + i, getSuggestedMinimumWidth()), paramInt1, k), View.resolveSizeAndState(j, paramInt2, k << 16));
  }
  
  public final boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    boolean bool1 = this.死;
    boolean bool = false;
    if (bool1) {
      if (!paramBoolean)
        return false; 
      this.か.fling(0, 0, 0, (int)paramFloat2, 0, 0, -2147483648, 2147483647);
      if (this.か.getFinalY() > this.痛.getHeight())
        bool = true; 
      if (bool) {
        旨();
        this.わ.run();
      } else {
        旨();
        this.赤.run();
      } 
      this.壊 = true;
      return true;
    } 
    return false;
  }
  
  public final boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public final void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {}
  
  public final void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = this.帰 + paramInt2;
    this.帰 = paramInt1;
    setActionBarHideOffset(paramInt1);
  }
  
  public final void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.も.淋 = paramInt;
    this.帰 = getActionBarHideOffset();
    旨();
    ル ル1 = this.あ;
    if (ル1 != null) {
      kz kz = (kz)ル1;
      ay ay = kz.크;
      if (ay != null) {
        ay.硬();
        kz.크 = null;
      } 
    } 
  }
  
  public final boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) == 0 || this.痛.getVisibility() != 0) ? false : this.死;
  }
  
  public final void onStopNestedScroll(View paramView) {
    if (this.死 && !this.壊) {
      if (this.帰 <= this.痛.getHeight()) {
        旨();
        postDelayed((Runnable)this.赤, 600L);
        return;
      } 
      旨();
      postDelayed((Runnable)this.わ, 600L);
    } 
  }
  
  public final void onWindowSystemUiVisibilityChanged(int paramInt) {
    boolean bool;
    int i = Build.VERSION.SDK_INT;
    super.onWindowSystemUiVisibilityChanged(paramInt);
    苦();
    int j = this.返;
    this.返 = paramInt;
    if ((paramInt & 0x4) == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if ((paramInt & 0x100) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    ル ル1 = this.あ;
    if (ル1 != null) {
      kz kz;
      ((kz)ル1).も = bool ^ true;
      if (i != 0 || !bool) {
        kz = (kz)ル1;
        if (kz.若) {
          kz.若 = false;
          kz.士(true);
        } 
      } else {
        kz = kz;
        if (!kz.若) {
          kz.若 = true;
          kz.士(true);
        } 
      } 
    } 
    if (((j ^ paramInt) & 0x100) != 0 && this.あ != null)
      rw.死((View)this); 
  }
  
  public final void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.怖 = paramInt;
    ル ル1 = this.あ;
    if (ル1 != null)
      ((kz)ル1).わ = paramInt; 
  }
  
  public void setActionBarHideOffset(int paramInt) {
    旨();
    paramInt = Math.max(0, Math.min(paramInt, this.痛.getHeight()));
    this.痛.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(ル paramル) {
    this.あ = paramル;
    if (getWindowToken() != null) {
      paramル = this.あ;
      int i = this.怖;
      ((kz)paramル).わ = i;
      i = this.返;
      if (i != 0) {
        onWindowSystemUiVisibilityChanged(i);
        rw.死((View)this);
      } 
    } 
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean) {
    this.産 = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (paramBoolean != this.死) {
      this.死 = paramBoolean;
      if (!paramBoolean) {
        旨();
        setActionBarHideOffset(0);
      } 
    } 
  }
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    苦();
    ls ls = (ls)this.痒;
    if (paramInt != 0) {
      drawable = 年.痛(ls.硬.getContext(), paramInt);
    } else {
      drawable = null;
    } 
    ls.暑 = drawable;
    ls.堅();
  }
  
  public void setIcon(Drawable paramDrawable) {
    苦();
    ls ls = (ls)this.痒;
    ls.暑 = paramDrawable;
    ls.堅();
  }
  
  public void setLogo(int paramInt) {
    Drawable drawable;
    苦();
    ls ls = (ls)this.痒;
    if (paramInt != 0) {
      drawable = 年.痛(ls.硬.getContext(), paramInt);
    } else {
      drawable = null;
    } 
    ls.冷 = drawable;
    ls.堅();
  }
  
  public void setOverlayMode(boolean paramBoolean) {
    this.興 = paramBoolean;
    if (paramBoolean && (getContext().getApplicationInfo()).targetSdkVersion < 19) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.起 = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback) {
    苦();
    ((ls)this.痒).ぱ = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    苦();
    ls ls = (ls)this.痒;
    if (!ls.美) {
      ls.旨 = paramCharSequence;
      if ((ls.堅 & 0x8) != 0) {
        Toolbar toolbar = ls.硬;
        toolbar.setTitle(paramCharSequence);
        if (ls.美)
          rw.返(toolbar.getRootView(), paramCharSequence); 
      } 
    } 
  }
  
  public final boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public final void ぱ(int paramInt) {
    苦();
    if (paramInt != 2) {
      if (paramInt != 5) {
        if (paramInt != 109)
          return; 
        setOverlayMode(true);
        return;
      } 
      this.痒.getClass();
      return;
    } 
    this.痒.getClass();
  }
  
  public final boolean 不() {
    苦();
    ActionMenuView actionMenuView = ((ls)this.痒).硬.淋;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (actionMenuView != null) {
      boolean bool;
      ツ ツ = actionMenuView.投;
      if (ツ != null && ツ.暑()) {
        bool = true;
      } else {
        bool = false;
      } 
      bool1 = bool2;
      if (bool)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public final void 冷(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public final void 堅(View paramView, int paramInt) {
    if (paramInt == 0)
      onStopNestedScroll(paramView); 
  }
  
  public final void 嬉(r2 paramr2, 홀 param홀) {
    苦();
    ls ls = (ls)this.痒;
    ツ ツ2 = ls.嬉;
    Toolbar toolbar = ls.硬;
    if (ツ2 == null)
      ls.嬉 = new ツ(toolbar.getContext()); 
    ツ ツ1 = ls.嬉;
    ツ1.痒 = (o3)param홀;
    if (paramr2 == null && toolbar.淋 == null)
      return; 
    toolbar.冷();
    r2 r21 = toolbar.淋.踊;
    if (r21 == paramr2)
      return; 
    if (r21 != null) {
      r21.恐((p3)toolbar.탄);
      r21.恐(toolbar.탈);
    } 
    if (toolbar.탈 == null)
      toolbar.탈 = new try(toolbar); 
    ツ1.寝 = true;
    if (paramr2 != null) {
      paramr2.堅((p3)ツ1, toolbar.死);
      paramr2.堅(toolbar.탈, toolbar.死);
    } else {
      ツ1.熱(toolbar.死, null);
      toolbar.탈.熱(toolbar.死, null);
      ツ1.冷();
      toolbar.탈.冷();
    } 
    toolbar.淋.setPopupTheme(toolbar.壊);
    toolbar.淋.setPresenter(ツ1);
    toolbar.탄 = ツ1;
    toolbar.恐();
  }
  
  public final boolean 寒(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return (paramInt2 == 0 && onStartNestedScroll(paramView1, paramView2, paramInt1));
  }
  
  public final void 旨() {
    removeCallbacks((Runnable)this.赤);
    removeCallbacks((Runnable)this.わ);
    ViewPropertyAnimator viewPropertyAnimator = this.ち;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
  }
  
  public final void 暑(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    冷(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public final void 熱(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt3 == 0)
      onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint); 
  }
  
  public final void 硬(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 0)
      onNestedScrollAccepted(paramView1, paramView2, paramInt1); 
  }
  
  public final void 苦() {
    if (this.恐 == null) {
      꾸 꾸1;
      this.恐 = (ContentFrameLayout)findViewById(2131230772);
      this.痛 = (ActionBarContainer)findViewById(2131230773);
      View view = findViewById(2131230771);
      if (view instanceof 꾸) {
        꾸1 = (꾸)view;
      } else if (꾸1 instanceof Toolbar) {
        꾸1 = ((Toolbar)꾸1).getWrapper();
      } else {
        throw new IllegalStateException("Can't make a decor toolbar out of ".concat(꾸1.getClass().getSimpleName()));
      } 
      this.痒 = 꾸1;
      return;
    } 
  }
  
  public final void 辛(Context paramContext) {
    TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(若);
    boolean bool2 = false;
    this.淋 = typedArray.getDimensionPixelSize(0, 0);
    Drawable drawable = typedArray.getDrawable(1);
    this.臭 = drawable;
    if (drawable == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    typedArray.recycle();
    boolean bool1 = bool2;
    if ((paramContext.getApplicationInfo()).targetSdkVersion < 19)
      bool1 = true; 
    this.起 = bool1;
    this.か = new OverScroller(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\ActionBarOverlayLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */