package androidx.privacysandbox.ads.adservices.java.topics;

import android.content.Context;
import androidx.privacysandbox.ads.adservices.java.internal.CoroutineAdapterKt;
import androidx.privacysandbox.ads.adservices.topics.GetTopicsRequest;
import androidx.privacysandbox.ads.adservices.topics.GetTopicsResponse;
import androidx.privacysandbox.ads.adservices.topics.TopicsManager;
import com.google.common.util.concurrent.ListenableFuture;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;

@Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\b&\030\000 \t2\0020\001:\002\b\tB\007\b\000¢\006\002\020\002J\026\020\003\032\b\022\004\022\0020\0050\0042\006\020\006\032\0020\007H'¨\006\n"}, d2 = {"Landroidx/privacysandbox/ads/adservices/java/topics/TopicsManagerFutures;", "", "()V", "getTopicsAsync", "Lcom/google/common/util/concurrent/ListenableFuture;", "Landroidx/privacysandbox/ads/adservices/topics/GetTopicsResponse;", "request", "Landroidx/privacysandbox/ads/adservices/topics/GetTopicsRequest;", "Api33Ext4JavaImpl", "Companion", "ads-adservices-java_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class TopicsManagerFutures {
  public static final Companion Companion = new Companion(null);
  
  @JvmStatic
  public static final TopicsManagerFutures from(Context paramContext) {
    return Companion.from(paramContext);
  }
  
  public abstract ListenableFuture<GetTopicsResponse> getTopicsAsync(GetTopicsRequest paramGetTopicsRequest);
  
  @Metadata(d1 = {"\000\"\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\b\002\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\026\020\005\032\b\022\004\022\0020\0070\0062\006\020\b\032\0020\tH\027R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006\n"}, d2 = {"Landroidx/privacysandbox/ads/adservices/java/topics/TopicsManagerFutures$Api33Ext4JavaImpl;", "Landroidx/privacysandbox/ads/adservices/java/topics/TopicsManagerFutures;", "mTopicsManager", "Landroidx/privacysandbox/ads/adservices/topics/TopicsManager;", "(Landroidx/privacysandbox/ads/adservices/topics/TopicsManager;)V", "getTopicsAsync", "Lcom/google/common/util/concurrent/ListenableFuture;", "Landroidx/privacysandbox/ads/adservices/topics/GetTopicsResponse;", "request", "Landroidx/privacysandbox/ads/adservices/topics/GetTopicsRequest;", "ads-adservices-java_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  private static final class Api33Ext4JavaImpl extends TopicsManagerFutures {
    private final TopicsManager mTopicsManager;
    
    public Api33Ext4JavaImpl(TopicsManager param1TopicsManager) {
      this.mTopicsManager = param1TopicsManager;
    }
    
    public ListenableFuture<GetTopicsResponse> getTopicsAsync(GetTopicsRequest param1GetTopicsRequest) {
      Intrinsics.checkNotNullParameter(param1GetTopicsRequest, "request");
      return CoroutineAdapterKt.asListenableFuture$default(BuildersKt.async$default(CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getMain()), null, null, new TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1(param1GetTopicsRequest, null), 3, null), null, 1, null);
    }
    
    @Metadata(d1 = {"\000\n\n\000\n\002\030\002\n\002\030\002\020\000\032\0020\001*\0020\002H@"}, d2 = {"<anonymous>", "Landroidx/privacysandbox/ads/adservices/topics/GetTopicsResponse;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "androidx.privacysandbox.ads.adservices.java.topics.TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1", f = "TopicsManagerFutures.kt", i = {}, l = {56}, m = "invokeSuspend", n = {}, s = {})
    static final class TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super GetTopicsResponse>, Object> {
      int label;
      
      TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1(GetTopicsRequest param2GetTopicsRequest, Continuation<? super TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1> param2Continuation) {
        super(2, param2Continuation);
      }
      
      public final Continuation<Unit> create(Object param2Object, Continuation<?> param2Continuation) {
        return (Continuation<Unit>)new TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1(this.$request, (Continuation)param2Continuation);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, Continuation<? super GetTopicsResponse> param2Continuation) {
        return ((TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1)create(param2CoroutineScope, param2Continuation)).invokeSuspend(Unit.INSTANCE);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i != 0) {
          if (i == 1) {
            ResultKt.throwOnFailure(param2Object);
            return param2Object;
          } 
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
        ResultKt.throwOnFailure(param2Object);
        param2Object = TopicsManagerFutures.Api33Ext4JavaImpl.this.mTopicsManager;
        GetTopicsRequest getTopicsRequest = this.$request;
        Continuation continuation = (Continuation)this;
        this.label = 1;
        param2Object = param2Object.getTopics(getTopicsRequest, continuation);
        return (param2Object == object) ? object : param2Object;
      }
    }
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\030\002\n\002\030\002\020\000\032\0020\001*\0020\002H@"}, d2 = {"<anonymous>", "Landroidx/privacysandbox/ads/adservices/topics/GetTopicsResponse;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
  @DebugMetadata(c = "androidx.privacysandbox.ads.adservices.java.topics.TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1", f = "TopicsManagerFutures.kt", i = {}, l = {56}, m = "invokeSuspend", n = {}, s = {})
  static final class TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super GetTopicsResponse>, Object> {
    int label;
    
    TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1(GetTopicsRequest param1GetTopicsRequest, Continuation<? super TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1(this.$request, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super GetTopicsResponse> param1Continuation) {
      return ((TopicsManagerFutures$Api33Ext4JavaImpl$getTopicsAsync$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
          return param1Object;
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
      ResultKt.throwOnFailure(param1Object);
      param1Object = TopicsManagerFutures.Api33Ext4JavaImpl.this.mTopicsManager;
      GetTopicsRequest getTopicsRequest = this.$request;
      Continuation continuation = (Continuation)this;
      this.label = 1;
      param1Object = param1Object.getTopics(getTopicsRequest, continuation);
      return (param1Object == object) ? object : param1Object;
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\022\020\003\032\004\030\0010\0042\006\020\005\032\0020\006H\007¨\006\007"}, d2 = {"Landroidx/privacysandbox/ads/adservices/java/topics/TopicsManagerFutures$Companion;", "", "()V", "from", "Landroidx/privacysandbox/ads/adservices/java/topics/TopicsManagerFutures;", "context", "Landroid/content/Context;", "ads-adservices-java_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    @JvmStatic
    public final TopicsManagerFutures from(Context param1Context) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      TopicsManager topicsManager = TopicsManager.Companion.obtain(param1Context);
      if (topicsManager != null) {
        TopicsManagerFutures.Api33Ext4JavaImpl api33Ext4JavaImpl = new TopicsManagerFutures.Api33Ext4JavaImpl(topicsManager);
      } else {
        topicsManager = null;
      } 
      return (TopicsManagerFutures)topicsManager;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\privacysandbox\ads\adservices\java\topics\TopicsManagerFutures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */