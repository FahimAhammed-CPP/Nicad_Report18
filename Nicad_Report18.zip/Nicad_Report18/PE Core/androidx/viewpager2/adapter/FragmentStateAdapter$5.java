package androidx.viewpager2.adapter;

import y.尻;
import y.肉;
import y.腰;

class FragmentStateAdapter$5 implements 肉 {
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 != 尻.ON_DESTROY)
      return; 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */