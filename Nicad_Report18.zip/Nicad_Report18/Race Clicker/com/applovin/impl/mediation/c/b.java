package com.applovin.impl.mediation.c;

import android.content.Context;
import com.applovin.impl.mediation.a.g;
import com.applovin.impl.mediation.a.h;
import com.applovin.impl.sdk.e.ac;
import com.applovin.impl.sdk.e.d;
import com.applovin.impl.sdk.e.r;
import com.applovin.impl.sdk.o;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.w;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.sdk.AppLovinSdkUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class b extends d {
  private static JSONObject a;
  
  private static final Object b = new Object();
  
  private static final Map<String, Set<String>> c = Collections.synchronizedMap(new HashMap<String, Set<String>>());
  
  private final String d;
  
  private final MaxAdFormat e;
  
  private final Map<String, Object> i;
  
  private final Context j;
  
  private final a k;
  
  public b(String paramString, MaxAdFormat paramMaxAdFormat, Map<String, Object> paramMap, Context paramContext, o paramo, a parama) {
    super("TaskCollectSignals", paramo);
    this.d = paramString;
    this.e = paramMaxAdFormat;
    this.i = paramMap;
    this.j = paramContext;
    this.k = parama;
  }
  
  private void a(h paramh, g.a parama) {
    if (paramh.aj()) {
      AppLovinSdkUtils.runOnUiThread(new Runnable(this, paramh, parama) {
            public void run() {
              b.d(this.c).am().collectSignal(b.a(this.c), b.b(this.c), this.a, b.c(this.c), this.b);
            }
          });
      return;
    } 
    this.f.am().collectSignal(this.d, this.e, paramh, this.j, parama);
  }
  
  private void a(String paramString, Throwable paramThrowable) {
    y y = this.h;
    if (y.a()) {
      y = this.h;
      String str = this.g;
      StringBuilder stringBuilder = new StringBuilder("No signals collected: ");
      stringBuilder.append(paramString);
      y.b(str, stringBuilder.toString(), paramThrowable);
    } 
    a a1 = this.k;
    if (a1 != null)
      a1.a(new JSONArray()); 
  }
  
  private void a(JSONArray paramJSONArray, JSONObject paramJSONObject) throws JSONException, InterruptedException {
    b b1 = new b(paramJSONArray.length(), this.k, this.f);
    for (int i = 0; i < paramJSONArray.length(); i++) {
      JSONObject jSONObject = paramJSONArray.getJSONObject(i);
      a(new h(this.i, jSONObject, paramJSONObject, this.f), b1);
    } 
    this.f.G().a((d)new ac(this.f, "timeoutCollectSignal", b1), r.b.a, ((Long)this.f.a(com.applovin.impl.sdk.c.a.j)).longValue());
  }
  
  public static void a(JSONObject paramJSONObject) {
    synchronized (b) {
      a = paramJSONObject;
      return;
    } 
  }
  
  public static void a(JSONObject paramJSONObject, o paramo) {
    try {
      JSONObject jSONObject = JsonUtils.getJSONObject(paramJSONObject, "ad_unit_signal_providers", null);
      if (jSONObject != null)
        for (String str : JsonUtils.toList(jSONObject.names())) {
          HashSet<String> hashSet = new HashSet(JsonUtils.getList(jSONObject, str, null));
          c.put(str, hashSet);
        }  
    } catch (JSONException jSONException) {
      StringBuilder stringBuilder = new StringBuilder("Failed to parse ad unit signal providers for JSON object: ");
      stringBuilder.append(paramJSONObject);
      y.c("TaskCollectSignals", stringBuilder.toString(), (Throwable)jSONException);
      paramo.ag().a("TaskCollectSignals", "parseAdUnitSignalProvidersJSON", (Throwable)jSONException);
    } 
  }
  
  private void b(JSONArray paramJSONArray, JSONObject paramJSONObject) throws JSONException, InterruptedException {
    StringBuilder stringBuilder;
    Set set = c.get(this.d);
    if (set == null || set.isEmpty()) {
      stringBuilder = new StringBuilder("No signal providers found for ad unit: ");
      stringBuilder.append(this.d);
      a(stringBuilder.toString(), (Throwable)null);
      return;
    } 
    b b1 = new b(set.size(), this.k, this.f);
    for (int i = 0; i < stringBuilder.length(); i++) {
      JSONObject jSONObject = stringBuilder.getJSONObject(i);
      if (set.contains(JsonUtils.getString(jSONObject, "name", null)))
        a(new h(this.i, jSONObject, paramJSONObject, this.f), b1); 
    } 
    this.f.G().a((d)new ac(this.f, "timeoutCollectSignal", b1), r.b.a, ((Long)this.f.a(com.applovin.impl.sdk.c.a.j)).longValue());
  }
  
  public void run() {
    try {
    
    } catch (JSONException jSONException) {
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } finally {
      Exception exception = null;
      a("Failed to collect signals", exception);
      this.f.ag().a("TaskCollectSignals", "collectSignals", exception);
    } 
  }
  
  public static interface a {
    void a(JSONArray param1JSONArray);
  }
  
  private static class b implements g.a, Runnable {
    private final b.a a;
    
    private final Object b;
    
    private int c;
    
    private final AtomicBoolean d;
    
    private final Collection<g> e;
    
    private final o f;
    
    private final y g;
    
    private b(int param1Int, b.a param1a, o param1o) {
      this.c = param1Int;
      this.a = param1a;
      this.f = param1o;
      this.g = param1o.F();
      this.b = new Object();
      this.e = new ArrayList<g>(param1Int);
      this.d = new AtomicBoolean();
    }
    
    private void a() {
      synchronized (this.b) {
        ArrayList<g> arrayList = new ArrayList<g>(this.e);
        null = new JSONArray();
        for (g g : arrayList) {
          try {
            JSONObject jSONObject1 = new JSONObject();
            h h = g.a();
            jSONObject1.put("name", h.ac());
            jSONObject1.put("class", h.ab());
            jSONObject1.put("adapter_version", g.c());
            jSONObject1.put("sdk_version", g.b());
            JSONObject jSONObject2 = new JSONObject();
            if (StringUtils.isValidString(g.e())) {
              jSONObject2.put("error_message", g.e());
            } else {
              jSONObject2.put("signal", g.d());
            } 
            jSONObject1.put("data", jSONObject2);
            null.put(jSONObject1);
            if (y.a()) {
              y y1 = this.g;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Collected signal from ");
              stringBuilder.append(h);
              y1.b("TaskCollectSignals", stringBuilder.toString());
            } 
          } catch (JSONException jSONException) {
            if (y.a())
              this.g.b("TaskCollectSignals", "Failed to create signal data", (Throwable)jSONException); 
            this.f.ag().a("TaskCollectSignals", "createSignalsData", (Throwable)jSONException);
          } 
        } 
        a((JSONArray)null);
        return;
      } 
    }
    
    private void a(JSONArray param1JSONArray) {
      b.a a1 = this.a;
      if (a1 != null)
        a1.a(param1JSONArray); 
    }
    
    public void a(g param1g) {
      synchronized (this.b) {
        this.e.add(param1g);
        int i = this.c - 1;
        this.c = i;
        if (i < 1) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 0 && this.d.compareAndSet(false, true)) {
          if (w.b() && ((Boolean)this.f.a(com.applovin.impl.sdk.c.b.gD)).booleanValue()) {
            ac ac = new ac(this.f, "handleSignalCollectionCompleted", new Runnable(this) {
                  public void run() {
                    b.b.a(this.a);
                  }
                });
            this.f.G().a((d)ac, r.b.k);
            return;
          } 
          a();
        } 
        return;
      } 
    }
    
    public void run() {
      if (this.d.compareAndSet(false, true))
        a(); 
    }
  }
  
  class null implements Runnable {
    null(b this$0) {}
    
    public void run() {
      b.b.a(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\impl\mediation\c\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */