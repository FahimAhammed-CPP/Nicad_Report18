package com.facebook.appevents;

import android.content.Context;
import com.facebook.FacebookSdk;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\bÁ\002\030\0002\0020\001:\001\022B\007\b\002¢\006\002\020\002J\030\020\006\032\0020\0072\006\020\b\032\0020\t2\006\020\n\032\0020\013H\007J\020\020\006\032\0020\0072\006\020\f\032\0020\rH\007J\b\020\016\032\0020\017H\007J\027\020\020\032\0020\0072\b\020\f\032\004\030\0010\017H\001¢\006\002\b\021R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004X\004¢\006\002\n\000¨\006\023"}, d2 = {"Lcom/facebook/appevents/AppEventStore;", "", "()V", "PERSISTED_EVENTS_FILENAME", "", "TAG", "persistEvents", "", "accessTokenAppIdPair", "Lcom/facebook/appevents/AccessTokenAppIdPair;", "appEvents", "Lcom/facebook/appevents/SessionEventsState;", "eventsToPersist", "Lcom/facebook/appevents/AppEventCollection;", "readAndClearStore", "Lcom/facebook/appevents/PersistedEvents;", "saveEventsToDisk", "saveEventsToDisk$facebook_core_release", "MovedClassObjectInputStream", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AppEventStore {
  public static final AppEventStore INSTANCE = new AppEventStore();
  
  private static final String PERSISTED_EVENTS_FILENAME = "AppEventsLogger.persistedevents";
  
  private static final String TAG;
  
  static {
    String str = AppEventStore.class.getName();
    Intrinsics.checkNotNullExpressionValue(str, "AppEventStore::class.java.name");
    TAG = str;
  }
  
  @JvmStatic
  public static final void persistEvents(AccessTokenAppIdPair paramAccessTokenAppIdPair, SessionEventsState paramSessionEventsState) {
    // Byte code:
    //   0: ldc com/facebook/appevents/AppEventStore
    //   2: monitorenter
    //   3: ldc com/facebook/appevents/AppEventStore
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_2
    //   9: iload_2
    //   10: ifeq -> 17
    //   13: ldc com/facebook/appevents/AppEventStore
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: ldc 'accessTokenAppIdPair'
    //   20: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: aload_1
    //   24: ldc 'appEvents'
    //   26: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   29: invokestatic assertIsNotMainThread : ()V
    //   32: invokestatic readAndClearStore : ()Lcom/facebook/appevents/PersistedEvents;
    //   35: astore_3
    //   36: aload_3
    //   37: aload_0
    //   38: aload_1
    //   39: invokevirtual getEventsToPersist : ()Ljava/util/List;
    //   42: invokevirtual addEvents : (Lcom/facebook/appevents/AccessTokenAppIdPair;Ljava/util/List;)V
    //   45: aload_3
    //   46: invokestatic saveEventsToDisk$facebook_core_release : (Lcom/facebook/appevents/PersistedEvents;)V
    //   49: ldc com/facebook/appevents/AppEventStore
    //   51: monitorexit
    //   52: return
    //   53: astore_0
    //   54: aload_0
    //   55: ldc com/facebook/appevents/AppEventStore
    //   57: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   60: ldc com/facebook/appevents/AppEventStore
    //   62: monitorexit
    //   63: return
    //   64: astore_0
    //   65: ldc com/facebook/appevents/AppEventStore
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	64	finally
    //   17	49	53	finally
    //   54	60	64	finally
  }
  
  @JvmStatic
  public static final void persistEvents(AppEventCollection paramAppEventCollection) {
    // Byte code:
    //   0: ldc com/facebook/appevents/AppEventStore
    //   2: monitorenter
    //   3: ldc com/facebook/appevents/AppEventStore
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_1
    //   9: iload_1
    //   10: ifeq -> 17
    //   13: ldc com/facebook/appevents/AppEventStore
    //   15: monitorexit
    //   16: return
    //   17: aload_0
    //   18: ldc 'eventsToPersist'
    //   20: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
    //   23: invokestatic assertIsNotMainThread : ()V
    //   26: invokestatic readAndClearStore : ()Lcom/facebook/appevents/PersistedEvents;
    //   29: astore_2
    //   30: aload_0
    //   31: invokevirtual keySet : ()Ljava/util/Set;
    //   34: invokeinterface iterator : ()Ljava/util/Iterator;
    //   39: astore_3
    //   40: aload_3
    //   41: invokeinterface hasNext : ()Z
    //   46: ifeq -> 103
    //   49: aload_3
    //   50: invokeinterface next : ()Ljava/lang/Object;
    //   55: checkcast com/facebook/appevents/AccessTokenAppIdPair
    //   58: astore #4
    //   60: aload_0
    //   61: aload #4
    //   63: invokevirtual get : (Lcom/facebook/appevents/AccessTokenAppIdPair;)Lcom/facebook/appevents/SessionEventsState;
    //   66: astore #5
    //   68: aload #5
    //   70: ifnull -> 87
    //   73: aload_2
    //   74: aload #4
    //   76: aload #5
    //   78: invokevirtual getEventsToPersist : ()Ljava/util/List;
    //   81: invokevirtual addEvents : (Lcom/facebook/appevents/AccessTokenAppIdPair;Ljava/util/List;)V
    //   84: goto -> 40
    //   87: new java/lang/IllegalStateException
    //   90: dup
    //   91: ldc 'Required value was null.'
    //   93: invokevirtual toString : ()Ljava/lang/String;
    //   96: invokespecial <init> : (Ljava/lang/String;)V
    //   99: checkcast java/lang/Throwable
    //   102: athrow
    //   103: aload_2
    //   104: invokestatic saveEventsToDisk$facebook_core_release : (Lcom/facebook/appevents/PersistedEvents;)V
    //   107: ldc com/facebook/appevents/AppEventStore
    //   109: monitorexit
    //   110: return
    //   111: astore_0
    //   112: aload_0
    //   113: ldc com/facebook/appevents/AppEventStore
    //   115: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   118: ldc com/facebook/appevents/AppEventStore
    //   120: monitorexit
    //   121: return
    //   122: astore_0
    //   123: ldc com/facebook/appevents/AppEventStore
    //   125: monitorexit
    //   126: aload_0
    //   127: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	122	finally
    //   17	40	111	finally
    //   40	68	111	finally
    //   73	84	111	finally
    //   87	103	111	finally
    //   103	107	111	finally
    //   112	118	122	finally
  }
  
  @JvmStatic
  public static final PersistedEvents readAndClearStore() {
    // Byte code:
    //   0: ldc com/facebook/appevents/AppEventStore
    //   2: monitorenter
    //   3: ldc com/facebook/appevents/AppEventStore
    //   5: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   8: istore_0
    //   9: iload_0
    //   10: ifeq -> 18
    //   13: ldc com/facebook/appevents/AppEventStore
    //   15: monitorexit
    //   16: aconst_null
    //   17: areturn
    //   18: invokestatic assertIsNotMainThread : ()V
    //   21: aconst_null
    //   22: checkcast com/facebook/appevents/AppEventStore$MovedClassObjectInputStream
    //   25: astore_1
    //   26: aconst_null
    //   27: checkcast com/facebook/appevents/PersistedEvents
    //   30: astore_1
    //   31: invokestatic getApplicationContext : ()Landroid/content/Context;
    //   34: astore #4
    //   36: aload #4
    //   38: ldc 'AppEventsLogger.persistedevents'
    //   40: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   43: astore_1
    //   44: aload_1
    //   45: ldc 'context.openFileInput(PERSISTED_EVENTS_FILENAME)'
    //   47: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
    //   50: new com/facebook/appevents/AppEventStore$MovedClassObjectInputStream
    //   53: dup
    //   54: new java/io/BufferedInputStream
    //   57: dup
    //   58: aload_1
    //   59: checkcast java/io/InputStream
    //   62: invokespecial <init> : (Ljava/io/InputStream;)V
    //   65: checkcast java/io/InputStream
    //   68: invokespecial <init> : (Ljava/io/InputStream;)V
    //   71: astore_2
    //   72: aload_2
    //   73: astore_1
    //   74: aload_2
    //   75: invokevirtual readObject : ()Ljava/lang/Object;
    //   78: astore_3
    //   79: aload_3
    //   80: ifnull -> 132
    //   83: aload_2
    //   84: astore_1
    //   85: aload_3
    //   86: checkcast com/facebook/appevents/PersistedEvents
    //   89: astore_3
    //   90: aload_2
    //   91: checkcast java/io/Closeable
    //   94: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   97: aload #4
    //   99: ldc 'AppEventsLogger.persistedevents'
    //   101: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   104: invokevirtual delete : ()Z
    //   107: pop
    //   108: aload_3
    //   109: astore_1
    //   110: goto -> 285
    //   113: astore_1
    //   114: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   117: ldc 'Got unexpected exception when removing events file: '
    //   119: aload_1
    //   120: checkcast java/lang/Throwable
    //   123: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   126: pop
    //   127: aload_3
    //   128: astore_1
    //   129: goto -> 285
    //   132: aload_2
    //   133: astore_1
    //   134: new java/lang/NullPointerException
    //   137: dup
    //   138: ldc 'null cannot be cast to non-null type com.facebook.appevents.PersistedEvents'
    //   140: invokespecial <init> : (Ljava/lang/String;)V
    //   143: athrow
    //   144: astore_3
    //   145: goto -> 157
    //   148: astore_2
    //   149: aconst_null
    //   150: astore_1
    //   151: goto -> 214
    //   154: astore_3
    //   155: aconst_null
    //   156: astore_2
    //   157: aload_2
    //   158: astore_1
    //   159: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   162: ldc 'Got unexpected exception while reading events: '
    //   164: aload_3
    //   165: checkcast java/lang/Throwable
    //   168: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   171: pop
    //   172: aload_2
    //   173: checkcast java/io/Closeable
    //   176: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   179: aload #4
    //   181: ldc 'AppEventsLogger.persistedevents'
    //   183: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   186: invokevirtual delete : ()Z
    //   189: pop
    //   190: goto -> 339
    //   193: astore_1
    //   194: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   197: astore_2
    //   198: aload_1
    //   199: checkcast java/lang/Throwable
    //   202: astore_1
    //   203: aload_2
    //   204: ldc 'Got unexpected exception when removing events file: '
    //   206: aload_1
    //   207: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   210: pop
    //   211: goto -> 339
    //   214: aload_1
    //   215: checkcast java/io/Closeable
    //   218: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   221: aload #4
    //   223: ldc 'AppEventsLogger.persistedevents'
    //   225: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   228: invokevirtual delete : ()Z
    //   231: pop
    //   232: goto -> 249
    //   235: astore_1
    //   236: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   239: ldc 'Got unexpected exception when removing events file: '
    //   241: aload_1
    //   242: checkcast java/lang/Throwable
    //   245: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   248: pop
    //   249: aload_2
    //   250: athrow
    //   251: aload_2
    //   252: checkcast java/io/Closeable
    //   255: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   258: aload #4
    //   260: ldc 'AppEventsLogger.persistedevents'
    //   262: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
    //   265: invokevirtual delete : ()Z
    //   268: pop
    //   269: goto -> 339
    //   272: astore_1
    //   273: getstatic com/facebook/appevents/AppEventStore.TAG : Ljava/lang/String;
    //   276: astore_2
    //   277: aload_1
    //   278: checkcast java/lang/Throwable
    //   281: astore_1
    //   282: goto -> 203
    //   285: aload_1
    //   286: astore_2
    //   287: aload_1
    //   288: ifnonnull -> 299
    //   291: new com/facebook/appevents/PersistedEvents
    //   294: dup
    //   295: invokespecial <init> : ()V
    //   298: astore_2
    //   299: ldc com/facebook/appevents/AppEventStore
    //   301: monitorexit
    //   302: aload_2
    //   303: areturn
    //   304: astore_1
    //   305: aload_1
    //   306: ldc com/facebook/appevents/AppEventStore
    //   308: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   311: ldc com/facebook/appevents/AppEventStore
    //   313: monitorexit
    //   314: aconst_null
    //   315: areturn
    //   316: astore_1
    //   317: ldc com/facebook/appevents/AppEventStore
    //   319: monitorexit
    //   320: aload_1
    //   321: athrow
    //   322: astore_1
    //   323: goto -> 334
    //   326: astore_1
    //   327: goto -> 251
    //   330: astore_2
    //   331: goto -> 214
    //   334: aconst_null
    //   335: astore_2
    //   336: goto -> 251
    //   339: aconst_null
    //   340: astore_1
    //   341: goto -> 285
    // Exception table:
    //   from	to	target	type
    //   3	9	316	finally
    //   18	36	304	finally
    //   36	72	322	java/io/FileNotFoundException
    //   36	72	154	java/lang/Exception
    //   36	72	148	finally
    //   74	79	326	java/io/FileNotFoundException
    //   74	79	144	java/lang/Exception
    //   74	79	330	finally
    //   85	90	326	java/io/FileNotFoundException
    //   85	90	144	java/lang/Exception
    //   85	90	330	finally
    //   90	97	304	finally
    //   97	108	113	java/lang/Exception
    //   97	108	304	finally
    //   114	127	304	finally
    //   134	144	326	java/io/FileNotFoundException
    //   134	144	144	java/lang/Exception
    //   134	144	330	finally
    //   159	172	330	finally
    //   172	179	304	finally
    //   179	190	193	java/lang/Exception
    //   179	190	304	finally
    //   194	203	304	finally
    //   203	211	304	finally
    //   214	221	304	finally
    //   221	232	235	java/lang/Exception
    //   221	232	304	finally
    //   236	249	304	finally
    //   249	251	304	finally
    //   251	258	304	finally
    //   258	269	272	java/lang/Exception
    //   258	269	304	finally
    //   273	282	304	finally
    //   291	299	304	finally
    //   305	311	316	finally
  }
  
  @JvmStatic
  public static final void saveEventsToDisk$facebook_core_release(PersistedEvents paramPersistedEvents) {
    if (CrashShieldHandler.isObjectCrashing(AppEventStore.class))
      return; 
    Exception exception = null;
    try {
      Exception exception1;
      null = (ObjectOutputStream)null;
      Context context = FacebookSdk.getApplicationContext();
    } finally {
      paramPersistedEvents = null;
      CrashShieldHandler.handleThrowable((Throwable)paramPersistedEvents, AppEventStore.class);
    } 
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\b\002\030\000 \0072\0020\001:\001\007B\017\022\b\020\002\032\004\030\0010\003¢\006\002\020\004J\b\020\005\032\0020\006H\024¨\006\b"}, d2 = {"Lcom/facebook/appevents/AppEventStore$MovedClassObjectInputStream;", "Ljava/io/ObjectInputStream;", "inputStream", "Ljava/io/InputStream;", "(Ljava/io/InputStream;)V", "readClassDescriptor", "Ljava/io/ObjectStreamClass;", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class MovedClassObjectInputStream extends ObjectInputStream {
    private static final String ACCESS_TOKEN_APP_ID_PAIR_SERIALIZATION_PROXY_V1_CLASS_NAME = "com.facebook.appevents.AppEventsLogger$AccessTokenAppIdPair$SerializationProxyV1";
    
    private static final String APP_EVENT_SERIALIZATION_PROXY_V1_CLASS_NAME = "com.facebook.appevents.AppEventsLogger$AppEvent$SerializationProxyV2";
    
    public static final Companion Companion = new Companion(null);
    
    public MovedClassObjectInputStream(InputStream param1InputStream) {
      super(param1InputStream);
    }
    
    protected ObjectStreamClass readClassDescriptor() throws IOException, ClassNotFoundException {
      ObjectStreamClass objectStreamClass1;
      ObjectStreamClass objectStreamClass2 = super.readClassDescriptor();
      Intrinsics.checkNotNullExpressionValue(objectStreamClass2, "resultClassDescriptor");
      if (Intrinsics.areEqual(objectStreamClass2.getName(), "com.facebook.appevents.AppEventsLogger$AccessTokenAppIdPair$SerializationProxyV1")) {
        objectStreamClass1 = ObjectStreamClass.lookup(AccessTokenAppIdPair.SerializationProxyV1.class);
      } else {
        objectStreamClass1 = objectStreamClass2;
        if (Intrinsics.areEqual(objectStreamClass2.getName(), "com.facebook.appevents.AppEventsLogger$AppEvent$SerializationProxyV2"))
          objectStreamClass1 = ObjectStreamClass.lookup(AppEvent.SerializationProxyV2.class); 
      } 
      Intrinsics.checkNotNullExpressionValue(objectStreamClass1, "resultClassDescriptor");
      return objectStreamClass1;
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/appevents/AppEventStore$MovedClassObjectInputStream$Companion;", "", "()V", "ACCESS_TOKEN_APP_ID_PAIR_SERIALIZATION_PROXY_V1_CLASS_NAME", "", "APP_EVENT_SERIALIZATION_PROXY_V1_CLASS_NAME", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/appevents/AppEventStore$MovedClassObjectInputStream$Companion;", "", "()V", "ACCESS_TOKEN_APP_ID_PAIR_SERIALIZATION_PROXY_V1_CLASS_NAME", "", "APP_EVENT_SERIALIZATION_PROXY_V1_CLASS_NAME", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\appevents\AppEventStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */