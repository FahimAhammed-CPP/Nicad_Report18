package androidx.appcompat.widget;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;
import y.hs;
import y.on;
import y.p3;
import y.r2;
import y.x2;
import y.ク;
import y.掛;

public final class try implements p3 {
  public x2 怖;
  
  public r2 淋;
  
  public try(Toolbar paramToolbar) {}
  
  public final boolean ぱ(x2 paramx2) {
    Toolbar toolbar = this.恐;
    toolbar.熱();
    ViewParent viewParent2 = toolbar.興.getParent();
    if (viewParent2 != toolbar) {
      if (viewParent2 instanceof ViewGroup)
        ((ViewGroup)viewParent2).removeView((View)toolbar.興); 
      toolbar.addView((View)toolbar.興);
    } 
    View view = paramx2.getActionView();
    toolbar.産 = view;
    this.怖 = paramx2;
    ViewParent viewParent1 = view.getParent();
    if (viewParent1 != toolbar) {
      if (viewParent1 instanceof ViewGroup)
        ((ViewGroup)viewParent1).removeView(toolbar.産); 
      hs hs = new hs();
      ((ク)hs).硬 = toolbar.歩 & 0x70 | 0x800003;
      hs.堅 = 2;
      toolbar.産.setLayoutParams((ViewGroup.LayoutParams)hs);
      toolbar.addView(toolbar.産);
    } 
    int i = toolbar.getChildCount();
    while (true) {
      int j = i - 1;
      if (j >= 0) {
        View view2 = toolbar.getChildAt(j);
        i = j;
        if (((hs)view2.getLayoutParams()).堅 != 2) {
          i = j;
          if (view2 != toolbar.淋) {
            toolbar.removeViewAt(j);
            toolbar.크.add(view2);
            i = j;
          } 
        } 
        continue;
      } 
      toolbar.requestLayout();
      paramx2.歩 = true;
      paramx2.悲.淋(false);
      View view1 = toolbar.産;
      if (view1 instanceof 掛)
        ((掛)view1).onActionViewExpanded(); 
      toolbar.恐();
      return true;
    } 
  }
  
  public final void 冷() {
    if (this.怖 != null) {
      r2 r21 = this.淋;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (r21 != null) {
        int j = r21.size();
        int i = 0;
        while (true) {
          bool1 = bool2;
          if (i < j) {
            if (this.淋.getItem(i) == this.怖) {
              bool1 = true;
              break;
            } 
            i++;
            continue;
          } 
          break;
        } 
      } 
      if (!bool1)
        美(this.怖); 
    } 
  }
  
  public final boolean 旨() {
    return false;
  }
  
  public final void 熱(Context paramContext, r2 paramr2) {
    r2 r21 = this.淋;
    if (r21 != null) {
      x2 x21 = this.怖;
      if (x21 != null)
        r21.暑(x21); 
    } 
    this.淋 = paramr2;
  }
  
  public final void 硬(r2 paramr2, boolean paramBoolean) {}
  
  public final boolean 美(x2 paramx2) {
    Toolbar toolbar = this.恐;
    View view = toolbar.産;
    if (view instanceof 掛)
      ((掛)view).onActionViewCollapsed(); 
    toolbar.removeView(toolbar.産);
    toolbar.removeView((View)toolbar.興);
    toolbar.産 = null;
    ArrayList<View> arrayList = toolbar.크;
    int i = arrayList.size();
    while (true) {
      if (--i >= 0) {
        toolbar.addView(arrayList.get(i));
        continue;
      } 
      arrayList.clear();
      this.怖 = null;
      toolbar.requestLayout();
      paramx2.歩 = false;
      paramx2.悲.淋(false);
      toolbar.恐();
      return true;
    } 
  }
  
  public final boolean 辛(on paramon) {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\try.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */