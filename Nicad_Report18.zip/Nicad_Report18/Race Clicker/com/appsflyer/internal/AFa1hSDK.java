package com.appsflyer.internal;

import android.content.Context;
import android.net.NetworkInfo;

public final class AFa1hSDK {
  private static boolean AFInAppEventType(NetworkInfo paramNetworkInfo) {
    return (paramNetworkInfo != null && paramNetworkInfo.isConnectedOrConnecting());
  }
  
  public final AFa1zSDK valueOf(Context paramContext) {
    // Byte code:
    //   0: ldc 'unknown'
    //   2: astore #6
    //   4: aconst_null
    //   5: astore #8
    //   7: aconst_null
    //   8: astore #7
    //   10: aload #6
    //   12: astore #5
    //   14: aload_1
    //   15: ldc 'connectivity'
    //   17: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   20: checkcast android/net/ConnectivityManager
    //   23: astore #9
    //   25: aload #6
    //   27: astore #4
    //   29: aload #9
    //   31: ifnull -> 134
    //   34: aload #6
    //   36: astore #5
    //   38: aload #9
    //   40: invokevirtual getAllNetworks : ()[Landroid/net/Network;
    //   43: astore #10
    //   45: aload #6
    //   47: astore #5
    //   49: aload #10
    //   51: arraylength
    //   52: istore_3
    //   53: iconst_0
    //   54: istore_2
    //   55: aload #6
    //   57: astore #4
    //   59: iload_2
    //   60: iload_3
    //   61: if_icmpge -> 134
    //   64: aload #6
    //   66: astore #5
    //   68: aload #9
    //   70: aload #10
    //   72: iload_2
    //   73: aaload
    //   74: invokevirtual getNetworkInfo : (Landroid/net/Network;)Landroid/net/NetworkInfo;
    //   77: astore #11
    //   79: aload #6
    //   81: astore #5
    //   83: aload #11
    //   85: invokestatic AFInAppEventType : (Landroid/net/NetworkInfo;)Z
    //   88: ifeq -> 286
    //   91: aload #6
    //   93: astore #5
    //   95: iconst_1
    //   96: aload #11
    //   98: invokevirtual getType : ()I
    //   101: if_icmpne -> 111
    //   104: ldc 'WIFI'
    //   106: astore #4
    //   108: goto -> 134
    //   111: aload #6
    //   113: astore #4
    //   115: aload #6
    //   117: astore #5
    //   119: aload #11
    //   121: invokevirtual getType : ()I
    //   124: ifne -> 134
    //   127: ldc 'MOBILE'
    //   129: astore #4
    //   131: goto -> 134
    //   134: aload #4
    //   136: astore #5
    //   138: aload_1
    //   139: ldc 'phone'
    //   141: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   144: checkcast android/telephony/TelephonyManager
    //   147: astore #10
    //   149: aload #4
    //   151: astore #5
    //   153: aload #10
    //   155: invokevirtual getSimOperatorName : ()Ljava/lang/String;
    //   158: astore #6
    //   160: aload #7
    //   162: astore_1
    //   163: aload #10
    //   165: invokevirtual getNetworkOperatorName : ()Ljava/lang/String;
    //   168: astore #9
    //   170: aload #9
    //   172: ifnull -> 198
    //   175: aload #9
    //   177: astore_1
    //   178: aload #4
    //   180: astore #8
    //   182: aload #9
    //   184: astore #5
    //   186: aload #6
    //   188: astore #7
    //   190: aload #9
    //   192: invokevirtual isEmpty : ()Z
    //   195: ifeq -> 272
    //   198: aload #9
    //   200: astore_1
    //   201: aload #4
    //   203: astore #8
    //   205: aload #9
    //   207: astore #5
    //   209: aload #6
    //   211: astore #7
    //   213: iconst_2
    //   214: aload #10
    //   216: invokevirtual getPhoneType : ()I
    //   219: if_icmpne -> 272
    //   222: ldc 'CDMA'
    //   224: astore #5
    //   226: aload #4
    //   228: astore #8
    //   230: aload #6
    //   232: astore #7
    //   234: goto -> 272
    //   237: astore #7
    //   239: goto -> 254
    //   242: astore #7
    //   244: aconst_null
    //   245: astore_1
    //   246: aload #8
    //   248: astore #6
    //   250: aload #5
    //   252: astore #4
    //   254: ldc 'Exception while collecting network info. '
    //   256: aload #7
    //   258: invokestatic afErrorLog : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   261: aload #6
    //   263: astore #7
    //   265: aload_1
    //   266: astore #5
    //   268: aload #4
    //   270: astore #8
    //   272: new com/appsflyer/internal/AFa1hSDK$AFa1zSDK
    //   275: dup
    //   276: aload #8
    //   278: aload #5
    //   280: aload #7
    //   282: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   285: areturn
    //   286: iload_2
    //   287: iconst_1
    //   288: iadd
    //   289: istore_2
    //   290: goto -> 55
    // Exception table:
    //   from	to	target	type
    //   14	25	242	finally
    //   38	45	242	finally
    //   49	53	242	finally
    //   68	79	242	finally
    //   83	91	242	finally
    //   95	104	242	finally
    //   119	127	242	finally
    //   138	149	242	finally
    //   153	160	242	finally
    //   163	170	237	finally
    //   190	198	237	finally
    //   213	222	237	finally
  }
  
  static final class AFa1zSDK {
    final String AFInAppEventParameterName;
    
    final String AFInAppEventType;
    
    final String AFKeystoreWrapper;
    
    AFa1zSDK(String param1String1, String param1String2, String param1String3) {
      this.AFInAppEventType = param1String1;
      this.AFKeystoreWrapper = param1String2;
      this.AFInAppEventParameterName = param1String3;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFa1hSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */