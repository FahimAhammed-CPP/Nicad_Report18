package androidx.core.view;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.RestrictedSuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequenceScope;
import kotlin.sequences.SequencesKt;

@Metadata(d1 = {"\000j\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\t\n\002\020\b\n\002\b\r\n\002\020\002\n\000\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\t\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\b\n\0325\020 \032\0020!*\0020\0022#\b\004\020\"\032\035\022\023\022\0210\002¢\006\f\b$\022\b\b%\022\004\b\b(&\022\004\022\0020!0#H\bø\001\000\0325\020'\032\0020!*\0020\0022#\b\004\020\"\032\035\022\023\022\0210\002¢\006\f\b$\022\b\b%\022\004\b\b(&\022\004\022\0020!0#H\bø\001\000\0325\020(\032\0020!*\0020\0022#\b\004\020\"\032\035\022\023\022\0210\002¢\006\f\b$\022\b\b%\022\004\b\b(&\022\004\022\0020!0#H\bø\001\000\0325\020)\032\0020!*\0020\0022#\b\004\020\"\032\035\022\023\022\0210\002¢\006\f\b$\022\b\b%\022\004\b\b(&\022\004\022\0020!0#H\bø\001\000\0325\020*\032\0020+*\0020\0022#\b\004\020\"\032\035\022\023\022\0210\002¢\006\f\b$\022\b\b%\022\004\b\b(&\022\004\022\0020!0#H\bø\001\000\032\024\020,\032\0020-*\0020\0022\b\b\002\020.\032\0020/\032(\0200\032\00201*\0020\0022\006\0202\032\002032\016\b\004\020\"\032\b\022\004\022\0020!04H\bø\001\000\032\"\0205\032\00201*\0020\0022\006\0202\032\002032\f\020\"\032\b\022\004\022\0020!04H\007\032\027\0206\032\0020!*\0020\0022\b\b\001\0207\032\0020\023H\b\032:\0208\032\0020!\"\n\b\000\0209\030\001*\0020:*\0020\0022\027\020;\032\023\022\004\022\002H9\022\004\022\0020!0#¢\006\002\b<H\bø\001\000¢\006\002\b=\032)\0208\032\0020!*\0020\0022\027\020;\032\023\022\004\022\0020:\022\004\022\0020!0#¢\006\002\b<H\bø\001\000\0325\020>\032\0020!*\0020\0022\b\b\003\020?\032\0020\0232\b\b\003\020@\032\0020\0232\b\b\003\020A\032\0020\0232\b\b\003\020B\032\0020\023H\b\0325\020C\032\0020!*\0020\0022\b\b\003\020D\032\0020\0232\b\b\003\020@\032\0020\0232\b\b\003\020E\032\0020\0232\b\b\003\020B\032\0020\023H\b\"\033\020\000\032\b\022\004\022\0020\0020\001*\0020\0028F¢\006\006\032\004\b\003\020\004\"\033\020\005\032\b\022\004\022\0020\0060\001*\0020\0028F¢\006\006\032\004\b\007\020\004\"*\020\n\032\0020\t*\0020\0022\006\020\b\032\0020\t8Æ\002@Æ\002X\016¢\006\f\032\004\b\n\020\013\"\004\b\f\020\r\"*\020\016\032\0020\t*\0020\0022\006\020\b\032\0020\t8Æ\002@Æ\002X\016¢\006\f\032\004\b\016\020\013\"\004\b\017\020\r\"*\020\020\032\0020\t*\0020\0022\006\020\b\032\0020\t8Æ\002@Æ\002X\016¢\006\f\032\004\b\020\020\013\"\004\b\021\020\r\"\026\020\022\032\0020\023*\0020\0028Æ\002¢\006\006\032\004\b\024\020\025\"\026\020\026\032\0020\023*\0020\0028Æ\002¢\006\006\032\004\b\027\020\025\"\026\020\030\032\0020\023*\0020\0028Æ\002¢\006\006\032\004\b\031\020\025\"\026\020\032\032\0020\023*\0020\0028Æ\002¢\006\006\032\004\b\033\020\025\"\026\020\034\032\0020\023*\0020\0028Æ\002¢\006\006\032\004\b\035\020\025\"\026\020\036\032\0020\023*\0020\0028Æ\002¢\006\006\032\004\b\037\020\025\002\007\n\005\b20\001¨\006F"}, d2 = {"allViews", "Lkotlin/sequences/Sequence;", "Landroid/view/View;", "getAllViews", "(Landroid/view/View;)Lkotlin/sequences/Sequence;", "ancestors", "Landroid/view/ViewParent;", "getAncestors", "value", "", "isGone", "(Landroid/view/View;)Z", "setGone", "(Landroid/view/View;Z)V", "isInvisible", "setInvisible", "isVisible", "setVisible", "marginBottom", "", "getMarginBottom", "(Landroid/view/View;)I", "marginEnd", "getMarginEnd", "marginLeft", "getMarginLeft", "marginRight", "getMarginRight", "marginStart", "getMarginStart", "marginTop", "getMarginTop", "doOnAttach", "", "action", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "view", "doOnDetach", "doOnLayout", "doOnNextLayout", "doOnPreDraw", "Landroidx/core/view/OneShotPreDrawListener;", "drawToBitmap", "Landroid/graphics/Bitmap;", "config", "Landroid/graphics/Bitmap$Config;", "postDelayed", "Ljava/lang/Runnable;", "delayInMillis", "", "Lkotlin/Function0;", "postOnAnimationDelayed", "setPadding", "size", "updateLayoutParams", "T", "Landroid/view/ViewGroup$LayoutParams;", "block", "Lkotlin/ExtensionFunctionType;", "updateLayoutParamsTyped", "updatePadding", "left", "top", "right", "bottom", "updatePaddingRelative", "start", "end", "core-ktx_release"}, k = 2, mv = {1, 7, 1}, xi = 48)
public final class ViewKt {
  public static final void doOnAttach(View paramView, Function1<? super View, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    if (ViewCompat.isAttachedToWindow(paramView)) {
      paramFunction1.invoke(paramView);
      return;
    } 
    paramView.addOnAttachStateChangeListener(new ViewKt$doOnAttach$1(paramView, paramFunction1));
  }
  
  public static final void doOnDetach(View paramView, Function1<? super View, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    if (!ViewCompat.isAttachedToWindow(paramView)) {
      paramFunction1.invoke(paramView);
      return;
    } 
    paramView.addOnAttachStateChangeListener(new ViewKt$doOnDetach$1(paramView, paramFunction1));
  }
  
  public static final void doOnLayout(View paramView, Function1<? super View, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    if (ViewCompat.isLaidOut(paramView) && !paramView.isLayoutRequested()) {
      paramFunction1.invoke(paramView);
      return;
    } 
    paramView.addOnLayoutChangeListener(new ViewKt$doOnLayout$$inlined$doOnNextLayout$1(paramFunction1));
  }
  
  public static final void doOnNextLayout(View paramView, Function1<? super View, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    paramView.addOnLayoutChangeListener(new ViewKt$doOnNextLayout$1(paramFunction1));
  }
  
  public static final OneShotPreDrawListener doOnPreDraw(View paramView, Function1<? super View, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    OneShotPreDrawListener oneShotPreDrawListener = OneShotPreDrawListener.add(paramView, new ViewKt$doOnPreDraw$1(paramFunction1, paramView));
    Intrinsics.checkNotNullExpressionValue(oneShotPreDrawListener, "View.doOnPreDraw(\n    cr…dd(this) { action(this) }");
    return oneShotPreDrawListener;
  }
  
  public static final Bitmap drawToBitmap(View paramView, Bitmap.Config paramConfig) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramConfig, "config");
    if (ViewCompat.isLaidOut(paramView)) {
      Bitmap bitmap = Bitmap.createBitmap(paramView.getWidth(), paramView.getHeight(), paramConfig);
      Intrinsics.checkNotNullExpressionValue(bitmap, "createBitmap(width, height, config)");
      Canvas canvas = new Canvas(bitmap);
      canvas.translate(-(paramView.getScrollX()), -(paramView.getScrollY()));
      paramView.draw(canvas);
      return bitmap;
    } 
    throw new IllegalStateException("View needs to be laid out before calling drawToBitmap()");
  }
  
  public static final Sequence<View> getAllViews(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    return SequencesKt.sequence(new ViewKt$allViews$1(paramView, null));
  }
  
  public static final Sequence<ViewParent> getAncestors(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    return SequencesKt.generateSequence(paramView.getParent(), ViewKt$ancestors$1.INSTANCE);
  }
  
  public static final int getMarginBottom(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)layoutParams;
    } else {
      layoutParams = null;
    } 
    return (layoutParams != null) ? ((ViewGroup.MarginLayoutParams)layoutParams).bottomMargin : 0;
  }
  
  public static final int getMarginEnd(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    return (layoutParams instanceof ViewGroup.MarginLayoutParams) ? MarginLayoutParamsCompat.getMarginEnd((ViewGroup.MarginLayoutParams)layoutParams) : 0;
  }
  
  public static final int getMarginLeft(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)layoutParams;
    } else {
      layoutParams = null;
    } 
    return (layoutParams != null) ? ((ViewGroup.MarginLayoutParams)layoutParams).leftMargin : 0;
  }
  
  public static final int getMarginRight(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)layoutParams;
    } else {
      layoutParams = null;
    } 
    return (layoutParams != null) ? ((ViewGroup.MarginLayoutParams)layoutParams).rightMargin : 0;
  }
  
  public static final int getMarginStart(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    return (layoutParams instanceof ViewGroup.MarginLayoutParams) ? MarginLayoutParamsCompat.getMarginStart((ViewGroup.MarginLayoutParams)layoutParams) : 0;
  }
  
  public static final int getMarginTop(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)layoutParams;
    } else {
      layoutParams = null;
    } 
    return (layoutParams != null) ? ((ViewGroup.MarginLayoutParams)layoutParams).topMargin : 0;
  }
  
  public static final boolean isGone(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    return (paramView.getVisibility() == 8);
  }
  
  public static final boolean isInvisible(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    return (paramView.getVisibility() == 4);
  }
  
  public static final boolean isVisible(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    return (paramView.getVisibility() == 0);
  }
  
  public static final Runnable postDelayed(View paramView, long paramLong, Function0<Unit> paramFunction0) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction0, "action");
    ViewKt$postDelayed$runnable$1 viewKt$postDelayed$runnable$1 = new ViewKt$postDelayed$runnable$1(paramFunction0);
    paramView.postDelayed(viewKt$postDelayed$runnable$1, paramLong);
    return viewKt$postDelayed$runnable$1;
  }
  
  public static final Runnable postOnAnimationDelayed(View paramView, long paramLong, Function0<Unit> paramFunction0) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction0, "action");
    ViewKt$$ExternalSyntheticLambda0 viewKt$$ExternalSyntheticLambda0 = new ViewKt$$ExternalSyntheticLambda0(paramFunction0);
    Api16Impl.postOnAnimationDelayed(paramView, viewKt$$ExternalSyntheticLambda0, paramLong);
    return viewKt$$ExternalSyntheticLambda0;
  }
  
  private static final void postOnAnimationDelayed$lambda-1(Function0 paramFunction0) {
    Intrinsics.checkNotNullParameter(paramFunction0, "$action");
    paramFunction0.invoke();
  }
  
  public static final void setGone(View paramView, boolean paramBoolean) {
    boolean bool;
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    paramView.setVisibility(bool);
  }
  
  public static final void setInvisible(View paramView, boolean paramBoolean) {
    boolean bool;
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    paramView.setVisibility(bool);
  }
  
  public static final void setPadding(View paramView, int paramInt) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    paramView.setPadding(paramInt, paramInt, paramInt, paramInt);
  }
  
  public static final void setVisible(View paramView, boolean paramBoolean) {
    byte b;
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    if (paramBoolean) {
      b = 0;
    } else {
      b = 8;
    } 
    paramView.setVisibility(b);
  }
  
  public static final void updateLayoutParams(View paramView, Function1<? super ViewGroup.LayoutParams, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "block");
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams != null) {
      paramFunction1.invoke(layoutParams);
      paramView.setLayoutParams(layoutParams);
      return;
    } 
    throw new NullPointerException("null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
  }
  
  public static final void updatePadding(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    paramView.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static final void updatePaddingRelative(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Intrinsics.checkNotNullParameter(paramView, "<this>");
    paramView.setPaddingRelative(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\002\030\002\n\002\030\002\020\000\032\0020\001*\b\022\004\022\0020\0030\002H@"}, d2 = {"<anonymous>", "", "Lkotlin/sequences/SequenceScope;", "Landroid/view/View;"}, k = 3, mv = {1, 7, 1}, xi = 48)
  @DebugMetadata(c = "androidx.core.view.ViewKt$allViews$1", f = "View.kt", i = {0}, l = {414, 416}, m = "invokeSuspend", n = {"$this$sequence"}, s = {"L$0"})
  static final class ViewKt$allViews$1 extends RestrictedSuspendLambda implements Function2<SequenceScope<? super View>, Continuation<? super Unit>, Object> {
    int label;
    
    ViewKt$allViews$1(View param1View, Continuation<? super ViewKt$allViews$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      ViewKt$allViews$1 viewKt$allViews$1 = new ViewKt$allViews$1(this.$this_allViews, (Continuation)param1Continuation);
      viewKt$allViews$1.L$0 = param1Object;
      return (Continuation<Unit>)viewKt$allViews$1;
    }
    
    public final Object invoke(SequenceScope<? super View> param1SequenceScope, Continuation<? super Unit> param1Continuation) {
      return ((ViewKt$allViews$1)create(param1SequenceScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            ResultKt.throwOnFailure(param1Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          SequenceScope sequenceScope = (SequenceScope)this.L$0;
          ResultKt.throwOnFailure(param1Object);
          param1Object = sequenceScope;
          View view = this.$this_allViews;
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        SequenceScope sequenceScope = (SequenceScope)this.L$0;
        View view2 = this.$this_allViews;
        Continuation continuation = (Continuation)this;
        this.L$0 = sequenceScope;
        this.label = 1;
        param1Object = sequenceScope;
        if (sequenceScope.yield(view2, continuation) == object)
          return object; 
        View view1 = this.$this_allViews;
      } 
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007"}, d2 = {"androidx/core/view/ViewKt$doOnAttach$1", "Landroid/view/View$OnAttachStateChangeListener;", "onViewAttachedToWindow", "", "view", "Landroid/view/View;", "onViewDetachedFromWindow", "core-ktx_release"}, k = 1, mv = {1, 7, 1}, xi = 176)
  public static final class ViewKt$doOnAttach$1 implements View.OnAttachStateChangeListener {
    public ViewKt$doOnAttach$1(View param1View, Function1<? super View, Unit> param1Function1) {}
    
    public void onViewAttachedToWindow(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "view");
      this.$this_doOnAttach.removeOnAttachStateChangeListener(this);
      this.$action.invoke(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "view");
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007"}, d2 = {"androidx/core/view/ViewKt$doOnDetach$1", "Landroid/view/View$OnAttachStateChangeListener;", "onViewAttachedToWindow", "", "view", "Landroid/view/View;", "onViewDetachedFromWindow", "core-ktx_release"}, k = 1, mv = {1, 7, 1}, xi = 176)
  public static final class ViewKt$doOnDetach$1 implements View.OnAttachStateChangeListener {
    public ViewKt$doOnDetach$1(View param1View, Function1<? super View, Unit> param1Function1) {}
    
    public void onViewAttachedToWindow(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "view");
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "view");
      this.$this_doOnDetach.removeOnAttachStateChangeListener(this);
      this.$action.invoke(param1View);
    }
  }
  
  @Metadata(d1 = {"\000\037\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\b*\001\000\b\n\030\0002\0020\001JP\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\0072\006\020\b\032\0020\0072\006\020\t\032\0020\0072\006\020\n\032\0020\0072\006\020\013\032\0020\0072\006\020\f\032\0020\0072\006\020\r\032\0020\0072\006\020\016\032\0020\007H\026¨\006\017¸\006\000"}, d2 = {"androidx/core/view/ViewKt$doOnNextLayout$1", "Landroid/view/View$OnLayoutChangeListener;", "onLayoutChange", "", "view", "Landroid/view/View;", "left", "", "top", "right", "bottom", "oldLeft", "oldTop", "oldRight", "oldBottom", "core-ktx_release"}, k = 1, mv = {1, 7, 1}, xi = 176)
  public static final class ViewKt$doOnLayout$$inlined$doOnNextLayout$1 implements View.OnLayoutChangeListener {
    public ViewKt$doOnLayout$$inlined$doOnNextLayout$1(Function1 param1Function1) {}
    
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      Intrinsics.checkNotNullParameter(param1View, "view");
      param1View.removeOnLayoutChangeListener(this);
      this.$action$inlined.invoke(param1View);
    }
  }
  
  @Metadata(d1 = {"\000\037\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\b*\001\000\b\n\030\0002\0020\001JP\020\002\032\0020\0032\006\020\004\032\0020\0052\006\020\006\032\0020\0072\006\020\b\032\0020\0072\006\020\t\032\0020\0072\006\020\n\032\0020\0072\006\020\013\032\0020\0072\006\020\f\032\0020\0072\006\020\r\032\0020\0072\006\020\016\032\0020\007H\026¨\006\017"}, d2 = {"androidx/core/view/ViewKt$doOnNextLayout$1", "Landroid/view/View$OnLayoutChangeListener;", "onLayoutChange", "", "view", "Landroid/view/View;", "left", "", "top", "right", "bottom", "oldLeft", "oldTop", "oldRight", "oldBottom", "core-ktx_release"}, k = 1, mv = {1, 7, 1}, xi = 176)
  public static final class ViewKt$doOnNextLayout$1 implements View.OnLayoutChangeListener {
    public ViewKt$doOnNextLayout$1(Function1<? super View, Unit> param1Function1) {}
    
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      Intrinsics.checkNotNullParameter(param1View, "view");
      param1View.removeOnLayoutChangeListener(this);
      this.$action.invoke(param1View);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 7, 1}, xi = 176)
  public static final class ViewKt$doOnPreDraw$1 implements Runnable {
    public ViewKt$doOnPreDraw$1(Function1<? super View, Unit> param1Function1, View param1View) {}
    
    public final void run() {
      this.$action.invoke(this.$this_doOnPreDraw);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 7, 1}, xi = 176)
  public static final class ViewKt$postDelayed$runnable$1 implements Runnable {
    public ViewKt$postDelayed$runnable$1(Function0<Unit> param1Function0) {}
    
    public final void run() {
      this.$action.invoke();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\core\view\ViewKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */