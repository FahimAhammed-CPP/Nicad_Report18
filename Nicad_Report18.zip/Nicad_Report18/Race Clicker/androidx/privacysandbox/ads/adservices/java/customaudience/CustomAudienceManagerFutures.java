package androidx.privacysandbox.ads.adservices.java.customaudience;

import android.content.Context;
import androidx.privacysandbox.ads.adservices.customaudience.CustomAudienceManager;
import androidx.privacysandbox.ads.adservices.customaudience.JoinCustomAudienceRequest;
import androidx.privacysandbox.ads.adservices.customaudience.LeaveCustomAudienceRequest;
import androidx.privacysandbox.ads.adservices.java.internal.CoroutineAdapterKt;
import com.google.common.util.concurrent.ListenableFuture;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\b&\030\000 \0132\0020\001:\002\n\013B\007\b\000¢\006\002\020\002J\026\020\003\032\b\022\004\022\0020\0050\0042\006\020\006\032\0020\007H'J\026\020\b\032\b\022\004\022\0020\0050\0042\006\020\006\032\0020\tH'¨\006\f"}, d2 = {"Landroidx/privacysandbox/ads/adservices/java/customaudience/CustomAudienceManagerFutures;", "", "()V", "joinCustomAudienceAsync", "Lcom/google/common/util/concurrent/ListenableFuture;", "", "request", "Landroidx/privacysandbox/ads/adservices/customaudience/JoinCustomAudienceRequest;", "leaveCustomAudienceAsync", "Landroidx/privacysandbox/ads/adservices/customaudience/LeaveCustomAudienceRequest;", "Api33Ext4JavaImpl", "Companion", "ads-adservices-java_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class CustomAudienceManagerFutures {
  public static final Companion Companion = new Companion(null);
  
  @JvmStatic
  public static final CustomAudienceManagerFutures from(Context paramContext) {
    return Companion.from(paramContext);
  }
  
  public abstract ListenableFuture<Unit> joinCustomAudienceAsync(JoinCustomAudienceRequest paramJoinCustomAudienceRequest);
  
  public abstract ListenableFuture<Unit> leaveCustomAudienceAsync(LeaveCustomAudienceRequest paramLeaveCustomAudienceRequest);
  
  @Metadata(d1 = {"\000(\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\b\002\030\0002\0020\001B\017\022\b\020\002\032\004\030\0010\003¢\006\002\020\004J\026\020\005\032\b\022\004\022\0020\0070\0062\006\020\b\032\0020\tH\027J\026\020\n\032\b\022\004\022\0020\0070\0062\006\020\b\032\0020\013H\027R\020\020\002\032\004\030\0010\003X\004¢\006\002\n\000¨\006\f"}, d2 = {"Landroidx/privacysandbox/ads/adservices/java/customaudience/CustomAudienceManagerFutures$Api33Ext4JavaImpl;", "Landroidx/privacysandbox/ads/adservices/java/customaudience/CustomAudienceManagerFutures;", "mCustomAudienceManager", "Landroidx/privacysandbox/ads/adservices/customaudience/CustomAudienceManager;", "(Landroidx/privacysandbox/ads/adservices/customaudience/CustomAudienceManager;)V", "joinCustomAudienceAsync", "Lcom/google/common/util/concurrent/ListenableFuture;", "", "request", "Landroidx/privacysandbox/ads/adservices/customaudience/JoinCustomAudienceRequest;", "leaveCustomAudienceAsync", "Landroidx/privacysandbox/ads/adservices/customaudience/LeaveCustomAudienceRequest;", "ads-adservices-java_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  private static final class Api33Ext4JavaImpl extends CustomAudienceManagerFutures {
    private final CustomAudienceManager mCustomAudienceManager;
    
    public Api33Ext4JavaImpl(CustomAudienceManager param1CustomAudienceManager) {
      this.mCustomAudienceManager = param1CustomAudienceManager;
    }
    
    public ListenableFuture<Unit> joinCustomAudienceAsync(JoinCustomAudienceRequest param1JoinCustomAudienceRequest) {
      Intrinsics.checkNotNullParameter(param1JoinCustomAudienceRequest, "request");
      return CoroutineAdapterKt.asListenableFuture$default(BuildersKt.async$default(CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getDefault()), null, null, new CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1(param1JoinCustomAudienceRequest, null), 3, null), null, 1, null);
    }
    
    public ListenableFuture<Unit> leaveCustomAudienceAsync(LeaveCustomAudienceRequest param1LeaveCustomAudienceRequest) {
      Intrinsics.checkNotNullParameter(param1LeaveCustomAudienceRequest, "request");
      return CoroutineAdapterKt.asListenableFuture$default(BuildersKt.async$default(CoroutineScopeKt.CoroutineScope((CoroutineContext)Dispatchers.getDefault()), null, null, new CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1(param1LeaveCustomAudienceRequest, null), 3, null), null, 1, null);
    }
    
    @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\030\002\020\000\032\0020\001*\0020\002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "androidx.privacysandbox.ads.adservices.java.customaudience.CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1", f = "CustomAudienceManagerFutures.kt", i = {}, l = {113}, m = "invokeSuspend", n = {}, s = {})
    static final class CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
      int label;
      
      CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1(JoinCustomAudienceRequest param2JoinCustomAudienceRequest, Continuation<? super CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1> param2Continuation) {
        super(2, param2Continuation);
      }
      
      public final Continuation<Unit> create(Object param2Object, Continuation<?> param2Continuation) {
        return (Continuation<Unit>)new CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1(this.$request, (Continuation)param2Continuation);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, Continuation<? super Unit> param2Continuation) {
        return ((CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1)create(param2CoroutineScope, param2Continuation)).invokeSuspend(Unit.INSTANCE);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i != 0) {
          if (i == 1) {
            ResultKt.throwOnFailure(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          ResultKt.throwOnFailure(param2Object);
          param2Object = CustomAudienceManagerFutures.Api33Ext4JavaImpl.this.mCustomAudienceManager;
          Intrinsics.checkNotNull(param2Object);
          JoinCustomAudienceRequest joinCustomAudienceRequest = this.$request;
          Continuation continuation = (Continuation)this;
          this.label = 1;
          if (param2Object.joinCustomAudience(joinCustomAudienceRequest, continuation) == object)
            return object; 
        } 
        return Unit.INSTANCE;
      }
    }
    
    @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\030\002\020\000\032\0020\001*\0020\002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
    @DebugMetadata(c = "androidx.privacysandbox.ads.adservices.java.customaudience.CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1", f = "CustomAudienceManagerFutures.kt", i = {}, l = {123}, m = "invokeSuspend", n = {}, s = {})
    static final class CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
      int label;
      
      CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1(LeaveCustomAudienceRequest param2LeaveCustomAudienceRequest, Continuation<? super CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1> param2Continuation) {
        super(2, param2Continuation);
      }
      
      public final Continuation<Unit> create(Object param2Object, Continuation<?> param2Continuation) {
        return (Continuation<Unit>)new CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1(this.$request, (Continuation)param2Continuation);
      }
      
      public final Object invoke(CoroutineScope param2CoroutineScope, Continuation<? super Unit> param2Continuation) {
        return ((CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1)create(param2CoroutineScope, param2Continuation)).invokeSuspend(Unit.INSTANCE);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        int i = this.label;
        if (i != 0) {
          if (i == 1) {
            ResultKt.throwOnFailure(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          ResultKt.throwOnFailure(param2Object);
          param2Object = CustomAudienceManagerFutures.Api33Ext4JavaImpl.this.mCustomAudienceManager;
          Intrinsics.checkNotNull(param2Object);
          LeaveCustomAudienceRequest leaveCustomAudienceRequest = this.$request;
          Continuation continuation = (Continuation)this;
          this.label = 1;
          if (param2Object.leaveCustomAudience(leaveCustomAudienceRequest, continuation) == object)
            return object; 
        } 
        return Unit.INSTANCE;
      }
    }
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\030\002\020\000\032\0020\001*\0020\002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
  @DebugMetadata(c = "androidx.privacysandbox.ads.adservices.java.customaudience.CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1", f = "CustomAudienceManagerFutures.kt", i = {}, l = {113}, m = "invokeSuspend", n = {}, s = {})
  static final class CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    
    CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1(JoinCustomAudienceRequest param1JoinCustomAudienceRequest, Continuation<? super CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1(this.$request, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((CustomAudienceManagerFutures$Api33Ext4JavaImpl$joinCustomAudienceAsync$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = CustomAudienceManagerFutures.Api33Ext4JavaImpl.this.mCustomAudienceManager;
        Intrinsics.checkNotNull(param1Object);
        JoinCustomAudienceRequest joinCustomAudienceRequest = this.$request;
        Continuation continuation = (Continuation)this;
        this.label = 1;
        if (param1Object.joinCustomAudience(joinCustomAudienceRequest, continuation) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\n\n\000\n\002\020\002\n\002\030\002\020\000\032\0020\001*\0020\002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {1, 8, 0}, xi = 48)
  @DebugMetadata(c = "androidx.privacysandbox.ads.adservices.java.customaudience.CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1", f = "CustomAudienceManagerFutures.kt", i = {}, l = {123}, m = "invokeSuspend", n = {}, s = {})
  static final class CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    int label;
    
    CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1(LeaveCustomAudienceRequest param1LeaveCustomAudienceRequest, Continuation<? super CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      return (Continuation<Unit>)new CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1(this.$request, (Continuation)param1Continuation);
    }
    
    public final Object invoke(CoroutineScope param1CoroutineScope, Continuation<? super Unit> param1Continuation) {
      return ((CustomAudienceManagerFutures$Api33Ext4JavaImpl$leaveCustomAudienceAsync$1)create(param1CoroutineScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = CustomAudienceManagerFutures.Api33Ext4JavaImpl.this.mCustomAudienceManager;
        Intrinsics.checkNotNull(param1Object);
        LeaveCustomAudienceRequest leaveCustomAudienceRequest = this.$request;
        Continuation continuation = (Continuation)this;
        this.label = 1;
        if (param1Object.leaveCustomAudience(leaveCustomAudienceRequest, continuation) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\022\020\003\032\004\030\0010\0042\006\020\005\032\0020\006H\007¨\006\007"}, d2 = {"Landroidx/privacysandbox/ads/adservices/java/customaudience/CustomAudienceManagerFutures$Companion;", "", "()V", "from", "Landroidx/privacysandbox/ads/adservices/java/customaudience/CustomAudienceManagerFutures;", "context", "Landroid/content/Context;", "ads-adservices-java_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Companion {
    private Companion() {}
    
    @JvmStatic
    public final CustomAudienceManagerFutures from(Context param1Context) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      CustomAudienceManager customAudienceManager = CustomAudienceManager.Companion.obtain(param1Context);
      if (customAudienceManager != null) {
        CustomAudienceManagerFutures.Api33Ext4JavaImpl api33Ext4JavaImpl = new CustomAudienceManagerFutures.Api33Ext4JavaImpl(customAudienceManager);
      } else {
        customAudienceManager = null;
      } 
      return (CustomAudienceManagerFutures)customAudienceManager;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\privacysandbox\ads\adservices\java\customaudience\CustomAudienceManagerFutures.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */