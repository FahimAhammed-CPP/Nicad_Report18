package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable;

public final class ShareOpenGraphContent extends ShareContent<ShareOpenGraphContent, ShareOpenGraphContent.Builder> {
  public static final Parcelable.Creator<ShareOpenGraphContent> CREATOR = new Parcelable.Creator<ShareOpenGraphContent>() {
      public ShareOpenGraphContent createFromParcel(Parcel param1Parcel) {
        return new ShareOpenGraphContent(param1Parcel);
      }
      
      public ShareOpenGraphContent[] newArray(int param1Int) {
        return new ShareOpenGraphContent[param1Int];
      }
    };
  
  private final ShareOpenGraphAction action;
  
  private final String previewPropertyName;
  
  ShareOpenGraphContent(Parcel paramParcel) {
    super(paramParcel);
    this.action = (new ShareOpenGraphAction.Builder()).readFrom(paramParcel).build();
    this.previewPropertyName = paramParcel.readString();
  }
  
  private ShareOpenGraphContent(Builder paramBuilder) {
    super(paramBuilder);
    this.action = paramBuilder.action;
    this.previewPropertyName = paramBuilder.previewPropertyName;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public ShareOpenGraphAction getAction() {
    return this.action;
  }
  
  public String getPreviewPropertyName() {
    return this.previewPropertyName;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeParcelable((Parcelable)this.action, 0);
    paramParcel.writeString(this.previewPropertyName);
  }
  
  public static final class Builder extends ShareContent.Builder<ShareOpenGraphContent, Builder> {
    private ShareOpenGraphAction action;
    
    private String previewPropertyName;
    
    public ShareOpenGraphContent build() {
      return new ShareOpenGraphContent(this);
    }
    
    public Builder readFrom(ShareOpenGraphContent param1ShareOpenGraphContent) {
      return (param1ShareOpenGraphContent == null) ? this : ((Builder)super.readFrom(param1ShareOpenGraphContent)).setAction(param1ShareOpenGraphContent.getAction()).setPreviewPropertyName(param1ShareOpenGraphContent.getPreviewPropertyName());
    }
    
    public Builder setAction(ShareOpenGraphAction param1ShareOpenGraphAction) {
      if (param1ShareOpenGraphAction == null) {
        param1ShareOpenGraphAction = null;
      } else {
        param1ShareOpenGraphAction = (new ShareOpenGraphAction.Builder()).readFrom(param1ShareOpenGraphAction).build();
      } 
      this.action = param1ShareOpenGraphAction;
      return this;
    }
    
    public Builder setPreviewPropertyName(String param1String) {
      this.previewPropertyName = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\model\ShareOpenGraphContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */