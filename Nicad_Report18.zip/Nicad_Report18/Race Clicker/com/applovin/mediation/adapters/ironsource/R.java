package com.applovin.mediation.adapters.ironsource;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
    
    public static final int mbridge_reward_activity_open = 2130771992;
    
    public static final int mbridge_reward_activity_stay = 2130771993;
  }
  
  public static final class array {
    public static final int al_exo_playback_speeds = 2130837504;
    
    public static final int al_exo_speed_multiplied_by_100 = 2130837505;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130903040;
    
    public static final int actionBarItemBackground = 2130903041;
    
    public static final int actionBarPopupTheme = 2130903042;
    
    public static final int actionBarSize = 2130903043;
    
    public static final int actionBarSplitStyle = 2130903044;
    
    public static final int actionBarStyle = 2130903045;
    
    public static final int actionBarTabBarStyle = 2130903046;
    
    public static final int actionBarTabStyle = 2130903047;
    
    public static final int actionBarTabTextStyle = 2130903048;
    
    public static final int actionBarTheme = 2130903049;
    
    public static final int actionBarWidgetTheme = 2130903050;
    
    public static final int actionButtonStyle = 2130903051;
    
    public static final int actionDropDownStyle = 2130903052;
    
    public static final int actionLayout = 2130903053;
    
    public static final int actionMenuTextAppearance = 2130903054;
    
    public static final int actionMenuTextColor = 2130903055;
    
    public static final int actionModeBackground = 2130903056;
    
    public static final int actionModeCloseButtonStyle = 2130903057;
    
    public static final int actionModeCloseDrawable = 2130903058;
    
    public static final int actionModeCopyDrawable = 2130903059;
    
    public static final int actionModeCutDrawable = 2130903060;
    
    public static final int actionModeFindDrawable = 2130903061;
    
    public static final int actionModePasteDrawable = 2130903062;
    
    public static final int actionModePopupWindowStyle = 2130903063;
    
    public static final int actionModeSelectAllDrawable = 2130903064;
    
    public static final int actionModeShareDrawable = 2130903065;
    
    public static final int actionModeSplitBackground = 2130903066;
    
    public static final int actionModeStyle = 2130903067;
    
    public static final int actionModeWebSearchDrawable = 2130903068;
    
    public static final int actionOverflowButtonStyle = 2130903069;
    
    public static final int actionOverflowMenuStyle = 2130903070;
    
    public static final int actionProviderClass = 2130903071;
    
    public static final int actionViewClass = 2130903072;
    
    public static final int activityChooserViewStyle = 2130903073;
    
    public static final int adSize = 2130903074;
    
    public static final int adSizes = 2130903075;
    
    public static final int adUnitId = 2130903076;
    
    public static final int al_ad_marker_color = 2130903077;
    
    public static final int al_ad_marker_width = 2130903078;
    
    public static final int al_animation_enabled = 2130903079;
    
    public static final int al_auto_show = 2130903080;
    
    public static final int al_backgroundTint = 2130903081;
    
    public static final int al_bar_gravity = 2130903082;
    
    public static final int al_bar_height = 2130903083;
    
    public static final int al_buffered_color = 2130903084;
    
    public static final int al_controller_layout_id = 2130903085;
    
    public static final int al_default_artwork = 2130903086;
    
    public static final int al_hide_during_ads = 2130903087;
    
    public static final int al_hide_on_touch = 2130903088;
    
    public static final int al_keep_content_on_player_reset = 2130903089;
    
    public static final int al_played_ad_marker_color = 2130903090;
    
    public static final int al_played_color = 2130903091;
    
    public static final int al_player_layout_id = 2130903092;
    
    public static final int al_repeat_toggle_modes = 2130903093;
    
    public static final int al_resize_mode = 2130903094;
    
    public static final int al_scrubber_color = 2130903095;
    
    public static final int al_scrubber_disabled_size = 2130903096;
    
    public static final int al_scrubber_dragged_size = 2130903097;
    
    public static final int al_scrubber_drawable = 2130903098;
    
    public static final int al_scrubber_enabled_size = 2130903099;
    
    public static final int al_show_buffering = 2130903100;
    
    public static final int al_show_fastforward_button = 2130903101;
    
    public static final int al_show_next_button = 2130903102;
    
    public static final int al_show_previous_button = 2130903103;
    
    public static final int al_show_rewind_button = 2130903104;
    
    public static final int al_show_shuffle_button = 2130903105;
    
    public static final int al_show_subtitle_button = 2130903106;
    
    public static final int al_show_timeout = 2130903107;
    
    public static final int al_show_vr_button = 2130903108;
    
    public static final int al_shutter_background_color = 2130903109;
    
    public static final int al_surface_type = 2130903110;
    
    public static final int al_time_bar_min_update_interval = 2130903111;
    
    public static final int al_touch_target_height = 2130903112;
    
    public static final int al_unplayed_color = 2130903113;
    
    public static final int al_use_artwork = 2130903114;
    
    public static final int al_use_controller = 2130903115;
    
    public static final int alertDialogButtonGroupStyle = 2130903116;
    
    public static final int alertDialogCenterButtons = 2130903117;
    
    public static final int alertDialogStyle = 2130903118;
    
    public static final int alertDialogTheme = 2130903119;
    
    public static final int allowStacking = 2130903120;
    
    public static final int alpha = 2130903121;
    
    public static final int alphabeticModifiers = 2130903122;
    
    public static final int arrowHeadLength = 2130903123;
    
    public static final int arrowShaftLength = 2130903124;
    
    public static final int autoCompleteTextViewStyle = 2130903125;
    
    public static final int autoSizeMaxTextSize = 2130903126;
    
    public static final int autoSizeMinTextSize = 2130903127;
    
    public static final int autoSizePresetSizes = 2130903128;
    
    public static final int autoSizeStepGranularity = 2130903129;
    
    public static final int autoSizeTextType = 2130903130;
    
    public static final int background = 2130903131;
    
    public static final int backgroundSplit = 2130903132;
    
    public static final int backgroundStacked = 2130903133;
    
    public static final int backgroundTint = 2130903134;
    
    public static final int backgroundTintMode = 2130903135;
    
    public static final int barLength = 2130903136;
    
    public static final int borderlessButtonStyle = 2130903137;
    
    public static final int buttonBarButtonStyle = 2130903138;
    
    public static final int buttonBarNegativeButtonStyle = 2130903139;
    
    public static final int buttonBarNeutralButtonStyle = 2130903140;
    
    public static final int buttonBarPositiveButtonStyle = 2130903141;
    
    public static final int buttonBarStyle = 2130903142;
    
    public static final int buttonCompat = 2130903143;
    
    public static final int buttonGravity = 2130903144;
    
    public static final int buttonIconDimen = 2130903145;
    
    public static final int buttonPanelSideLayout = 2130903146;
    
    public static final int buttonSize = 2130903147;
    
    public static final int buttonStyle = 2130903148;
    
    public static final int buttonStyleSmall = 2130903149;
    
    public static final int buttonTint = 2130903150;
    
    public static final int buttonTintMode = 2130903151;
    
    public static final int cardBackgroundColor = 2130903152;
    
    public static final int cardCornerRadius = 2130903153;
    
    public static final int cardElevation = 2130903154;
    
    public static final int cardMaxElevation = 2130903155;
    
    public static final int cardPreventCornerOverlap = 2130903156;
    
    public static final int cardUseCompatPadding = 2130903157;
    
    public static final int cardViewStyle = 2130903158;
    
    public static final int checkboxStyle = 2130903159;
    
    public static final int checkedTextViewStyle = 2130903160;
    
    public static final int circleCrop = 2130903161;
    
    public static final int closeIcon = 2130903162;
    
    public static final int closeItemLayout = 2130903163;
    
    public static final int collapseContentDescription = 2130903164;
    
    public static final int collapseIcon = 2130903165;
    
    public static final int color = 2130903166;
    
    public static final int colorAccent = 2130903167;
    
    public static final int colorBackgroundFloating = 2130903168;
    
    public static final int colorButtonNormal = 2130903169;
    
    public static final int colorControlActivated = 2130903170;
    
    public static final int colorControlHighlight = 2130903171;
    
    public static final int colorControlNormal = 2130903172;
    
    public static final int colorError = 2130903173;
    
    public static final int colorPrimary = 2130903174;
    
    public static final int colorPrimaryDark = 2130903175;
    
    public static final int colorScheme = 2130903176;
    
    public static final int colorSwitchThumbNormal = 2130903177;
    
    public static final int commitIcon = 2130903190;
    
    public static final int contentDescription = 2130903191;
    
    public static final int contentInsetEnd = 2130903192;
    
    public static final int contentInsetEndWithActions = 2130903193;
    
    public static final int contentInsetLeft = 2130903194;
    
    public static final int contentInsetRight = 2130903195;
    
    public static final int contentInsetStart = 2130903196;
    
    public static final int contentInsetStartWithNavigation = 2130903197;
    
    public static final int contentPadding = 2130903198;
    
    public static final int contentPaddingBottom = 2130903199;
    
    public static final int contentPaddingLeft = 2130903200;
    
    public static final int contentPaddingRight = 2130903201;
    
    public static final int contentPaddingTop = 2130903202;
    
    public static final int controlBackground = 2130903203;
    
    public static final int coordinatorLayoutStyle = 2130903204;
    
    public static final int corner = 2130903205;
    
    public static final int customNavigationLayout = 2130903206;
    
    public static final int defaultQueryHint = 2130903207;
    
    public static final int dialogCornerRadius = 2130903208;
    
    public static final int dialogPreferredPadding = 2130903209;
    
    public static final int dialogTheme = 2130903210;
    
    public static final int displayOptions = 2130903211;
    
    public static final int divider = 2130903212;
    
    public static final int dividerHorizontal = 2130903213;
    
    public static final int dividerPadding = 2130903214;
    
    public static final int dividerVertical = 2130903215;
    
    public static final int drawableBottomCompat = 2130903216;
    
    public static final int drawableEndCompat = 2130903217;
    
    public static final int drawableLeftCompat = 2130903218;
    
    public static final int drawableRightCompat = 2130903219;
    
    public static final int drawableSize = 2130903220;
    
    public static final int drawableStartCompat = 2130903221;
    
    public static final int drawableTint = 2130903222;
    
    public static final int drawableTintMode = 2130903223;
    
    public static final int drawableTopCompat = 2130903224;
    
    public static final int drawerArrowStyle = 2130903225;
    
    public static final int dropDownListViewStyle = 2130903226;
    
    public static final int dropdownListPreferredItemHeight = 2130903227;
    
    public static final int editTextBackground = 2130903228;
    
    public static final int editTextColor = 2130903229;
    
    public static final int editTextStyle = 2130903230;
    
    public static final int elevation = 2130903231;
    
    public static final int expandActivityOverflowButtonDrawable = 2130903232;
    
    public static final int fastScrollEnabled = 2130903233;
    
    public static final int fastScrollHorizontalThumbDrawable = 2130903234;
    
    public static final int fastScrollHorizontalTrackDrawable = 2130903235;
    
    public static final int fastScrollVerticalThumbDrawable = 2130903236;
    
    public static final int fastScrollVerticalTrackDrawable = 2130903237;
    
    public static final int firstBaselineToTopHeight = 2130903238;
    
    public static final int font = 2130903239;
    
    public static final int fontFamily = 2130903240;
    
    public static final int fontProviderAuthority = 2130903241;
    
    public static final int fontProviderCerts = 2130903242;
    
    public static final int fontProviderFetchStrategy = 2130903243;
    
    public static final int fontProviderFetchTimeout = 2130903244;
    
    public static final int fontProviderPackage = 2130903245;
    
    public static final int fontProviderQuery = 2130903246;
    
    public static final int fontProviderSystemFontFamily = 2130903247;
    
    public static final int fontStyle = 2130903248;
    
    public static final int fontVariationSettings = 2130903249;
    
    public static final int fontWeight = 2130903250;
    
    public static final int gapBetweenBars = 2130903251;
    
    public static final int goIcon = 2130903252;
    
    public static final int height = 2130903253;
    
    public static final int hideOnContentScroll = 2130903254;
    
    public static final int homeAsUpIndicator = 2130903255;
    
    public static final int homeLayout = 2130903256;
    
    public static final int icon = 2130903257;
    
    public static final int iconTint = 2130903258;
    
    public static final int iconTintMode = 2130903259;
    
    public static final int iconifiedByDefault = 2130903260;
    
    public static final int imageAspectRatio = 2130903261;
    
    public static final int imageAspectRatioAdjust = 2130903262;
    
    public static final int imageButtonStyle = 2130903263;
    
    public static final int indeterminateProgressStyle = 2130903264;
    
    public static final int initialActivityCount = 2130903265;
    
    public static final int isLightTheme = 2130903266;
    
    public static final int itemPadding = 2130903267;
    
    public static final int keylines = 2130903268;
    
    public static final int lStar = 2130903269;
    
    public static final int lastBaselineToBottomHeight = 2130903270;
    
    public static final int layout = 2130903271;
    
    public static final int layoutManager = 2130903272;
    
    public static final int layout_anchor = 2130903273;
    
    public static final int layout_anchorGravity = 2130903274;
    
    public static final int layout_behavior = 2130903275;
    
    public static final int layout_dodgeInsetEdges = 2130903276;
    
    public static final int layout_insetEdge = 2130903277;
    
    public static final int layout_keyline = 2130903278;
    
    public static final int lineHeight = 2130903279;
    
    public static final int listChoiceBackgroundIndicator = 2130903280;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130903281;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130903282;
    
    public static final int listDividerAlertDialog = 2130903283;
    
    public static final int listItemLayout = 2130903284;
    
    public static final int listLayout = 2130903285;
    
    public static final int listMenuViewStyle = 2130903286;
    
    public static final int listPopupWindowStyle = 2130903287;
    
    public static final int listPreferredItemHeight = 2130903288;
    
    public static final int listPreferredItemHeightLarge = 2130903289;
    
    public static final int listPreferredItemHeightSmall = 2130903290;
    
    public static final int listPreferredItemPaddingEnd = 2130903291;
    
    public static final int listPreferredItemPaddingLeft = 2130903292;
    
    public static final int listPreferredItemPaddingRight = 2130903293;
    
    public static final int listPreferredItemPaddingStart = 2130903294;
    
    public static final int logo = 2130903295;
    
    public static final int logoDescription = 2130903296;
    
    public static final int maxButtonHeight = 2130903297;
    
    public static final int mbridge_click = 2130903298;
    
    public static final int mbridge_data = 2130903299;
    
    public static final int mbridge_effect = 2130903300;
    
    public static final int mbridge_effect_strategy = 2130903301;
    
    public static final int mbridge_report = 2130903302;
    
    public static final int mbridge_strategy = 2130903303;
    
    public static final int measureWithLargestChild = 2130903304;
    
    public static final int menu = 2130903305;
    
    public static final int multiChoiceItemLayout = 2130903306;
    
    public static final int navigationContentDescription = 2130903307;
    
    public static final int navigationIcon = 2130903308;
    
    public static final int navigationMode = 2130903309;
    
    public static final int nestedScrollViewStyle = 2130903310;
    
    public static final int numericModifiers = 2130903311;
    
    public static final int overlapAnchor = 2130903312;
    
    public static final int paddingBottomNoButtons = 2130903313;
    
    public static final int paddingEnd = 2130903314;
    
    public static final int paddingStart = 2130903315;
    
    public static final int paddingTopNoTitle = 2130903316;
    
    public static final int panelBackground = 2130903317;
    
    public static final int panelMenuListTheme = 2130903318;
    
    public static final int panelMenuListWidth = 2130903319;
    
    public static final int popupMenuStyle = 2130903320;
    
    public static final int popupTheme = 2130903321;
    
    public static final int popupWindowStyle = 2130903322;
    
    public static final int preserveIconSpacing = 2130903323;
    
    public static final int progressBarPadding = 2130903324;
    
    public static final int progressBarStyle = 2130903325;
    
    public static final int queryBackground = 2130903326;
    
    public static final int queryHint = 2130903327;
    
    public static final int queryPatterns = 2130903328;
    
    public static final int radioButtonStyle = 2130903329;
    
    public static final int ratingBarStyle = 2130903330;
    
    public static final int ratingBarStyleIndicator = 2130903331;
    
    public static final int ratingBarStyleSmall = 2130903332;
    
    public static final int recyclerViewStyle = 2130903333;
    
    public static final int reverseLayout = 2130903334;
    
    public static final int scopeUris = 2130903335;
    
    public static final int searchHintIcon = 2130903336;
    
    public static final int searchIcon = 2130903337;
    
    public static final int searchViewStyle = 2130903338;
    
    public static final int seekBarStyle = 2130903339;
    
    public static final int selectableItemBackground = 2130903340;
    
    public static final int selectableItemBackgroundBorderless = 2130903341;
    
    public static final int shortcutMatchRequired = 2130903342;
    
    public static final int showAsAction = 2130903343;
    
    public static final int showDividers = 2130903344;
    
    public static final int showText = 2130903345;
    
    public static final int showTitle = 2130903346;
    
    public static final int singleChoiceItemLayout = 2130903347;
    
    public static final int spanCount = 2130903348;
    
    public static final int spinBars = 2130903349;
    
    public static final int spinnerDropDownItemStyle = 2130903350;
    
    public static final int spinnerStyle = 2130903351;
    
    public static final int splitTrack = 2130903352;
    
    public static final int srcCompat = 2130903353;
    
    public static final int stackFromEnd = 2130903354;
    
    public static final int state_above_anchor = 2130903355;
    
    public static final int statusBarBackground = 2130903356;
    
    public static final int subMenuArrow = 2130903357;
    
    public static final int submitBackground = 2130903358;
    
    public static final int subtitle = 2130903359;
    
    public static final int subtitleTextAppearance = 2130903360;
    
    public static final int subtitleTextColor = 2130903361;
    
    public static final int subtitleTextStyle = 2130903362;
    
    public static final int suggestionRowLayout = 2130903363;
    
    public static final int switchMinWidth = 2130903364;
    
    public static final int switchPadding = 2130903365;
    
    public static final int switchStyle = 2130903366;
    
    public static final int switchTextAppearance = 2130903367;
    
    public static final int textAllCaps = 2130903368;
    
    public static final int textAppearanceLargePopupMenu = 2130903369;
    
    public static final int textAppearanceListItem = 2130903370;
    
    public static final int textAppearanceListItemSecondary = 2130903371;
    
    public static final int textAppearanceListItemSmall = 2130903372;
    
    public static final int textAppearancePopupMenuHeader = 2130903373;
    
    public static final int textAppearanceSearchResultSubtitle = 2130903374;
    
    public static final int textAppearanceSearchResultTitle = 2130903375;
    
    public static final int textAppearanceSmallPopupMenu = 2130903376;
    
    public static final int textColorAlertDialogListItem = 2130903377;
    
    public static final int textColorSearchUrl = 2130903378;
    
    public static final int textLocale = 2130903379;
    
    public static final int theme = 2130903380;
    
    public static final int thickness = 2130903381;
    
    public static final int thumbTextPadding = 2130903382;
    
    public static final int thumbTint = 2130903383;
    
    public static final int thumbTintMode = 2130903384;
    
    public static final int tickMark = 2130903385;
    
    public static final int tickMarkTint = 2130903386;
    
    public static final int tickMarkTintMode = 2130903387;
    
    public static final int tint = 2130903388;
    
    public static final int tintMode = 2130903389;
    
    public static final int title = 2130903390;
    
    public static final int titleMargin = 2130903391;
    
    public static final int titleMarginBottom = 2130903392;
    
    public static final int titleMarginEnd = 2130903393;
    
    public static final int titleMarginStart = 2130903394;
    
    public static final int titleMarginTop = 2130903395;
    
    public static final int titleMargins = 2130903396;
    
    public static final int titleTextAppearance = 2130903397;
    
    public static final int titleTextColor = 2130903398;
    
    public static final int titleTextStyle = 2130903399;
    
    public static final int toolbarNavigationButtonStyle = 2130903400;
    
    public static final int toolbarStyle = 2130903401;
    
    public static final int tooltipForegroundColor = 2130903402;
    
    public static final int tooltipFrameBackground = 2130903403;
    
    public static final int tooltipText = 2130903404;
    
    public static final int track = 2130903405;
    
    public static final int trackTint = 2130903406;
    
    public static final int trackTintMode = 2130903407;
    
    public static final int ttcIndex = 2130903408;
    
    public static final int viewInflaterClass = 2130903409;
    
    public static final int voiceIcon = 2130903410;
    
    public static final int windowActionBar = 2130903411;
    
    public static final int windowActionBarOverlay = 2130903412;
    
    public static final int windowActionModeOverlay = 2130903413;
    
    public static final int windowFixedHeightMajor = 2130903414;
    
    public static final int windowFixedHeightMinor = 2130903415;
    
    public static final int windowFixedWidthMajor = 2130903416;
    
    public static final int windowFixedWidthMinor = 2130903417;
    
    public static final int windowMinWidthMajor = 2130903418;
    
    public static final int windowMinWidthMinor = 2130903419;
    
    public static final int windowNoTitle = 2130903420;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2130968576;
    
    public static final int abc_allow_stacked_button_bar = 2130968577;
    
    public static final int abc_config_actionMenuItemAllCaps = 2130968578;
    
    public static final int enable_system_alarm_service_default = 2130968579;
    
    public static final int enable_system_foreground_service_default = 2130968580;
    
    public static final int enable_system_job_service_default = 2130968581;
    
    public static final int workmanager_test_configuration = 2130968582;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131034117;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131034118;
    
    public static final int abc_btn_colored_borderless_text_material = 2131034119;
    
    public static final int abc_btn_colored_text_material = 2131034120;
    
    public static final int abc_color_highlight_material = 2131034121;
    
    public static final int abc_hint_foreground_material_dark = 2131034122;
    
    public static final int abc_hint_foreground_material_light = 2131034123;
    
    public static final int abc_input_method_navigation_guard = 2131034124;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131034125;
    
    public static final int abc_primary_text_disable_only_material_light = 2131034126;
    
    public static final int abc_primary_text_material_dark = 2131034127;
    
    public static final int abc_primary_text_material_light = 2131034128;
    
    public static final int abc_search_url_text = 2131034129;
    
    public static final int abc_search_url_text_normal = 2131034130;
    
    public static final int abc_search_url_text_pressed = 2131034131;
    
    public static final int abc_search_url_text_selected = 2131034132;
    
    public static final int abc_secondary_text_material_dark = 2131034133;
    
    public static final int abc_secondary_text_material_light = 2131034134;
    
    public static final int abc_tint_btn_checkable = 2131034135;
    
    public static final int abc_tint_default = 2131034136;
    
    public static final int abc_tint_edittext = 2131034137;
    
    public static final int abc_tint_seek_thumb = 2131034138;
    
    public static final int abc_tint_spinner = 2131034139;
    
    public static final int abc_tint_switch_track = 2131034140;
    
    public static final int accent_material_dark = 2131034141;
    
    public static final int accent_material_light = 2131034142;
    
    public static final int al_exo_black_opacity_60 = 2131034143;
    
    public static final int al_exo_black_opacity_70 = 2131034144;
    
    public static final int al_exo_bottom_bar_background = 2131034145;
    
    public static final int al_exo_edit_mode_background_color = 2131034146;
    
    public static final int al_exo_error_message_background_color = 2131034147;
    
    public static final int al_exo_styled_error_message_background = 2131034148;
    
    public static final int al_exo_white = 2131034149;
    
    public static final int al_exo_white_opacity_70 = 2131034150;
    
    public static final int androidx_core_ripple_material_light = 2131034151;
    
    public static final int androidx_core_secondary_text_default_material_light = 2131034152;
    
    public static final int applovin_sdk_adBadgeTextColor = 2131034153;
    
    public static final int applovin_sdk_adControlbutton_brightBlueColor = 2131034154;
    
    public static final int applovin_sdk_brand_color = 2131034155;
    
    public static final int applovin_sdk_brand_color_dark = 2131034156;
    
    public static final int applovin_sdk_checkmarkColor = 2131034157;
    
    public static final int applovin_sdk_ctaButtonColor = 2131034165;
    
    public static final int applovin_sdk_ctaButtonPressedColor = 2131034166;
    
    public static final int applovin_sdk_disclosureButtonColor = 2131034167;
    
    public static final int applovin_sdk_greenColor = 2131034168;
    
    public static final int applovin_sdk_highlightListItemColor = 2131034169;
    
    public static final int applovin_sdk_highlightTextColor = 2131034170;
    
    public static final int applovin_sdk_listViewBackground = 2131034171;
    
    public static final int applovin_sdk_listViewSectionTextColor = 2131034172;
    
    public static final int applovin_sdk_starColor = 2131034173;
    
    public static final int applovin_sdk_textColorPrimary = 2131034174;
    
    public static final int applovin_sdk_textColorPrimaryDark = 2131034175;
    
    public static final int applovin_sdk_textColorSecondaryDark = 2131034176;
    
    public static final int applovin_sdk_warningColor = 2131034177;
    
    public static final int applovin_sdk_xmarkColor = 2131034178;
    
    public static final int background_floating_material_dark = 2131034179;
    
    public static final int background_floating_material_light = 2131034180;
    
    public static final int background_material_dark = 2131034181;
    
    public static final int background_material_light = 2131034182;
    
    public static final int blank_background = 2131034183;
    
    public static final int bright_foreground_disabled_material_dark = 2131034184;
    
    public static final int bright_foreground_disabled_material_light = 2131034185;
    
    public static final int bright_foreground_inverse_material_dark = 2131034186;
    
    public static final int bright_foreground_inverse_material_light = 2131034187;
    
    public static final int bright_foreground_material_dark = 2131034188;
    
    public static final int bright_foreground_material_light = 2131034189;
    
    public static final int browser_actions_bg_grey = 2131034190;
    
    public static final int browser_actions_divider_color = 2131034191;
    
    public static final int browser_actions_text_color = 2131034192;
    
    public static final int browser_actions_title_color = 2131034193;
    
    public static final int button_material_dark = 2131034194;
    
    public static final int button_material_light = 2131034195;
    
    public static final int cardview_dark_background = 2131034196;
    
    public static final int cardview_light_background = 2131034197;
    
    public static final int cardview_shadow_end_color = 2131034198;
    
    public static final int cardview_shadow_start_color = 2131034199;
    
    public static final int common_google_signin_btn_text_dark = 2131034222;
    
    public static final int common_google_signin_btn_text_dark_default = 2131034223;
    
    public static final int common_google_signin_btn_text_dark_disabled = 2131034224;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131034225;
    
    public static final int common_google_signin_btn_text_dark_pressed = 2131034226;
    
    public static final int common_google_signin_btn_text_light = 2131034227;
    
    public static final int common_google_signin_btn_text_light_default = 2131034228;
    
    public static final int common_google_signin_btn_text_light_disabled = 2131034229;
    
    public static final int common_google_signin_btn_text_light_focused = 2131034230;
    
    public static final int common_google_signin_btn_text_light_pressed = 2131034231;
    
    public static final int common_google_signin_btn_tint = 2131034232;
    
    public static final int dim_foreground_disabled_material_dark = 2131034233;
    
    public static final int dim_foreground_disabled_material_light = 2131034234;
    
    public static final int dim_foreground_material_dark = 2131034235;
    
    public static final int dim_foreground_material_light = 2131034236;
    
    public static final int error_color_material_dark = 2131034237;
    
    public static final int error_color_material_light = 2131034238;
    
    public static final int foreground_material_dark = 2131034239;
    
    public static final int foreground_material_light = 2131034240;
    
    public static final int highlighted_text_material_dark = 2131034244;
    
    public static final int highlighted_text_material_light = 2131034245;
    
    public static final int ia_endcard_background = 2131034246;
    
    public static final int ia_endcard_gray = 2131034247;
    
    public static final int ia_fullscreen_background = 2131034248;
    
    public static final int ia_mraid_expanded_dimmed_bk = 2131034249;
    
    public static final int ia_overlay_bg_color = 2131034250;
    
    public static final int ia_overlay_stroke_color = 2131034251;
    
    public static final int ia_video_background_color = 2131034252;
    
    public static final int ia_video_overlay_stroke = 2131034253;
    
    public static final int ia_video_overlay_text = 2131034254;
    
    public static final int ia_video_overlay_text_background = 2131034255;
    
    public static final int ia_video_overlay_text_background_pressed = 2131034256;
    
    public static final int ia_video_overlay_text_shadow = 2131034257;
    
    public static final int ia_video_progressbar = 2131034258;
    
    public static final int ia_video_progressbar_background = 2131034259;
    
    public static final int ia_video_progressbar_green = 2131034260;
    
    public static final int ia_video_transparent_overlay = 2131034261;
    
    public static final int material_blue_grey_800 = 2131034262;
    
    public static final int material_blue_grey_900 = 2131034263;
    
    public static final int material_blue_grey_950 = 2131034264;
    
    public static final int material_deep_teal_200 = 2131034265;
    
    public static final int material_deep_teal_500 = 2131034266;
    
    public static final int material_grey_100 = 2131034267;
    
    public static final int material_grey_300 = 2131034268;
    
    public static final int material_grey_50 = 2131034269;
    
    public static final int material_grey_600 = 2131034270;
    
    public static final int material_grey_800 = 2131034271;
    
    public static final int material_grey_850 = 2131034272;
    
    public static final int material_grey_900 = 2131034273;
    
    public static final int mbridge_black = 2131034274;
    
    public static final int mbridge_black_66 = 2131034275;
    
    public static final int mbridge_black_alpha_50 = 2131034276;
    
    public static final int mbridge_cm_feedback_dialog_chice_bg_pressed = 2131034277;
    
    public static final int mbridge_cm_feedback_rb_text_color_color_list = 2131034278;
    
    public static final int mbridge_color_999999 = 2131034279;
    
    public static final int mbridge_color_cc000000 = 2131034280;
    
    public static final int mbridge_common_white = 2131034281;
    
    public static final int mbridge_cpb_blue = 2131034282;
    
    public static final int mbridge_cpb_blue_dark = 2131034283;
    
    public static final int mbridge_cpb_green = 2131034284;
    
    public static final int mbridge_cpb_green_dark = 2131034285;
    
    public static final int mbridge_cpb_grey = 2131034286;
    
    public static final int mbridge_cpb_red = 2131034287;
    
    public static final int mbridge_cpb_red_dark = 2131034288;
    
    public static final int mbridge_cpb_white = 2131034289;
    
    public static final int mbridge_dd_grey = 2131034290;
    
    public static final int mbridge_ee_grey = 2131034291;
    
    public static final int mbridge_interstitial_black = 2131034292;
    
    public static final int mbridge_interstitial_white = 2131034293;
    
    public static final int mbridge_more_offer_list_bg = 2131034294;
    
    public static final int mbridge_purple_200 = 2131034301;
    
    public static final int mbridge_purple_500 = 2131034302;
    
    public static final int mbridge_purple_700 = 2131034303;
    
    public static final int mbridge_reward_black = 2131034304;
    
    public static final int mbridge_reward_cta_bg = 2131034305;
    
    public static final int mbridge_reward_desc_textcolor = 2131034306;
    
    public static final int mbridge_reward_endcard_hor_bg = 2131034307;
    
    public static final int mbridge_reward_endcard_land_bg = 2131034308;
    
    public static final int mbridge_reward_endcard_line_bg = 2131034309;
    
    public static final int mbridge_reward_endcard_vast_bg = 2131034310;
    
    public static final int mbridge_reward_kiloo_background = 2131034311;
    
    public static final int mbridge_reward_layer_text_bg = 2131034312;
    
    public static final int mbridge_reward_minicard_bg = 2131034313;
    
    public static final int mbridge_reward_six_black_transparent = 2131034314;
    
    public static final int mbridge_reward_six_black_transparent1 = 2131034315;
    
    public static final int mbridge_reward_six_black_transparent2 = 2131034316;
    
    public static final int mbridge_reward_title_textcolor = 2131034317;
    
    public static final int mbridge_reward_white = 2131034318;
    
    public static final int mbridge_teal_200 = 2131034319;
    
    public static final int mbridge_teal_700 = 2131034320;
    
    public static final int mbridge_video_common_alertview_bg = 2131034321;
    
    public static final int mbridge_video_common_alertview_cancel_button_bg_default = 2131034322;
    
    public static final int mbridge_video_common_alertview_cancel_button_bg_pressed = 2131034323;
    
    public static final int mbridge_video_common_alertview_cancel_button_textcolor = 2131034324;
    
    public static final int mbridge_video_common_alertview_confirm_button_bg_default = 2131034325;
    
    public static final int mbridge_video_common_alertview_confirm_button_bg_pressed = 2131034326;
    
    public static final int mbridge_video_common_alertview_confirm_button_textcolor = 2131034327;
    
    public static final int mbridge_video_common_alertview_content_textcolor = 2131034328;
    
    public static final int mbridge_video_common_alertview_feedback_rb_bg = 2131034329;
    
    public static final int mbridge_video_common_alertview_title_textcolor = 2131034330;
    
    public static final int mbridge_white = 2131034331;
    
    public static final int notification_action_color_filter = 2131034332;
    
    public static final int notification_icon_bg_color = 2131034333;
    
    public static final int notification_material_background_media_default_color = 2131034334;
    
    public static final int primary_dark_material_dark = 2131034335;
    
    public static final int primary_dark_material_light = 2131034336;
    
    public static final int primary_material_dark = 2131034337;
    
    public static final int primary_material_light = 2131034338;
    
    public static final int primary_text_default_material_dark = 2131034339;
    
    public static final int primary_text_default_material_light = 2131034340;
    
    public static final int primary_text_disabled_material_dark = 2131034341;
    
    public static final int primary_text_disabled_material_light = 2131034342;
    
    public static final int ripple_material_dark = 2131034343;
    
    public static final int ripple_material_light = 2131034344;
    
    public static final int secondary_text_default_material_dark = 2131034345;
    
    public static final int secondary_text_default_material_light = 2131034346;
    
    public static final int secondary_text_disabled_material_dark = 2131034347;
    
    public static final int secondary_text_disabled_material_light = 2131034348;
    
    public static final int switch_thumb_disabled_material_dark = 2131034349;
    
    public static final int switch_thumb_disabled_material_light = 2131034350;
    
    public static final int switch_thumb_material_dark = 2131034351;
    
    public static final int switch_thumb_material_light = 2131034352;
    
    public static final int switch_thumb_normal_material_dark = 2131034353;
    
    public static final int switch_thumb_normal_material_light = 2131034354;
    
    public static final int tooltip_background_dark = 2131034355;
    
    public static final int tooltip_background_light = 2131034356;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131099648;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131099649;
    
    public static final int abc_action_bar_default_height_material = 2131099650;
    
    public static final int abc_action_bar_default_padding_end_material = 2131099651;
    
    public static final int abc_action_bar_default_padding_start_material = 2131099652;
    
    public static final int abc_action_bar_elevation_material = 2131099653;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131099655;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131099656;
    
    public static final int abc_action_bar_stacked_max_height = 2131099657;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131099658;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;
    
    public static final int abc_action_button_min_height_material = 2131099661;
    
    public static final int abc_action_button_min_width_material = 2131099662;
    
    public static final int abc_action_button_min_width_overflow_material = 2131099663;
    
    public static final int abc_alert_dialog_button_bar_height = 2131099664;
    
    public static final int abc_alert_dialog_button_dimen = 2131099665;
    
    public static final int abc_button_inset_horizontal_material = 2131099666;
    
    public static final int abc_button_inset_vertical_material = 2131099667;
    
    public static final int abc_button_padding_horizontal_material = 2131099668;
    
    public static final int abc_button_padding_vertical_material = 2131099669;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131099670;
    
    public static final int abc_config_prefDialogWidth = 2131099671;
    
    public static final int abc_control_corner_material = 2131099672;
    
    public static final int abc_control_inset_material = 2131099673;
    
    public static final int abc_control_padding_material = 2131099674;
    
    public static final int abc_dialog_corner_radius_material = 2131099675;
    
    public static final int abc_dialog_fixed_height_major = 2131099676;
    
    public static final int abc_dialog_fixed_height_minor = 2131099677;
    
    public static final int abc_dialog_fixed_width_major = 2131099678;
    
    public static final int abc_dialog_fixed_width_minor = 2131099679;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131099681;
    
    public static final int abc_dialog_min_width_major = 2131099682;
    
    public static final int abc_dialog_min_width_minor = 2131099683;
    
    public static final int abc_dialog_padding_material = 2131099684;
    
    public static final int abc_dialog_padding_top_material = 2131099685;
    
    public static final int abc_dialog_title_divider_material = 2131099686;
    
    public static final int abc_disabled_alpha_material_dark = 2131099687;
    
    public static final int abc_disabled_alpha_material_light = 2131099688;
    
    public static final int abc_dropdownitem_icon_width = 2131099689;
    
    public static final int abc_dropdownitem_text_padding_left = 2131099690;
    
    public static final int abc_dropdownitem_text_padding_right = 2131099691;
    
    public static final int abc_edit_text_inset_bottom_material = 2131099692;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131099693;
    
    public static final int abc_edit_text_inset_top_material = 2131099694;
    
    public static final int abc_floating_window_z = 2131099695;
    
    public static final int abc_list_item_height_large_material = 2131099696;
    
    public static final int abc_list_item_height_material = 2131099697;
    
    public static final int abc_list_item_height_small_material = 2131099698;
    
    public static final int abc_list_item_padding_horizontal_material = 2131099699;
    
    public static final int abc_panel_menu_list_width = 2131099700;
    
    public static final int abc_progress_bar_height_material = 2131099701;
    
    public static final int abc_search_view_preferred_height = 2131099702;
    
    public static final int abc_search_view_preferred_width = 2131099703;
    
    public static final int abc_seekbar_track_background_height_material = 2131099704;
    
    public static final int abc_seekbar_track_progress_height_material = 2131099705;
    
    public static final int abc_select_dialog_padding_start_material = 2131099706;
    
    public static final int abc_switch_padding = 2131099707;
    
    public static final int abc_text_size_body_1_material = 2131099708;
    
    public static final int abc_text_size_body_2_material = 2131099709;
    
    public static final int abc_text_size_button_material = 2131099710;
    
    public static final int abc_text_size_caption_material = 2131099711;
    
    public static final int abc_text_size_display_1_material = 2131099712;
    
    public static final int abc_text_size_display_2_material = 2131099713;
    
    public static final int abc_text_size_display_3_material = 2131099714;
    
    public static final int abc_text_size_display_4_material = 2131099715;
    
    public static final int abc_text_size_headline_material = 2131099716;
    
    public static final int abc_text_size_large_material = 2131099717;
    
    public static final int abc_text_size_medium_material = 2131099718;
    
    public static final int abc_text_size_menu_header_material = 2131099719;
    
    public static final int abc_text_size_menu_material = 2131099720;
    
    public static final int abc_text_size_small_material = 2131099721;
    
    public static final int abc_text_size_subhead_material = 2131099722;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131099723;
    
    public static final int abc_text_size_title_material = 2131099724;
    
    public static final int abc_text_size_title_material_toolbar = 2131099725;
    
    public static final int al_exo_error_message_height = 2131099726;
    
    public static final int al_exo_error_message_margin_bottom = 2131099727;
    
    public static final int al_exo_error_message_text_padding_horizontal = 2131099728;
    
    public static final int al_exo_error_message_text_padding_vertical = 2131099729;
    
    public static final int al_exo_error_message_text_size = 2131099730;
    
    public static final int al_exo_icon_horizontal_margin = 2131099731;
    
    public static final int al_exo_icon_padding = 2131099732;
    
    public static final int al_exo_icon_padding_bottom = 2131099733;
    
    public static final int al_exo_icon_size = 2131099734;
    
    public static final int al_exo_icon_text_size = 2131099735;
    
    public static final int al_exo_media_button_height = 2131099736;
    
    public static final int al_exo_media_button_width = 2131099737;
    
    public static final int al_exo_setting_width = 2131099738;
    
    public static final int al_exo_settings_height = 2131099739;
    
    public static final int al_exo_settings_icon_size = 2131099740;
    
    public static final int al_exo_settings_main_text_size = 2131099741;
    
    public static final int al_exo_settings_offset = 2131099742;
    
    public static final int al_exo_settings_sub_text_size = 2131099743;
    
    public static final int al_exo_settings_text_height = 2131099744;
    
    public static final int al_exo_small_icon_height = 2131099745;
    
    public static final int al_exo_small_icon_horizontal_margin = 2131099746;
    
    public static final int al_exo_small_icon_padding_horizontal = 2131099747;
    
    public static final int al_exo_small_icon_padding_vertical = 2131099748;
    
    public static final int al_exo_small_icon_width = 2131099749;
    
    public static final int al_exo_styled_bottom_bar_height = 2131099750;
    
    public static final int al_exo_styled_bottom_bar_margin_top = 2131099751;
    
    public static final int al_exo_styled_bottom_bar_time_padding = 2131099752;
    
    public static final int al_exo_styled_controls_padding = 2131099753;
    
    public static final int al_exo_styled_minimal_controls_margin_bottom = 2131099754;
    
    public static final int al_exo_styled_progress_bar_height = 2131099755;
    
    public static final int al_exo_styled_progress_dragged_thumb_size = 2131099756;
    
    public static final int al_exo_styled_progress_enabled_thumb_size = 2131099757;
    
    public static final int al_exo_styled_progress_layout_height = 2131099758;
    
    public static final int al_exo_styled_progress_margin_bottom = 2131099759;
    
    public static final int al_exo_styled_progress_touch_target_height = 2131099760;
    
    public static final int applovin_sdk_actionBarHeight = 2131099761;
    
    public static final int applovin_sdk_adControlButton_height = 2131099762;
    
    public static final int applovin_sdk_adControlButton_width = 2131099763;
    
    public static final int applovin_sdk_mediationDebuggerDetailListItemTextSize = 2131099767;
    
    public static final int applovin_sdk_mediationDebuggerSectionHeight = 2131099768;
    
    public static final int applovin_sdk_mediationDebuggerSectionTextSize = 2131099769;
    
    public static final int applovin_sdk_mrec_height = 2131099770;
    
    public static final int applovin_sdk_mrec_width = 2131099771;
    
    public static final int browser_actions_context_menu_max_width = 2131099772;
    
    public static final int browser_actions_context_menu_min_padding = 2131099773;
    
    public static final int cardview_compat_inset_shadow = 2131099774;
    
    public static final int cardview_default_elevation = 2131099775;
    
    public static final int cardview_default_radius = 2131099776;
    
    public static final int compat_button_inset_horizontal_material = 2131099793;
    
    public static final int compat_button_inset_vertical_material = 2131099794;
    
    public static final int compat_button_padding_horizontal_material = 2131099795;
    
    public static final int compat_button_padding_vertical_material = 2131099796;
    
    public static final int compat_control_corner_material = 2131099797;
    
    public static final int compat_notification_large_icon_max_height = 2131099798;
    
    public static final int compat_notification_large_icon_max_width = 2131099799;
    
    public static final int default_margin = 2131099800;
    
    public static final int disabled_alpha_material_dark = 2131099801;
    
    public static final int disabled_alpha_material_light = 2131099802;
    
    public static final int fastscroll_default_thickness = 2131099803;
    
    public static final int fastscroll_margin = 2131099804;
    
    public static final int fastscroll_minimum_range = 2131099805;
    
    public static final int highlight_alpha_material_colored = 2131099806;
    
    public static final int highlight_alpha_material_dark = 2131099807;
    
    public static final int highlight_alpha_material_light = 2131099808;
    
    public static final int hint_alpha_material_dark = 2131099809;
    
    public static final int hint_alpha_material_light = 2131099810;
    
    public static final int hint_pressed_alpha_material_dark = 2131099811;
    
    public static final int hint_pressed_alpha_material_light = 2131099812;
    
    public static final int ia_bg_corner_radius = 2131099813;
    
    public static final int ia_button_padding_lateral = 2131099814;
    
    public static final int ia_endcard_button_margin_bottom = 2131099815;
    
    public static final int ia_endcard_button_padding_vertical = 2131099816;
    
    public static final int ia_endcard_overlay_button_height_large = 2131099818;
    
    public static final int ia_endcard_overlay_button_height_medium = 2131099819;
    
    public static final int ia_endcard_overlay_button_width_large = 2131099820;
    
    public static final int ia_endcard_overlay_button_width_medium = 2131099821;
    
    public static final int ia_image_control_padding = 2131099824;
    
    public static final int ia_image_control_size = 2131099825;
    
    public static final int ia_inner_drawable_padding = 2131099826;
    
    public static final int ia_overlay_control_margin = 2131099827;
    
    public static final int ia_overlay_stroke_width = 2131099828;
    
    public static final int ia_play_button_size = 2131099829;
    
    public static final int ia_progress_bar_height = 2131099830;
    
    public static final int ia_round_control_padding = 2131099831;
    
    public static final int ia_round_control_size = 2131099832;
    
    public static final int ia_round_overlay_radius = 2131099834;
    
    public static final int ia_video_control_margin = 2131099835;
    
    public static final int ia_video_overlay_button_width = 2131099836;
    
    public static final int ia_video_overlay_text_large = 2131099842;
    
    public static final int ia_video_overlay_text_large_plus = 2131099844;
    
    public static final int ia_video_overlay_text_small = 2131099845;
    
    public static final int ia_video_text_padding = 2131099846;
    
    public static final int item_touch_helper_max_drag_scroll_per_frame = 2131099855;
    
    public static final int item_touch_helper_swipe_escape_max_velocity = 2131099856;
    
    public static final int item_touch_helper_swipe_escape_velocity = 2131099857;
    
    public static final int mbridge_video_common_alertview_bg_padding = 2131099858;
    
    public static final int mbridge_video_common_alertview_button_height = 2131099859;
    
    public static final int mbridge_video_common_alertview_button_margintop = 2131099860;
    
    public static final int mbridge_video_common_alertview_button_radius = 2131099861;
    
    public static final int mbridge_video_common_alertview_button_textsize = 2131099862;
    
    public static final int mbridge_video_common_alertview_button_width = 2131099863;
    
    public static final int mbridge_video_common_alertview_content_margintop = 2131099864;
    
    public static final int mbridge_video_common_alertview_content_size = 2131099865;
    
    public static final int mbridge_video_common_alertview_contentview_maxwidth = 2131099866;
    
    public static final int mbridge_video_common_alertview_contentview_minwidth = 2131099867;
    
    public static final int mbridge_video_common_alertview_title_size = 2131099868;
    
    public static final int notification_action_icon_size = 2131099869;
    
    public static final int notification_action_text_size = 2131099870;
    
    public static final int notification_big_circle_margin = 2131099871;
    
    public static final int notification_content_margin_start = 2131099872;
    
    public static final int notification_large_icon_height = 2131099873;
    
    public static final int notification_large_icon_width = 2131099874;
    
    public static final int notification_main_column_padding_top = 2131099875;
    
    public static final int notification_media_narrow_margin = 2131099876;
    
    public static final int notification_right_icon_size = 2131099877;
    
    public static final int notification_right_side_padding_top = 2131099878;
    
    public static final int notification_small_icon_background_padding = 2131099879;
    
    public static final int notification_small_icon_size_as_large = 2131099880;
    
    public static final int notification_subtext_size = 2131099881;
    
    public static final int notification_top_pad = 2131099882;
    
    public static final int notification_top_pad_large_text = 2131099883;
    
    public static final int subtitle_corner_radius = 2131099884;
    
    public static final int subtitle_outline_width = 2131099885;
    
    public static final int subtitle_shadow_offset = 2131099886;
    
    public static final int subtitle_shadow_radius = 2131099887;
    
    public static final int text_margin = 2131099888;
    
    public static final int tooltip_corner_radius = 2131099889;
    
    public static final int tooltip_horizontal_padding = 2131099890;
    
    public static final int tooltip_margin = 2131099891;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131099892;
    
    public static final int tooltip_precise_anchor_threshold = 2131099893;
    
    public static final int tooltip_vertical_padding = 2131099894;
    
    public static final int tooltip_y_offset_non_touch = 2131099895;
    
    public static final int tooltip_y_offset_touch = 2131099896;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131165194;
    
    public static final int abc_action_bar_item_background_material = 2131165195;
    
    public static final int abc_btn_borderless_material = 2131165196;
    
    public static final int abc_btn_check_material = 2131165197;
    
    public static final int abc_btn_check_material_anim = 2131165198;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131165199;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131165200;
    
    public static final int abc_btn_colored_material = 2131165201;
    
    public static final int abc_btn_default_mtrl_shape = 2131165202;
    
    public static final int abc_btn_radio_material = 2131165203;
    
    public static final int abc_btn_radio_material_anim = 2131165204;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131165205;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131165206;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165207;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165208;
    
    public static final int abc_cab_background_internal_bg = 2131165209;
    
    public static final int abc_cab_background_top_material = 2131165210;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131165211;
    
    public static final int abc_control_background_material = 2131165212;
    
    public static final int abc_dialog_material_background = 2131165213;
    
    public static final int abc_edit_text_material = 2131165214;
    
    public static final int abc_ic_ab_back_material = 2131165215;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131165216;
    
    public static final int abc_ic_clear_material = 2131165217;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165218;
    
    public static final int abc_ic_go_search_api_material = 2131165219;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165220;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131165221;
    
    public static final int abc_ic_menu_overflow_material = 2131165222;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165223;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165224;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131165225;
    
    public static final int abc_ic_search_api_material = 2131165226;
    
    public static final int abc_ic_star_black_16dp = 2131165227;
    
    public static final int abc_ic_star_black_36dp = 2131165228;
    
    public static final int abc_ic_star_black_48dp = 2131165229;
    
    public static final int abc_ic_star_half_black_16dp = 2131165230;
    
    public static final int abc_ic_star_half_black_36dp = 2131165231;
    
    public static final int abc_ic_star_half_black_48dp = 2131165232;
    
    public static final int abc_ic_voice_search_api_material = 2131165233;
    
    public static final int abc_item_background_holo_dark = 2131165234;
    
    public static final int abc_item_background_holo_light = 2131165235;
    
    public static final int abc_list_divider_material = 2131165236;
    
    public static final int abc_list_divider_mtrl_alpha = 2131165237;
    
    public static final int abc_list_focused_holo = 2131165238;
    
    public static final int abc_list_longpressed_holo = 2131165239;
    
    public static final int abc_list_pressed_holo_dark = 2131165240;
    
    public static final int abc_list_pressed_holo_light = 2131165241;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131165242;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131165243;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131165244;
    
    public static final int abc_list_selector_disabled_holo_light = 2131165245;
    
    public static final int abc_list_selector_holo_dark = 2131165246;
    
    public static final int abc_list_selector_holo_light = 2131165247;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165248;
    
    public static final int abc_popup_background_mtrl_mult = 2131165249;
    
    public static final int abc_ratingbar_indicator_material = 2131165250;
    
    public static final int abc_ratingbar_material = 2131165251;
    
    public static final int abc_ratingbar_small_material = 2131165252;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131165253;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165254;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165255;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131165256;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131165257;
    
    public static final int abc_seekbar_thumb_material = 2131165258;
    
    public static final int abc_seekbar_tick_mark_material = 2131165259;
    
    public static final int abc_seekbar_track_material = 2131165260;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131165261;
    
    public static final int abc_spinner_textfield_background_material = 2131165262;
    
    public static final int abc_switch_thumb_material = 2131165263;
    
    public static final int abc_switch_track_mtrl_alpha = 2131165264;
    
    public static final int abc_tab_indicator_material = 2131165265;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131165266;
    
    public static final int abc_text_cursor_material = 2131165267;
    
    public static final int abc_text_select_handle_left_mtrl_dark = 2131165268;
    
    public static final int abc_text_select_handle_left_mtrl_light = 2131165269;
    
    public static final int abc_text_select_handle_middle_mtrl_dark = 2131165270;
    
    public static final int abc_text_select_handle_middle_mtrl_light = 2131165271;
    
    public static final int abc_text_select_handle_right_mtrl_dark = 2131165272;
    
    public static final int abc_text_select_handle_right_mtrl_light = 2131165273;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131165274;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131165275;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131165276;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131165277;
    
    public static final int abc_textfield_search_material = 2131165278;
    
    public static final int abc_vector_test = 2131165279;
    
    public static final int admob_close_button_black_circle_white_cross = 2131165280;
    
    public static final int admob_close_button_white_circle_black_cross = 2131165281;
    
    public static final int al_exo_controls_fastforward = 2131165282;
    
    public static final int al_exo_controls_fullscreen_enter = 2131165283;
    
    public static final int al_exo_controls_fullscreen_exit = 2131165284;
    
    public static final int al_exo_controls_next = 2131165285;
    
    public static final int al_exo_controls_pause = 2131165286;
    
    public static final int al_exo_controls_play = 2131165287;
    
    public static final int al_exo_controls_previous = 2131165288;
    
    public static final int al_exo_controls_repeat_all = 2131165289;
    
    public static final int al_exo_controls_repeat_off = 2131165290;
    
    public static final int al_exo_controls_repeat_one = 2131165291;
    
    public static final int al_exo_controls_rewind = 2131165292;
    
    public static final int al_exo_controls_shuffle_off = 2131165293;
    
    public static final int al_exo_controls_shuffle_on = 2131165294;
    
    public static final int al_exo_controls_vr = 2131165295;
    
    public static final int al_exo_notification_fastforward = 2131165296;
    
    public static final int al_exo_notification_next = 2131165297;
    
    public static final int al_exo_notification_pause = 2131165298;
    
    public static final int al_exo_notification_play = 2131165299;
    
    public static final int al_exo_notification_previous = 2131165300;
    
    public static final int al_exo_notification_rewind = 2131165301;
    
    public static final int al_exo_notification_small_icon = 2131165302;
    
    public static final int al_exo_notification_stop = 2131165303;
    
    public static final int al_exo_styled_controls_audiotrack = 2131165304;
    
    public static final int al_exo_styled_controls_check = 2131165305;
    
    public static final int al_exo_styled_controls_fastforward = 2131165306;
    
    public static final int al_exo_styled_controls_fullscreen_enter = 2131165307;
    
    public static final int al_exo_styled_controls_fullscreen_exit = 2131165308;
    
    public static final int al_exo_styled_controls_next = 2131165309;
    
    public static final int al_exo_styled_controls_overflow_hide = 2131165310;
    
    public static final int al_exo_styled_controls_overflow_show = 2131165311;
    
    public static final int al_exo_styled_controls_pause = 2131165312;
    
    public static final int al_exo_styled_controls_play = 2131165313;
    
    public static final int al_exo_styled_controls_previous = 2131165314;
    
    public static final int al_exo_styled_controls_repeat_all = 2131165315;
    
    public static final int al_exo_styled_controls_repeat_off = 2131165316;
    
    public static final int al_exo_styled_controls_repeat_one = 2131165317;
    
    public static final int al_exo_styled_controls_rewind = 2131165318;
    
    public static final int al_exo_styled_controls_settings = 2131165319;
    
    public static final int al_exo_styled_controls_shuffle_off = 2131165320;
    
    public static final int al_exo_styled_controls_shuffle_on = 2131165321;
    
    public static final int al_exo_styled_controls_speed = 2131165322;
    
    public static final int al_exo_styled_controls_subtitle_off = 2131165323;
    
    public static final int al_exo_styled_controls_subtitle_on = 2131165324;
    
    public static final int al_exo_styled_controls_vr = 2131165325;
    
    public static final int applovin_creative_debugger_report_ad_rounded_button = 2131165330;
    
    public static final int applovin_exo_edit_mode_logo = 2131165331;
    
    public static final int applovin_exo_ic_audiotrack = 2131165332;
    
    public static final int applovin_exo_ic_check = 2131165333;
    
    public static final int applovin_exo_ic_chevron_left = 2131165334;
    
    public static final int applovin_exo_ic_chevron_right = 2131165335;
    
    public static final int applovin_exo_ic_default_album_image = 2131165336;
    
    public static final int applovin_exo_ic_forward = 2131165337;
    
    public static final int applovin_exo_ic_fullscreen_enter = 2131165338;
    
    public static final int applovin_exo_ic_fullscreen_exit = 2131165339;
    
    public static final int applovin_exo_ic_pause_circle_filled = 2131165340;
    
    public static final int applovin_exo_ic_play_circle_filled = 2131165341;
    
    public static final int applovin_exo_ic_rewind = 2131165342;
    
    public static final int applovin_exo_ic_settings = 2131165343;
    
    public static final int applovin_exo_ic_skip_next = 2131165344;
    
    public static final int applovin_exo_ic_skip_previous = 2131165345;
    
    public static final int applovin_exo_ic_speed = 2131165346;
    
    public static final int applovin_exo_ic_subtitle_off = 2131165347;
    
    public static final int applovin_exo_ic_subtitle_on = 2131165348;
    
    public static final int applovin_exo_icon_circular_play = 2131165349;
    
    public static final int applovin_exo_icon_fastforward = 2131165350;
    
    public static final int applovin_exo_icon_fullscreen_enter = 2131165351;
    
    public static final int applovin_exo_icon_fullscreen_exit = 2131165352;
    
    public static final int applovin_exo_icon_next = 2131165353;
    
    public static final int applovin_exo_icon_pause = 2131165354;
    
    public static final int applovin_exo_icon_play = 2131165355;
    
    public static final int applovin_exo_icon_previous = 2131165356;
    
    public static final int applovin_exo_icon_repeat_all = 2131165357;
    
    public static final int applovin_exo_icon_repeat_off = 2131165358;
    
    public static final int applovin_exo_icon_repeat_one = 2131165359;
    
    public static final int applovin_exo_icon_rewind = 2131165360;
    
    public static final int applovin_exo_icon_shuffle_off = 2131165361;
    
    public static final int applovin_exo_icon_shuffle_on = 2131165362;
    
    public static final int applovin_exo_icon_stop = 2131165363;
    
    public static final int applovin_exo_icon_vr = 2131165364;
    
    public static final int applovin_exo_rounded_rectangle = 2131165365;
    
    public static final int applovin_ic_baseline_add_circle_outline = 2131165366;
    
    public static final int applovin_ic_check_mark_bordered = 2131165367;
    
    public static final int applovin_ic_check_mark_borderless = 2131165368;
    
    public static final int applovin_ic_disclosure_arrow = 2131165369;
    
    public static final int applovin_ic_mediation_adcolony = 2131165370;
    
    public static final int applovin_ic_mediation_admob = 2131165371;
    
    public static final int applovin_ic_mediation_amazon_marketplace = 2131165372;
    
    public static final int applovin_ic_mediation_applovin = 2131165373;
    
    public static final int applovin_ic_mediation_bidmachine = 2131165374;
    
    public static final int applovin_ic_mediation_chartboost = 2131165375;
    
    public static final int applovin_ic_mediation_criteo = 2131165376;
    
    public static final int applovin_ic_mediation_facebook = 2131165377;
    
    public static final int applovin_ic_mediation_fyber = 2131165378;
    
    public static final int applovin_ic_mediation_google_ad_manager = 2131165379;
    
    public static final int applovin_ic_mediation_hyprmx = 2131165380;
    
    public static final int applovin_ic_mediation_inmobi = 2131165381;
    
    public static final int applovin_ic_mediation_ironsource = 2131165382;
    
    public static final int applovin_ic_mediation_line = 2131165383;
    
    public static final int applovin_ic_mediation_maio = 2131165384;
    
    public static final int applovin_ic_mediation_mintegral = 2131165385;
    
    public static final int applovin_ic_mediation_mobilefuse = 2131165386;
    
    public static final int applovin_ic_mediation_mytarget = 2131165387;
    
    public static final int applovin_ic_mediation_nend = 2131165388;
    
    public static final int applovin_ic_mediation_ogury_presage = 2131165389;
    
    public static final int applovin_ic_mediation_pangle = 2131165390;
    
    public static final int applovin_ic_mediation_placeholder = 2131165391;
    
    public static final int applovin_ic_mediation_smaato = 2131165392;
    
    public static final int applovin_ic_mediation_tapjoy = 2131165393;
    
    public static final int applovin_ic_mediation_tiktok = 2131165394;
    
    public static final int applovin_ic_mediation_unity = 2131165395;
    
    public static final int applovin_ic_mediation_verve = 2131165396;
    
    public static final int applovin_ic_mediation_vungle = 2131165397;
    
    public static final int applovin_ic_mediation_yandex = 2131165398;
    
    public static final int applovin_ic_mute_to_unmute = 2131165399;
    
    public static final int applovin_ic_pause_icon = 2131165400;
    
    public static final int applovin_ic_play_icon = 2131165401;
    
    public static final int applovin_ic_privacy_icon = 2131165402;
    
    public static final int applovin_ic_privacy_icon_layered_list = 2131165403;
    
    public static final int applovin_ic_replay_icon = 2131165404;
    
    public static final int applovin_ic_unmute_to_mute = 2131165405;
    
    public static final int applovin_ic_warning = 2131165406;
    
    public static final int applovin_ic_warning_outline = 2131165407;
    
    public static final int applovin_ic_white_small = 2131165408;
    
    public static final int applovin_ic_x_mark = 2131165409;
    
    public static final int applovin_rounded_black_background = 2131165410;
    
    public static final int applovin_rounded_button = 2131165411;
    
    public static final int applovin_rounded_text_view_border = 2131165412;
    
    public static final int bg_circle_overlay = 2131165413;
    
    public static final int bg_green = 2131165414;
    
    public static final int bg_green_medium = 2131165415;
    
    public static final int bg_text_overlay = 2131165417;
    
    public static final int btn_checkbox_checked_mtrl = 2131165418;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131165419;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131165420;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131165421;
    
    public static final int btn_radio_off_mtrl = 2131165422;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131165423;
    
    public static final int btn_radio_on_mtrl = 2131165424;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131165425;
    
    public static final int common_full_open_on_phone = 2131165451;
    
    public static final int common_google_signin_btn_icon_dark = 2131165452;
    
    public static final int common_google_signin_btn_icon_dark_focused = 2131165453;
    
    public static final int common_google_signin_btn_icon_dark_normal = 2131165454;
    
    public static final int common_google_signin_btn_icon_dark_normal_background = 2131165455;
    
    public static final int common_google_signin_btn_icon_disabled = 2131165456;
    
    public static final int common_google_signin_btn_icon_light = 2131165457;
    
    public static final int common_google_signin_btn_icon_light_focused = 2131165458;
    
    public static final int common_google_signin_btn_icon_light_normal = 2131165459;
    
    public static final int common_google_signin_btn_icon_light_normal_background = 2131165460;
    
    public static final int common_google_signin_btn_text_dark = 2131165461;
    
    public static final int common_google_signin_btn_text_dark_focused = 2131165462;
    
    public static final int common_google_signin_btn_text_dark_normal = 2131165463;
    
    public static final int common_google_signin_btn_text_dark_normal_background = 2131165464;
    
    public static final int common_google_signin_btn_text_disabled = 2131165465;
    
    public static final int common_google_signin_btn_text_light = 2131165466;
    
    public static final int common_google_signin_btn_text_light_focused = 2131165467;
    
    public static final int common_google_signin_btn_text_light_normal = 2131165468;
    
    public static final int common_google_signin_btn_text_light_normal_background = 2131165469;
    
    public static final int googleg_disabled_color_18 = 2131165475;
    
    public static final int googleg_standard_color_18 = 2131165476;
    
    public static final int ia_close = 2131165478;
    
    public static final int ia_collapse = 2131165479;
    
    public static final int ia_expand = 2131165480;
    
    public static final int ia_ib_background = 2131165481;
    
    public static final int ia_ib_close = 2131165482;
    
    public static final int ia_ib_left_arrow = 2131165483;
    
    public static final int ia_ib_refresh = 2131165484;
    
    public static final int ia_ib_right_arrow = 2131165485;
    
    public static final int ia_ib_unleft_arrow = 2131165486;
    
    public static final int ia_ib_unright_arrow = 2131165487;
    
    public static final int ia_mute = 2131165488;
    
    public static final int ia_play = 2131165489;
    
    public static final int ia_progress_bar_drawable = 2131165490;
    
    public static final int ia_round_overlay_bg = 2131165491;
    
    public static final int ia_round_overlay_bg_with_close = 2131165493;
    
    public static final int ia_sel_expand_collapse = 2131165494;
    
    public static final int ia_sel_mute = 2131165495;
    
    public static final int ia_unmute = 2131165497;
    
    public static final int mbridge_banner_close = 2131165502;
    
    public static final int mbridge_bottom_media_control = 2131165503;
    
    public static final int mbridge_cm_alertview_bg = 2131165504;
    
    public static final int mbridge_cm_alertview_cancel_bg = 2131165505;
    
    public static final int mbridge_cm_alertview_cancel_bg_nor = 2131165506;
    
    public static final int mbridge_cm_alertview_cancel_bg_pressed = 2131165507;
    
    public static final int mbridge_cm_alertview_confirm_bg = 2131165508;
    
    public static final int mbridge_cm_alertview_confirm_bg_nor = 2131165509;
    
    public static final int mbridge_cm_alertview_confirm_bg_pressed = 2131165510;
    
    public static final int mbridge_cm_backward = 2131165511;
    
    public static final int mbridge_cm_backward_disabled = 2131165512;
    
    public static final int mbridge_cm_backward_nor = 2131165513;
    
    public static final int mbridge_cm_backward_selected = 2131165514;
    
    public static final int mbridge_cm_btn_shake = 2131165515;
    
    public static final int mbridge_cm_circle_50black = 2131165516;
    
    public static final int mbridge_cm_end_animation = 2131165517;
    
    public static final int mbridge_cm_exits = 2131165518;
    
    public static final int mbridge_cm_exits_nor = 2131165519;
    
    public static final int mbridge_cm_exits_selected = 2131165520;
    
    public static final int mbridge_cm_feedback_btn_bg = 2131165521;
    
    public static final int mbridge_cm_feedback_choice_btn_bg = 2131165522;
    
    public static final int mbridge_cm_feedback_choice_btn_bg_nor = 2131165523;
    
    public static final int mbridge_cm_feedback_choice_btn_bg_pressed = 2131165524;
    
    public static final int mbridge_cm_feedback_dialog_view_bg = 2131165525;
    
    public static final int mbridge_cm_feedback_dialog_view_btn_bg = 2131165526;
    
    public static final int mbridge_cm_forward = 2131165527;
    
    public static final int mbridge_cm_forward_disabled = 2131165528;
    
    public static final int mbridge_cm_forward_nor = 2131165529;
    
    public static final int mbridge_cm_forward_selected = 2131165530;
    
    public static final int mbridge_cm_head = 2131165531;
    
    public static final int mbridge_cm_highlight = 2131165532;
    
    public static final int mbridge_cm_progress = 2131165533;
    
    public static final int mbridge_cm_progress_drawable = 2131165534;
    
    public static final int mbridge_cm_progress_icon = 2131165535;
    
    public static final int mbridge_cm_refresh = 2131165536;
    
    public static final int mbridge_cm_refresh_nor = 2131165537;
    
    public static final int mbridge_cm_refresh_selected = 2131165538;
    
    public static final int mbridge_cm_tail = 2131165539;
    
    public static final int mbridge_download_message_dialog_star_sel = 2131165542;
    
    public static final int mbridge_download_message_dilaog_star_nor = 2131165543;
    
    public static final int mbridge_finger_media_control = 2131165544;
    
    public static final int mbridge_icon_click_circle = 2131165545;
    
    public static final int mbridge_icon_click_hand = 2131165546;
    
    public static final int mbridge_icon_play_bg = 2131165547;
    
    public static final int mbridge_interstitial_close = 2131165548;
    
    public static final int mbridge_interstitial_over = 2131165549;
    
    public static final int mbridge_order_layout_list_bg = 2131165575;
    
    public static final int mbridge_reward_activity_ad_end_land_des_rl_hot = 2131165576;
    
    public static final int mbridge_reward_close = 2131165577;
    
    public static final int mbridge_reward_close_ec = 2131165578;
    
    public static final int mbridge_reward_end_close_shape_oval = 2131165579;
    
    public static final int mbridge_reward_end_land_shape = 2131165580;
    
    public static final int mbridge_reward_end_pager_logo = 2131165581;
    
    public static final int mbridge_reward_end_shape_oval = 2131165582;
    
    public static final int mbridge_reward_flag_cn = 2131165583;
    
    public static final int mbridge_reward_flag_en = 2131165584;
    
    public static final int mbridge_reward_more_offer_default_bg = 2131165585;
    
    public static final int mbridge_reward_notice = 2131165586;
    
    public static final int mbridge_reward_popview_close = 2131165587;
    
    public static final int mbridge_reward_shape_choice = 2131165588;
    
    public static final int mbridge_reward_shape_choice_rl = 2131165589;
    
    public static final int mbridge_reward_shape_end_pager = 2131165590;
    
    public static final int mbridge_reward_shape_mf_selector = 2131165591;
    
    public static final int mbridge_reward_shape_mof_like_normal = 2131165592;
    
    public static final int mbridge_reward_shape_mof_like_pressed = 2131165593;
    
    public static final int mbridge_reward_shape_order = 2131165594;
    
    public static final int mbridge_reward_shape_order_history = 2131165595;
    
    public static final int mbridge_reward_shape_progress = 2131165596;
    
    public static final int mbridge_reward_shape_videoend_buttonbg = 2131165597;
    
    public static final int mbridge_reward_sound_close = 2131165598;
    
    public static final int mbridge_reward_sound_open = 2131165599;
    
    public static final int mbridge_reward_two_title_arabia_land = 2131165600;
    
    public static final int mbridge_reward_two_title_arabia_por = 2131165601;
    
    public static final int mbridge_reward_two_title_en_land = 2131165602;
    
    public static final int mbridge_reward_two_title_en_por = 2131165603;
    
    public static final int mbridge_reward_two_title_france_land = 2131165604;
    
    public static final int mbridge_reward_two_title_france_por = 2131165605;
    
    public static final int mbridge_reward_two_title_germany_land = 2131165606;
    
    public static final int mbridge_reward_two_title_germany_por = 2131165607;
    
    public static final int mbridge_reward_two_title_japan_land = 2131165608;
    
    public static final int mbridge_reward_two_title_japan_por = 2131165609;
    
    public static final int mbridge_reward_two_title_korea_land = 2131165610;
    
    public static final int mbridge_reward_two_title_korea_por = 2131165611;
    
    public static final int mbridge_reward_two_title_russian_land = 2131165612;
    
    public static final int mbridge_reward_two_title_russian_por = 2131165613;
    
    public static final int mbridge_reward_two_title_zh = 2131165614;
    
    public static final int mbridge_reward_two_title_zh_trad = 2131165615;
    
    public static final int mbridge_reward_user = 2131165616;
    
    public static final int mbridge_reward_vast_end_close = 2131165617;
    
    public static final int mbridge_reward_vast_end_ok = 2131165618;
    
    public static final int mbridge_reward_video_icon = 2131165619;
    
    public static final int mbridge_reward_video_progress_bg = 2131165620;
    
    public static final int mbridge_reward_video_progressbar_bg = 2131165621;
    
    public static final int mbridge_reward_video_time_count_num_bg = 2131165622;
    
    public static final int mbridge_shape_btn = 2131165623;
    
    public static final int mbridge_shape_line = 2131165624;
    
    public static final int mbridge_shape_splash_corners_14 = 2131165625;
    
    public static final int mbridge_slide_hand = 2131165626;
    
    public static final int mbridge_slide_rightarrow = 2131165627;
    
    public static final int mbridge_splash_adchoice = 2131165628;
    
    public static final int mbridge_splash_button_bg_gray = 2131165629;
    
    public static final int mbridge_splash_button_bg_gray_55 = 2131165630;
    
    public static final int mbridge_splash_button_bg_green = 2131165631;
    
    public static final int mbridge_splash_close_bg = 2131165632;
    
    public static final int mbridge_splash_notice = 2131165633;
    
    public static final int mbridge_video_common_full_star = 2131165634;
    
    public static final int mbridge_video_common_full_while_star = 2131165635;
    
    public static final int mbridge_video_common_half_star = 2131165636;
    
    public static final int notification_action_background = 2131165637;
    
    public static final int notification_bg = 2131165638;
    
    public static final int notification_bg_low = 2131165639;
    
    public static final int notification_bg_low_normal = 2131165640;
    
    public static final int notification_bg_low_pressed = 2131165641;
    
    public static final int notification_bg_normal = 2131165642;
    
    public static final int notification_bg_normal_pressed = 2131165643;
    
    public static final int notification_icon_background = 2131165644;
    
    public static final int notification_template_icon_bg = 2131165645;
    
    public static final int notification_template_icon_low_bg = 2131165646;
    
    public static final int notification_tile_bg = 2131165647;
    
    public static final int notify_panel_notification_icon_bg = 2131165648;
    
    public static final int tooltip_frame_dark = 2131165652;
    
    public static final int tooltip_frame_light = 2131165653;
  }
  
  public static final class font {
    public static final int roboto_medium_numbers = 2131230720;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131296262;
    
    public static final int accessibility_custom_action_0 = 2131296263;
    
    public static final int accessibility_custom_action_1 = 2131296264;
    
    public static final int accessibility_custom_action_10 = 2131296265;
    
    public static final int accessibility_custom_action_11 = 2131296266;
    
    public static final int accessibility_custom_action_12 = 2131296267;
    
    public static final int accessibility_custom_action_13 = 2131296268;
    
    public static final int accessibility_custom_action_14 = 2131296269;
    
    public static final int accessibility_custom_action_15 = 2131296270;
    
    public static final int accessibility_custom_action_16 = 2131296271;
    
    public static final int accessibility_custom_action_17 = 2131296272;
    
    public static final int accessibility_custom_action_18 = 2131296273;
    
    public static final int accessibility_custom_action_19 = 2131296274;
    
    public static final int accessibility_custom_action_2 = 2131296275;
    
    public static final int accessibility_custom_action_20 = 2131296276;
    
    public static final int accessibility_custom_action_21 = 2131296277;
    
    public static final int accessibility_custom_action_22 = 2131296278;
    
    public static final int accessibility_custom_action_23 = 2131296279;
    
    public static final int accessibility_custom_action_24 = 2131296280;
    
    public static final int accessibility_custom_action_25 = 2131296281;
    
    public static final int accessibility_custom_action_26 = 2131296282;
    
    public static final int accessibility_custom_action_27 = 2131296283;
    
    public static final int accessibility_custom_action_28 = 2131296284;
    
    public static final int accessibility_custom_action_29 = 2131296285;
    
    public static final int accessibility_custom_action_3 = 2131296286;
    
    public static final int accessibility_custom_action_30 = 2131296287;
    
    public static final int accessibility_custom_action_31 = 2131296288;
    
    public static final int accessibility_custom_action_4 = 2131296289;
    
    public static final int accessibility_custom_action_5 = 2131296290;
    
    public static final int accessibility_custom_action_6 = 2131296291;
    
    public static final int accessibility_custom_action_7 = 2131296292;
    
    public static final int accessibility_custom_action_8 = 2131296293;
    
    public static final int accessibility_custom_action_9 = 2131296294;
    
    public static final int action0 = 2131296295;
    
    public static final int action_bar = 2131296296;
    
    public static final int action_bar_activity_content = 2131296297;
    
    public static final int action_bar_container = 2131296298;
    
    public static final int action_bar_root = 2131296299;
    
    public static final int action_bar_spinner = 2131296300;
    
    public static final int action_bar_subtitle = 2131296301;
    
    public static final int action_bar_title = 2131296302;
    
    public static final int action_container = 2131296303;
    
    public static final int action_context_bar = 2131296304;
    
    public static final int action_divider = 2131296305;
    
    public static final int action_image = 2131296306;
    
    public static final int action_menu_divider = 2131296307;
    
    public static final int action_menu_presenter = 2131296308;
    
    public static final int action_mode_bar = 2131296309;
    
    public static final int action_mode_bar_stub = 2131296310;
    
    public static final int action_mode_close_button = 2131296311;
    
    public static final int action_share = 2131296312;
    
    public static final int action_text = 2131296313;
    
    public static final int actions = 2131296314;
    
    public static final int activity_chooser_view_content = 2131296315;
    
    public static final int ad_control_button = 2131296316;
    
    public static final int ad_controls_view = 2131296317;
    
    public static final int ad_presenter_view = 2131296318;
    
    public static final int ad_view_container = 2131296319;
    
    public static final int add = 2131296320;
    
    public static final int adjust_height = 2131296321;
    
    public static final int adjust_width = 2131296322;
    
    public static final int al_exo_ad_overlay = 2131296323;
    
    public static final int al_exo_artwork = 2131296324;
    
    public static final int al_exo_audio_track = 2131296325;
    
    public static final int al_exo_basic_controls = 2131296326;
    
    public static final int al_exo_bottom_bar = 2131296327;
    
    public static final int al_exo_buffering = 2131296328;
    
    public static final int al_exo_center_controls = 2131296329;
    
    public static final int al_exo_content_frame = 2131296330;
    
    public static final int al_exo_controller = 2131296331;
    
    public static final int al_exo_controller_placeholder = 2131296332;
    
    public static final int al_exo_controls_background = 2131296333;
    
    public static final int al_exo_duration = 2131296334;
    
    public static final int al_exo_error_message = 2131296335;
    
    public static final int al_exo_extra_controls = 2131296336;
    
    public static final int al_exo_extra_controls_scroll_view = 2131296337;
    
    public static final int al_exo_ffwd = 2131296338;
    
    public static final int al_exo_ffwd_with_amount = 2131296339;
    
    public static final int al_exo_fullscreen = 2131296340;
    
    public static final int al_exo_minimal_controls = 2131296341;
    
    public static final int al_exo_minimal_fullscreen = 2131296342;
    
    public static final int al_exo_next = 2131296343;
    
    public static final int al_exo_overflow_hide = 2131296344;
    
    public static final int al_exo_overflow_show = 2131296345;
    
    public static final int al_exo_overlay = 2131296346;
    
    public static final int al_exo_pause = 2131296347;
    
    public static final int al_exo_play = 2131296348;
    
    public static final int al_exo_play_pause = 2131296349;
    
    public static final int al_exo_playback_speed = 2131296350;
    
    public static final int al_exo_position = 2131296351;
    
    public static final int al_exo_prev = 2131296352;
    
    public static final int al_exo_progress = 2131296353;
    
    public static final int al_exo_progress_placeholder = 2131296354;
    
    public static final int al_exo_repeat_toggle = 2131296355;
    
    public static final int al_exo_rew = 2131296356;
    
    public static final int al_exo_rew_with_amount = 2131296357;
    
    public static final int al_exo_settings = 2131296358;
    
    public static final int al_exo_shuffle = 2131296359;
    
    public static final int al_exo_shutter = 2131296360;
    
    public static final int al_exo_subtitle = 2131296361;
    
    public static final int al_exo_subtitles = 2131296362;
    
    public static final int al_exo_time = 2131296363;
    
    public static final int al_exo_vr = 2131296364;
    
    public static final int alertTitle = 2131296365;
    
    public static final int always = 2131296367;
    
    public static final int app_open_ad_control_button = 2131296370;
    
    public static final int app_open_ad_control_view = 2131296371;
    
    public static final int applovin_native_ad_badge_and_title_text_view = 2131296372;
    
    public static final int applovin_native_ad_content_linear_layout = 2131296373;
    
    public static final int applovin_native_ad_view_container = 2131296374;
    
    public static final int applovin_native_advertiser_text_view = 2131296375;
    
    public static final int applovin_native_badge_text_view = 2131296376;
    
    public static final int applovin_native_body_text_view = 2131296377;
    
    public static final int applovin_native_cta_button = 2131296378;
    
    public static final int applovin_native_guideline = 2131296379;
    
    public static final int applovin_native_icon_and_text_layout = 2131296380;
    
    public static final int applovin_native_icon_image_view = 2131296381;
    
    public static final int applovin_native_icon_view = 2131296382;
    
    public static final int applovin_native_inner_linear_layout = 2131296383;
    
    public static final int applovin_native_inner_parent_layout = 2131296384;
    
    public static final int applovin_native_leader_icon_and_text_layout = 2131296385;
    
    public static final int applovin_native_media_content_view = 2131296386;
    
    public static final int applovin_native_options_view = 2131296387;
    
    public static final int applovin_native_star_rating_view = 2131296388;
    
    public static final int applovin_native_title_text_view = 2131296389;
    
    public static final int async = 2131296390;
    
    public static final int auto = 2131296391;
    
    public static final int banner_ad_view_container = 2131296394;
    
    public static final int banner_control_button = 2131296395;
    
    public static final int banner_control_view = 2131296396;
    
    public static final int banner_label = 2131296397;
    
    public static final int blocking = 2131296399;
    
    public static final int bottom = 2131296400;
    
    public static final int browser_actions_header_text = 2131296402;
    
    public static final int browser_actions_menu_item_icon = 2131296403;
    
    public static final int browser_actions_menu_item_text = 2131296404;
    
    public static final int browser_actions_menu_items = 2131296405;
    
    public static final int browser_actions_menu_view = 2131296406;
    
    public static final int button = 2131296407;
    
    public static final int buttonPanel = 2131296408;
    
    public static final int cancel_action = 2131296409;
    
    public static final int center = 2131296411;
    
    public static final int checkbox = 2131296414;
    
    public static final int checked = 2131296415;
    
    public static final int chronometer = 2131296416;
    
    public static final int content = 2131296443;
    
    public static final int contentPanel = 2131296444;
    
    public static final int custom = 2131296447;
    
    public static final int customPanel = 2131296448;
    
    public static final int dark = 2131296449;
    
    public static final int decor_content_parent = 2131296450;
    
    public static final int default_activity_button = 2131296451;
    
    public static final int detailImageView = 2131296452;
    
    public static final int dialog_button = 2131296453;
    
    public static final int edit_query = 2131296457;
    
    public static final int email_report_tv = 2131296458;
    
    public static final int end = 2131296459;
    
    public static final int end_padder = 2131296460;
    
    public static final int exo_check = 2131296461;
    
    public static final int exo_icon = 2131296462;
    
    public static final int exo_main_text = 2131296463;
    
    public static final int exo_settings_listview = 2131296464;
    
    public static final int exo_sub_text = 2131296465;
    
    public static final int exo_text = 2131296466;
    
    public static final int exo_track_selection_view = 2131296467;
    
    public static final int expand_activities_button = 2131296468;
    
    public static final int expanded_menu = 2131296469;
    
    public static final int fill = 2131296470;
    
    public static final int fit = 2131296473;
    
    public static final int fixed_height = 2131296474;
    
    public static final int fixed_width = 2131296475;
    
    public static final int forever = 2131296476;
    
    public static final int group_divider = 2131296479;
    
    public static final int home = 2131296481;
    
    public static final int ia_ad_content = 2131296483;
    
    public static final int ia_b_end_card_call_to_action = 2131296484;
    
    public static final int ia_buffering_overlay = 2131296485;
    
    public static final int ia_close_button_background_item = 2131296488;
    
    public static final int ia_default_endcard_video_overlay = 2131296490;
    
    public static final int ia_endcard_video_overlay = 2131296492;
    
    public static final int ia_iv_close_button = 2131296495;
    
    public static final int ia_iv_expand_collapse_button = 2131296496;
    
    public static final int ia_iv_last_frame = 2131296497;
    
    public static final int ia_iv_mute_button = 2131296498;
    
    public static final int ia_iv_play_button = 2131296500;
    
    public static final int ia_paused_video_overlay = 2131296502;
    
    public static final int ia_texture_view_host = 2131296503;
    
    public static final int ia_tv_call_to_action = 2131296505;
    
    public static final int ia_tv_close_button = 2131296506;
    
    public static final int ia_tv_remaining_time = 2131296507;
    
    public static final int ia_tv_skip = 2131296508;
    
    public static final int ia_video_progressbar = 2131296511;
    
    public static final int icon = 2131296513;
    
    public static final int icon_group = 2131296514;
    
    public static final int icon_only = 2131296515;
    
    public static final int image = 2131296517;
    
    public static final int imageView = 2131296518;
    
    public static final int image_view = 2131296519;
    
    public static final int info = 2131296520;
    
    public static final int inn_texture_view = 2131296522;
    
    public static final int inneractive_vast_endcard_gif = 2131296523;
    
    public static final int inneractive_vast_endcard_html = 2131296524;
    
    public static final int inneractive_vast_endcard_iframe = 2131296525;
    
    public static final int inneractive_vast_endcard_static = 2131296526;
    
    public static final int inneractive_webview_internal_browser = 2131296527;
    
    public static final int inneractive_webview_mraid = 2131296528;
    
    public static final int inneractive_webview_vast_endcard = 2131296530;
    
    public static final int inneractive_webview_vast_vpaid = 2131296531;
    
    public static final int interstitial_control_button = 2131296533;
    
    public static final int interstitial_control_view = 2131296534;
    
    public static final int italic = 2131296535;
    
    public static final int item = 2131296536;
    
    public static final int item_touch_helper_previous_elevation = 2131296537;
    
    public static final int layout = 2131296540;
    
    public static final int left = 2131296542;
    
    public static final int light = 2131296543;
    
    public static final int line1 = 2131296544;
    
    public static final int line3 = 2131296545;
    
    public static final int listMode = 2131296546;
    
    public static final int listView = 2131296547;
    
    public static final int list_item = 2131296548;
    
    public static final int mbridge_animation_click_view = 2131296553;
    
    public static final int mbridge_bottom_finger_bg = 2131296554;
    
    public static final int mbridge_bottom_icon_iv = 2131296555;
    
    public static final int mbridge_bottom_item_rl = 2131296556;
    
    public static final int mbridge_bottom_iv = 2131296557;
    
    public static final int mbridge_bottom_play_bg = 2131296558;
    
    public static final int mbridge_bottom_ration = 2131296559;
    
    public static final int mbridge_bottom_title_tv = 2131296560;
    
    public static final int mbridge_bt_container = 2131296561;
    
    public static final int mbridge_bt_container_root = 2131296562;
    
    public static final int mbridge_center_view = 2131296563;
    
    public static final int mbridge_choice_frl = 2131296564;
    
    public static final int mbridge_choice_one_countdown_tv = 2131296565;
    
    public static final int mbridge_cta_layout = 2131296566;
    
    public static final int mbridge_ec_layout_center = 2131296567;
    
    public static final int mbridge_ec_layout_top = 2131296568;
    
    public static final int mbridge_interstitial_iv_close = 2131296582;
    
    public static final int mbridge_interstitial_pb = 2131296583;
    
    public static final int mbridge_interstitial_wv = 2131296584;
    
    public static final int mbridge_iv_adbanner = 2131296585;
    
    public static final int mbridge_iv_adbanner_bg = 2131296586;
    
    public static final int mbridge_iv_appicon = 2131296587;
    
    public static final int mbridge_iv_close = 2131296588;
    
    public static final int mbridge_iv_flag = 2131296589;
    
    public static final int mbridge_iv_icon = 2131296590;
    
    public static final int mbridge_iv_iconbg = 2131296591;
    
    public static final int mbridge_iv_link = 2131296592;
    
    public static final int mbridge_iv_logo = 2131296593;
    
    public static final int mbridge_iv_vastclose = 2131296599;
    
    public static final int mbridge_iv_vastok = 2131296600;
    
    public static final int mbridge_layout_bottomLayout = 2131296601;
    
    public static final int mbridge_lv_desc_tv = 2131296604;
    
    public static final int mbridge_lv_icon_iv = 2131296605;
    
    public static final int mbridge_lv_item_rl = 2131296606;
    
    public static final int mbridge_lv_iv = 2131296607;
    
    public static final int mbridge_lv_iv_bg = 2131296608;
    
    public static final int mbridge_lv_iv_burl = 2131296609;
    
    public static final int mbridge_lv_iv_cover = 2131296610;
    
    public static final int mbridge_lv_sv_starlevel = 2131296611;
    
    public static final int mbridge_lv_title_tv = 2131296612;
    
    public static final int mbridge_lv_tv_install = 2131296613;
    
    public static final int mbridge_more_offer_ll_item = 2131296614;
    
    public static final int mbridge_moreoffer_hls = 2131296615;
    
    public static final int mbridge_native_ec_controller = 2131296617;
    
    public static final int mbridge_native_ec_layer_layout = 2131296618;
    
    public static final int mbridge_native_ec_layout = 2131296619;
    
    public static final int mbridge_native_endcard_feed_btn = 2131296620;
    
    public static final int mbridge_native_order_camp_controller = 2131296621;
    
    public static final int mbridge_native_order_camp_feed_btn = 2131296622;
    
    public static final int mbridge_order_view_h_lv = 2131296627;
    
    public static final int mbridge_order_view_iv_close = 2131296628;
    
    public static final int mbridge_order_view_lv = 2131296629;
    
    public static final int mbridge_order_viewed_tv = 2131296630;
    
    public static final int mbridge_playercommon_ll_loading = 2131296631;
    
    public static final int mbridge_playercommon_ll_sur_container = 2131296632;
    
    public static final int mbridge_playercommon_rl_root = 2131296633;
    
    public static final int mbridge_progressBar = 2131296635;
    
    public static final int mbridge_progressBar1 = 2131296636;
    
    public static final int mbridge_reward_bottom_widget = 2131296637;
    
    public static final int mbridge_reward_choice_one_like_iv = 2131296638;
    
    public static final int mbridge_reward_click_tv = 2131296639;
    
    public static final int mbridge_reward_cta_layout = 2131296640;
    
    public static final int mbridge_reward_desc_tv = 2131296641;
    
    public static final int mbridge_reward_end_card_item_iv = 2131296642;
    
    public static final int mbridge_reward_end_card_item_title_tv = 2131296643;
    
    public static final int mbridge_reward_end_card_like_tv = 2131296644;
    
    public static final int mbridge_reward_end_card_more_offer_rl = 2131296645;
    
    public static final int mbridge_reward_end_card_offer_title_rl = 2131296646;
    
    public static final int mbridge_reward_icon_riv = 2131296647;
    
    public static final int mbridge_reward_logo_iv = 2131296648;
    
    public static final int mbridge_reward_popview = 2131296649;
    
    public static final int mbridge_reward_root_container = 2131296650;
    
    public static final int mbridge_reward_segment_progressbar = 2131296651;
    
    public static final int mbridge_reward_stars_mllv = 2131296652;
    
    public static final int mbridge_reward_title_tv = 2131296653;
    
    public static final int mbridge_rl_content = 2131296654;
    
    public static final int mbridge_rl_playing_close = 2131296656;
    
    public static final int mbridge_sound_switch = 2131296657;
    
    public static final int mbridge_sv_starlevel = 2131296658;
    
    public static final int mbridge_tag_icon = 2131296659;
    
    public static final int mbridge_tag_title = 2131296660;
    
    public static final int mbridge_temp_container = 2131296661;
    
    public static final int mbridge_textView = 2131296662;
    
    public static final int mbridge_text_layout = 2131296663;
    
    public static final int mbridge_title_layout = 2131296665;
    
    public static final int mbridge_top_control = 2131296666;
    
    public static final int mbridge_top_finger_bg = 2131296667;
    
    public static final int mbridge_top_icon_iv = 2131296668;
    
    public static final int mbridge_top_item_rl = 2131296669;
    
    public static final int mbridge_top_iv = 2131296670;
    
    public static final int mbridge_top_play_bg = 2131296671;
    
    public static final int mbridge_top_ration = 2131296672;
    
    public static final int mbridge_top_title_tv = 2131296673;
    
    public static final int mbridge_tv_appdesc = 2131296674;
    
    public static final int mbridge_tv_apptitle = 2131296675;
    
    public static final int mbridge_tv_count = 2131296676;
    
    public static final int mbridge_tv_cta = 2131296677;
    
    public static final int mbridge_tv_desc = 2131296678;
    
    public static final int mbridge_tv_install = 2131296679;
    
    public static final int mbridge_tv_number = 2131296680;
    
    public static final int mbridge_tv_number_layout = 2131296681;
    
    public static final int mbridge_tv_reward_status = 2131296682;
    
    public static final int mbridge_tv_title = 2131296683;
    
    public static final int mbridge_tv_vasttag = 2131296684;
    
    public static final int mbridge_tv_vasttitle = 2131296685;
    
    public static final int mbridge_vec_btn = 2131296686;
    
    public static final int mbridge_vec_iv_close = 2131296687;
    
    public static final int mbridge_vec_iv_icon = 2131296688;
    
    public static final int mbridge_vec_tv_desc = 2131296689;
    
    public static final int mbridge_vec_tv_title = 2131296690;
    
    public static final int mbridge_vfpv = 2131296691;
    
    public static final int mbridge_vfpv_fl = 2131296692;
    
    public static final int mbridge_video_common_alertview_cancel_button = 2131296693;
    
    public static final int mbridge_video_common_alertview_confirm_button = 2131296694;
    
    public static final int mbridge_video_common_alertview_contentview = 2131296695;
    
    public static final int mbridge_video_common_alertview_contentview_scrollview = 2131296696;
    
    public static final int mbridge_video_common_alertview_titleview = 2131296698;
    
    public static final int mbridge_video_progress_bar = 2131296699;
    
    public static final int mbridge_video_templete_container = 2131296700;
    
    public static final int mbridge_video_templete_progressbar = 2131296701;
    
    public static final int mbridge_video_templete_videoview = 2131296702;
    
    public static final int mbridge_video_templete_webview_parent = 2131296703;
    
    public static final int mbridge_videoview_bg = 2131296704;
    
    public static final int mbridge_viewgroup_ctaroot = 2131296706;
    
    public static final int mbridge_windwv_close = 2131296707;
    
    public static final int mbridge_windwv_content_rl = 2131296708;
    
    public static final int media_actions = 2131296709;
    
    public static final int message = 2131296710;
    
    public static final int middle = 2131296712;
    
    public static final int mraid_video_view = 2131296713;
    
    public static final int mrec_ad_view_container = 2131296714;
    
    public static final int mrec_control_button = 2131296715;
    
    public static final int mrec_control_view = 2131296716;
    
    public static final int multiply = 2131296717;
    
    public static final int native_ad_view_container = 2131296718;
    
    public static final int native_control_button = 2131296719;
    
    public static final int native_control_view = 2131296720;
    
    public static final int never = 2131296721;
    
    public static final int none = 2131296723;
    
    public static final int normal = 2131296724;
    
    public static final int notification_background = 2131296725;
    
    public static final int notification_main_column = 2131296726;
    
    public static final int notification_main_column_container = 2131296727;
    
    public static final int off = 2131296728;
    
    public static final int on = 2131296729;
    
    public static final int parentPanel = 2131296733;
    
    public static final int privacy_icon_button = 2131296738;
    
    public static final int progress_bar = 2131296741;
    
    public static final int progress_circular = 2131296742;
    
    public static final int progress_horizontal = 2131296743;
    
    public static final int radio = 2131296744;
    
    public static final int report_ad_button = 2131296746;
    
    public static final int rewarded_control_button = 2131296747;
    
    public static final int rewarded_control_view = 2131296748;
    
    public static final int rewarded_interstitial_control_button = 2131296749;
    
    public static final int rewarded_interstitial_control_view = 2131296750;
    
    public static final int right = 2131296751;
    
    public static final int right_icon = 2131296752;
    
    public static final int right_side = 2131296753;
    
    public static final int screen = 2131296754;
    
    public static final int scrollIndicatorDown = 2131296755;
    
    public static final int scrollIndicatorUp = 2131296756;
    
    public static final int scrollView = 2131296757;
    
    public static final int search_badge = 2131296759;
    
    public static final int search_bar = 2131296760;
    
    public static final int search_button = 2131296761;
    
    public static final int search_close_btn = 2131296762;
    
    public static final int search_edit_frame = 2131296763;
    
    public static final int search_go_btn = 2131296764;
    
    public static final int search_mag_icon = 2131296765;
    
    public static final int search_plate = 2131296766;
    
    public static final int search_src_text = 2131296767;
    
    public static final int search_voice_btn = 2131296768;
    
    public static final int select_dialog_listview = 2131296769;
    
    public static final int shortcut = 2131296770;
    
    public static final int show_mrec_button = 2131296774;
    
    public static final int show_native_button = 2131296775;
    
    public static final int spacer = 2131296779;
    
    public static final int spherical_gl_surface_view = 2131296780;
    
    public static final int split_action_bar = 2131296781;
    
    public static final int src_atop = 2131296782;
    
    public static final int src_in = 2131296783;
    
    public static final int src_over = 2131296784;
    
    public static final int standard = 2131296785;
    
    public static final int start = 2131296786;
    
    public static final int status_bar_latest_event_content = 2131296787;
    
    public static final int status_textview = 2131296788;
    
    public static final int submenuarrow = 2131296789;
    
    public static final int submit_area = 2131296790;
    
    public static final int surface_view = 2131296791;
    
    public static final int tabMode = 2131296792;
    
    public static final int tag_accessibility_actions = 2131296793;
    
    public static final int tag_accessibility_clickable_spans = 2131296794;
    
    public static final int tag_accessibility_heading = 2131296795;
    
    public static final int tag_accessibility_pane_title = 2131296796;
    
    public static final int tag_on_apply_window_listener = 2131296797;
    
    public static final int tag_on_receive_content_listener = 2131296798;
    
    public static final int tag_on_receive_content_mime_types = 2131296799;
    
    public static final int tag_screen_reader_focusable = 2131296800;
    
    public static final int tag_state_description = 2131296801;
    
    public static final int tag_transition_group = 2131296802;
    
    public static final int tag_unhandled_key_event_manager = 2131296803;
    
    public static final int tag_unhandled_key_listeners = 2131296804;
    
    public static final int tag_window_insets_animation_callback = 2131296805;
    
    public static final int text = 2131296806;
    
    public static final int text2 = 2131296807;
    
    public static final int textSpacerNoButtons = 2131296808;
    
    public static final int textSpacerNoTitle = 2131296809;
    
    public static final int textView = 2131296810;
    
    public static final int texture_view = 2131296811;
    
    public static final int time = 2131296812;
    
    public static final int title = 2131296813;
    
    public static final int titleDividerNoCustom = 2131296814;
    
    public static final int title_template = 2131296815;
    
    public static final int top = 2131296817;
    
    public static final int topPanel = 2131296818;
    
    public static final int unchecked = 2131296819;
    
    public static final int uniform = 2131296821;
    
    public static final int up = 2131296824;
    
    public static final int video_decoder_gl_surface_view = 2131296826;
    
    public static final int view_tree_lifecycle_owner = 2131296827;
    
    public static final int when_playing = 2131296828;
    
    public static final int wide = 2131296829;
    
    public static final int wrap_content = 2131296831;
    
    public static final int zoom = 2131296833;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131361792;
    
    public static final int abc_config_activityShortDur = 2131361793;
    
    public static final int al_exo_media_button_opacity_percentage_disabled = 2131361794;
    
    public static final int al_exo_media_button_opacity_percentage_enabled = 2131361795;
    
    public static final int cancel_button_image_alpha = 2131361796;
    
    public static final int config_tooltipAnimTime = 2131361797;
    
    public static final int google_play_services_version = 2131361798;
    
    public static final int ia_ib_button_size_dp = 2131361799;
    
    public static final int ia_ib_toolbar_height_dp = 2131361800;
    
    public static final int status_bar_notification_info_maxnum = 2131361801;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131427328;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131427329;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131427330;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131427331;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131427332;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131427333;
    
    public static final int fast_out_slow_in = 2131427334;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131492864;
    
    public static final int abc_action_bar_up_container = 2131492865;
    
    public static final int abc_action_menu_item_layout = 2131492866;
    
    public static final int abc_action_menu_layout = 2131492867;
    
    public static final int abc_action_mode_bar = 2131492868;
    
    public static final int abc_action_mode_close_item_material = 2131492869;
    
    public static final int abc_activity_chooser_view = 2131492870;
    
    public static final int abc_activity_chooser_view_list_item = 2131492871;
    
    public static final int abc_alert_dialog_button_bar_material = 2131492872;
    
    public static final int abc_alert_dialog_material = 2131492873;
    
    public static final int abc_alert_dialog_title_material = 2131492874;
    
    public static final int abc_cascading_menu_item_layout = 2131492875;
    
    public static final int abc_dialog_title_material = 2131492876;
    
    public static final int abc_expanded_menu_layout = 2131492877;
    
    public static final int abc_list_menu_item_checkbox = 2131492878;
    
    public static final int abc_list_menu_item_icon = 2131492879;
    
    public static final int abc_list_menu_item_layout = 2131492880;
    
    public static final int abc_list_menu_item_radio = 2131492881;
    
    public static final int abc_popup_menu_header_item_layout = 2131492882;
    
    public static final int abc_popup_menu_item_layout = 2131492883;
    
    public static final int abc_screen_content_include = 2131492884;
    
    public static final int abc_screen_simple = 2131492885;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131492886;
    
    public static final int abc_screen_toolbar = 2131492887;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131492888;
    
    public static final int abc_search_view = 2131492889;
    
    public static final int abc_select_dialog_material = 2131492890;
    
    public static final int abc_tooltip = 2131492891;
    
    public static final int applovin_debugger_list_item_detail = 2131492898;
    
    public static final int applovin_exo_list_divider = 2131492899;
    
    public static final int applovin_exo_player_control_view = 2131492900;
    
    public static final int applovin_exo_player_view = 2131492901;
    
    public static final int applovin_exo_styled_player_control_ffwd_button = 2131492902;
    
    public static final int applovin_exo_styled_player_control_rewind_button = 2131492903;
    
    public static final int applovin_exo_styled_player_control_view = 2131492904;
    
    public static final int applovin_exo_styled_player_view = 2131492905;
    
    public static final int applovin_exo_styled_settings_list = 2131492906;
    
    public static final int applovin_exo_styled_settings_list_item = 2131492907;
    
    public static final int applovin_exo_styled_sub_settings_list_item = 2131492908;
    
    public static final int applovin_exo_track_selection_dialog = 2131492909;
    
    public static final int applovin_native_ad_media_view = 2131492910;
    
    public static final int browser_actions_context_menu_page = 2131492911;
    
    public static final int browser_actions_context_menu_row = 2131492912;
    
    public static final int creative_debugger_displayed_ad_detail_activity = 2131492920;
    
    public static final int custom_dialog = 2131492921;
    
    public static final int ia_buffering_overlay = 2131492924;
    
    public static final int ia_default_video_end_card = 2131492926;
    
    public static final int ia_fullscreen_activity = 2131492927;
    
    public static final int ia_rich_media_video = 2131492928;
    
    public static final int ia_video_view = 2131492929;
    
    public static final int loading_alert = 2131492931;
    
    public static final int max_hybrid_native_ad_view = 2131492932;
    
    public static final int max_native_ad_banner_icon_and_text_layout = 2131492933;
    
    public static final int max_native_ad_banner_view = 2131492934;
    
    public static final int max_native_ad_leader_view = 2131492935;
    
    public static final int max_native_ad_media_banner_view = 2131492936;
    
    public static final int max_native_ad_medium_template_1 = 2131492937;
    
    public static final int max_native_ad_mrec_view = 2131492938;
    
    public static final int max_native_ad_recycler_view_item = 2131492939;
    
    public static final int max_native_ad_small_template_1 = 2131492940;
    
    public static final int max_native_ad_vertical_banner_view = 2131492941;
    
    public static final int max_native_ad_vertical_leader_view = 2131492942;
    
    public static final int max_native_ad_vertical_media_banner_view = 2131492943;
    
    public static final int mbridge_bt_container = 2131492944;
    
    public static final int mbridge_cm_alertview = 2131492945;
    
    public static final int mbridge_cm_feedbackview = 2131492947;
    
    public static final int mbridge_cm_loading_layout = 2131492948;
    
    public static final int mbridge_interstitial_activity = 2131492949;
    
    public static final int mbridge_more_offer_activity = 2131492950;
    
    public static final int mbridge_order_layout_item = 2131492955;
    
    public static final int mbridge_order_layout_list_landscape = 2131492956;
    
    public static final int mbridge_order_layout_list_portrait = 2131492957;
    
    public static final int mbridge_playercommon_player_view = 2131492958;
    
    public static final int mbridge_reward_activity_video_templete = 2131492959;
    
    public static final int mbridge_reward_activity_video_templete_transparent = 2131492960;
    
    public static final int mbridge_reward_clickable_cta = 2131492961;
    
    public static final int mbridge_reward_end_card_layout_landscape = 2131492962;
    
    public static final int mbridge_reward_end_card_layout_portrait = 2131492963;
    
    public static final int mbridge_reward_end_card_more_offer_item = 2131492964;
    
    public static final int mbridge_reward_endcard_h5 = 2131492965;
    
    public static final int mbridge_reward_endcard_native_half_landscape = 2131492966;
    
    public static final int mbridge_reward_endcard_native_half_portrait = 2131492967;
    
    public static final int mbridge_reward_endcard_native_hor = 2131492968;
    
    public static final int mbridge_reward_endcard_native_land = 2131492969;
    
    public static final int mbridge_reward_endcard_vast = 2131492970;
    
    public static final int mbridge_reward_layer_floor = 2131492971;
    
    public static final int mbridge_reward_layer_floor_302 = 2131492972;
    
    public static final int mbridge_reward_layer_floor_802 = 2131492973;
    
    public static final int mbridge_reward_layer_floor_904 = 2131492974;
    
    public static final int mbridge_reward_layer_floor_bottom = 2131492975;
    
    public static final int mbridge_reward_more_offer_view = 2131492976;
    
    public static final int mbridge_reward_videoend_cover = 2131492977;
    
    public static final int mbridge_reward_videoview_item = 2131492978;
    
    public static final int mbridge_reward_view_tag_item = 2131492979;
    
    public static final int mbridge_same_choice_one_layout_landscape = 2131492980;
    
    public static final int mbridge_same_choice_one_layout_portrait = 2131492981;
    
    public static final int mediation_debugger_ad_unit_detail_activity = 2131492982;
    
    public static final int mediation_debugger_list_item_right_detail = 2131492983;
    
    public static final int mediation_debugger_list_section = 2131492984;
    
    public static final int mediation_debugger_list_section_centered = 2131492985;
    
    public static final int mediation_debugger_list_view = 2131492986;
    
    public static final int mediation_debugger_multi_ad_activity = 2131492987;
    
    public static final int mediation_debugger_text_view_activity = 2131492988;
    
    public static final int notification_action = 2131492989;
    
    public static final int notification_action_tombstone = 2131492990;
    
    public static final int notification_media_action = 2131492991;
    
    public static final int notification_media_cancel_action = 2131492992;
    
    public static final int notification_template_big_media = 2131492993;
    
    public static final int notification_template_big_media_custom = 2131492994;
    
    public static final int notification_template_big_media_narrow = 2131492995;
    
    public static final int notification_template_big_media_narrow_custom = 2131492996;
    
    public static final int notification_template_custom_big = 2131492997;
    
    public static final int notification_template_icon_group = 2131492998;
    
    public static final int notification_template_lines_media = 2131492999;
    
    public static final int notification_template_media = 2131493000;
    
    public static final int notification_template_media_custom = 2131493001;
    
    public static final int notification_template_part_chronometer = 2131493002;
    
    public static final int notification_template_part_time = 2131493003;
    
    public static final int select_dialog_item_material = 2131493005;
    
    public static final int select_dialog_multichoice_material = 2131493006;
    
    public static final int select_dialog_singlechoice_material = 2131493007;
    
    public static final int support_simple_spinner_dropdown_item = 2131493009;
  }
  
  public static final class menu {
    public static final int creative_debugger_displayed_ad_activity_menu = 2131558400;
    
    public static final int mediation_debugger_activity_menu = 2131558401;
  }
  
  public static final class plurals {
    public static final int al_exo_controls_fastforward_by_amount_description = 2131689472;
    
    public static final int al_exo_controls_rewind_by_amount_description = 2131689473;
  }
  
  public static final class raw {
    public static final int applovin_consent_flow_privacy_policy = 2131755009;
    
    public static final int applovin_consent_flow_terms_of_service_and_privacy_policy = 2131755010;
    
    public static final int omsdk_v_1_0 = 2131755012;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131820552;
    
    public static final int abc_action_bar_up_description = 2131820553;
    
    public static final int abc_action_menu_overflow_description = 2131820554;
    
    public static final int abc_action_mode_done = 2131820555;
    
    public static final int abc_activity_chooser_view_see_all = 2131820556;
    
    public static final int abc_activitychooserview_choose_application = 2131820557;
    
    public static final int abc_capital_off = 2131820558;
    
    public static final int abc_capital_on = 2131820559;
    
    public static final int abc_menu_alt_shortcut_label = 2131820560;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131820561;
    
    public static final int abc_menu_delete_shortcut_label = 2131820562;
    
    public static final int abc_menu_enter_shortcut_label = 2131820563;
    
    public static final int abc_menu_function_shortcut_label = 2131820564;
    
    public static final int abc_menu_meta_shortcut_label = 2131820565;
    
    public static final int abc_menu_shift_shortcut_label = 2131820566;
    
    public static final int abc_menu_space_shortcut_label = 2131820567;
    
    public static final int abc_menu_sym_shortcut_label = 2131820568;
    
    public static final int abc_prepend_shortcut_label = 2131820569;
    
    public static final int abc_search_hint = 2131820570;
    
    public static final int abc_searchview_description_clear = 2131820571;
    
    public static final int abc_searchview_description_query = 2131820572;
    
    public static final int abc_searchview_description_search = 2131820573;
    
    public static final int abc_searchview_description_submit = 2131820574;
    
    public static final int abc_searchview_description_voice = 2131820575;
    
    public static final int abc_shareactionprovider_share_with = 2131820576;
    
    public static final int abc_shareactionprovider_share_with_application = 2131820577;
    
    public static final int abc_toolbar_collapse_description = 2131820578;
    
    public static final int al_exo_controls_cc_disabled_description = 2131820580;
    
    public static final int al_exo_controls_cc_enabled_description = 2131820581;
    
    public static final int al_exo_controls_custom_playback_speed = 2131820582;
    
    public static final int al_exo_controls_fastforward_description = 2131820583;
    
    public static final int al_exo_controls_fullscreen_enter_description = 2131820584;
    
    public static final int al_exo_controls_fullscreen_exit_description = 2131820585;
    
    public static final int al_exo_controls_hide = 2131820586;
    
    public static final int al_exo_controls_next_description = 2131820587;
    
    public static final int al_exo_controls_overflow_hide_description = 2131820588;
    
    public static final int al_exo_controls_overflow_show_description = 2131820589;
    
    public static final int al_exo_controls_pause_description = 2131820590;
    
    public static final int al_exo_controls_play_description = 2131820591;
    
    public static final int al_exo_controls_playback_speed = 2131820592;
    
    public static final int al_exo_controls_playback_speed_normal = 2131820593;
    
    public static final int al_exo_controls_previous_description = 2131820594;
    
    public static final int al_exo_controls_repeat_all_description = 2131820595;
    
    public static final int al_exo_controls_repeat_off_description = 2131820596;
    
    public static final int al_exo_controls_repeat_one_description = 2131820597;
    
    public static final int al_exo_controls_rewind_description = 2131820598;
    
    public static final int al_exo_controls_seek_bar_description = 2131820599;
    
    public static final int al_exo_controls_settings_description = 2131820600;
    
    public static final int al_exo_controls_show = 2131820601;
    
    public static final int al_exo_controls_shuffle_off_description = 2131820602;
    
    public static final int al_exo_controls_shuffle_on_description = 2131820603;
    
    public static final int al_exo_controls_stop_description = 2131820604;
    
    public static final int al_exo_controls_time_placeholder = 2131820605;
    
    public static final int al_exo_controls_vr_description = 2131820606;
    
    public static final int al_exo_download_completed = 2131820607;
    
    public static final int al_exo_download_description = 2131820608;
    
    public static final int al_exo_download_downloading = 2131820609;
    
    public static final int al_exo_download_failed = 2131820610;
    
    public static final int al_exo_download_notification_channel_name = 2131820611;
    
    public static final int al_exo_download_paused = 2131820612;
    
    public static final int al_exo_download_paused_for_network = 2131820613;
    
    public static final int al_exo_download_paused_for_wifi = 2131820614;
    
    public static final int al_exo_download_removing = 2131820615;
    
    public static final int al_exo_item_list = 2131820616;
    
    public static final int al_exo_track_bitrate = 2131820617;
    
    public static final int al_exo_track_mono = 2131820618;
    
    public static final int al_exo_track_resolution = 2131820619;
    
    public static final int al_exo_track_role_alternate = 2131820620;
    
    public static final int al_exo_track_role_closed_captions = 2131820621;
    
    public static final int al_exo_track_role_commentary = 2131820622;
    
    public static final int al_exo_track_role_supplementary = 2131820623;
    
    public static final int al_exo_track_selection_auto = 2131820624;
    
    public static final int al_exo_track_selection_none = 2131820625;
    
    public static final int al_exo_track_selection_title_audio = 2131820626;
    
    public static final int al_exo_track_selection_title_text = 2131820627;
    
    public static final int al_exo_track_selection_title_video = 2131820628;
    
    public static final int al_exo_track_stereo = 2131820629;
    
    public static final int al_exo_track_surround = 2131820630;
    
    public static final int al_exo_track_surround_5_point_1 = 2131820631;
    
    public static final int al_exo_track_surround_7_point_1 = 2131820632;
    
    public static final int al_exo_track_unknown = 2131820633;
    
    public static final int androidx_startup = 2131820634;
    
    public static final int app_name = 2131820635;
    
    public static final int applovin_agree_message = 2131820636;
    
    public static final int applovin_alt_privacy_policy_text = 2131820637;
    
    public static final int applovin_continue_button_text = 2131820638;
    
    public static final int applovin_creative_debugger_disabled_text = 2131820639;
    
    public static final int applovin_creative_debugger_no_ads_text = 2131820640;
    
    public static final int applovin_list_item_image_description = 2131820663;
    
    public static final int applovin_pp_and_tos_title = 2131820664;
    
    public static final int applovin_pp_title = 2131820665;
    
    public static final int applovin_privacy_policy_text = 2131820666;
    
    public static final int applovin_terms_of_service_text = 2131820667;
    
    public static final int applovin_terms_of_use_text = 2131820668;
    
    public static final int campaign_appName = 2131820669;
    
    public static final int campaign_iconUrl = 2131820670;
    
    public static final int campaign_imageUrl = 2131820671;
    
    public static final int common_google_play_services_enable_button = 2131820695;
    
    public static final int common_google_play_services_enable_text = 2131820696;
    
    public static final int common_google_play_services_enable_title = 2131820697;
    
    public static final int common_google_play_services_install_button = 2131820698;
    
    public static final int common_google_play_services_install_text = 2131820699;
    
    public static final int common_google_play_services_install_title = 2131820700;
    
    public static final int common_google_play_services_notification_channel_name = 2131820701;
    
    public static final int common_google_play_services_notification_ticker = 2131820702;
    
    public static final int common_google_play_services_unknown_issue = 2131820703;
    
    public static final int common_google_play_services_unsupported_text = 2131820704;
    
    public static final int common_google_play_services_update_button = 2131820705;
    
    public static final int common_google_play_services_update_text = 2131820706;
    
    public static final int common_google_play_services_update_title = 2131820707;
    
    public static final int common_google_play_services_updating_text = 2131820708;
    
    public static final int common_google_play_services_wear_update_text = 2131820709;
    
    public static final int common_open_on_phone = 2131820710;
    
    public static final int common_signin_button_text = 2131820711;
    
    public static final int common_signin_button_text_long = 2131820712;
    
    public static final int copy_toast_msg = 2131820713;
    
    public static final int defaults = 2131820714;
    
    public static final int dyAction_getClick = 2131820715;
    
    public static final int dyAction_getLogicClick = 2131820716;
    
    public static final int dyAction_getLongClick = 2131820717;
    
    public static final int dyAction_getMove = 2131820718;
    
    public static final int dyAction_getWobble = 2131820719;
    
    public static final int dyEffect_getCountDown = 2131820720;
    
    public static final int dyEffect_getVisible = 2131820721;
    
    public static final int dyEffect_getVisibleParam = 2131820722;
    
    public static final int dyEffect_getWobble = 2131820723;
    
    public static final int dyStrategy_feedback = 2131820724;
    
    public static final int dyStrategy_getActivity = 2131820725;
    
    public static final int dyStrategy_getClose = 2131820726;
    
    public static final int dyStrategy_getDeeplink = 2131820727;
    
    public static final int dyStrategy_getDownload = 2131820728;
    
    public static final int dyStrategy_notice = 2131820729;
    
    public static final int dyStrategy_permissionInfo = 2131820730;
    
    public static final int dyStrategy_privateAddress = 2131820731;
    
    public static final int fallback_menu_item_copy_link = 2131820732;
    
    public static final int fallback_menu_item_open_in_browser = 2131820733;
    
    public static final int fallback_menu_item_share_link = 2131820734;
    
    public static final int ia_str_video_error = 2131820736;
    
    public static final int ia_video_before_skip_format = 2131820738;
    
    public static final int ia_video_install_now_text = 2131820739;
    
    public static final int ia_video_skip_text = 2131820741;
    
    public static final int mSplashData_setAdClickText = 2131820742;
    
    public static final int mSplashData_setAppInfo = 2131820743;
    
    public static final int mSplashData_setCountDownText = 2131820744;
    
    public static final int mSplashData_setLogoImage = 2131820745;
    
    public static final int mSplashData_setLogoText = 2131820746;
    
    public static final int mSplashData_setNoticeImage = 2131820747;
    
    public static final int mbridge_cm_feedback_btn_text = 2131820748;
    
    public static final int mbridge_cm_feedback_dialog_close_close = 2131820749;
    
    public static final int mbridge_cm_feedback_dialog_close_submit = 2131820750;
    
    public static final int mbridge_cm_feedback_dialog_content_other = 2131820754;
    
    public static final int mbridge_cm_feedback_dialog_title = 2131820759;
    
    public static final int mbridge_reward_appdesc = 2131820760;
    
    public static final int mbridge_reward_apptitle = 2131820761;
    
    public static final int mbridge_reward_clickable_cta_btntext = 2131820762;
    
    public static final int mbridge_reward_endcard_ad = 2131820763;
    
    public static final int mbridge_reward_endcard_vast_notice = 2131820764;
    
    public static final int mbridge_reward_heat_count_unit = 2131820765;
    
    public static final int mbridge_reward_install = 2131820766;
    
    public static final int mbridge_reward_video_view_reward_time_complete = 2131820767;
    
    public static final int mbridge_reward_video_view_reward_time_left = 2131820768;
    
    public static final int mbridge_reward_viewed_text_str = 2131820769;
    
    public static final int offline_notification_text = 2131820776;
    
    public static final int offline_notification_title = 2131820777;
    
    public static final int offline_opt_in_confirm = 2131820778;
    
    public static final int offline_opt_in_confirmation = 2131820779;
    
    public static final int offline_opt_in_decline = 2131820780;
    
    public static final int offline_opt_in_message = 2131820781;
    
    public static final int offline_opt_in_title = 2131820782;
    
    public static final int s1 = 2131820783;
    
    public static final int s2 = 2131820784;
    
    public static final int s3 = 2131820785;
    
    public static final int s4 = 2131820786;
    
    public static final int s5 = 2131820787;
    
    public static final int s6 = 2131820788;
    
    public static final int s7 = 2131820789;
    
    public static final int search_menu_title = 2131820790;
    
    public static final int status_bar_notification_info_overflow = 2131820795;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131886080;
    
    public static final int AlertDialog_AppCompat_Light = 2131886081;
    
    public static final int Animation_AppCompat_Dialog = 2131886082;
    
    public static final int Animation_AppCompat_DropDownUp = 2131886083;
    
    public static final int Animation_AppCompat_Tooltip = 2131886084;
    
    public static final int AppBaseTheme = 2131886085;
    
    public static final int AppLovinExoMediaButton = 2131886086;
    
    public static final int AppLovinExoMediaButton_FastForward = 2131886087;
    
    public static final int AppLovinExoMediaButton_Next = 2131886088;
    
    public static final int AppLovinExoMediaButton_Pause = 2131886089;
    
    public static final int AppLovinExoMediaButton_Play = 2131886090;
    
    public static final int AppLovinExoMediaButton_Previous = 2131886091;
    
    public static final int AppLovinExoMediaButton_Rewind = 2131886092;
    
    public static final int AppLovinExoMediaButton_VR = 2131886093;
    
    public static final int AppLovinExoStyledControls = 2131886094;
    
    public static final int AppLovinExoStyledControls_Button = 2131886095;
    
    public static final int AppLovinExoStyledControls_ButtonText = 2131886113;
    
    public static final int AppLovinExoStyledControls_Button_Bottom = 2131886096;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_AudioTrack = 2131886097;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_CC = 2131886098;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_FullScreen = 2131886099;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_OverflowHide = 2131886100;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_OverflowShow = 2131886101;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_PlaybackSpeed = 2131886102;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_RepeatToggle = 2131886103;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_Settings = 2131886104;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_Shuffle = 2131886105;
    
    public static final int AppLovinExoStyledControls_Button_Bottom_VR = 2131886106;
    
    public static final int AppLovinExoStyledControls_Button_Center = 2131886107;
    
    public static final int AppLovinExoStyledControls_Button_Center_FfwdWithAmount = 2131886108;
    
    public static final int AppLovinExoStyledControls_Button_Center_Next = 2131886109;
    
    public static final int AppLovinExoStyledControls_Button_Center_PlayPause = 2131886110;
    
    public static final int AppLovinExoStyledControls_Button_Center_Previous = 2131886111;
    
    public static final int AppLovinExoStyledControls_Button_Center_RewWithAmount = 2131886112;
    
    public static final int AppLovinExoStyledControls_TimeBar = 2131886114;
    
    public static final int AppLovinExoStyledControls_TimeText = 2131886115;
    
    public static final int AppLovinExoStyledControls_TimeText_Duration = 2131886116;
    
    public static final int AppLovinExoStyledControls_TimeText_Position = 2131886117;
    
    public static final int AppLovinExoStyledControls_TimeText_Separator = 2131886118;
    
    public static final int Base_AlertDialog_AppCompat = 2131886119;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131886120;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131886121;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131886122;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131886123;
    
    public static final int Base_CardView = 2131886124;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131886126;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131886125;
    
    public static final int Base_TextAppearance_AppCompat = 2131886127;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131886128;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131886129;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131886130;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131886131;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131886132;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131886133;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131886134;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131886135;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131886136;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131886137;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131886138;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131886139;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131886140;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131886141;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131886142;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131886143;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131886144;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131886145;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131886146;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131886147;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131886148;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131886149;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131886150;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131886151;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131886152;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131886153;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131886154;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131886155;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131886156;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131886157;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131886158;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131886159;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131886160;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131886161;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131886162;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131886163;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131886164;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131886165;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131886166;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131886167;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131886168;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131886169;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131886170;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131886171;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131886172;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131886173;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131886174;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131886189;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131886190;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131886191;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131886192;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131886193;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131886194;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131886195;
    
    public static final int Base_Theme_AppCompat = 2131886175;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131886176;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131886177;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131886181;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131886178;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131886179;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131886180;
    
    public static final int Base_Theme_AppCompat_Light = 2131886182;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131886183;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131886184;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131886188;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131886185;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131886186;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131886187;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131886200;
    
    public static final int Base_V21_Theme_AppCompat = 2131886196;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131886197;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131886198;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131886199;
    
    public static final int Base_V22_Theme_AppCompat = 2131886201;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131886202;
    
    public static final int Base_V23_Theme_AppCompat = 2131886203;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131886204;
    
    public static final int Base_V26_Theme_AppCompat = 2131886205;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131886206;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131886207;
    
    public static final int Base_V28_Theme_AppCompat = 2131886208;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131886209;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131886214;
    
    public static final int Base_V7_Theme_AppCompat = 2131886210;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131886211;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131886212;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131886213;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131886215;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131886216;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131886217;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131886218;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131886219;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131886220;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131886221;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131886222;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131886223;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131886224;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131886225;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131886226;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131886227;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131886228;
    
    public static final int Base_Widget_AppCompat_Button = 2131886229;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131886235;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131886236;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131886230;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131886231;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131886232;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131886233;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131886234;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131886237;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131886238;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131886239;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131886240;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131886241;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131886242;
    
    public static final int Base_Widget_AppCompat_EditText = 2131886243;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131886244;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131886245;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131886246;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131886247;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131886248;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131886249;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131886250;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131886251;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131886252;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131886253;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131886254;
    
    public static final int Base_Widget_AppCompat_ListView = 2131886255;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131886256;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131886257;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131886258;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131886259;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131886260;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131886261;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131886262;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131886263;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131886264;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131886265;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131886266;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131886267;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131886268;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131886269;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131886270;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131886271;
    
    public static final int Base_Widget_AppCompat_TextView = 2131886272;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131886273;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131886274;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131886275;
    
    public static final int CardView = 2131886277;
    
    public static final int CardView_Dark = 2131886278;
    
    public static final int CardView_Light = 2131886279;
    
    public static final int InneractiveAppTheme_Home = 2131886280;
    
    public static final int LargeIconView = 2131886281;
    
    public static final int MBridgeAppTheme = 2131886282;
    
    public static final int Platform_AppCompat = 2131886283;
    
    public static final int Platform_AppCompat_Light = 2131886284;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131886285;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131886286;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131886287;
    
    public static final int Platform_V21_AppCompat = 2131886288;
    
    public static final int Platform_V21_AppCompat_Light = 2131886289;
    
    public static final int Platform_V25_AppCompat = 2131886290;
    
    public static final int Platform_V25_AppCompat_Light = 2131886291;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131886292;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131886293;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131886294;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131886295;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131886296;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131886297;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131886298;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131886299;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131886300;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131886301;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131886307;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131886302;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131886303;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131886304;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131886305;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131886306;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131886308;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131886309;
    
    public static final int SmallIconView = 2131886310;
    
    public static final int TextAppearance_AppCompat = 2131886311;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131886312;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131886313;
    
    public static final int TextAppearance_AppCompat_Button = 2131886314;
    
    public static final int TextAppearance_AppCompat_Caption = 2131886315;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131886316;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131886317;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131886318;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131886319;
    
    public static final int TextAppearance_AppCompat_Headline = 2131886320;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131886321;
    
    public static final int TextAppearance_AppCompat_Large = 2131886322;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131886323;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131886324;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131886325;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131886326;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131886327;
    
    public static final int TextAppearance_AppCompat_Medium = 2131886328;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131886329;
    
    public static final int TextAppearance_AppCompat_Menu = 2131886330;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131886331;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131886332;
    
    public static final int TextAppearance_AppCompat_Small = 2131886333;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131886334;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131886335;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131886336;
    
    public static final int TextAppearance_AppCompat_Title = 2131886337;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131886338;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131886339;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131886340;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131886341;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131886342;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131886343;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131886344;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131886345;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131886346;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131886347;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131886348;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131886349;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131886350;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131886351;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131886352;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131886353;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131886354;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131886355;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131886356;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131886357;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131886358;
    
    public static final int TextAppearance_Compat_Notification = 2131886359;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131886360;
    
    public static final int TextAppearance_Compat_Notification_Info_Media = 2131886361;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131886362;
    
    public static final int TextAppearance_Compat_Notification_Line2_Media = 2131886363;
    
    public static final int TextAppearance_Compat_Notification_Media = 2131886364;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131886365;
    
    public static final int TextAppearance_Compat_Notification_Time_Media = 2131886366;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131886367;
    
    public static final int TextAppearance_Compat_Notification_Title_Media = 2131886368;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131886369;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131886370;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131886371;
    
    public static final int ThemeOverlay_AppCompat = 2131886400;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131886401;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131886402;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131886403;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2131886404;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2131886405;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131886406;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131886407;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131886408;
    
    public static final int Theme_AppCompat = 2131886372;
    
    public static final int Theme_AppCompat_CompactMenu = 2131886373;
    
    public static final int Theme_AppCompat_DayNight = 2131886374;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131886375;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131886376;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131886379;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131886377;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131886378;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131886380;
    
    public static final int Theme_AppCompat_Dialog = 2131886381;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131886384;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131886382;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131886383;
    
    public static final int Theme_AppCompat_Light = 2131886385;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131886386;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131886387;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131886390;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131886388;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131886389;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131886391;
    
    public static final int Theme_AppCompat_NoActionBar = 2131886392;
    
    public static final int Theme_IAPTheme = 2131886398;
    
    public static final int Widget_AppCompat_ActionBar = 2131886411;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131886412;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131886413;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131886414;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131886415;
    
    public static final int Widget_AppCompat_ActionButton = 2131886416;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131886417;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131886418;
    
    public static final int Widget_AppCompat_ActionMode = 2131886419;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131886420;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131886421;
    
    public static final int Widget_AppCompat_Button = 2131886422;
    
    public static final int Widget_AppCompat_ButtonBar = 2131886428;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131886429;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131886423;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131886424;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131886425;
    
    public static final int Widget_AppCompat_Button_Colored = 2131886426;
    
    public static final int Widget_AppCompat_Button_Small = 2131886427;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131886430;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131886431;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131886432;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131886433;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131886434;
    
    public static final int Widget_AppCompat_EditText = 2131886435;
    
    public static final int Widget_AppCompat_ImageButton = 2131886436;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131886437;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131886438;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131886439;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131886440;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131886441;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131886442;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131886443;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131886444;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131886445;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131886446;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131886447;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131886448;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131886449;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131886450;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131886451;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131886452;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131886453;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131886454;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131886455;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131886456;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131886457;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131886458;
    
    public static final int Widget_AppCompat_ListMenuView = 2131886459;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131886460;
    
    public static final int Widget_AppCompat_ListView = 2131886461;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131886462;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131886463;
    
    public static final int Widget_AppCompat_PopupMenu = 2131886464;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131886465;
    
    public static final int Widget_AppCompat_PopupWindow = 2131886466;
    
    public static final int Widget_AppCompat_ProgressBar = 2131886467;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131886468;
    
    public static final int Widget_AppCompat_RatingBar = 2131886469;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131886470;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131886471;
    
    public static final int Widget_AppCompat_SearchView = 2131886472;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131886473;
    
    public static final int Widget_AppCompat_SeekBar = 2131886474;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131886475;
    
    public static final int Widget_AppCompat_Spinner = 2131886476;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131886477;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131886478;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131886479;
    
    public static final int Widget_AppCompat_TextView = 2131886480;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131886481;
    
    public static final int Widget_AppCompat_Toolbar = 2131886482;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131886483;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131886484;
    
    public static final int Widget_Compat_NotificationActionText = 2131886485;
    
    public static final int Widget_Support_CoordinatorLayout = 2131886486;
    
    public static final int com_applovin_creative_CreativeDebuggerActivity_ActionBar = 2131886487;
    
    public static final int com_applovin_creative_CreativeDebuggerActivity_ActionBar_TitleTextStyle = 2131886488;
    
    public static final int com_applovin_creative_CreativeDebuggerActivity_Theme = 2131886489;
    
    public static final int com_applovin_creative_debugger_ui_DisplayedAdActivity_ReportAdButton = 2131886490;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar = 2131886495;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar_Live = 2131886496;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_ActionBar_TitleTextStyle = 2131886497;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_Theme = 2131886498;
    
    public static final int com_applovin_mediation_MaxDebuggerActivity_Theme_Live = 2131886499;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_AdBadgeTextView = 2131886500;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_AutoScrollingTextView = 2131886501;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_CTAButton = 2131886502;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeAdBadgeTextView = 2131886503;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeScrollingBodyTextView = 2131886504;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeScrollingTitleTextView = 2131886505;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeVerticalBodyTextSize = 2131886506;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_LargeVerticalTitleTextSize = 2131886507;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_ScrollingTitleTextView = 2131886508;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallAdBadgeTextView = 2131886509;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallScrollingBodyTextView = 2131886510;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallScrollingTitleTextView = 2131886511;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallVerticalBodyTextSize = 2131886512;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_SmallVerticalTitleTextSize = 2131886513;
    
    public static final int com_applovin_mediation_nativeAds_MaxNativeAdView_TitleTextStyle = 2131886514;
    
    public static final int ia_bottom_left_overlay = 2131886523;
    
    public static final int ia_bottom_right_overlay = 2131886524;
    
    public static final int ia_expand_collapse_button_style = 2131886525;
    
    public static final int ia_mute_button_style = 2131886528;
    
    public static final int ia_play_button_style = 2131886529;
    
    public static final int ia_top_left_overlay = 2131886530;
    
    public static final int ia_top_right_overlay = 2131886531;
    
    public static final int ia_tv_call_to_action_style = 2131886533;
    
    public static final int ia_tv_remaining_time_style = 2131886534;
    
    public static final int ia_tv_skip_style = 2131886535;
    
    public static final int ia_video_overlay_text_view = 2131886536;
    
    public static final int ia_video_progressbar_style = 2131886537;
    
    public static final int mbridge_common_activity_style = 2131886539;
    
    public static final int mbridge_reward_theme = 2131886540;
    
    public static final int mbridge_transparent_common_activity_style = 2131886541;
    
    public static final int mbridge_transparent_theme = 2131886542;
    
    public static final int myDialog = 2131886543;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130903131, 2130903132, 2130903133, 2130903192, 2130903193, 2130903194, 2130903195, 2130903196, 2130903197, 2130903206, 
        2130903211, 2130903212, 2130903231, 2130903253, 2130903254, 2130903255, 2130903256, 2130903257, 2130903264, 2130903267, 
        2130903295, 2130903309, 2130903321, 2130903324, 2130903325, 2130903359, 2130903362, 2130903390, 2130903399 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130903131, 2130903132, 2130903163, 2130903253, 2130903362, 2130903399 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130903232, 2130903265 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AdsAttrs = new int[] { 2130903074, 2130903075, 2130903076 };
    
    public static final int AdsAttrs_adSize = 0;
    
    public static final int AdsAttrs_adSizes = 1;
    
    public static final int AdsAttrs_adUnitId = 2;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130903145, 2130903146, 2130903284, 2130903285, 2130903306, 2130903346, 2130903347 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130903353, 2130903388, 2130903389 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130903385, 2130903386, 2130903387 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130903126, 2130903127, 2130903128, 2130903129, 2130903130, 2130903216, 2130903217, 2130903218, 2130903219, 
        2130903221, 2130903222, 2130903223, 2130903224, 2130903238, 2130903240, 2130903249, 2130903270, 2130903279, 2130903368, 
        2130903379 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 14;
    
    public static final int AppCompatTextView_fontFamily = 15;
    
    public static final int AppCompatTextView_fontVariationSettings = 16;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 17;
    
    public static final int AppCompatTextView_lineHeight = 18;
    
    public static final int AppCompatTextView_textAllCaps = 19;
    
    public static final int AppCompatTextView_textLocale = 20;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130903040, 2130903041, 2130903042, 2130903043, 2130903044, 2130903045, 2130903046, 2130903047, 
        2130903048, 2130903049, 2130903050, 2130903051, 2130903052, 2130903054, 2130903055, 2130903056, 2130903057, 2130903058, 
        2130903059, 2130903060, 2130903061, 2130903062, 2130903063, 2130903064, 2130903065, 2130903066, 2130903067, 2130903068, 
        2130903069, 2130903070, 2130903073, 2130903116, 2130903117, 2130903118, 2130903119, 2130903125, 2130903137, 2130903138, 
        2130903139, 2130903140, 2130903141, 2130903142, 2130903148, 2130903149, 2130903159, 2130903160, 2130903167, 2130903168, 
        2130903169, 2130903170, 2130903171, 2130903172, 2130903173, 2130903174, 2130903175, 2130903177, 2130903203, 2130903208, 
        2130903209, 2130903210, 2130903213, 2130903215, 2130903226, 2130903227, 2130903228, 2130903229, 2130903230, 2130903255, 
        2130903263, 2130903280, 2130903281, 2130903282, 2130903283, 2130903286, 2130903287, 2130903288, 2130903289, 2130903290, 
        2130903291, 2130903292, 2130903293, 2130903294, 2130903317, 2130903318, 2130903319, 2130903320, 2130903322, 2130903329, 
        2130903330, 2130903331, 2130903332, 2130903338, 2130903339, 2130903340, 2130903341, 2130903350, 2130903351, 2130903366, 
        2130903369, 2130903370, 2130903371, 2130903372, 2130903373, 2130903374, 2130903375, 2130903376, 2130903377, 2130903378, 
        2130903400, 2130903401, 2130903402, 2130903403, 2130903409, 2130903411, 2130903412, 2130903413, 2130903414, 2130903415, 
        2130903416, 2130903417, 2130903418, 2130903419, 2130903420 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 49;
    
    public static final int AppCompatTheme_colorButtonNormal = 50;
    
    public static final int AppCompatTheme_colorControlActivated = 51;
    
    public static final int AppCompatTheme_colorControlHighlight = 52;
    
    public static final int AppCompatTheme_colorControlNormal = 53;
    
    public static final int AppCompatTheme_colorError = 54;
    
    public static final int AppCompatTheme_colorPrimary = 55;
    
    public static final int AppCompatTheme_colorPrimaryDark = 56;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
    
    public static final int AppCompatTheme_controlBackground = 58;
    
    public static final int AppCompatTheme_dialogCornerRadius = 59;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 60;
    
    public static final int AppCompatTheme_dialogTheme = 61;
    
    public static final int AppCompatTheme_dividerHorizontal = 62;
    
    public static final int AppCompatTheme_dividerVertical = 63;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 64;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
    
    public static final int AppCompatTheme_editTextBackground = 66;
    
    public static final int AppCompatTheme_editTextColor = 67;
    
    public static final int AppCompatTheme_editTextStyle = 68;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 69;
    
    public static final int AppCompatTheme_imageButtonStyle = 70;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 72;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 73;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 74;
    
    public static final int AppCompatTheme_listMenuViewStyle = 75;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 76;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 77;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 79;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 80;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 83;
    
    public static final int AppCompatTheme_panelBackground = 84;
    
    public static final int AppCompatTheme_panelMenuListTheme = 85;
    
    public static final int AppCompatTheme_panelMenuListWidth = 86;
    
    public static final int AppCompatTheme_popupMenuStyle = 87;
    
    public static final int AppCompatTheme_popupWindowStyle = 88;
    
    public static final int AppCompatTheme_radioButtonStyle = 89;
    
    public static final int AppCompatTheme_ratingBarStyle = 90;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 91;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 92;
    
    public static final int AppCompatTheme_searchViewStyle = 93;
    
    public static final int AppCompatTheme_seekBarStyle = 94;
    
    public static final int AppCompatTheme_selectableItemBackground = 95;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 96;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 97;
    
    public static final int AppCompatTheme_spinnerStyle = 98;
    
    public static final int AppCompatTheme_switchStyle = 99;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 100;
    
    public static final int AppCompatTheme_textAppearanceListItem = 101;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 102;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 103;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 104;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 105;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 106;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 107;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 108;
    
    public static final int AppCompatTheme_textColorSearchUrl = 109;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 110;
    
    public static final int AppCompatTheme_toolbarStyle = 111;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 112;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 113;
    
    public static final int AppCompatTheme_viewInflaterClass = 114;
    
    public static final int AppCompatTheme_windowActionBar = 115;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 116;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 117;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 118;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 119;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 120;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 121;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 122;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 123;
    
    public static final int AppCompatTheme_windowNoTitle = 124;
    
    public static final int[] AppLovinAspectRatioFrameLayout = new int[] { 2130903094 };
    
    public static final int AppLovinAspectRatioFrameLayout_al_resize_mode = 0;
    
    public static final int[] AppLovinDefaultTimeBar = new int[] { 
        2130903077, 2130903078, 2130903082, 2130903083, 2130903084, 2130903090, 2130903091, 2130903095, 2130903096, 2130903097, 
        2130903098, 2130903099, 2130903112, 2130903113 };
    
    public static final int AppLovinDefaultTimeBar_al_ad_marker_color = 0;
    
    public static final int AppLovinDefaultTimeBar_al_ad_marker_width = 1;
    
    public static final int AppLovinDefaultTimeBar_al_bar_gravity = 2;
    
    public static final int AppLovinDefaultTimeBar_al_bar_height = 3;
    
    public static final int AppLovinDefaultTimeBar_al_buffered_color = 4;
    
    public static final int AppLovinDefaultTimeBar_al_played_ad_marker_color = 5;
    
    public static final int AppLovinDefaultTimeBar_al_played_color = 6;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_color = 7;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_disabled_size = 8;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_dragged_size = 9;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_drawable = 10;
    
    public static final int AppLovinDefaultTimeBar_al_scrubber_enabled_size = 11;
    
    public static final int AppLovinDefaultTimeBar_al_touch_target_height = 12;
    
    public static final int AppLovinDefaultTimeBar_al_unplayed_color = 13;
    
    public static final int[] AppLovinPlayerControlView = new int[] { 
        2130903077, 2130903078, 2130903082, 2130903083, 2130903084, 2130903085, 2130903090, 2130903091, 2130903093, 2130903095, 
        2130903096, 2130903097, 2130903098, 2130903099, 2130903101, 2130903102, 2130903103, 2130903104, 2130903105, 2130903107, 
        2130903111, 2130903112, 2130903113 };
    
    public static final int AppLovinPlayerControlView_al_ad_marker_color = 0;
    
    public static final int AppLovinPlayerControlView_al_ad_marker_width = 1;
    
    public static final int AppLovinPlayerControlView_al_bar_gravity = 2;
    
    public static final int AppLovinPlayerControlView_al_bar_height = 3;
    
    public static final int AppLovinPlayerControlView_al_buffered_color = 4;
    
    public static final int AppLovinPlayerControlView_al_controller_layout_id = 5;
    
    public static final int AppLovinPlayerControlView_al_played_ad_marker_color = 6;
    
    public static final int AppLovinPlayerControlView_al_played_color = 7;
    
    public static final int AppLovinPlayerControlView_al_repeat_toggle_modes = 8;
    
    public static final int AppLovinPlayerControlView_al_scrubber_color = 9;
    
    public static final int AppLovinPlayerControlView_al_scrubber_disabled_size = 10;
    
    public static final int AppLovinPlayerControlView_al_scrubber_dragged_size = 11;
    
    public static final int AppLovinPlayerControlView_al_scrubber_drawable = 12;
    
    public static final int AppLovinPlayerControlView_al_scrubber_enabled_size = 13;
    
    public static final int AppLovinPlayerControlView_al_show_fastforward_button = 14;
    
    public static final int AppLovinPlayerControlView_al_show_next_button = 15;
    
    public static final int AppLovinPlayerControlView_al_show_previous_button = 16;
    
    public static final int AppLovinPlayerControlView_al_show_rewind_button = 17;
    
    public static final int AppLovinPlayerControlView_al_show_shuffle_button = 18;
    
    public static final int AppLovinPlayerControlView_al_show_timeout = 19;
    
    public static final int AppLovinPlayerControlView_al_time_bar_min_update_interval = 20;
    
    public static final int AppLovinPlayerControlView_al_touch_target_height = 21;
    
    public static final int AppLovinPlayerControlView_al_unplayed_color = 22;
    
    public static final int[] AppLovinPlayerView = new int[] { 
        2130903077, 2130903078, 2130903080, 2130903083, 2130903084, 2130903085, 2130903086, 2130903087, 2130903088, 2130903089, 
        2130903090, 2130903091, 2130903092, 2130903093, 2130903094, 2130903095, 2130903096, 2130903097, 2130903098, 2130903099, 
        2130903100, 2130903105, 2130903107, 2130903109, 2130903110, 2130903111, 2130903112, 2130903113, 2130903114, 2130903115 };
    
    public static final int AppLovinPlayerView_al_ad_marker_color = 0;
    
    public static final int AppLovinPlayerView_al_ad_marker_width = 1;
    
    public static final int AppLovinPlayerView_al_auto_show = 2;
    
    public static final int AppLovinPlayerView_al_bar_height = 3;
    
    public static final int AppLovinPlayerView_al_buffered_color = 4;
    
    public static final int AppLovinPlayerView_al_controller_layout_id = 5;
    
    public static final int AppLovinPlayerView_al_default_artwork = 6;
    
    public static final int AppLovinPlayerView_al_hide_during_ads = 7;
    
    public static final int AppLovinPlayerView_al_hide_on_touch = 8;
    
    public static final int AppLovinPlayerView_al_keep_content_on_player_reset = 9;
    
    public static final int AppLovinPlayerView_al_played_ad_marker_color = 10;
    
    public static final int AppLovinPlayerView_al_played_color = 11;
    
    public static final int AppLovinPlayerView_al_player_layout_id = 12;
    
    public static final int AppLovinPlayerView_al_repeat_toggle_modes = 13;
    
    public static final int AppLovinPlayerView_al_resize_mode = 14;
    
    public static final int AppLovinPlayerView_al_scrubber_color = 15;
    
    public static final int AppLovinPlayerView_al_scrubber_disabled_size = 16;
    
    public static final int AppLovinPlayerView_al_scrubber_dragged_size = 17;
    
    public static final int AppLovinPlayerView_al_scrubber_drawable = 18;
    
    public static final int AppLovinPlayerView_al_scrubber_enabled_size = 19;
    
    public static final int AppLovinPlayerView_al_show_buffering = 20;
    
    public static final int AppLovinPlayerView_al_show_shuffle_button = 21;
    
    public static final int AppLovinPlayerView_al_show_timeout = 22;
    
    public static final int AppLovinPlayerView_al_shutter_background_color = 23;
    
    public static final int AppLovinPlayerView_al_surface_type = 24;
    
    public static final int AppLovinPlayerView_al_time_bar_min_update_interval = 25;
    
    public static final int AppLovinPlayerView_al_touch_target_height = 26;
    
    public static final int AppLovinPlayerView_al_unplayed_color = 27;
    
    public static final int AppLovinPlayerView_al_use_artwork = 28;
    
    public static final int AppLovinPlayerView_al_use_controller = 29;
    
    public static final int[] AppLovinStyledPlayerControlView = new int[] { 
        2130903077, 2130903078, 2130903079, 2130903082, 2130903083, 2130903084, 2130903085, 2130903090, 2130903091, 2130903093, 
        2130903095, 2130903096, 2130903097, 2130903098, 2130903099, 2130903101, 2130903102, 2130903103, 2130903104, 2130903105, 
        2130903106, 2130903107, 2130903108, 2130903111, 2130903112, 2130903113 };
    
    public static final int AppLovinStyledPlayerControlView_al_ad_marker_color = 0;
    
    public static final int AppLovinStyledPlayerControlView_al_ad_marker_width = 1;
    
    public static final int AppLovinStyledPlayerControlView_al_animation_enabled = 2;
    
    public static final int AppLovinStyledPlayerControlView_al_bar_gravity = 3;
    
    public static final int AppLovinStyledPlayerControlView_al_bar_height = 4;
    
    public static final int AppLovinStyledPlayerControlView_al_buffered_color = 5;
    
    public static final int AppLovinStyledPlayerControlView_al_controller_layout_id = 6;
    
    public static final int AppLovinStyledPlayerControlView_al_played_ad_marker_color = 7;
    
    public static final int AppLovinStyledPlayerControlView_al_played_color = 8;
    
    public static final int AppLovinStyledPlayerControlView_al_repeat_toggle_modes = 9;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_color = 10;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_disabled_size = 11;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_dragged_size = 12;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_drawable = 13;
    
    public static final int AppLovinStyledPlayerControlView_al_scrubber_enabled_size = 14;
    
    public static final int AppLovinStyledPlayerControlView_al_show_fastforward_button = 15;
    
    public static final int AppLovinStyledPlayerControlView_al_show_next_button = 16;
    
    public static final int AppLovinStyledPlayerControlView_al_show_previous_button = 17;
    
    public static final int AppLovinStyledPlayerControlView_al_show_rewind_button = 18;
    
    public static final int AppLovinStyledPlayerControlView_al_show_shuffle_button = 19;
    
    public static final int AppLovinStyledPlayerControlView_al_show_subtitle_button = 20;
    
    public static final int AppLovinStyledPlayerControlView_al_show_timeout = 21;
    
    public static final int AppLovinStyledPlayerControlView_al_show_vr_button = 22;
    
    public static final int AppLovinStyledPlayerControlView_al_time_bar_min_update_interval = 23;
    
    public static final int AppLovinStyledPlayerControlView_al_touch_target_height = 24;
    
    public static final int AppLovinStyledPlayerControlView_al_unplayed_color = 25;
    
    public static final int[] AppLovinStyledPlayerView = new int[] { 
        2130903077, 2130903078, 2130903079, 2130903080, 2130903082, 2130903083, 2130903084, 2130903085, 2130903086, 2130903087, 
        2130903088, 2130903089, 2130903090, 2130903091, 2130903092, 2130903093, 2130903094, 2130903095, 2130903096, 2130903097, 
        2130903098, 2130903099, 2130903100, 2130903105, 2130903106, 2130903107, 2130903108, 2130903109, 2130903110, 2130903111, 
        2130903112, 2130903113, 2130903114, 2130903115 };
    
    public static final int AppLovinStyledPlayerView_al_ad_marker_color = 0;
    
    public static final int AppLovinStyledPlayerView_al_ad_marker_width = 1;
    
    public static final int AppLovinStyledPlayerView_al_animation_enabled = 2;
    
    public static final int AppLovinStyledPlayerView_al_auto_show = 3;
    
    public static final int AppLovinStyledPlayerView_al_bar_gravity = 4;
    
    public static final int AppLovinStyledPlayerView_al_bar_height = 5;
    
    public static final int AppLovinStyledPlayerView_al_buffered_color = 6;
    
    public static final int AppLovinStyledPlayerView_al_controller_layout_id = 7;
    
    public static final int AppLovinStyledPlayerView_al_default_artwork = 8;
    
    public static final int AppLovinStyledPlayerView_al_hide_during_ads = 9;
    
    public static final int AppLovinStyledPlayerView_al_hide_on_touch = 10;
    
    public static final int AppLovinStyledPlayerView_al_keep_content_on_player_reset = 11;
    
    public static final int AppLovinStyledPlayerView_al_played_ad_marker_color = 12;
    
    public static final int AppLovinStyledPlayerView_al_played_color = 13;
    
    public static final int AppLovinStyledPlayerView_al_player_layout_id = 14;
    
    public static final int AppLovinStyledPlayerView_al_repeat_toggle_modes = 15;
    
    public static final int AppLovinStyledPlayerView_al_resize_mode = 16;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_color = 17;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_disabled_size = 18;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_dragged_size = 19;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_drawable = 20;
    
    public static final int AppLovinStyledPlayerView_al_scrubber_enabled_size = 21;
    
    public static final int AppLovinStyledPlayerView_al_show_buffering = 22;
    
    public static final int AppLovinStyledPlayerView_al_show_shuffle_button = 23;
    
    public static final int AppLovinStyledPlayerView_al_show_subtitle_button = 24;
    
    public static final int AppLovinStyledPlayerView_al_show_timeout = 25;
    
    public static final int AppLovinStyledPlayerView_al_show_vr_button = 26;
    
    public static final int AppLovinStyledPlayerView_al_shutter_background_color = 27;
    
    public static final int AppLovinStyledPlayerView_al_surface_type = 28;
    
    public static final int AppLovinStyledPlayerView_al_time_bar_min_update_interval = 29;
    
    public static final int AppLovinStyledPlayerView_al_touch_target_height = 30;
    
    public static final int AppLovinStyledPlayerView_al_unplayed_color = 31;
    
    public static final int AppLovinStyledPlayerView_al_use_artwork = 32;
    
    public static final int AppLovinStyledPlayerView_al_use_controller = 33;
    
    public static final int[] ButtonBarLayout = new int[] { 2130903120 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] Capability = new int[] { 2130903328, 2130903342 };
    
    public static final int Capability_queryPatterns = 0;
    
    public static final int Capability_shortcutMatchRequired = 1;
    
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130903152, 2130903153, 2130903154, 2130903155, 2130903156, 2130903157, 2130903198, 2130903199, 
        2130903200, 2130903201, 2130903202 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130903121, 2130903269 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130903143, 2130903150, 2130903151 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] CoordinatorLayout = new int[] { 2130903268, 2130903356 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130903273, 2130903274, 2130903275, 2130903276, 2130903277, 2130903278 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130903123, 2130903124, 2130903136, 2130903166, 2130903220, 2130903251, 2130903349, 2130903381 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130903241, 2130903242, 2130903243, 2130903244, 2130903245, 2130903246, 2130903247 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903239, 2130903248, 2130903249, 2130903250, 2130903408 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130903212, 2130903214, 2130903304, 2130903344 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] LoadingImageView = new int[] { 2130903161, 2130903261, 2130903262 };
    
    public static final int LoadingImageView_circleCrop = 0;
    
    public static final int LoadingImageView_imageAspectRatio = 1;
    
    public static final int LoadingImageView_imageAspectRatioAdjust = 2;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130903053, 2130903071, 2130903072, 2130903122, 2130903191, 2130903258, 2130903259, 
        2130903311, 2130903343, 2130903404 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130903323, 2130903357 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130903312 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130903355 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] RecycleListView = new int[] { 2130903313, 2130903316 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] RecyclerView = new int[] { 
        16842948, 16842987, 16842993, 2130903233, 2130903234, 2130903235, 2130903236, 2130903237, 2130903272, 2130903334, 
        2130903348, 2130903354 };
    
    public static final int RecyclerView_android_clipToPadding = 1;
    
    public static final int RecyclerView_android_descendantFocusability = 2;
    
    public static final int RecyclerView_android_orientation = 0;
    
    public static final int RecyclerView_fastScrollEnabled = 3;
    
    public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 4;
    
    public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 5;
    
    public static final int RecyclerView_fastScrollVerticalThumbDrawable = 6;
    
    public static final int RecyclerView_fastScrollVerticalTrackDrawable = 7;
    
    public static final int RecyclerView_layoutManager = 8;
    
    public static final int RecyclerView_reverseLayout = 9;
    
    public static final int RecyclerView_spanCount = 10;
    
    public static final int RecyclerView_stackFromEnd = 11;
    
    public static final int[] RoundRectImageView = new int[] { 2130903205 };
    
    public static final int RoundRectImageView_corner = 0;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130903162, 2130903190, 2130903207, 2130903252, 2130903260, 2130903271, 
        2130903326, 2130903327, 2130903336, 2130903337, 2130903358, 2130903363, 2130903410 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] SignInButton = new int[] { 2130903147, 2130903176, 2130903335 };
    
    public static final int SignInButton_buttonSize = 0;
    
    public static final int SignInButton_colorScheme = 1;
    
    public static final int SignInButton_scopeUris = 2;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130903321 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130903345, 2130903352, 2130903364, 2130903365, 2130903367, 2130903382, 2130903383, 
        2130903384, 2130903405, 2130903406, 2130903407 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130903240, 2130903249, 2130903368, 2130903379 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130903144, 2130903164, 2130903165, 2130903192, 2130903193, 2130903194, 2130903195, 2130903196, 
        2130903197, 2130903295, 2130903296, 2130903297, 2130903305, 2130903307, 2130903308, 2130903321, 2130903359, 2130903360, 
        2130903361, 2130903390, 2130903391, 2130903392, 2130903393, 2130903394, 2130903395, 2130903396, 2130903397, 2130903398 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130903314, 2130903315, 2130903380 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130903134, 2130903135 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
  }
  
  public static final class xml {
    public static final int image_share_filepaths = 2132017155;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\adapters\ironsource\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */