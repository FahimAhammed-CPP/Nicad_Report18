package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.lang.ref.WeakReference;
import y.ey;
import y.td;

public final class ViewStubCompat extends View {
  public int 怖;
  
  public WeakReference 恐;
  
  public int 淋 = 0;
  
  public LayoutInflater 痛;
  
  public ViewStubCompat(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, td.탑, 0, 0);
    this.怖 = typedArray.getResourceId(2, -1);
    this.淋 = typedArray.getResourceId(1, 0);
    setId(typedArray.getResourceId(0, -1));
    typedArray.recycle();
    setVisibility(8);
    setWillNotDraw(true);
  }
  
  public final void dispatchDraw(Canvas paramCanvas) {}
  
  public final void draw(Canvas paramCanvas) {}
  
  public int getInflatedId() {
    return this.怖;
  }
  
  public LayoutInflater getLayoutInflater() {
    return this.痛;
  }
  
  public int getLayoutResource() {
    return this.淋;
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(0, 0);
  }
  
  public void setInflatedId(int paramInt) {
    this.怖 = paramInt;
  }
  
  public void setLayoutInflater(LayoutInflater paramLayoutInflater) {
    this.痛 = paramLayoutInflater;
  }
  
  public void setLayoutResource(int paramInt) {
    this.淋 = paramInt;
  }
  
  public void setOnInflateListener(ey paramey) {}
  
  public void setVisibility(int paramInt) {
    WeakReference<View> weakReference = this.恐;
    if (weakReference != null) {
      View view = weakReference.get();
      if (view != null) {
        view.setVisibility(paramInt);
        return;
      } 
      throw new IllegalStateException("setVisibility called on un-referenced view");
    } 
    super.setVisibility(paramInt);
    if (paramInt == 0 || paramInt == 4)
      硬(); 
  }
  
  public final View 硬() {
    ViewParent viewParent = getParent();
    if (viewParent instanceof ViewGroup) {
      if (this.淋 != 0) {
        ViewGroup viewGroup = (ViewGroup)viewParent;
        LayoutInflater layoutInflater = this.痛;
        if (layoutInflater == null)
          layoutInflater = LayoutInflater.from(getContext()); 
        View view = layoutInflater.inflate(this.淋, viewGroup, false);
        int i = this.怖;
        if (i != -1)
          view.setId(i); 
        i = viewGroup.indexOfChild(this);
        viewGroup.removeViewInLayout(this);
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams != null) {
          viewGroup.addView(view, i, layoutParams);
        } else {
          viewGroup.addView(view, i);
        } 
        this.恐 = new WeakReference<View>(view);
        return view;
      } 
      throw new IllegalArgumentException("ViewStub must have a valid layoutResource");
    } 
    throw new IllegalStateException("ViewStub must have a non-null ViewGroup viewParent");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\ViewStubCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */