package androidx.core.util;

import android.util.SizeF;

public final class SizeFCompat {
  private final float mHeight;
  
  private final float mWidth;
  
  public SizeFCompat(float paramFloat1, float paramFloat2) {
    this.mWidth = Preconditions.checkArgumentFinite(paramFloat1, "width");
    this.mHeight = Preconditions.checkArgumentFinite(paramFloat2, "height");
  }
  
  public static SizeFCompat toSizeFCompat(SizeF paramSizeF) {
    return Api21Impl.toSizeFCompat(paramSizeF);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SizeFCompat))
      return false; 
    paramObject = paramObject;
    return (((SizeFCompat)paramObject).mWidth == this.mWidth && ((SizeFCompat)paramObject).mHeight == this.mHeight);
  }
  
  public float getHeight() {
    return this.mHeight;
  }
  
  public float getWidth() {
    return this.mWidth;
  }
  
  public int hashCode() {
    return Float.floatToIntBits(this.mWidth) ^ Float.floatToIntBits(this.mHeight);
  }
  
  public SizeF toSizeF() {
    return Api21Impl.toSizeF(this);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mWidth);
    stringBuilder.append("x");
    stringBuilder.append(this.mHeight);
    return stringBuilder.toString();
  }
  
  private static final class Api21Impl {
    static SizeF toSizeF(SizeFCompat param1SizeFCompat) {
      Preconditions.checkNotNull(param1SizeFCompat);
      return new SizeF(param1SizeFCompat.getWidth(), param1SizeFCompat.getHeight());
    }
    
    static SizeFCompat toSizeFCompat(SizeF param1SizeF) {
      Preconditions.checkNotNull(param1SizeF);
      return new SizeFCompat(param1SizeF.getWidth(), param1SizeF.getHeight());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\cor\\util\SizeFCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */