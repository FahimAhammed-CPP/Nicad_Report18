package androidx.privacysandbox.ads.adservices.java.internal;

import androidx.concurrent.futures.CallbackToFutureAdapter;
import com.google.common.util.concurrent.ListenableFuture;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.Deferred;

@Metadata(d1 = {"\000\024\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\000\n\000\032*\020\000\032\b\022\004\022\002H\0020\001\"\004\b\000\020\002*\b\022\004\022\002H\0020\0032\n\b\002\020\004\032\004\030\0010\005H\000¨\006\006"}, d2 = {"asListenableFuture", "Lcom/google/common/util/concurrent/ListenableFuture;", "T", "Lkotlinx/coroutines/Deferred;", "tag", "", "ads-adservices-java_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class CoroutineAdapterKt {
  public static final <T> ListenableFuture<T> asListenableFuture(Deferred<? extends T> paramDeferred, Object paramObject) {
    Intrinsics.checkNotNullParameter(paramDeferred, "<this>");
    ListenableFuture<T> listenableFuture = CallbackToFutureAdapter.getFuture((CallbackToFutureAdapter.Resolver)new CoroutineAdapterKt$.ExternalSyntheticLambda0(paramDeferred, paramObject));
    Intrinsics.checkNotNullExpressionValue(listenableFuture, "getFuture { completer ->…        }\n    }\n    tag\n}");
    return listenableFuture;
  }
  
  private static final Object asListenableFuture$lambda$0(Deferred<? extends T> paramDeferred, Object paramObject, CallbackToFutureAdapter.Completer<T> paramCompleter) {
    Intrinsics.checkNotNullParameter(paramDeferred, "$this_asListenableFuture");
    Intrinsics.checkNotNullParameter(paramCompleter, "completer");
    paramDeferred.invokeOnCompletion(new CoroutineAdapterKt$asListenableFuture$1$1(paramCompleter, paramDeferred));
    return paramObject;
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\002\n\002\b\002\n\002\020\003\n\000\020\000\032\0020\001\"\004\b\000\020\0022\b\020\003\032\004\030\0010\004H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "T", "it", "", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class CoroutineAdapterKt$asListenableFuture$1$1 extends Lambda implements Function1<Throwable, Unit> {
    CoroutineAdapterKt$asListenableFuture$1$1(CallbackToFutureAdapter.Completer<T> param1Completer, Deferred<? extends T> param1Deferred) {
      super(1);
    }
    
    public final void invoke(Throwable param1Throwable) {
      if (param1Throwable != null) {
        if (param1Throwable instanceof java.util.concurrent.CancellationException) {
          this.$completer.setCancelled();
          return;
        } 
        this.$completer.setException(param1Throwable);
        return;
      } 
      this.$completer.set(this.$this_asListenableFuture.getCompleted());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\privacysandbox\ads\adservices\java\internal\CoroutineAdapterKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */