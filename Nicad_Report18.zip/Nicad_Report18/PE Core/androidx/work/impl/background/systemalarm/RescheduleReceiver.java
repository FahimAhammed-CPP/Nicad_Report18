package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import y.z00;
import y.獅;
import y.갇;

public class RescheduleReceiver extends BroadcastReceiver {
  static {
    獅.苦("RescheduleReceiver");
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    獅 獅 = 獅.辛();
    String.format("Received intent %s", new Object[] { paramIntent });
    獅.寒(new Throwable[0]);
    if (Build.VERSION.SDK_INT >= 23)
      try {
        null = z00.ニ(paramContext);
        BroadcastReceiver.PendingResult pendingResult = goAsync();
        synchronized (z00.わ) {
          null.ち = pendingResult;
          if (null.か) {
            pendingResult.finish();
            null.ち = null;
          } 
          return;
        } 
      } catch (IllegalStateException illegalStateException) {
        獅.辛().不(new Throwable[] { illegalStateException });
        return;
      }  
    int i = 갇.痛;
    paramIntent = new Intent((Context)illegalStateException, SystemAlarmService.class);
    paramIntent.setAction("ACTION_RESCHEDULE");
    illegalStateException.startService(paramIntent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\background\systemalarm\RescheduleReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */