package com.facebook.share.internal;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.util.Pair;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookRequestError;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.appevents.InternalAppEventsLogger;
import com.facebook.internal.AppCall;
import com.facebook.internal.CallbackManagerImpl;
import com.facebook.internal.NativeAppCallAttachmentStore;
import com.facebook.internal.NativeProtocol;
import com.facebook.internal.Utility;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import com.facebook.share.Sharer;
import com.facebook.share.model.CameraEffectTextures;
import com.facebook.share.model.ShareCameraEffectContent;
import com.facebook.share.model.ShareMedia;
import com.facebook.share.model.ShareMediaContent;
import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.model.ShareStoryContent;
import com.facebook.share.model.ShareVideoContent;
import com.facebook.share.widget.LikeView;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class ShareInternalUtility {
  public static final String MY_PHOTOS = "me/photos";
  
  private static final String MY_STAGING_RESOURCES = "me/staging_resources";
  
  private static final String STAGING_PARAM = "file";
  
  private static AppCall getAppCallFromActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      return (uUID == null) ? null : AppCall.finishPendingCall(uUID, paramInt1);
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, ShareInternalUtility.class);
    } 
  }
  
  private static NativeAppCallAttachmentStore.Attachment getAttachment(UUID paramUUID, Uri paramUri, Bitmap paramBitmap) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramBitmap != null) {
      try {
        return NativeAppCallAttachmentStore.createAttachment(paramUUID, paramBitmap);
      } finally {
        paramUUID = null;
      } 
    } else if (paramUri != null) {
      return NativeAppCallAttachmentStore.createAttachment(paramUUID, paramUri);
    } 
    return null;
  }
  
  private static NativeAppCallAttachmentStore.Attachment getAttachment(UUID paramUUID, ShareMedia paramShareMedia) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      return getAttachment(paramUUID, (Uri)bitmap2, bitmap1);
    } finally {
      paramUUID = null;
      CrashShieldHandler.handleThrowable((Throwable)paramUUID, ShareInternalUtility.class);
    } 
  }
  
  public static Bundle getBackgroundAssetMediaInfo(ShareStoryContent paramShareStoryContent, final UUID appCallId) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramShareStoryContent != null)
      try {
        if (paramShareStoryContent.getBackgroundAsset() == null)
          return null; 
        ArrayList<ShareMedia> arrayList1 = new ArrayList();
        arrayList1.add(paramShareStoryContent.getBackgroundAsset());
        final ArrayList attachments = new ArrayList();
        List<Bundle> list = Utility.map(arrayList1, new Utility.Mapper<ShareMedia, Bundle>() {
              public Bundle apply(ShareMedia param1ShareMedia) {
                NativeAppCallAttachmentStore.Attachment attachment = ShareInternalUtility.access$000(appCallId, param1ShareMedia);
                attachments.add(attachment);
                Bundle bundle = new Bundle();
                bundle.putString("type", param1ShareMedia.getMediaType().name());
                bundle.putString("uri", attachment.getAttachmentUrl());
                String str = ShareInternalUtility.getUriExtension(attachment.getOriginalUri());
                if (str != null)
                  Utility.putNonEmptyString(bundle, "extension", str); 
                return bundle;
              }
            });
        return list.get(0);
      } finally {
        paramShareStoryContent = null;
      }  
    return null;
  }
  
  public static Pair<String, String> getFieldNameAndNamespaceFromFullName(String paramString) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
    
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, ShareInternalUtility.class);
    } 
    Object object = null;
    return new Pair(object, paramString);
  }
  
  public static List<Bundle> getMediaInfos(ShareMediaContent paramShareMediaContent, final UUID appCallId) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramShareMediaContent != null)
      try {
        List list = paramShareMediaContent.getMedia();
        if (list == null)
          return null; 
        final ArrayList attachments = new ArrayList();
        return Utility.map(list, new Utility.Mapper<ShareMedia, Bundle>() {
              public Bundle apply(ShareMedia param1ShareMedia) {
                NativeAppCallAttachmentStore.Attachment attachment = ShareInternalUtility.access$000(appCallId, param1ShareMedia);
                attachments.add(attachment);
                Bundle bundle = new Bundle();
                bundle.putString("type", param1ShareMedia.getMediaType().name());
                bundle.putString("uri", attachment.getAttachmentUrl());
                return bundle;
              }
            });
      } finally {
        paramShareMediaContent = null;
      }  
    return null;
  }
  
  public static LikeView.ObjectType getMostSpecificObjectType(LikeView.ObjectType paramObjectType1, LikeView.ObjectType paramObjectType2) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramObjectType1 == paramObjectType2)
      return paramObjectType1; 
    try {
      return (paramObjectType2 == objectType) ? paramObjectType1 : null;
    } finally {
      paramObjectType1 = null;
      CrashShieldHandler.handleThrowable((Throwable)paramObjectType1, ShareInternalUtility.class);
    } 
  }
  
  public static String getNativeDialogCompletionGesture(Bundle paramBundle) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      return paramBundle.containsKey("completionGesture") ? paramBundle.getString("completionGesture") : paramBundle.getString("com.facebook.platform.extra.COMPLETION_GESTURE");
    } finally {
      paramBundle = null;
      CrashShieldHandler.handleThrowable((Throwable)paramBundle, ShareInternalUtility.class);
    } 
  }
  
  public static List<String> getPhotoUrls(SharePhotoContent paramSharePhotoContent, final UUID appCallId) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramSharePhotoContent != null)
      try {
        List list = paramSharePhotoContent.getPhotos();
        if (list == null)
          return null; 
        list = Utility.map(list, new Utility.Mapper<SharePhoto, NativeAppCallAttachmentStore.Attachment>() {
              public NativeAppCallAttachmentStore.Attachment apply(SharePhoto param1SharePhoto) {
                return ShareInternalUtility.access$000(appCallId, (ShareMedia)param1SharePhoto);
              }
            });
        return Utility.map(list, new Utility.Mapper<NativeAppCallAttachmentStore.Attachment, String>() {
              public String apply(NativeAppCallAttachmentStore.Attachment param1Attachment) {
                return param1Attachment.getAttachmentUrl();
              }
            });
      } finally {
        paramSharePhotoContent = null;
      }  
    return null;
  }
  
  public static String getShareDialogPostId(Bundle paramBundle) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      return paramBundle.containsKey("postId") ? paramBundle.getString("postId") : (paramBundle.containsKey("com.facebook.platform.extra.POST_ID") ? paramBundle.getString("com.facebook.platform.extra.POST_ID") : paramBundle.getString("post_id"));
    } finally {
      paramBundle = null;
      CrashShieldHandler.handleThrowable((Throwable)paramBundle, ShareInternalUtility.class);
    } 
  }
  
  public static ResultProcessor getShareResultProcessor(final FacebookCallback<Sharer.Result> callback) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      return new ResultProcessor(callback) {
          public void onCancel(AppCall param1AppCall) {
            ShareInternalUtility.invokeOnCancelCallback(callback);
          }
          
          public void onError(AppCall param1AppCall, FacebookException param1FacebookException) {
            ShareInternalUtility.invokeOnErrorCallback(callback, param1FacebookException);
          }
          
          public void onSuccess(AppCall param1AppCall, Bundle param1Bundle) {
            if (param1Bundle != null) {
              String str = ShareInternalUtility.getNativeDialogCompletionGesture(param1Bundle);
              if (str == null || "post".equalsIgnoreCase(str)) {
                str = ShareInternalUtility.getShareDialogPostId(param1Bundle);
                ShareInternalUtility.invokeOnSuccessCallback(callback, str);
                return;
              } 
              if ("cancel".equalsIgnoreCase(str)) {
                ShareInternalUtility.invokeOnCancelCallback(callback);
                return;
              } 
              ShareInternalUtility.invokeOnErrorCallback(callback, new FacebookException("UnknownError"));
              return;
            } 
          }
        };
    } finally {
      callback = null;
      CrashShieldHandler.handleThrowable((Throwable)callback, ShareInternalUtility.class);
    } 
  }
  
  public static Bundle getStickerUrl(ShareStoryContent paramShareStoryContent, final UUID appCallId) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramShareStoryContent != null)
      try {
        if (paramShareStoryContent.getStickerAsset() == null)
          return null; 
        ArrayList<SharePhoto> arrayList = new ArrayList();
        arrayList.add(paramShareStoryContent.getStickerAsset());
        List list = Utility.map(arrayList, new Utility.Mapper<SharePhoto, NativeAppCallAttachmentStore.Attachment>() {
              public NativeAppCallAttachmentStore.Attachment apply(SharePhoto param1SharePhoto) {
                return ShareInternalUtility.access$000(appCallId, (ShareMedia)param1SharePhoto);
              }
            });
        List<Bundle> list1 = Utility.map(list, new Utility.Mapper<NativeAppCallAttachmentStore.Attachment, Bundle>() {
              public Bundle apply(NativeAppCallAttachmentStore.Attachment param1Attachment) {
                Bundle bundle = new Bundle();
                bundle.putString("uri", param1Attachment.getAttachmentUrl());
                String str = ShareInternalUtility.getUriExtension(param1Attachment.getOriginalUri());
                if (str != null)
                  Utility.putNonEmptyString(bundle, "extension", str); 
                return bundle;
              }
            });
        return list1.get(0);
      } finally {
        paramShareStoryContent = null;
      }  
    return null;
  }
  
  public static Bundle getTextureUrlBundle(ShareCameraEffectContent paramShareCameraEffectContent, UUID paramUUID) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramShareCameraEffectContent != null)
      try {
        CameraEffectTextures cameraEffectTextures = paramShareCameraEffectContent.getTextures();
        if (cameraEffectTextures == null)
          return null; 
        Bundle bundle = new Bundle();
        ArrayList<NativeAppCallAttachmentStore.Attachment> arrayList = new ArrayList();
        for (String str : cameraEffectTextures.keySet()) {
          NativeAppCallAttachmentStore.Attachment attachment = getAttachment(paramUUID, cameraEffectTextures.getTextureUri(str), cameraEffectTextures.getTextureBitmap(str));
          arrayList.add(attachment);
          bundle.putString(str, attachment.getAttachmentUrl());
        } 
        return bundle;
      } finally {
        paramShareCameraEffectContent = null;
      }  
    return null;
  }
  
  public static String getUriExtension(Uri paramUri) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramUri == null)
      return null; 
    try {
      return (i == -1) ? null : null.substring(i);
    } finally {
      paramUri = null;
      CrashShieldHandler.handleThrowable((Throwable)paramUri, ShareInternalUtility.class);
    } 
  }
  
  public static String getVideoUrl(ShareVideoContent paramShareVideoContent, UUID paramUUID) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramShareVideoContent != null)
      try {
        if (paramShareVideoContent.getVideo() == null)
          return null; 
        NativeAppCallAttachmentStore.Attachment attachment = NativeAppCallAttachmentStore.createAttachment(paramUUID, paramShareVideoContent.getVideo().getLocalUrl());
        ArrayList<NativeAppCallAttachmentStore.Attachment> arrayList = new ArrayList(1);
        arrayList.add(attachment);
        return attachment.getAttachmentUrl();
      } finally {
        paramShareVideoContent = null;
      }  
    return null;
  }
  
  public static boolean handleActivityResult(int paramInt1, int paramInt2, Intent paramIntent, ResultProcessor paramResultProcessor) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return false; 
    try {
      AppCall appCall = getAppCallFromActivityResult(paramInt1, paramInt2, paramIntent);
      if (appCall == null)
        return false; 
      NativeAppCallAttachmentStore.cleanupAttachmentsForCall(appCall.getCallId());
      if (paramResultProcessor == null)
        return true; 
      FacebookException facebookException = NativeProtocol.getExceptionFromErrorData(NativeProtocol.getErrorDataFromResultIntent(paramIntent));
      return true;
    } finally {
      paramIntent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramIntent, ShareInternalUtility.class);
    } 
  }
  
  public static void invokeCallbackWithError(FacebookCallback<Sharer.Result> paramFacebookCallback, String paramString) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      return;
    } finally {
      paramFacebookCallback = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookCallback, ShareInternalUtility.class);
    } 
  }
  
  public static void invokeCallbackWithException(FacebookCallback<Sharer.Result> paramFacebookCallback, Exception paramException) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      if (paramException instanceof FacebookException)
        return; 
      StringBuilder stringBuilder = new StringBuilder("Error preparing share content: ");
      return;
    } finally {
      paramFacebookCallback = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookCallback, ShareInternalUtility.class);
    } 
  }
  
  public static void invokeCallbackWithResults(FacebookCallback<Sharer.Result> paramFacebookCallback, String paramString, GraphResponse paramGraphResponse) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      FacebookRequestError facebookRequestError = paramGraphResponse.getError();
      return;
    } finally {
      paramFacebookCallback = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookCallback, ShareInternalUtility.class);
    } 
  }
  
  static void invokeOnCancelCallback(FacebookCallback<Sharer.Result> paramFacebookCallback) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      return;
    } finally {
      paramFacebookCallback = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookCallback, ShareInternalUtility.class);
    } 
  }
  
  static void invokeOnErrorCallback(FacebookCallback<Sharer.Result> paramFacebookCallback, FacebookException paramFacebookException) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      return;
    } finally {
      paramFacebookCallback = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookCallback, ShareInternalUtility.class);
    } 
  }
  
  static void invokeOnErrorCallback(FacebookCallback<Sharer.Result> paramFacebookCallback, GraphResponse paramGraphResponse, String paramString) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      return;
    } finally {
      paramFacebookCallback = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookCallback, ShareInternalUtility.class);
    } 
  }
  
  static void invokeOnErrorCallback(FacebookCallback<Sharer.Result> paramFacebookCallback, String paramString) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      return;
    } finally {
      paramFacebookCallback = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookCallback, ShareInternalUtility.class);
    } 
  }
  
  static void invokeOnSuccessCallback(FacebookCallback<Sharer.Result> paramFacebookCallback, String paramString) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      return;
    } finally {
      paramFacebookCallback = null;
      CrashShieldHandler.handleThrowable((Throwable)paramFacebookCallback, ShareInternalUtility.class);
    } 
  }
  
  private static void logShareResult(String paramString1, String paramString2) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      InternalAppEventsLogger internalAppEventsLogger = new InternalAppEventsLogger(FacebookSdk.getApplicationContext());
      Bundle bundle = new Bundle();
      bundle.putString("fb_share_dialog_outcome", paramString1);
      return;
    } finally {
      paramString1 = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString1, ShareInternalUtility.class);
    } 
  }
  
  public static GraphRequest newUploadStagingResourceWithImageRequest(AccessToken paramAccessToken, Bitmap paramBitmap, GraphRequest.Callback paramCallback) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      return new GraphRequest(paramAccessToken, "me/staging_resources", bundle, HttpMethod.POST, paramCallback);
    } finally {
      paramAccessToken = null;
      CrashShieldHandler.handleThrowable((Throwable)paramAccessToken, ShareInternalUtility.class);
    } 
  }
  
  public static GraphRequest newUploadStagingResourceWithImageRequest(AccessToken paramAccessToken, Uri paramUri, GraphRequest.Callback paramCallback) throws FileNotFoundException {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      if (Utility.isFileUri(paramUri))
        return newUploadStagingResourceWithImageRequest(paramAccessToken, new File(paramUri.getPath()), paramCallback); 
      if (Utility.isContentUri(paramUri)) {
        GraphRequest.ParcelableResourceWithMimeType parcelableResourceWithMimeType = new GraphRequest.ParcelableResourceWithMimeType((Parcelable)paramUri, "image/png");
        return new GraphRequest(paramAccessToken, "me/staging_resources", bundle, HttpMethod.POST, paramCallback);
      } 
      throw new FacebookException("The image Uri must be either a file:// or content:// Uri");
    } finally {
      paramAccessToken = null;
      CrashShieldHandler.handleThrowable((Throwable)paramAccessToken, ShareInternalUtility.class);
    } 
  }
  
  public static GraphRequest newUploadStagingResourceWithImageRequest(AccessToken paramAccessToken, File paramFile, GraphRequest.Callback paramCallback) throws FileNotFoundException {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      GraphRequest.ParcelableResourceWithMimeType parcelableResourceWithMimeType = new GraphRequest.ParcelableResourceWithMimeType((Parcelable)ParcelFileDescriptor.open(paramFile, 268435456), "image/png");
      return new GraphRequest(paramAccessToken, "me/staging_resources", bundle, HttpMethod.POST, paramCallback);
    } finally {
      paramAccessToken = null;
      CrashShieldHandler.handleThrowable((Throwable)paramAccessToken, ShareInternalUtility.class);
    } 
  }
  
  public static void registerSharerCallback(int paramInt, CallbackManager paramCallbackManager, FacebookCallback<Sharer.Result> paramFacebookCallback) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      if (paramCallbackManager instanceof CallbackManagerImpl)
        return; 
      throw new FacebookException("Unexpected CallbackManager, please use the provided Factory.");
    } finally {
      paramCallbackManager = null;
      CrashShieldHandler.handleThrowable((Throwable)paramCallbackManager, ShareInternalUtility.class);
    } 
  }
  
  public static void registerStaticShareCallback(int paramInt) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return; 
    try {
      return;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, ShareInternalUtility.class);
    } 
  }
  
  public static JSONArray removeNamespacesFromOGJsonArray(JSONArray paramJSONArray, boolean paramBoolean) throws JSONException {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      int i;
      return jSONArray;
    } finally {
      paramJSONArray = null;
      CrashShieldHandler.handleThrowable((Throwable)paramJSONArray, ShareInternalUtility.class);
    } 
  }
  
  public static JSONObject removeNamespacesFromOGJsonObject(JSONObject paramJSONObject, boolean paramBoolean) {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    if (paramJSONObject == null)
      return null; 
    try {
      int i;
      JSONObject jSONObject1 = new JSONObject();
      JSONObject jSONObject2 = new JSONObject();
    } catch (JSONException jSONException) {
      throw new FacebookException("Failed to create json object from share content");
    } finally {
      paramJSONObject = null;
      CrashShieldHandler.handleThrowable((Throwable)paramJSONObject, ShareInternalUtility.class);
    } 
  }
  
  public static JSONObject toJSONObjectForCall(final UUID callId, ShareOpenGraphContent paramShareOpenGraphContent) throws JSONException {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      ShareOpenGraphAction shareOpenGraphAction = paramShareOpenGraphContent.getAction();
      final ArrayList attachments = new ArrayList();
      JSONObject jSONObject = OpenGraphJSONUtility.toJSONObject(shareOpenGraphAction, new OpenGraphJSONUtility.PhotoJSONProcessor() {
            public JSONObject toJSONObject(SharePhoto param1SharePhoto) {
              NativeAppCallAttachmentStore.Attachment attachment = ShareInternalUtility.access$000(callId, (ShareMedia)param1SharePhoto);
              if (attachment == null)
                return null; 
              attachments.add(attachment);
              JSONObject jSONObject = new JSONObject();
              try {
                jSONObject.put("url", attachment.getAttachmentUrl());
                if (param1SharePhoto.getUserGenerated())
                  jSONObject.put("user_generated", true); 
                return jSONObject;
              } catch (JSONException jSONException) {
                throw new FacebookException("Unable to attach images", jSONException);
              } 
            }
          });
      NativeAppCallAttachmentStore.addAttachments(arrayList);
      return jSONObject;
    } finally {
      callId = null;
      CrashShieldHandler.handleThrowable((Throwable)callId, ShareInternalUtility.class);
    } 
  }
  
  public static JSONObject toJSONObjectForWeb(ShareOpenGraphContent paramShareOpenGraphContent) throws JSONException {
    if (CrashShieldHandler.isObjectCrashing(ShareInternalUtility.class))
      return null; 
    try {
      return OpenGraphJSONUtility.toJSONObject(paramShareOpenGraphContent.getAction(), new OpenGraphJSONUtility.PhotoJSONProcessor() {
            public JSONObject toJSONObject(SharePhoto param1SharePhoto) {
              Uri uri = param1SharePhoto.getImageUrl();
              if (Utility.isWebUri(uri)) {
                JSONObject jSONObject = new JSONObject();
                try {
                  jSONObject.put("url", uri.toString());
                  return jSONObject;
                } catch (JSONException jSONException) {
                  throw new FacebookException("Unable to attach images", jSONException);
                } 
              } 
              throw new FacebookException("Only web images may be used in OG objects shared via the web dialog");
            }
          });
    } finally {
      paramShareOpenGraphContent = null;
      CrashShieldHandler.handleThrowable((Throwable)paramShareOpenGraphContent, ShareInternalUtility.class);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\internal\ShareInternalUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */