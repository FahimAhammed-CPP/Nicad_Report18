package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.WeakHashMap;
import y.af;
import y.aw;
import y.bf;
import y.ex;
import y.ik;
import y.l8;
import y.om;
import y.pe;
import y.pm;
import y.qe;
import y.rm;
import y.rw;
import y.sm;
import y.we;
import y.み;
import y.コ;
import y.賊;
import y.邪;
import y.빈;
import y.표;

public class StaggeredGridLayoutManager extends pe implements af {
  public int[] あ;
  
  public final 빈 か;
  
  public final Rect 噛;
  
  public int 壊;
  
  public rm 寝;
  
  public int 帰;
  
  public sm[] 怖;
  
  public l8 恐;
  
  public final boolean 投;
  
  public final int 歩;
  
  public BitSet 死;
  
  public boolean 泳;
  
  public int 淋 = -1;
  
  public boolean 産;
  
  public int 痒;
  
  public l8 痛;
  
  public int 臭;
  
  public boolean 興;
  
  public final om 触;
  
  public final み 起;
  
  public boolean 踊;
  
  public final ex 返;
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    boolean bool = false;
    this.興 = false;
    this.産 = false;
    this.壊 = -1;
    this.帰 = Integer.MIN_VALUE;
    ex ex1 = new ex(1);
    this.返 = ex1;
    this.歩 = 2;
    this.噛 = new Rect();
    this.触 = new om(this);
    this.投 = true;
    this.か = new 빈(1, this);
    RecyclerView$LayoutManager$Properties recyclerView$LayoutManager$Properties = pe.踊(paramContext, paramAttributeSet, paramInt1, paramInt2);
    paramInt1 = recyclerView$LayoutManager$Properties.硬;
    if (paramInt1 == 0 || paramInt1 == 1) {
      熱(null);
      if (paramInt1 != this.痒) {
        this.痒 = paramInt1;
        l8 l81 = this.恐;
        this.恐 = this.痛;
        this.痛 = l81;
        탱();
      } 
      paramInt1 = recyclerView$LayoutManager$Properties.堅;
      熱(null);
      if (paramInt1 != this.淋) {
        ex1.暑();
        탱();
        this.淋 = paramInt1;
        this.死 = new BitSet(this.淋);
        this.怖 = new sm[this.淋];
        for (paramInt1 = bool; paramInt1 < this.淋; paramInt1++)
          this.怖[paramInt1] = new sm(this, paramInt1); 
        탱();
      } 
      boolean bool1 = recyclerView$LayoutManager$Properties.熱;
      熱(null);
      rm rm1 = this.寝;
      if (rm1 != null && rm1.興 != bool1)
        rm1.興 = bool1; 
      this.興 = bool1;
      탱();
      this.起 = new み();
      this.恐 = (l8)l8.硬(this, this.痒);
      this.痛 = (l8)l8.硬(this, 1 - this.痒);
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public static int さ(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int i = View.MeasureSpec.getMode(paramInt1);
    return (i == Integer.MIN_VALUE || i == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i) : paramInt1;
  }
  
  public final int う(we paramwe, み paramみ, bf parambf) {
    int i;
    this.死.set(0, this.淋, true);
    み み1 = this.起;
    if (み1.不) {
      if (paramみ.冷 == 1) {
        i = Integer.MAX_VALUE;
      } else {
        i = Integer.MIN_VALUE;
      } 
    } else if (paramみ.冷 == 1) {
      i = paramみ.美 + paramみ.堅;
    } else {
      i = paramみ.寒 - paramみ.堅;
    } 
    int k = paramみ.冷;
    int j;
    for (j = 0; j < this.淋; j++) {
      if (!(this.怖[j]).硬.isEmpty())
        け(this.怖[j], k, i); 
    } 
    if (this.産) {
      k = this.恐.寒();
    } else {
      k = this.恐.旨();
    } 
    j = 0;
    while (true) {
      int m = paramみ.熱;
      if (m >= 0 && m < parambf.堅()) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m != 0 && (み1.不 || !this.死.isEmpty())) {
        int n;
        int i1;
        sm sm1;
        View view = (paramwe.不(paramみ.熱, Long.MAX_VALUE)).硬;
        paramみ.熱 += paramみ.暑;
        pm pm = (pm)view.getLayoutParams();
        int i2 = pm.硬();
        ex ex1 = this.返;
        int[] arrayOfInt = (int[])ex1.堅;
        if (arrayOfInt == null || i2 >= arrayOfInt.length) {
          j = -1;
        } else {
          j = arrayOfInt[i2];
        } 
        if (j == -1) {
          m = 1;
        } else {
          m = 0;
        } 
        if (m != 0) {
          sm sm2;
          if (せ(paramみ.冷)) {
            j = this.淋 - 1;
            m = -1;
            n = -1;
          } else {
            m = this.淋;
            j = 0;
            n = 1;
          } 
          i1 = paramみ.冷;
          int[] arrayOfInt1 = null;
          arrayOfInt = null;
          if (i1 == 1) {
            int i3 = this.恐.旨();
            i1 = Integer.MAX_VALUE;
            while (true) {
              arrayOfInt1 = arrayOfInt;
              if (j != m) {
                sm2 = this.怖[j];
                int i5 = sm2.寒(i3);
                int i4 = i1;
                if (i5 < i1) {
                  i4 = i5;
                  sm sm3 = sm2;
                } 
                j += n;
                i1 = i4;
                continue;
              } 
              break;
            } 
          } else {
            int i3 = this.恐.寒();
            i1 = Integer.MIN_VALUE;
            sm sm3 = sm2;
            while (true) {
              sm2 = sm3;
              if (j != m) {
                sm2 = this.怖[j];
                int i5 = sm2.不(i3);
                int i4 = i1;
                if (i5 > i1) {
                  sm3 = sm2;
                  i4 = i5;
                } 
                j += n;
                i1 = i4;
                continue;
              } 
              break;
            } 
          } 
          sm1 = sm2;
          ex1.冷(i2);
          ((int[])ex1.堅)[i2] = sm1.冷;
        } else {
          sm1 = this.怖[j];
        } 
        pm.冷 = sm1;
        if (paramみ.冷 == 1) {
          堅(-1, view, false);
        } else {
          堅(0, view, false);
        } 
        if (this.痒 == 1) {
          j = pe.興(false, this.臭, this.苦, 0, ((ViewGroup.MarginLayoutParams)pm).width);
          m = this.寂;
          n = this.嬉;
          i1 = 歩();
          科(view, j, pe.興(true, m, n, 壊() + i1, ((ViewGroup.MarginLayoutParams)pm).height), false);
        } else {
          j = this.悲;
          m = this.苦;
          n = 帰();
          科(view, pe.興(true, j, m, 返() + n, ((ViewGroup.MarginLayoutParams)pm).width), pe.興(false, this.臭, this.嬉, 0, ((ViewGroup.MarginLayoutParams)pm).height), false);
        } 
        if (paramみ.冷 == 1) {
          j = sm1.寒(k);
          m = this.恐.熱(view) + j;
        } else {
          m = sm1.不(k);
          j = m - this.恐.熱(view);
        } 
        if (paramみ.冷 == 1) {
          sm sm2 = pm.冷;
          sm2.getClass();
          pm = (pm)view.getLayoutParams();
          pm.冷 = sm2;
          ArrayList<View> arrayList = sm2.硬;
          arrayList.add(view);
          sm2.熱 = Integer.MIN_VALUE;
          if (arrayList.size() == 1)
            sm2.堅 = Integer.MIN_VALUE; 
          if (pm.熱() || pm.堅()) {
            n = sm2.暑;
            sm2.暑 = sm2.寒.恐.熱(view) + n;
          } 
        } else {
          sm sm2 = pm.冷;
          sm2.getClass();
          pm = (pm)view.getLayoutParams();
          pm.冷 = sm2;
          ArrayList<View> arrayList = sm2.硬;
          arrayList.add(0, view);
          sm2.堅 = Integer.MIN_VALUE;
          if (arrayList.size() == 1)
            sm2.熱 = Integer.MIN_VALUE; 
          if (pm.熱() || pm.堅()) {
            n = sm2.暑;
            sm2.暑 = sm2.寒.恐.熱(view) + n;
          } 
        } 
        if (歯() && this.痒 == 1) {
          n = this.痛.寒() - (this.淋 - 1 - sm1.冷) * this.臭;
          i1 = n - this.痛.熱(view);
        } else {
          n = sm1.冷;
          i1 = this.臭;
          i1 = this.痛.旨() + n * i1;
          n = this.痛.熱(view) + i1;
        } 
        if (this.痒 == 1) {
          pe.あ(view, i1, j, n, m);
        } else {
          pe.あ(view, j, i1, m, n);
        } 
        け(sm1, み1.冷, i);
        治(paramwe, み1);
        if (み1.旨 && view.hasFocusable())
          this.死.set(sm1.冷, false); 
        j = 1;
        continue;
      } 
      break;
    } 
    if (j == 0)
      治(paramwe, み1); 
    if (み1.冷 == -1) {
      i = 師(this.恐.旨());
      i = this.恐.旨() - i;
    } else {
      i = 護(this.恐.寒()) - this.恐.寒();
    } 
    return (i > 0) ? Math.min(paramみ.堅, i) : 0;
  }
  
  public final void か(int paramInt) {
    super.か(paramInt);
    for (int i = 0; i < this.淋; i++) {
      sm sm1 = this.怖[i];
      int j = sm1.堅;
      if (j != Integer.MIN_VALUE)
        sm1.堅 = j + paramInt; 
      j = sm1.熱;
      if (j != Integer.MIN_VALUE)
        sm1.熱 = j + paramInt; 
    } 
  }
  
  public final boolean く() {
    return (this.寝 == null);
  }
  
  public final void け(sm paramsm, int paramInt1, int paramInt2) {
    int i = paramsm.暑;
    int j = paramsm.冷;
    if (paramInt1 == -1) {
      paramInt1 = paramsm.堅;
      if (paramInt1 == Integer.MIN_VALUE) {
        View view = paramsm.硬.get(0);
        pm pm = sm.旨(view);
        paramsm.堅 = paramsm.寒.恐.暑(view);
        pm.getClass();
        paramInt1 = paramsm.堅;
      } 
      if (paramInt1 + i <= paramInt2) {
        this.死.set(j, false);
        return;
      } 
    } else {
      paramInt1 = paramsm.熱;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramsm.硬();
        paramInt1 = paramsm.熱;
      } 
      if (paramInt1 - i >= paramInt2)
        this.死.set(j, false); 
    } 
  }
  
  public final int ご() {
    return (起() == 0) ? 0 : pe.泳(臭(0));
  }
  
  public final void し(RecyclerView paramRecyclerView, int paramInt) {
    邪 邪 = new 邪(paramRecyclerView.getContext());
    邪.硬 = paramInt;
    私(邪);
  }
  
  public final boolean せ(int paramInt) {
    boolean bool;
    if (this.痒 == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return (bool != this.産);
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.産) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool == 歯());
  }
  
  public final void ち(int paramInt) {
    super.ち(paramInt);
    for (int i = 0; i < this.淋; i++) {
      sm sm1 = this.怖[i];
      int j = sm1.堅;
      if (j != Integer.MIN_VALUE)
        sm1.堅 = j + paramInt; 
      j = sm1.熱;
      if (j != Integer.MIN_VALUE)
        sm1.熱 = j + paramInt; 
    } 
  }
  
  public final View ね(boolean paramBoolean) {
    int j = this.恐.旨();
    int k = this.恐.寒();
    int m = 起();
    View view = null;
    int i = 0;
    while (i < m) {
      View view2 = 臭(i);
      int n = this.恐.暑(view2);
      View view1 = view;
      if (this.恐.堅(view2) > j)
        if (n >= k) {
          view1 = view;
        } else if (n < j) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i++;
      view = view1;
    } 
    return view;
  }
  
  public final void は(we paramwe, bf parambf, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 寝 : Ly/rm;
    //   4: astore #14
    //   6: aload_0
    //   7: getfield 触 : Ly/om;
    //   10: astore #13
    //   12: aload #14
    //   14: ifnonnull -> 25
    //   17: aload_0
    //   18: getfield 壊 : I
    //   21: iconst_m1
    //   22: if_icmpeq -> 43
    //   25: aload_2
    //   26: invokevirtual 堅 : ()I
    //   29: ifne -> 43
    //   32: aload_0
    //   33: aload_1
    //   34: invokevirtual 탐 : (Ly/we;)V
    //   37: aload #13
    //   39: invokevirtual 硬 : ()V
    //   42: return
    //   43: aload #13
    //   45: getfield 冷 : Z
    //   48: istore #12
    //   50: iconst_1
    //   51: istore #9
    //   53: iload #12
    //   55: ifeq -> 82
    //   58: aload_0
    //   59: getfield 壊 : I
    //   62: iconst_m1
    //   63: if_icmpne -> 82
    //   66: aload_0
    //   67: getfield 寝 : Ly/rm;
    //   70: ifnull -> 76
    //   73: goto -> 82
    //   76: iconst_0
    //   77: istore #7
    //   79: goto -> 85
    //   82: iconst_1
    //   83: istore #7
    //   85: aload #13
    //   87: getfield 美 : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   90: astore #14
    //   92: aload_0
    //   93: getfield 返 : Ly/ex;
    //   96: astore #15
    //   98: iload #7
    //   100: ifeq -> 1125
    //   103: aload #13
    //   105: invokevirtual 硬 : ()V
    //   108: aload_0
    //   109: getfield 寝 : Ly/rm;
    //   112: astore #16
    //   114: aload #16
    //   116: ifnull -> 445
    //   119: aload #16
    //   121: getfield 恐 : I
    //   124: istore #6
    //   126: iload #6
    //   128: ifle -> 297
    //   131: iload #6
    //   133: aload_0
    //   134: getfield 淋 : I
    //   137: if_icmpne -> 257
    //   140: iconst_0
    //   141: istore #6
    //   143: iload #6
    //   145: aload_0
    //   146: getfield 淋 : I
    //   149: if_icmpge -> 297
    //   152: aload_0
    //   153: getfield 怖 : [Ly/sm;
    //   156: iload #6
    //   158: aaload
    //   159: invokevirtual 堅 : ()V
    //   162: aload_0
    //   163: getfield 寝 : Ly/rm;
    //   166: astore #16
    //   168: aload #16
    //   170: getfield 痛 : [I
    //   173: iload #6
    //   175: iaload
    //   176: istore #10
    //   178: iload #10
    //   180: istore #8
    //   182: iload #10
    //   184: ldc -2147483648
    //   186: if_icmpeq -> 225
    //   189: aload #16
    //   191: getfield 産 : Z
    //   194: ifeq -> 209
    //   197: aload_0
    //   198: getfield 恐 : Ly/l8;
    //   201: invokevirtual 寒 : ()I
    //   204: istore #8
    //   206: goto -> 218
    //   209: aload_0
    //   210: getfield 恐 : Ly/l8;
    //   213: invokevirtual 旨 : ()I
    //   216: istore #8
    //   218: iload #10
    //   220: iload #8
    //   222: iadd
    //   223: istore #8
    //   225: aload_0
    //   226: getfield 怖 : [Ly/sm;
    //   229: iload #6
    //   231: aaload
    //   232: astore #16
    //   234: aload #16
    //   236: iload #8
    //   238: putfield 堅 : I
    //   241: aload #16
    //   243: iload #8
    //   245: putfield 熱 : I
    //   248: iload #6
    //   250: iconst_1
    //   251: iadd
    //   252: istore #6
    //   254: goto -> 143
    //   257: aload #16
    //   259: aconst_null
    //   260: putfield 痛 : [I
    //   263: aload #16
    //   265: iconst_0
    //   266: putfield 恐 : I
    //   269: aload #16
    //   271: iconst_0
    //   272: putfield 痒 : I
    //   275: aload #16
    //   277: aconst_null
    //   278: putfield 臭 : [I
    //   281: aload #16
    //   283: aconst_null
    //   284: putfield 起 : Ljava/util/List;
    //   287: aload #16
    //   289: aload #16
    //   291: getfield 怖 : I
    //   294: putfield 淋 : I
    //   297: aload_0
    //   298: getfield 寝 : Ly/rm;
    //   301: astore #16
    //   303: aload_0
    //   304: aload #16
    //   306: getfield 死 : Z
    //   309: putfield 踊 : Z
    //   312: aload #16
    //   314: getfield 興 : Z
    //   317: istore #12
    //   319: aload_0
    //   320: aconst_null
    //   321: invokevirtual 熱 : (Ljava/lang/String;)V
    //   324: aload_0
    //   325: getfield 寝 : Ly/rm;
    //   328: astore #16
    //   330: aload #16
    //   332: ifnull -> 352
    //   335: aload #16
    //   337: getfield 興 : Z
    //   340: iload #12
    //   342: if_icmpeq -> 352
    //   345: aload #16
    //   347: iload #12
    //   349: putfield 興 : Z
    //   352: aload_0
    //   353: iload #12
    //   355: putfield 興 : Z
    //   358: aload_0
    //   359: invokevirtual 탱 : ()V
    //   362: aload_0
    //   363: invokevirtual 弁 : ()V
    //   366: aload_0
    //   367: getfield 寝 : Ly/rm;
    //   370: astore #16
    //   372: aload #16
    //   374: getfield 淋 : I
    //   377: istore #6
    //   379: iload #6
    //   381: iconst_m1
    //   382: if_icmpeq -> 404
    //   385: aload_0
    //   386: iload #6
    //   388: putfield 壊 : I
    //   391: aload #13
    //   393: aload #16
    //   395: getfield 産 : Z
    //   398: putfield 熱 : Z
    //   401: goto -> 413
    //   404: aload #13
    //   406: aload_0
    //   407: getfield 産 : Z
    //   410: putfield 熱 : Z
    //   413: aload #16
    //   415: getfield 痒 : I
    //   418: iconst_1
    //   419: if_icmple -> 458
    //   422: aload #15
    //   424: aload #16
    //   426: getfield 臭 : [I
    //   429: putfield 堅 : Ljava/lang/Object;
    //   432: aload #15
    //   434: aload #16
    //   436: getfield 起 : Ljava/util/List;
    //   439: putfield 熱 : Ljava/lang/Object;
    //   442: goto -> 458
    //   445: aload_0
    //   446: invokevirtual 弁 : ()V
    //   449: aload #13
    //   451: aload_0
    //   452: getfield 産 : Z
    //   455: putfield 熱 : Z
    //   458: aload_2
    //   459: getfield 美 : Z
    //   462: ifne -> 962
    //   465: aload_0
    //   466: getfield 壊 : I
    //   469: istore #6
    //   471: iload #6
    //   473: iconst_m1
    //   474: if_icmpne -> 480
    //   477: goto -> 962
    //   480: iload #6
    //   482: iflt -> 951
    //   485: iload #6
    //   487: aload_2
    //   488: invokevirtual 堅 : ()I
    //   491: if_icmplt -> 497
    //   494: goto -> 951
    //   497: aload_0
    //   498: getfield 寝 : Ly/rm;
    //   501: astore #16
    //   503: aload #16
    //   505: ifnull -> 548
    //   508: aload #16
    //   510: getfield 淋 : I
    //   513: iconst_m1
    //   514: if_icmpeq -> 548
    //   517: aload #16
    //   519: getfield 恐 : I
    //   522: iconst_1
    //   523: if_icmpge -> 529
    //   526: goto -> 548
    //   529: aload #13
    //   531: ldc -2147483648
    //   533: putfield 堅 : I
    //   536: aload #13
    //   538: aload_0
    //   539: getfield 壊 : I
    //   542: putfield 硬 : I
    //   545: goto -> 945
    //   548: aload_0
    //   549: aload_0
    //   550: getfield 壊 : I
    //   553: invokevirtual 怖 : (I)Landroid/view/View;
    //   556: astore #16
    //   558: aload #16
    //   560: ifnull -> 806
    //   563: aload_0
    //   564: getfield 産 : Z
    //   567: ifeq -> 579
    //   570: aload_0
    //   571: invokevirtual 看 : ()I
    //   574: istore #6
    //   576: goto -> 585
    //   579: aload_0
    //   580: invokevirtual ご : ()I
    //   583: istore #6
    //   585: aload #13
    //   587: iload #6
    //   589: putfield 硬 : I
    //   592: aload_0
    //   593: getfield 帰 : I
    //   596: ldc -2147483648
    //   598: if_icmpeq -> 669
    //   601: aload #13
    //   603: getfield 熱 : Z
    //   606: ifeq -> 639
    //   609: aload #13
    //   611: aload_0
    //   612: getfield 恐 : Ly/l8;
    //   615: invokevirtual 寒 : ()I
    //   618: aload_0
    //   619: getfield 帰 : I
    //   622: isub
    //   623: aload_0
    //   624: getfield 恐 : Ly/l8;
    //   627: aload #16
    //   629: invokevirtual 堅 : (Landroid/view/View;)I
    //   632: isub
    //   633: putfield 堅 : I
    //   636: goto -> 945
    //   639: aload #13
    //   641: aload_0
    //   642: getfield 恐 : Ly/l8;
    //   645: invokevirtual 旨 : ()I
    //   648: aload_0
    //   649: getfield 帰 : I
    //   652: iadd
    //   653: aload_0
    //   654: getfield 恐 : Ly/l8;
    //   657: aload #16
    //   659: invokevirtual 暑 : (Landroid/view/View;)I
    //   662: isub
    //   663: putfield 堅 : I
    //   666: goto -> 945
    //   669: aload_0
    //   670: getfield 恐 : Ly/l8;
    //   673: aload #16
    //   675: invokevirtual 熱 : (Landroid/view/View;)I
    //   678: aload_0
    //   679: getfield 恐 : Ly/l8;
    //   682: invokevirtual 不 : ()I
    //   685: if_icmple -> 727
    //   688: aload #13
    //   690: getfield 熱 : Z
    //   693: ifeq -> 708
    //   696: aload_0
    //   697: getfield 恐 : Ly/l8;
    //   700: invokevirtual 寒 : ()I
    //   703: istore #6
    //   705: goto -> 717
    //   708: aload_0
    //   709: getfield 恐 : Ly/l8;
    //   712: invokevirtual 旨 : ()I
    //   715: istore #6
    //   717: aload #13
    //   719: iload #6
    //   721: putfield 堅 : I
    //   724: goto -> 945
    //   727: aload_0
    //   728: getfield 恐 : Ly/l8;
    //   731: aload #16
    //   733: invokevirtual 暑 : (Landroid/view/View;)I
    //   736: aload_0
    //   737: getfield 恐 : Ly/l8;
    //   740: invokevirtual 旨 : ()I
    //   743: isub
    //   744: istore #6
    //   746: iload #6
    //   748: ifge -> 762
    //   751: aload #13
    //   753: iload #6
    //   755: ineg
    //   756: putfield 堅 : I
    //   759: goto -> 945
    //   762: aload_0
    //   763: getfield 恐 : Ly/l8;
    //   766: invokevirtual 寒 : ()I
    //   769: aload_0
    //   770: getfield 恐 : Ly/l8;
    //   773: aload #16
    //   775: invokevirtual 堅 : (Landroid/view/View;)I
    //   778: isub
    //   779: istore #6
    //   781: iload #6
    //   783: ifge -> 796
    //   786: aload #13
    //   788: iload #6
    //   790: putfield 堅 : I
    //   793: goto -> 945
    //   796: aload #13
    //   798: ldc -2147483648
    //   800: putfield 堅 : I
    //   803: goto -> 945
    //   806: aload_0
    //   807: getfield 壊 : I
    //   810: istore #6
    //   812: aload #13
    //   814: iload #6
    //   816: putfield 硬 : I
    //   819: aload_0
    //   820: getfield 帰 : I
    //   823: istore #8
    //   825: iload #8
    //   827: ldc -2147483648
    //   829: if_icmpne -> 896
    //   832: aload_0
    //   833: iload #6
    //   835: invokevirtual ぼ : (I)I
    //   838: iconst_1
    //   839: if_icmpne -> 848
    //   842: iconst_1
    //   843: istore #12
    //   845: goto -> 851
    //   848: iconst_0
    //   849: istore #12
    //   851: aload #13
    //   853: iload #12
    //   855: putfield 熱 : Z
    //   858: iload #12
    //   860: ifeq -> 876
    //   863: aload #14
    //   865: getfield 恐 : Ly/l8;
    //   868: invokevirtual 寒 : ()I
    //   871: istore #6
    //   873: goto -> 886
    //   876: aload #14
    //   878: getfield 恐 : Ly/l8;
    //   881: invokevirtual 旨 : ()I
    //   884: istore #6
    //   886: aload #13
    //   888: iload #6
    //   890: putfield 堅 : I
    //   893: goto -> 939
    //   896: aload #13
    //   898: getfield 熱 : Z
    //   901: ifeq -> 923
    //   904: aload #13
    //   906: aload #14
    //   908: getfield 恐 : Ly/l8;
    //   911: invokevirtual 寒 : ()I
    //   914: iload #8
    //   916: isub
    //   917: putfield 堅 : I
    //   920: goto -> 939
    //   923: aload #13
    //   925: aload #14
    //   927: getfield 恐 : Ly/l8;
    //   930: invokevirtual 旨 : ()I
    //   933: iload #8
    //   935: iadd
    //   936: putfield 堅 : I
    //   939: aload #13
    //   941: iconst_1
    //   942: putfield 暑 : Z
    //   945: iconst_1
    //   946: istore #6
    //   948: goto -> 965
    //   951: aload_0
    //   952: iconst_m1
    //   953: putfield 壊 : I
    //   956: aload_0
    //   957: ldc -2147483648
    //   959: putfield 帰 : I
    //   962: iconst_0
    //   963: istore #6
    //   965: iload #6
    //   967: ifeq -> 973
    //   970: goto -> 1119
    //   973: aload_0
    //   974: getfield 泳 : Z
    //   977: ifeq -> 1041
    //   980: aload_2
    //   981: invokevirtual 堅 : ()I
    //   984: istore #11
    //   986: aload_0
    //   987: invokevirtual 起 : ()I
    //   990: istore #6
    //   992: iload #6
    //   994: iconst_1
    //   995: isub
    //   996: istore #8
    //   998: iload #8
    //   1000: iflt -> 1102
    //   1003: aload_0
    //   1004: iload #8
    //   1006: invokevirtual 臭 : (I)Landroid/view/View;
    //   1009: invokestatic 泳 : (Landroid/view/View;)I
    //   1012: istore #10
    //   1014: iload #8
    //   1016: istore #6
    //   1018: iload #10
    //   1020: iflt -> 992
    //   1023: iload #8
    //   1025: istore #6
    //   1027: iload #10
    //   1029: iload #11
    //   1031: if_icmpge -> 992
    //   1034: iload #10
    //   1036: istore #6
    //   1038: goto -> 1105
    //   1041: aload_2
    //   1042: invokevirtual 堅 : ()I
    //   1045: istore #10
    //   1047: aload_0
    //   1048: invokevirtual 起 : ()I
    //   1051: istore #11
    //   1053: iconst_0
    //   1054: istore #6
    //   1056: iload #6
    //   1058: iload #11
    //   1060: if_icmpge -> 1102
    //   1063: aload_0
    //   1064: iload #6
    //   1066: invokevirtual 臭 : (I)Landroid/view/View;
    //   1069: invokestatic 泳 : (Landroid/view/View;)I
    //   1072: istore #8
    //   1074: iload #8
    //   1076: iflt -> 1093
    //   1079: iload #8
    //   1081: iload #10
    //   1083: if_icmpge -> 1093
    //   1086: iload #8
    //   1088: istore #6
    //   1090: goto -> 1105
    //   1093: iload #6
    //   1095: iconst_1
    //   1096: iadd
    //   1097: istore #6
    //   1099: goto -> 1056
    //   1102: iconst_0
    //   1103: istore #6
    //   1105: aload #13
    //   1107: iload #6
    //   1109: putfield 硬 : I
    //   1112: aload #13
    //   1114: ldc -2147483648
    //   1116: putfield 堅 : I
    //   1119: aload #13
    //   1121: iconst_1
    //   1122: putfield 冷 : Z
    //   1125: aload_0
    //   1126: getfield 寝 : Ly/rm;
    //   1129: ifnonnull -> 1174
    //   1132: aload_0
    //   1133: getfield 壊 : I
    //   1136: iconst_m1
    //   1137: if_icmpne -> 1174
    //   1140: aload #13
    //   1142: getfield 熱 : Z
    //   1145: aload_0
    //   1146: getfield 泳 : Z
    //   1149: if_icmpne -> 1163
    //   1152: aload_0
    //   1153: invokevirtual 歯 : ()Z
    //   1156: aload_0
    //   1157: getfield 踊 : Z
    //   1160: if_icmpeq -> 1174
    //   1163: aload #15
    //   1165: invokevirtual 暑 : ()V
    //   1168: aload #13
    //   1170: iconst_1
    //   1171: putfield 暑 : Z
    //   1174: aload_0
    //   1175: invokevirtual 起 : ()I
    //   1178: ifle -> 1595
    //   1181: aload_0
    //   1182: getfield 寝 : Ly/rm;
    //   1185: astore #15
    //   1187: aload #15
    //   1189: ifnull -> 1201
    //   1192: aload #15
    //   1194: getfield 恐 : I
    //   1197: iconst_1
    //   1198: if_icmpge -> 1595
    //   1201: aload #13
    //   1203: getfield 暑 : Z
    //   1206: ifeq -> 1277
    //   1209: iconst_0
    //   1210: istore #6
    //   1212: iload #6
    //   1214: aload_0
    //   1215: getfield 淋 : I
    //   1218: if_icmpge -> 1595
    //   1221: aload_0
    //   1222: getfield 怖 : [Ly/sm;
    //   1225: iload #6
    //   1227: aaload
    //   1228: invokevirtual 堅 : ()V
    //   1231: aload #13
    //   1233: getfield 堅 : I
    //   1236: istore #7
    //   1238: iload #7
    //   1240: ldc -2147483648
    //   1242: if_icmpeq -> 1268
    //   1245: aload_0
    //   1246: getfield 怖 : [Ly/sm;
    //   1249: iload #6
    //   1251: aaload
    //   1252: astore #14
    //   1254: aload #14
    //   1256: iload #7
    //   1258: putfield 堅 : I
    //   1261: aload #14
    //   1263: iload #7
    //   1265: putfield 熱 : I
    //   1268: iload #6
    //   1270: iconst_1
    //   1271: iadd
    //   1272: istore #6
    //   1274: goto -> 1212
    //   1277: iload #7
    //   1279: ifne -> 1352
    //   1282: aload #13
    //   1284: getfield 寒 : [I
    //   1287: ifnonnull -> 1293
    //   1290: goto -> 1352
    //   1293: iconst_0
    //   1294: istore #6
    //   1296: iload #6
    //   1298: aload_0
    //   1299: getfield 淋 : I
    //   1302: if_icmpge -> 1595
    //   1305: aload_0
    //   1306: getfield 怖 : [Ly/sm;
    //   1309: iload #6
    //   1311: aaload
    //   1312: astore #14
    //   1314: aload #14
    //   1316: invokevirtual 堅 : ()V
    //   1319: aload #13
    //   1321: getfield 寒 : [I
    //   1324: iload #6
    //   1326: iaload
    //   1327: istore #7
    //   1329: aload #14
    //   1331: iload #7
    //   1333: putfield 堅 : I
    //   1336: aload #14
    //   1338: iload #7
    //   1340: putfield 熱 : I
    //   1343: iload #6
    //   1345: iconst_1
    //   1346: iadd
    //   1347: istore #6
    //   1349: goto -> 1296
    //   1352: iconst_0
    //   1353: istore #7
    //   1355: iload #7
    //   1357: aload_0
    //   1358: getfield 淋 : I
    //   1361: if_icmpge -> 1514
    //   1364: aload_0
    //   1365: getfield 怖 : [Ly/sm;
    //   1368: iload #7
    //   1370: aaload
    //   1371: astore #15
    //   1373: aload_0
    //   1374: getfield 産 : Z
    //   1377: istore #12
    //   1379: aload #13
    //   1381: getfield 堅 : I
    //   1384: istore #10
    //   1386: iload #12
    //   1388: ifeq -> 1403
    //   1391: aload #15
    //   1393: ldc -2147483648
    //   1395: invokevirtual 寒 : (I)I
    //   1398: istore #6
    //   1400: goto -> 1412
    //   1403: aload #15
    //   1405: ldc -2147483648
    //   1407: invokevirtual 不 : (I)I
    //   1410: istore #6
    //   1412: aload #15
    //   1414: invokevirtual 堅 : ()V
    //   1417: iload #6
    //   1419: ldc -2147483648
    //   1421: if_icmpne -> 1427
    //   1424: goto -> 1505
    //   1427: aload #15
    //   1429: getfield 寒 : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1432: astore #16
    //   1434: iload #12
    //   1436: ifeq -> 1452
    //   1439: iload #6
    //   1441: aload #16
    //   1443: getfield 恐 : Ly/l8;
    //   1446: invokevirtual 寒 : ()I
    //   1449: if_icmplt -> 1505
    //   1452: iload #12
    //   1454: ifne -> 1473
    //   1457: iload #6
    //   1459: aload #16
    //   1461: getfield 恐 : Ly/l8;
    //   1464: invokevirtual 旨 : ()I
    //   1467: if_icmple -> 1473
    //   1470: goto -> 1505
    //   1473: iload #6
    //   1475: istore #8
    //   1477: iload #10
    //   1479: ldc -2147483648
    //   1481: if_icmpeq -> 1491
    //   1484: iload #6
    //   1486: iload #10
    //   1488: iadd
    //   1489: istore #8
    //   1491: aload #15
    //   1493: iload #8
    //   1495: putfield 熱 : I
    //   1498: aload #15
    //   1500: iload #8
    //   1502: putfield 堅 : I
    //   1505: iload #7
    //   1507: iconst_1
    //   1508: iadd
    //   1509: istore #7
    //   1511: goto -> 1355
    //   1514: aload_0
    //   1515: getfield 怖 : [Ly/sm;
    //   1518: astore #15
    //   1520: aload #15
    //   1522: arraylength
    //   1523: istore #7
    //   1525: aload #13
    //   1527: getfield 寒 : [I
    //   1530: astore #16
    //   1532: aload #16
    //   1534: ifnull -> 1545
    //   1537: aload #16
    //   1539: arraylength
    //   1540: iload #7
    //   1542: if_icmpge -> 1558
    //   1545: aload #13
    //   1547: aload #14
    //   1549: getfield 怖 : [Ly/sm;
    //   1552: arraylength
    //   1553: newarray int
    //   1555: putfield 寒 : [I
    //   1558: iconst_0
    //   1559: istore #6
    //   1561: iload #6
    //   1563: iload #7
    //   1565: if_icmpge -> 1595
    //   1568: aload #13
    //   1570: getfield 寒 : [I
    //   1573: iload #6
    //   1575: aload #15
    //   1577: iload #6
    //   1579: aaload
    //   1580: ldc -2147483648
    //   1582: invokevirtual 不 : (I)I
    //   1585: iastore
    //   1586: iload #6
    //   1588: iconst_1
    //   1589: iadd
    //   1590: istore #6
    //   1592: goto -> 1561
    //   1595: aload_0
    //   1596: aload_1
    //   1597: invokevirtual 淋 : (Ly/we;)V
    //   1600: aload_0
    //   1601: getfield 起 : Ly/み;
    //   1604: astore #14
    //   1606: aload #14
    //   1608: iconst_0
    //   1609: putfield 硬 : Z
    //   1612: aload_0
    //   1613: getfield 痛 : Ly/l8;
    //   1616: invokevirtual 不 : ()I
    //   1619: istore #6
    //   1621: aload_0
    //   1622: iload #6
    //   1624: aload_0
    //   1625: getfield 淋 : I
    //   1628: idiv
    //   1629: putfield 臭 : I
    //   1632: iload #6
    //   1634: aload_0
    //   1635: getfield 痛 : Ly/l8;
    //   1638: invokevirtual 美 : ()I
    //   1641: invokestatic makeMeasureSpec : (II)I
    //   1644: pop
    //   1645: aload_0
    //   1646: aload #13
    //   1648: getfield 硬 : I
    //   1651: aload_2
    //   1652: invokevirtual 防 : (ILy/bf;)V
    //   1655: aload #13
    //   1657: getfield 熱 : Z
    //   1660: ifeq -> 1710
    //   1663: aload_0
    //   1664: iconst_m1
    //   1665: invokevirtual 消 : (I)V
    //   1668: aload_0
    //   1669: aload_1
    //   1670: aload #14
    //   1672: aload_2
    //   1673: invokevirtual う : (Ly/we;Ly/み;Ly/bf;)I
    //   1676: pop
    //   1677: aload_0
    //   1678: iconst_1
    //   1679: invokevirtual 消 : (I)V
    //   1682: aload #14
    //   1684: aload #13
    //   1686: getfield 硬 : I
    //   1689: aload #14
    //   1691: getfield 暑 : I
    //   1694: iadd
    //   1695: putfield 熱 : I
    //   1698: aload_0
    //   1699: aload_1
    //   1700: aload #14
    //   1702: aload_2
    //   1703: invokevirtual う : (Ly/we;Ly/み;Ly/bf;)I
    //   1706: pop
    //   1707: goto -> 1754
    //   1710: aload_0
    //   1711: iconst_1
    //   1712: invokevirtual 消 : (I)V
    //   1715: aload_0
    //   1716: aload_1
    //   1717: aload #14
    //   1719: aload_2
    //   1720: invokevirtual う : (Ly/we;Ly/み;Ly/bf;)I
    //   1723: pop
    //   1724: aload_0
    //   1725: iconst_m1
    //   1726: invokevirtual 消 : (I)V
    //   1729: aload #14
    //   1731: aload #13
    //   1733: getfield 硬 : I
    //   1736: aload #14
    //   1738: getfield 暑 : I
    //   1741: iadd
    //   1742: putfield 熱 : I
    //   1745: aload_0
    //   1746: aload_1
    //   1747: aload #14
    //   1749: aload_2
    //   1750: invokevirtual う : (Ly/we;Ly/み;Ly/bf;)I
    //   1753: pop
    //   1754: aload_0
    //   1755: getfield 痛 : Ly/l8;
    //   1758: invokevirtual 美 : ()I
    //   1761: ldc 1073741824
    //   1763: if_icmpne -> 1769
    //   1766: goto -> 2098
    //   1769: aload_0
    //   1770: invokevirtual 起 : ()I
    //   1773: istore #8
    //   1775: fconst_0
    //   1776: fstore #4
    //   1778: iconst_0
    //   1779: istore #6
    //   1781: iload #6
    //   1783: iload #8
    //   1785: if_icmpge -> 1849
    //   1788: aload_0
    //   1789: iload #6
    //   1791: invokevirtual 臭 : (I)Landroid/view/View;
    //   1794: astore #14
    //   1796: aload_0
    //   1797: getfield 痛 : Ly/l8;
    //   1800: aload #14
    //   1802: invokevirtual 熱 : (Landroid/view/View;)I
    //   1805: i2f
    //   1806: fstore #5
    //   1808: fload #5
    //   1810: fload #4
    //   1812: fcmpg
    //   1813: ifge -> 1819
    //   1816: goto -> 1840
    //   1819: aload #14
    //   1821: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1824: checkcast y/pm
    //   1827: invokevirtual getClass : ()Ljava/lang/Class;
    //   1830: pop
    //   1831: fload #4
    //   1833: fload #5
    //   1835: invokestatic max : (FF)F
    //   1838: fstore #4
    //   1840: iload #6
    //   1842: iconst_1
    //   1843: iadd
    //   1844: istore #6
    //   1846: goto -> 1781
    //   1849: aload_0
    //   1850: getfield 臭 : I
    //   1853: istore #10
    //   1855: fload #4
    //   1857: aload_0
    //   1858: getfield 淋 : I
    //   1861: i2f
    //   1862: fmul
    //   1863: invokestatic round : (F)I
    //   1866: istore #7
    //   1868: iload #7
    //   1870: istore #6
    //   1872: aload_0
    //   1873: getfield 痛 : Ly/l8;
    //   1876: invokevirtual 美 : ()I
    //   1879: ldc -2147483648
    //   1881: if_icmpne -> 1898
    //   1884: iload #7
    //   1886: aload_0
    //   1887: getfield 痛 : Ly/l8;
    //   1890: invokevirtual 不 : ()I
    //   1893: invokestatic min : (II)I
    //   1896: istore #6
    //   1898: aload_0
    //   1899: iload #6
    //   1901: aload_0
    //   1902: getfield 淋 : I
    //   1905: idiv
    //   1906: putfield 臭 : I
    //   1909: iload #6
    //   1911: aload_0
    //   1912: getfield 痛 : Ly/l8;
    //   1915: invokevirtual 美 : ()I
    //   1918: invokestatic makeMeasureSpec : (II)I
    //   1921: pop
    //   1922: aload_0
    //   1923: getfield 臭 : I
    //   1926: iload #10
    //   1928: if_icmpne -> 1934
    //   1931: goto -> 2098
    //   1934: iconst_0
    //   1935: istore #6
    //   1937: iload #6
    //   1939: iload #8
    //   1941: if_icmpge -> 2098
    //   1944: aload_0
    //   1945: iload #6
    //   1947: invokevirtual 臭 : (I)Landroid/view/View;
    //   1950: astore #14
    //   1952: aload #14
    //   1954: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1957: checkcast y/pm
    //   1960: astore #15
    //   1962: aload #15
    //   1964: invokevirtual getClass : ()Ljava/lang/Class;
    //   1967: pop
    //   1968: aload_0
    //   1969: invokevirtual 歯 : ()Z
    //   1972: ifeq -> 2032
    //   1975: aload_0
    //   1976: getfield 痒 : I
    //   1979: iconst_1
    //   1980: if_icmpne -> 2032
    //   1983: aload_0
    //   1984: getfield 淋 : I
    //   1987: istore #7
    //   1989: aload #15
    //   1991: getfield 冷 : Ly/sm;
    //   1994: getfield 冷 : I
    //   1997: istore #11
    //   1999: aload #14
    //   2001: iload #7
    //   2003: iconst_1
    //   2004: isub
    //   2005: iload #11
    //   2007: isub
    //   2008: ineg
    //   2009: aload_0
    //   2010: getfield 臭 : I
    //   2013: imul
    //   2014: iload #7
    //   2016: iconst_1
    //   2017: isub
    //   2018: iload #11
    //   2020: isub
    //   2021: ineg
    //   2022: iload #10
    //   2024: imul
    //   2025: isub
    //   2026: invokevirtual offsetLeftAndRight : (I)V
    //   2029: goto -> 2089
    //   2032: aload #15
    //   2034: getfield 冷 : Ly/sm;
    //   2037: getfield 冷 : I
    //   2040: istore #11
    //   2042: aload_0
    //   2043: getfield 臭 : I
    //   2046: iload #11
    //   2048: imul
    //   2049: istore #7
    //   2051: iload #11
    //   2053: iload #10
    //   2055: imul
    //   2056: istore #11
    //   2058: aload_0
    //   2059: getfield 痒 : I
    //   2062: iconst_1
    //   2063: if_icmpne -> 2079
    //   2066: aload #14
    //   2068: iload #7
    //   2070: iload #11
    //   2072: isub
    //   2073: invokevirtual offsetLeftAndRight : (I)V
    //   2076: goto -> 2089
    //   2079: aload #14
    //   2081: iload #7
    //   2083: iload #11
    //   2085: isub
    //   2086: invokevirtual offsetTopAndBottom : (I)V
    //   2089: iload #6
    //   2091: iconst_1
    //   2092: iadd
    //   2093: istore #6
    //   2095: goto -> 1937
    //   2098: aload_0
    //   2099: invokevirtual 起 : ()I
    //   2102: ifle -> 2143
    //   2105: aload_0
    //   2106: getfield 産 : Z
    //   2109: ifeq -> 2129
    //   2112: aload_0
    //   2113: aload_1
    //   2114: aload_2
    //   2115: iconst_1
    //   2116: invokevirtual 年 : (Ly/we;Ly/bf;Z)V
    //   2119: aload_0
    //   2120: aload_1
    //   2121: aload_2
    //   2122: iconst_0
    //   2123: invokevirtual 医 : (Ly/we;Ly/bf;Z)V
    //   2126: goto -> 2143
    //   2129: aload_0
    //   2130: aload_1
    //   2131: aload_2
    //   2132: iconst_1
    //   2133: invokevirtual 医 : (Ly/we;Ly/bf;Z)V
    //   2136: aload_0
    //   2137: aload_1
    //   2138: aload_2
    //   2139: iconst_0
    //   2140: invokevirtual 年 : (Ly/we;Ly/bf;Z)V
    //   2143: iload_3
    //   2144: ifeq -> 2224
    //   2147: aload_2
    //   2148: getfield 美 : Z
    //   2151: ifne -> 2224
    //   2154: aload_0
    //   2155: getfield 歩 : I
    //   2158: ifeq -> 2181
    //   2161: aload_0
    //   2162: invokevirtual 起 : ()I
    //   2165: ifle -> 2181
    //   2168: aload_0
    //   2169: invokevirtual 婦 : ()Landroid/view/View;
    //   2172: ifnull -> 2181
    //   2175: iconst_1
    //   2176: istore #6
    //   2178: goto -> 2184
    //   2181: iconst_0
    //   2182: istore #6
    //   2184: iload #6
    //   2186: ifeq -> 2224
    //   2189: aload_0
    //   2190: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   2193: astore #14
    //   2195: aload #14
    //   2197: ifnull -> 2210
    //   2200: aload #14
    //   2202: aload_0
    //   2203: getfield か : Ly/빈;
    //   2206: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   2209: pop
    //   2210: aload_0
    //   2211: invokevirtual 僕 : ()Z
    //   2214: ifeq -> 2224
    //   2217: iload #9
    //   2219: istore #6
    //   2221: goto -> 2227
    //   2224: iconst_0
    //   2225: istore #6
    //   2227: aload_2
    //   2228: getfield 美 : Z
    //   2231: ifeq -> 2239
    //   2234: aload #13
    //   2236: invokevirtual 硬 : ()V
    //   2239: aload_0
    //   2240: aload #13
    //   2242: getfield 熱 : Z
    //   2245: putfield 泳 : Z
    //   2248: aload_0
    //   2249: aload_0
    //   2250: invokevirtual 歯 : ()Z
    //   2253: putfield 踊 : Z
    //   2256: iload #6
    //   2258: ifeq -> 2273
    //   2261: aload #13
    //   2263: invokevirtual 硬 : ()V
    //   2266: aload_0
    //   2267: aload_1
    //   2268: aload_2
    //   2269: iconst_0
    //   2270: invokevirtual は : (Ly/we;Ly/bf;Z)V
    //   2273: return
  }
  
  public final int ぱ(bf parambf) {
    return 俺(parambf);
  }
  
  public final void ふ(int paramInt1, int paramInt2, int paramInt3) {
    if (this.産) {
      int j = 看();
    } else {
      int j = ご();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        int j = paramInt2 + 1;
      } else {
        int j = paramInt1 + 1;
        int k = paramInt2;
        ex ex2 = this.返;
        ex2.美(k);
      } 
    } else {
      int j = paramInt1 + paramInt2;
    } 
    int i = paramInt1;
    ex ex1 = this.返;
    ex1.美(i);
  }
  
  public final void べ(int paramInt, we paramwe) {
    while (起() > 0) {
      View view = 臭(0);
      if (this.恐.堅(view) <= paramInt && this.恐.辛(view) <= paramInt) {
        pm pm1 = (pm)view.getLayoutParams();
        pm1.getClass();
        if (pm1.冷.硬.size() == 1)
          return; 
        sm sm1 = pm1.冷;
        ArrayList<View> arrayList = sm1.硬;
        View view1 = arrayList.remove(0);
        pm pm2 = sm.旨(view1);
        pm2.冷 = null;
        if (arrayList.size() == 0)
          sm1.熱 = Integer.MIN_VALUE; 
        if (pm2.熱() || pm2.堅())
          sm1.暑 -= sm1.寒.恐.熱(view1); 
        sm1.堅 = Integer.MIN_VALUE;
        탕(view, paramwe);
      } 
    } 
  }
  
  public final int ぼ(int paramInt) {
    boolean bool;
    int i = 起();
    byte b = -1;
    if (i == 0) {
      paramInt = b;
      if (this.産)
        paramInt = 1; 
      return paramInt;
    } 
    if (paramInt < ご()) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool != this.産) ? -1 : 1;
  }
  
  public final void ゃ(RecyclerView paramRecyclerView) {
    RecyclerView recyclerView = this.堅;
    if (recyclerView != null)
      recyclerView.removeCallbacks((Runnable)this.か); 
    for (int i = 0; i < this.淋; i++)
      this.怖[i].堅(); 
    paramRecyclerView.requestLayout();
  }
  
  public final int ょ(bf parambf) {
    if (起() == 0)
      return 0; 
    l8 l81 = this.恐;
    boolean bool = this.投;
    return ik.淋(parambf, l81, ね(bool ^ true), 少(bool ^ true), this, this.投);
  }
  
  public final int れ(bf parambf) {
    if (起() == 0)
      return 0; 
    l8 l81 = this.恐;
    boolean bool = this.投;
    return ik.悲(parambf, l81, ね(bool ^ true), 少(bool ^ true), this, this.投);
  }
  
  public final void わ(AccessibilityEvent paramAccessibilityEvent) {
    super.わ(paramAccessibilityEvent);
    if (起() > 0) {
      View view1 = ね(false);
      View view2 = 少(false);
      if (view1 != null) {
        if (view2 == null)
          return; 
        int i = pe.泳(view1);
        int j = pe.泳(view2);
        if (i < j) {
          paramAccessibilityEvent.setFromIndex(i);
          paramAccessibilityEvent.setToIndex(j);
          return;
        } 
        paramAccessibilityEvent.setFromIndex(j);
        paramAccessibilityEvent.setToIndex(i);
      } 
    } 
  }
  
  public final void ㅌ(we paramwe, bf parambf) {
    は(paramwe, parambf, true);
  }
  
  public final int 俺(bf parambf) {
    if (起() == 0)
      return 0; 
    l8 l81 = this.恐;
    boolean bool = this.投;
    return ik.寂(parambf, l81, ね(bool ^ true), 少(bool ^ true), this, this.投, this.産);
  }
  
  public final boolean 僕() {
    if (起() != 0 && this.歩 != 0) {
      int i;
      if (!this.美)
        return false; 
      if (this.産) {
        i = 看();
        ご();
      } else {
        i = ご();
        看();
      } 
      if (i == 0 && 婦() != null) {
        this.返.暑();
        this.寒 = true;
        탱();
        return true;
      } 
    } 
    return false;
  }
  
  public final boolean 冷() {
    return (this.痒 == 1);
  }
  
  public final void 医(we paramwe, bf parambf, boolean paramBoolean) {
    int i = 師(2147483647);
    if (i == Integer.MAX_VALUE)
      return; 
    i -= this.恐.旨();
    if (i > 0) {
      i -= 士(i, paramwe, parambf);
      if (paramBoolean && i > 0)
        this.恐.苦(-i); 
    } 
  }
  
  public final int 士(int paramInt, we paramwe, bf parambf) {
    if (起() != 0) {
      if (paramInt == 0)
        return 0; 
      政(paramInt, parambf);
      み み1 = this.起;
      int i = う(paramwe, み1, parambf);
      if (み1.堅 >= i)
        if (paramInt < 0) {
          paramInt = -i;
        } else {
          paramInt = i;
        }  
      this.恐.苦(-paramInt);
      this.泳 = this.産;
      み1.堅 = 0;
      治(paramwe, み1);
      return paramInt;
    } 
    return 0;
  }
  
  public final View 婦() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 起 : ()I
    //   4: iconst_1
    //   5: isub
    //   6: istore_1
    //   7: new java/util/BitSet
    //   10: dup
    //   11: aload_0
    //   12: getfield 淋 : I
    //   15: invokespecial <init> : (I)V
    //   18: astore #8
    //   20: aload #8
    //   22: iconst_0
    //   23: aload_0
    //   24: getfield 淋 : I
    //   27: iconst_1
    //   28: invokevirtual set : (IIZ)V
    //   31: aload_0
    //   32: getfield 痒 : I
    //   35: istore_2
    //   36: iconst_m1
    //   37: istore #4
    //   39: iload_2
    //   40: iconst_1
    //   41: if_icmpne -> 56
    //   44: aload_0
    //   45: invokevirtual 歯 : ()Z
    //   48: ifeq -> 56
    //   51: iconst_1
    //   52: istore_2
    //   53: goto -> 58
    //   56: iconst_m1
    //   57: istore_2
    //   58: aload_0
    //   59: getfield 産 : Z
    //   62: ifeq -> 70
    //   65: iconst_m1
    //   66: istore_3
    //   67: goto -> 76
    //   70: iload_1
    //   71: iconst_1
    //   72: iadd
    //   73: istore_3
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: istore #5
    //   79: iload_1
    //   80: iload_3
    //   81: if_icmpge -> 90
    //   84: iconst_1
    //   85: istore #4
    //   87: iload_1
    //   88: istore #5
    //   90: iload #5
    //   92: iload_3
    //   93: if_icmpeq -> 521
    //   96: aload_0
    //   97: iload #5
    //   99: invokevirtual 臭 : (I)Landroid/view/View;
    //   102: astore #9
    //   104: aload #9
    //   106: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   109: checkcast y/pm
    //   112: astore #10
    //   114: aload #8
    //   116: aload #10
    //   118: getfield 冷 : Ly/sm;
    //   121: getfield 冷 : I
    //   124: invokevirtual get : (I)Z
    //   127: ifeq -> 336
    //   130: aload #10
    //   132: getfield 冷 : Ly/sm;
    //   135: astore #11
    //   137: aload_0
    //   138: getfield 産 : Z
    //   141: ifeq -> 213
    //   144: aload #11
    //   146: getfield 熱 : I
    //   149: istore_1
    //   150: iload_1
    //   151: ldc -2147483648
    //   153: if_icmpeq -> 159
    //   156: goto -> 170
    //   159: aload #11
    //   161: invokevirtual 硬 : ()V
    //   164: aload #11
    //   166: getfield 熱 : I
    //   169: istore_1
    //   170: iload_1
    //   171: aload_0
    //   172: getfield 恐 : Ly/l8;
    //   175: invokevirtual 寒 : ()I
    //   178: if_icmpge -> 314
    //   181: aload #11
    //   183: getfield 硬 : Ljava/util/ArrayList;
    //   186: astore #11
    //   188: aload #11
    //   190: aload #11
    //   192: invokevirtual size : ()I
    //   195: iconst_1
    //   196: isub
    //   197: invokevirtual get : (I)Ljava/lang/Object;
    //   200: checkcast android/view/View
    //   203: invokestatic 旨 : (Landroid/view/View;)Ly/pm;
    //   206: invokevirtual getClass : ()Ljava/lang/Class;
    //   209: pop
    //   210: goto -> 309
    //   213: aload #11
    //   215: getfield 堅 : I
    //   218: istore_1
    //   219: iload_1
    //   220: ldc -2147483648
    //   222: if_icmpeq -> 228
    //   225: goto -> 279
    //   228: aload #11
    //   230: getfield 硬 : Ljava/util/ArrayList;
    //   233: iconst_0
    //   234: invokevirtual get : (I)Ljava/lang/Object;
    //   237: checkcast android/view/View
    //   240: astore #12
    //   242: aload #12
    //   244: invokestatic 旨 : (Landroid/view/View;)Ly/pm;
    //   247: astore #13
    //   249: aload #11
    //   251: aload #11
    //   253: getfield 寒 : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   256: getfield 恐 : Ly/l8;
    //   259: aload #12
    //   261: invokevirtual 暑 : (Landroid/view/View;)I
    //   264: putfield 堅 : I
    //   267: aload #13
    //   269: invokevirtual getClass : ()Ljava/lang/Class;
    //   272: pop
    //   273: aload #11
    //   275: getfield 堅 : I
    //   278: istore_1
    //   279: iload_1
    //   280: aload_0
    //   281: getfield 恐 : Ly/l8;
    //   284: invokevirtual 旨 : ()I
    //   287: if_icmple -> 314
    //   290: aload #11
    //   292: getfield 硬 : Ljava/util/ArrayList;
    //   295: iconst_0
    //   296: invokevirtual get : (I)Ljava/lang/Object;
    //   299: checkcast android/view/View
    //   302: invokestatic 旨 : (Landroid/view/View;)Ly/pm;
    //   305: invokevirtual getClass : ()Ljava/lang/Class;
    //   308: pop
    //   309: iconst_1
    //   310: istore_1
    //   311: goto -> 316
    //   314: iconst_0
    //   315: istore_1
    //   316: iload_1
    //   317: ifeq -> 323
    //   320: aload #9
    //   322: areturn
    //   323: aload #8
    //   325: aload #10
    //   327: getfield 冷 : Ly/sm;
    //   330: getfield 冷 : I
    //   333: invokevirtual clear : (I)V
    //   336: iload #5
    //   338: iload #4
    //   340: iadd
    //   341: istore #7
    //   343: iload #7
    //   345: istore #5
    //   347: iload #7
    //   349: iload_3
    //   350: if_icmpeq -> 90
    //   353: aload_0
    //   354: iload #7
    //   356: invokevirtual 臭 : (I)Landroid/view/View;
    //   359: astore #11
    //   361: aload_0
    //   362: getfield 産 : Z
    //   365: ifeq -> 407
    //   368: aload_0
    //   369: getfield 恐 : Ly/l8;
    //   372: aload #9
    //   374: invokevirtual 堅 : (Landroid/view/View;)I
    //   377: istore_1
    //   378: aload_0
    //   379: getfield 恐 : Ly/l8;
    //   382: aload #11
    //   384: invokevirtual 堅 : (Landroid/view/View;)I
    //   387: istore #5
    //   389: iload_1
    //   390: iload #5
    //   392: if_icmpge -> 398
    //   395: aload #9
    //   397: areturn
    //   398: iload_1
    //   399: iload #5
    //   401: if_icmpne -> 448
    //   404: goto -> 443
    //   407: aload_0
    //   408: getfield 恐 : Ly/l8;
    //   411: aload #9
    //   413: invokevirtual 暑 : (Landroid/view/View;)I
    //   416: istore_1
    //   417: aload_0
    //   418: getfield 恐 : Ly/l8;
    //   421: aload #11
    //   423: invokevirtual 暑 : (Landroid/view/View;)I
    //   426: istore #5
    //   428: iload_1
    //   429: iload #5
    //   431: if_icmple -> 437
    //   434: aload #9
    //   436: areturn
    //   437: iload_1
    //   438: iload #5
    //   440: if_icmpne -> 448
    //   443: iconst_1
    //   444: istore_1
    //   445: goto -> 450
    //   448: iconst_0
    //   449: istore_1
    //   450: iload #7
    //   452: istore #5
    //   454: iload_1
    //   455: ifeq -> 90
    //   458: aload #11
    //   460: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   463: checkcast y/pm
    //   466: astore #11
    //   468: aload #10
    //   470: getfield 冷 : Ly/sm;
    //   473: getfield 冷 : I
    //   476: aload #11
    //   478: getfield 冷 : Ly/sm;
    //   481: getfield 冷 : I
    //   484: isub
    //   485: ifge -> 493
    //   488: iconst_1
    //   489: istore_1
    //   490: goto -> 495
    //   493: iconst_0
    //   494: istore_1
    //   495: iload_2
    //   496: ifge -> 505
    //   499: iconst_1
    //   500: istore #6
    //   502: goto -> 508
    //   505: iconst_0
    //   506: istore #6
    //   508: iload #7
    //   510: istore #5
    //   512: iload_1
    //   513: iload #6
    //   515: if_icmpeq -> 90
    //   518: aload #9
    //   520: areturn
    //   521: aconst_null
    //   522: areturn
  }
  
  public final int 嬉(bf parambf) {
    return れ(parambf);
  }
  
  public final void 家(int paramInt, we paramwe) {
    int i = 起() - 1;
    while (i >= 0) {
      View view = 臭(i);
      if (this.恐.暑(view) >= paramInt && this.恐.ぱ(view) >= paramInt) {
        pm pm1 = (pm)view.getLayoutParams();
        pm1.getClass();
        if (pm1.冷.硬.size() == 1)
          return; 
        sm sm1 = pm1.冷;
        ArrayList<View> arrayList = sm1.硬;
        int j = arrayList.size();
        View view1 = arrayList.remove(j - 1);
        pm pm2 = sm.旨(view1);
        pm2.冷 = null;
        if (pm2.熱() || pm2.堅())
          sm1.暑 -= sm1.寒.恐.熱(view1); 
        if (j == 1)
          sm1.堅 = Integer.MIN_VALUE; 
        sm1.熱 = Integer.MIN_VALUE;
        탕(view, paramwe);
        i--;
      } 
    } 
  }
  
  public final int 寂(bf parambf) {
    return ょ(parambf);
  }
  
  public final boolean 寒(qe paramqe) {
    return paramqe instanceof pm;
  }
  
  public final int 寝(we paramwe, bf parambf) {
    return (this.痒 == 0) ? this.淋 : super.寝(paramwe, parambf);
  }
  
  public final View 少(boolean paramBoolean) {
    int j = this.恐.旨();
    int k = this.恐.寒();
    int i = 起() - 1;
    View view;
    for (view = null; i >= 0; view = view1) {
      View view2 = 臭(i);
      int m = this.恐.暑(view2);
      int n = this.恐.堅(view2);
      View view1 = view;
      if (n > j)
        if (m >= k) {
          view1 = view;
        } else if (n > k) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i--;
    } 
    return view;
  }
  
  public final int 師(int paramInt) {
    int j = this.怖[0].不(paramInt);
    int i = 1;
    while (i < this.淋) {
      int m = this.怖[i].不(paramInt);
      int k = j;
      if (m < j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public final void 年(we paramwe, bf parambf, boolean paramBoolean) {
    int i = 護(-2147483648);
    if (i == Integer.MIN_VALUE)
      return; 
    i = this.恐.寒() - i;
    if (i > 0) {
      i -= -士(-i, paramwe, parambf);
      if (paramBoolean && i > 0)
        this.恐.苦(i); 
    } 
  }
  
  public final void 弁() {
    if (this.痒 == 1 || !歯()) {
      this.産 = this.興;
      return;
    } 
    this.産 = this.興 ^ true;
  }
  
  public final qe 恐() {
    return (qe)((this.痒 == 0) ? new pm(-2, -1) : new pm(-1, -2));
  }
  
  public final int 悲(bf parambf) {
    return 俺(parambf);
  }
  
  public final void 政(int paramInt, bf parambf) {
    int i;
    byte b;
    if (paramInt > 0) {
      i = 看();
      b = 1;
    } else {
      i = ご();
      b = -1;
    } 
    み み1 = this.起;
    み1.硬 = true;
    防(i, parambf);
    消(b);
    み1.熱 = i + み1.暑;
    み1.堅 = Math.abs(paramInt);
  }
  
  public final void 旨(int paramInt1, int paramInt2, bf parambf, 표 param표) {
    if (this.痒 != 0)
      paramInt1 = paramInt2; 
    if (起() != 0) {
      if (paramInt1 == 0)
        return; 
      政(paramInt1, parambf);
      int[] arrayOfInt = this.あ;
      if (arrayOfInt == null || arrayOfInt.length < this.淋)
        this.あ = new int[this.淋]; 
      paramInt2 = 0;
      paramInt1 = 0;
      while (true) {
        int i = this.淋;
        み み1 = this.起;
        if (paramInt2 < i) {
          if (み1.暑 == -1) {
            i = み1.寒;
            j = this.怖[paramInt2].不(i);
          } else {
            i = this.怖[paramInt2].寒(み1.美);
            j = み1.美;
          } 
          int j = i - j;
          i = paramInt1;
          if (j >= 0) {
            this.あ[paramInt1] = j;
            i = paramInt1 + 1;
          } 
          paramInt2++;
          paramInt1 = i;
          continue;
        } 
        Arrays.sort(this.あ, 0, paramInt1);
        paramInt2 = 0;
        while (paramInt2 < paramInt1) {
          i = み1.熱;
          if (i >= 0 && i < parambf.堅()) {
            i = 1;
          } else {
            i = 0;
          } 
          if (i != 0) {
            param표.硬(み1.熱, this.あ[paramInt2]);
            み1.熱 += み1.暑;
            paramInt2++;
          } 
        } 
        break;
      } 
    } 
  }
  
  public final boolean 暑() {
    return (this.痒 == 0);
  }
  
  public final boolean 歯() {
    return (rw.不((View)this.堅) == 1);
  }
  
  public final void 治(we paramwe, み paramみ) {
    if (paramみ.硬) {
      if (paramみ.不)
        return; 
      if (paramみ.堅 == 0) {
        if (paramみ.冷 == -1) {
          家(paramみ.美, paramwe);
          return;
        } 
        べ(paramみ.寒, paramwe);
        return;
      } 
      int k = paramみ.冷;
      int j = 1;
      int i = 1;
      if (k == -1) {
        int n = paramみ.寒;
        for (j = this.怖[0].不(n); i < this.淋; j = k) {
          int i1 = this.怖[i].不(n);
          k = j;
          if (i1 > j)
            k = i1; 
          i++;
        } 
        i = n - j;
        if (i < 0) {
          i = paramみ.美;
        } else {
          i = paramみ.美 - Math.min(i, paramみ.堅);
        } 
        家(i, paramwe);
        return;
      } 
      int m = paramみ.美;
      k = this.怖[0].寒(m);
      i = j;
      for (j = k; i < this.淋; j = k) {
        int n = this.怖[i].寒(m);
        k = j;
        if (n < j)
          k = n; 
        i++;
      } 
      i = j - paramみ.美;
      if (i < 0) {
        i = paramみ.寒;
      } else {
        j = paramみ.寒;
        i = Math.min(i, paramみ.堅) + j;
      } 
      べ(i, paramwe);
    } 
  }
  
  public final void 消(int paramInt) {
    boolean bool1;
    み み1 = this.起;
    み1.冷 = paramInt;
    boolean bool2 = this.産;
    boolean bool = true;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 == bool1) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    み1.暑 = paramInt;
  }
  
  public final void 熱(String paramString) {
    if (this.寝 == null) {
      RecyclerView recyclerView = this.堅;
      if (recyclerView != null)
        recyclerView.不(paramString); 
    } 
  }
  
  public final int 産(we paramwe, bf parambf) {
    return (this.痒 == 1) ? this.淋 : super.産(paramwe, parambf);
  }
  
  public final qe 痒(ViewGroup.LayoutParams paramLayoutParams) {
    return (qe)((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new pm((ViewGroup.MarginLayoutParams)paramLayoutParams) : new pm(paramLayoutParams));
  }
  
  public final qe 痛(Context paramContext, AttributeSet paramAttributeSet) {
    return (qe)new pm(paramContext, paramAttributeSet);
  }
  
  public final int 看() {
    int i = 起();
    return (i == 0) ? 0 : pe.泳(臭(i - 1));
  }
  
  public final PointF 硬(int paramInt) {
    paramInt = ぼ(paramInt);
    PointF pointF = new PointF();
    if (paramInt == 0)
      return null; 
    if (this.痒 == 0) {
      pointF.x = paramInt;
      pointF.y = 0.0F;
      return pointF;
    } 
    pointF.x = 0.0F;
    pointF.y = paramInt;
    return pointF;
  }
  
  public final void 科(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    RecyclerView recyclerView = this.堅;
    Rect rect = this.噛;
    if (recyclerView == null) {
      rect.set(0, 0, 0, 0);
    } else {
      rect.set(recyclerView.あ(paramView));
    } 
    pm pm = (pm)paramView.getLayoutParams();
    paramInt1 = さ(paramInt1, ((ViewGroup.MarginLayoutParams)pm).leftMargin + rect.left, ((ViewGroup.MarginLayoutParams)pm).rightMargin + rect.right);
    paramInt2 = さ(paramInt2, ((ViewGroup.MarginLayoutParams)pm).topMargin + rect.top, ((ViewGroup.MarginLayoutParams)pm).bottomMargin + rect.bottom);
    if (퉁(paramView, paramInt1, paramInt2, (qe)pm))
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public final void 若(we paramwe, bf parambf, View paramView, コ paramコ) {
    int i;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof pm)) {
      も(paramView, paramコ);
      return;
    } 
    pm pm = (pm)layoutParams;
    if (this.痒 == 0) {
      sm1 = pm.冷;
      if (sm1 == null) {
        i = -1;
      } else {
        i = sm1.冷;
      } 
      paramコ.旨(賊.起(i, 1, -1, -1, false));
      return;
    } 
    sm sm1 = ((pm)sm1).冷;
    if (sm1 == null) {
      i = -1;
    } else {
      i = sm1.冷;
    } 
    paramコ.旨(賊.起(-1, -1, i, 1, false));
  }
  
  public final int 苦(bf parambf) {
    return ょ(parambf);
  }
  
  public final boolean 触() {
    return (this.歩 != 0);
  }
  
  public final int 護(int paramInt) {
    int j = this.怖[0].寒(paramInt);
    int i = 1;
    while (i < this.淋) {
      int m = this.怖[i].寒(paramInt);
      int k = j;
      if (m > j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public final View 赤(View paramView, int paramInt, we paramwe, bf parambf) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 起 : ()I
    //   4: ifne -> 9
    //   7: aconst_null
    //   8: areturn
    //   9: aload_0
    //   10: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   13: astore #9
    //   15: aload #9
    //   17: ifnonnull -> 25
    //   20: aconst_null
    //   21: astore_1
    //   22: goto -> 59
    //   25: aload #9
    //   27: aload_1
    //   28: invokevirtual 帰 : (Landroid/view/View;)Landroid/view/View;
    //   31: astore #9
    //   33: aload #9
    //   35: ifnonnull -> 41
    //   38: goto -> 20
    //   41: aload #9
    //   43: astore_1
    //   44: aload_0
    //   45: getfield 硬 : Ly/話;
    //   48: aload #9
    //   50: invokevirtual 辛 : (Landroid/view/View;)Z
    //   53: ifeq -> 59
    //   56: goto -> 20
    //   59: aload_1
    //   60: ifnonnull -> 65
    //   63: aconst_null
    //   64: areturn
    //   65: aload_0
    //   66: invokevirtual 弁 : ()V
    //   69: iload_2
    //   70: iconst_1
    //   71: if_icmpeq -> 176
    //   74: iload_2
    //   75: iconst_2
    //   76: if_icmpeq -> 155
    //   79: iload_2
    //   80: bipush #17
    //   82: if_icmpeq -> 139
    //   85: iload_2
    //   86: bipush #33
    //   88: if_icmpeq -> 128
    //   91: iload_2
    //   92: bipush #66
    //   94: if_icmpeq -> 118
    //   97: iload_2
    //   98: sipush #130
    //   101: if_icmpeq -> 107
    //   104: goto -> 149
    //   107: aload_0
    //   108: getfield 痒 : I
    //   111: iconst_1
    //   112: if_icmpne -> 149
    //   115: goto -> 194
    //   118: aload_0
    //   119: getfield 痒 : I
    //   122: ifne -> 149
    //   125: goto -> 194
    //   128: aload_0
    //   129: getfield 痒 : I
    //   132: iconst_1
    //   133: if_icmpne -> 149
    //   136: goto -> 199
    //   139: aload_0
    //   140: getfield 痒 : I
    //   143: ifne -> 149
    //   146: goto -> 199
    //   149: ldc -2147483648
    //   151: istore_2
    //   152: goto -> 201
    //   155: aload_0
    //   156: getfield 痒 : I
    //   159: iconst_1
    //   160: if_icmpne -> 166
    //   163: goto -> 194
    //   166: aload_0
    //   167: invokevirtual 歯 : ()Z
    //   170: ifeq -> 194
    //   173: goto -> 199
    //   176: aload_0
    //   177: getfield 痒 : I
    //   180: iconst_1
    //   181: if_icmpne -> 187
    //   184: goto -> 199
    //   187: aload_0
    //   188: invokevirtual 歯 : ()Z
    //   191: ifeq -> 199
    //   194: iconst_1
    //   195: istore_2
    //   196: goto -> 201
    //   199: iconst_m1
    //   200: istore_2
    //   201: iload_2
    //   202: ldc -2147483648
    //   204: if_icmpne -> 209
    //   207: aconst_null
    //   208: areturn
    //   209: aload_1
    //   210: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   213: checkcast y/pm
    //   216: astore #9
    //   218: aload #9
    //   220: invokevirtual getClass : ()Ljava/lang/Class;
    //   223: pop
    //   224: aload #9
    //   226: getfield 冷 : Ly/sm;
    //   229: astore #9
    //   231: iload_2
    //   232: iconst_1
    //   233: if_icmpne -> 245
    //   236: aload_0
    //   237: invokevirtual 看 : ()I
    //   240: istore #5
    //   242: goto -> 251
    //   245: aload_0
    //   246: invokevirtual ご : ()I
    //   249: istore #5
    //   251: aload_0
    //   252: iload #5
    //   254: aload #4
    //   256: invokevirtual 防 : (ILy/bf;)V
    //   259: aload_0
    //   260: iload_2
    //   261: invokevirtual 消 : (I)V
    //   264: aload_0
    //   265: getfield 起 : Ly/み;
    //   268: astore #10
    //   270: aload #10
    //   272: aload #10
    //   274: getfield 暑 : I
    //   277: iload #5
    //   279: iadd
    //   280: putfield 熱 : I
    //   283: aload #10
    //   285: aload_0
    //   286: getfield 恐 : Ly/l8;
    //   289: invokevirtual 不 : ()I
    //   292: i2f
    //   293: ldc_w 0.33333334
    //   296: fmul
    //   297: f2i
    //   298: putfield 堅 : I
    //   301: aload #10
    //   303: iconst_1
    //   304: putfield 旨 : Z
    //   307: iconst_0
    //   308: istore #7
    //   310: aload #10
    //   312: iconst_0
    //   313: putfield 硬 : Z
    //   316: aload_0
    //   317: aload_3
    //   318: aload #10
    //   320: aload #4
    //   322: invokevirtual う : (Ly/we;Ly/み;Ly/bf;)I
    //   325: pop
    //   326: aload_0
    //   327: aload_0
    //   328: getfield 産 : Z
    //   331: putfield 泳 : Z
    //   334: aload #9
    //   336: iload #5
    //   338: iload_2
    //   339: invokevirtual 美 : (II)Landroid/view/View;
    //   342: astore_3
    //   343: aload_3
    //   344: ifnull -> 354
    //   347: aload_3
    //   348: aload_1
    //   349: if_acmpeq -> 354
    //   352: aload_3
    //   353: areturn
    //   354: aload_0
    //   355: iload_2
    //   356: invokevirtual せ : (I)Z
    //   359: ifeq -> 409
    //   362: aload_0
    //   363: getfield 淋 : I
    //   366: iconst_1
    //   367: isub
    //   368: istore #6
    //   370: iload #6
    //   372: iflt -> 455
    //   375: aload_0
    //   376: getfield 怖 : [Ly/sm;
    //   379: iload #6
    //   381: aaload
    //   382: iload #5
    //   384: iload_2
    //   385: invokevirtual 美 : (II)Landroid/view/View;
    //   388: astore_3
    //   389: aload_3
    //   390: ifnull -> 400
    //   393: aload_3
    //   394: aload_1
    //   395: if_acmpeq -> 400
    //   398: aload_3
    //   399: areturn
    //   400: iload #6
    //   402: iconst_1
    //   403: isub
    //   404: istore #6
    //   406: goto -> 370
    //   409: iconst_0
    //   410: istore #6
    //   412: iload #6
    //   414: aload_0
    //   415: getfield 淋 : I
    //   418: if_icmpge -> 455
    //   421: aload_0
    //   422: getfield 怖 : [Ly/sm;
    //   425: iload #6
    //   427: aaload
    //   428: iload #5
    //   430: iload_2
    //   431: invokevirtual 美 : (II)Landroid/view/View;
    //   434: astore_3
    //   435: aload_3
    //   436: ifnull -> 446
    //   439: aload_3
    //   440: aload_1
    //   441: if_acmpeq -> 446
    //   444: aload_3
    //   445: areturn
    //   446: iload #6
    //   448: iconst_1
    //   449: iadd
    //   450: istore #6
    //   452: goto -> 412
    //   455: aload_0
    //   456: getfield 興 : Z
    //   459: istore #8
    //   461: iload_2
    //   462: iconst_m1
    //   463: if_icmpne -> 472
    //   466: iconst_1
    //   467: istore #5
    //   469: goto -> 475
    //   472: iconst_0
    //   473: istore #5
    //   475: iload #8
    //   477: iconst_1
    //   478: ixor
    //   479: iload #5
    //   481: if_icmpne -> 490
    //   484: iconst_1
    //   485: istore #5
    //   487: goto -> 493
    //   490: iconst_0
    //   491: istore #5
    //   493: iload #5
    //   495: ifeq -> 508
    //   498: aload #9
    //   500: invokevirtual 熱 : ()I
    //   503: istore #6
    //   505: goto -> 515
    //   508: aload #9
    //   510: invokevirtual 暑 : ()I
    //   513: istore #6
    //   515: aload_0
    //   516: iload #6
    //   518: invokevirtual 怖 : (I)Landroid/view/View;
    //   521: astore_3
    //   522: aload_3
    //   523: ifnull -> 533
    //   526: aload_3
    //   527: aload_1
    //   528: if_acmpeq -> 533
    //   531: aload_3
    //   532: areturn
    //   533: iload #7
    //   535: istore #6
    //   537: aload_0
    //   538: iload_2
    //   539: invokevirtual せ : (I)Z
    //   542: ifeq -> 623
    //   545: aload_0
    //   546: getfield 淋 : I
    //   549: iconst_1
    //   550: isub
    //   551: istore_2
    //   552: iload_2
    //   553: iflt -> 688
    //   556: iload_2
    //   557: aload #9
    //   559: getfield 冷 : I
    //   562: if_icmpne -> 568
    //   565: goto -> 616
    //   568: iload #5
    //   570: ifeq -> 587
    //   573: aload_0
    //   574: getfield 怖 : [Ly/sm;
    //   577: iload_2
    //   578: aaload
    //   579: invokevirtual 熱 : ()I
    //   582: istore #6
    //   584: goto -> 598
    //   587: aload_0
    //   588: getfield 怖 : [Ly/sm;
    //   591: iload_2
    //   592: aaload
    //   593: invokevirtual 暑 : ()I
    //   596: istore #6
    //   598: aload_0
    //   599: iload #6
    //   601: invokevirtual 怖 : (I)Landroid/view/View;
    //   604: astore_3
    //   605: aload_3
    //   606: ifnull -> 616
    //   609: aload_3
    //   610: aload_1
    //   611: if_acmpeq -> 616
    //   614: aload_3
    //   615: areturn
    //   616: iload_2
    //   617: iconst_1
    //   618: isub
    //   619: istore_2
    //   620: goto -> 552
    //   623: iload #6
    //   625: aload_0
    //   626: getfield 淋 : I
    //   629: if_icmpge -> 688
    //   632: iload #5
    //   634: ifeq -> 651
    //   637: aload_0
    //   638: getfield 怖 : [Ly/sm;
    //   641: iload #6
    //   643: aaload
    //   644: invokevirtual 熱 : ()I
    //   647: istore_2
    //   648: goto -> 662
    //   651: aload_0
    //   652: getfield 怖 : [Ly/sm;
    //   655: iload #6
    //   657: aaload
    //   658: invokevirtual 暑 : ()I
    //   661: istore_2
    //   662: aload_0
    //   663: iload_2
    //   664: invokevirtual 怖 : (I)Landroid/view/View;
    //   667: astore_3
    //   668: aload_3
    //   669: ifnull -> 679
    //   672: aload_3
    //   673: aload_1
    //   674: if_acmpeq -> 679
    //   677: aload_3
    //   678: areturn
    //   679: iload #6
    //   681: iconst_1
    //   682: iadd
    //   683: istore #6
    //   685: goto -> 623
    //   688: aconst_null
    //   689: areturn
  }
  
  public final int 辛(bf parambf) {
    return れ(parambf);
  }
  
  public final void 防(int paramInt, bf parambf) {
    // Byte code:
    //   0: aload_0
    //   1: getfield 起 : Ly/み;
    //   4: astore #8
    //   6: iconst_0
    //   7: istore #6
    //   9: aload #8
    //   11: iconst_0
    //   12: putfield 堅 : I
    //   15: aload #8
    //   17: iload_1
    //   18: putfield 熱 : I
    //   21: aload_0
    //   22: getfield 冷 : Ly/邪;
    //   25: astore #9
    //   27: aload #9
    //   29: ifnull -> 45
    //   32: aload #9
    //   34: getfield 冷 : Z
    //   37: ifeq -> 45
    //   40: iconst_1
    //   41: istore_3
    //   42: goto -> 47
    //   45: iconst_0
    //   46: istore_3
    //   47: iload_3
    //   48: ifeq -> 112
    //   51: aload_2
    //   52: getfield 硬 : I
    //   55: istore_3
    //   56: iload_3
    //   57: iconst_m1
    //   58: if_icmpeq -> 112
    //   61: aload_0
    //   62: getfield 産 : Z
    //   65: istore #7
    //   67: iload_3
    //   68: iload_1
    //   69: if_icmpge -> 78
    //   72: iconst_1
    //   73: istore #5
    //   75: goto -> 81
    //   78: iconst_0
    //   79: istore #5
    //   81: iload #7
    //   83: iload #5
    //   85: if_icmpne -> 99
    //   88: aload_0
    //   89: getfield 恐 : Ly/l8;
    //   92: invokevirtual 不 : ()I
    //   95: istore_1
    //   96: goto -> 114
    //   99: aload_0
    //   100: getfield 恐 : Ly/l8;
    //   103: invokevirtual 不 : ()I
    //   106: istore_3
    //   107: iconst_0
    //   108: istore_1
    //   109: goto -> 116
    //   112: iconst_0
    //   113: istore_1
    //   114: iconst_0
    //   115: istore_3
    //   116: aload_0
    //   117: getfield 堅 : Landroidx/recyclerview/widget/RecyclerView;
    //   120: astore_2
    //   121: aload_2
    //   122: ifnull -> 138
    //   125: aload_2
    //   126: getfield 起 : Z
    //   129: ifeq -> 138
    //   132: iconst_1
    //   133: istore #4
    //   135: goto -> 141
    //   138: iconst_0
    //   139: istore #4
    //   141: iload #4
    //   143: ifeq -> 177
    //   146: aload #8
    //   148: aload_0
    //   149: getfield 恐 : Ly/l8;
    //   152: invokevirtual 旨 : ()I
    //   155: iload_3
    //   156: isub
    //   157: putfield 寒 : I
    //   160: aload #8
    //   162: aload_0
    //   163: getfield 恐 : Ly/l8;
    //   166: invokevirtual 寒 : ()I
    //   169: iload_1
    //   170: iadd
    //   171: putfield 美 : I
    //   174: goto -> 198
    //   177: aload #8
    //   179: aload_0
    //   180: getfield 恐 : Ly/l8;
    //   183: invokevirtual 冷 : ()I
    //   186: iload_1
    //   187: iadd
    //   188: putfield 美 : I
    //   191: aload #8
    //   193: iload_3
    //   194: ineg
    //   195: putfield 寒 : I
    //   198: aload #8
    //   200: iconst_0
    //   201: putfield 旨 : Z
    //   204: aload #8
    //   206: iconst_1
    //   207: putfield 硬 : Z
    //   210: iload #6
    //   212: istore #5
    //   214: aload_0
    //   215: getfield 恐 : Ly/l8;
    //   218: invokevirtual 美 : ()I
    //   221: ifne -> 241
    //   224: iload #6
    //   226: istore #5
    //   228: aload_0
    //   229: getfield 恐 : Ly/l8;
    //   232: invokevirtual 冷 : ()I
    //   235: ifne -> 241
    //   238: iconst_1
    //   239: istore #5
    //   241: aload #8
    //   243: iload #5
    //   245: putfield 不 : Z
    //   248: return
  }
  
  public final void 코(int paramInt1, int paramInt2) {
    ふ(paramInt1, paramInt2, 1);
  }
  
  public final void 쾌() {
    this.返.暑();
    탱();
  }
  
  public final void 크(int paramInt1, int paramInt2) {
    ふ(paramInt1, paramInt2, 8);
  }
  
  public final void 큰(int paramInt1, int paramInt2) {
    ふ(paramInt1, paramInt2, 2);
  }
  
  public final void 키(int paramInt1, int paramInt2) {
    ふ(paramInt1, paramInt2, 4);
  }
  
  public final void 타(bf parambf) {
    this.壊 = -1;
    this.帰 = Integer.MIN_VALUE;
    this.寝 = null;
    this.触.硬();
  }
  
  public final void 탁(Parcelable paramParcelable) {
    if (paramParcelable instanceof rm) {
      this.寝 = (rm)paramParcelable;
      탱();
    } 
  }
  
  public final Parcelable 탄() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 寝 : Ly/rm;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: new y/rm
    //   14: dup
    //   15: aload #4
    //   17: invokespecial <init> : (Ly/rm;)V
    //   20: areturn
    //   21: new y/rm
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore #5
    //   30: aload #5
    //   32: aload_0
    //   33: getfield 興 : Z
    //   36: putfield 興 : Z
    //   39: aload #5
    //   41: aload_0
    //   42: getfield 泳 : Z
    //   45: putfield 産 : Z
    //   48: aload #5
    //   50: aload_0
    //   51: getfield 踊 : Z
    //   54: putfield 死 : Z
    //   57: iconst_0
    //   58: istore_2
    //   59: aload_0
    //   60: getfield 返 : Ly/ex;
    //   63: astore #4
    //   65: aload #4
    //   67: ifnull -> 116
    //   70: aload #4
    //   72: getfield 堅 : Ljava/lang/Object;
    //   75: checkcast [I
    //   78: astore #6
    //   80: aload #6
    //   82: ifnull -> 116
    //   85: aload #5
    //   87: aload #6
    //   89: putfield 臭 : [I
    //   92: aload #5
    //   94: aload #6
    //   96: arraylength
    //   97: putfield 痒 : I
    //   100: aload #5
    //   102: aload #4
    //   104: getfield 熱 : Ljava/lang/Object;
    //   107: checkcast java/util/List
    //   110: putfield 起 : Ljava/util/List;
    //   113: goto -> 122
    //   116: aload #5
    //   118: iconst_0
    //   119: putfield 痒 : I
    //   122: aload_0
    //   123: invokevirtual 起 : ()I
    //   126: istore_1
    //   127: iconst_m1
    //   128: istore_3
    //   129: iload_1
    //   130: ifle -> 317
    //   133: aload_0
    //   134: getfield 泳 : Z
    //   137: ifeq -> 148
    //   140: aload_0
    //   141: invokevirtual 看 : ()I
    //   144: istore_1
    //   145: goto -> 153
    //   148: aload_0
    //   149: invokevirtual ご : ()I
    //   152: istore_1
    //   153: aload #5
    //   155: iload_1
    //   156: putfield 淋 : I
    //   159: aload_0
    //   160: getfield 産 : Z
    //   163: ifeq -> 176
    //   166: aload_0
    //   167: iconst_1
    //   168: invokevirtual 少 : (Z)Landroid/view/View;
    //   171: astore #4
    //   173: goto -> 183
    //   176: aload_0
    //   177: iconst_1
    //   178: invokevirtual ね : (Z)Landroid/view/View;
    //   181: astore #4
    //   183: aload #4
    //   185: ifnonnull -> 193
    //   188: iload_3
    //   189: istore_1
    //   190: goto -> 199
    //   193: aload #4
    //   195: invokestatic 泳 : (Landroid/view/View;)I
    //   198: istore_1
    //   199: aload #5
    //   201: iload_1
    //   202: putfield 怖 : I
    //   205: aload_0
    //   206: getfield 淋 : I
    //   209: istore_1
    //   210: aload #5
    //   212: iload_1
    //   213: putfield 恐 : I
    //   216: aload #5
    //   218: iload_1
    //   219: newarray int
    //   221: putfield 痛 : [I
    //   224: iload_2
    //   225: aload_0
    //   226: getfield 淋 : I
    //   229: if_icmpge -> 335
    //   232: aload_0
    //   233: getfield 泳 : Z
    //   236: ifeq -> 270
    //   239: aload_0
    //   240: getfield 怖 : [Ly/sm;
    //   243: iload_2
    //   244: aaload
    //   245: ldc -2147483648
    //   247: invokevirtual 寒 : (I)I
    //   250: istore_3
    //   251: iload_3
    //   252: istore_1
    //   253: iload_3
    //   254: ldc -2147483648
    //   256: if_icmpeq -> 302
    //   259: aload_0
    //   260: getfield 恐 : Ly/l8;
    //   263: invokevirtual 寒 : ()I
    //   266: istore_1
    //   267: goto -> 298
    //   270: aload_0
    //   271: getfield 怖 : [Ly/sm;
    //   274: iload_2
    //   275: aaload
    //   276: ldc -2147483648
    //   278: invokevirtual 不 : (I)I
    //   281: istore_3
    //   282: iload_3
    //   283: istore_1
    //   284: iload_3
    //   285: ldc -2147483648
    //   287: if_icmpeq -> 302
    //   290: aload_0
    //   291: getfield 恐 : Ly/l8;
    //   294: invokevirtual 旨 : ()I
    //   297: istore_1
    //   298: iload_3
    //   299: iload_1
    //   300: isub
    //   301: istore_1
    //   302: aload #5
    //   304: getfield 痛 : [I
    //   307: iload_2
    //   308: iload_1
    //   309: iastore
    //   310: iload_2
    //   311: iconst_1
    //   312: iadd
    //   313: istore_2
    //   314: goto -> 224
    //   317: aload #5
    //   319: iconst_m1
    //   320: putfield 淋 : I
    //   323: aload #5
    //   325: iconst_m1
    //   326: putfield 怖 : I
    //   329: aload #5
    //   331: iconst_0
    //   332: putfield 恐 : I
    //   335: aload #5
    //   337: areturn
  }
  
  public final void 탈(int paramInt) {
    if (paramInt == 0)
      僕(); 
  }
  
  public final int 터(int paramInt, we paramwe, bf parambf) {
    return 士(paramInt, paramwe, parambf);
  }
  
  public final void 테(int paramInt) {
    rm rm1 = this.寝;
    if (rm1 != null && rm1.淋 != paramInt) {
      rm1.痛 = null;
      rm1.恐 = 0;
      rm1.淋 = -1;
      rm1.怖 = -1;
    } 
    this.壊 = paramInt;
    this.帰 = Integer.MIN_VALUE;
    탱();
  }
  
  public final int 토(int paramInt, we paramwe, bf parambf) {
    return 士(paramInt, paramwe, parambf);
  }
  
  public final void 통(Rect paramRect, int paramInt1, int paramInt2) {
    RecyclerView recyclerView;
    int i = 帰();
    i = 返() + i;
    int j = 歩();
    j = 壊() + j;
    if (this.痒 == 1) {
      int k = paramRect.height();
      recyclerView = this.堅;
      WeakHashMap weakHashMap = rw.硬;
      int m = Build.VERSION.SDK_INT;
      paramInt2 = pe.美(paramInt2, k + j, aw.暑((View)recyclerView));
      i = pe.美(paramInt1, this.臭 * this.淋 + i, aw.冷((View)this.堅));
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      int k = recyclerView.width();
      recyclerView = this.堅;
      WeakHashMap weakHashMap = rw.硬;
      int m = Build.VERSION.SDK_INT;
      paramInt1 = pe.美(paramInt1, k + i, aw.冷((View)recyclerView));
      i = pe.美(paramInt2, this.臭 * this.淋 + j, aw.暑((View)this.堅));
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    RecyclerView.冷(this.堅, paramInt2, paramInt1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\recyclerview\widget\StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */