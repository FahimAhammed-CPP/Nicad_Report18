package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import y.ぷ;
import y.성;
import y.혹;

public class FitWindowsFrameLayout extends FrameLayout {
  public 성 淋;
  
  public FitWindowsFrameLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public final boolean fitSystemWindows(Rect paramRect) {
    성 성1 = this.淋;
    if (성1 != null)
      paramRect.top = ((ぷ)((혹)성1).怖).あ(null, paramRect); 
    return super.fitSystemWindows(paramRect);
  }
  
  public void setOnFitSystemWindowsListener(성 param성) {
    this.淋 = param성;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\FitWindowsFrameLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */