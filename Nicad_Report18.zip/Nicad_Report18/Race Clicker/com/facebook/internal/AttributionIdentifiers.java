package com.facebook.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.facebook.FacebookSdk;
import java.lang.reflect.Method;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\t\n\002\020\t\n\002\020\013\n\002\b\006\030\000 \0222\0020\001:\003\022\023\024B\005¢\006\002\020\002R\023\020\003\032\004\030\0010\0048F¢\006\006\032\004\b\005\020\006R\020\020\007\032\004\030\0010\004X\016¢\006\002\n\000R\"\020\t\032\004\030\0010\0042\b\020\b\032\004\030\0010\004@BX\016¢\006\b\n\000\032\004\b\n\020\006R\"\020\013\032\004\030\0010\0042\b\020\b\032\004\030\0010\004@BX\016¢\006\b\n\000\032\004\b\f\020\006R\016\020\r\032\0020\016X\016¢\006\002\n\000R\036\020\020\032\0020\0172\006\020\b\032\0020\017@BX\016¢\006\b\n\000\032\004\b\020\020\021¨\006\025"}, d2 = {"Lcom/facebook/internal/AttributionIdentifiers;", "", "()V", "androidAdvertiserId", "", "getAndroidAdvertiserId", "()Ljava/lang/String;", "androidAdvertiserIdValue", "<set-?>", "androidInstallerPackage", "getAndroidInstallerPackage", "attributionId", "getAttributionId", "fetchTime", "", "", "isTrackingLimited", "()Z", "Companion", "GoogleAdInfo", "GoogleAdServiceConnection", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class AttributionIdentifiers {
  private static final String ANDROID_ID_COLUMN_NAME = "androidid";
  
  private static final String ATTRIBUTION_ID_COLUMN_NAME = "aid";
  
  private static final String ATTRIBUTION_ID_CONTENT_PROVIDER = "com.facebook.katana.provider.AttributionIdProvider";
  
  private static final String ATTRIBUTION_ID_CONTENT_PROVIDER_WAKIZASHI = "com.facebook.wakizashi.provider.AttributionIdProvider";
  
  private static final int CONNECTION_RESULT_SUCCESS = 0;
  
  public static final Companion Companion = new Companion(null);
  
  private static final long IDENTIFIER_REFRESH_INTERVAL_MILLIS = 3600000L;
  
  private static final String LIMIT_TRACKING_COLUMN_NAME = "limit_tracking";
  
  private static final String TAG = AttributionIdentifiers.class.getCanonicalName();
  
  public static AttributionIdentifiers cachedIdentifiers;
  
  private String androidAdvertiserIdValue;
  
  private String androidInstallerPackage;
  
  private String attributionId;
  
  private long fetchTime;
  
  private boolean isTrackingLimited;
  
  @JvmStatic
  public static final AttributionIdentifiers getAttributionIdentifiers(Context paramContext) {
    return Companion.getAttributionIdentifiers(paramContext);
  }
  
  @JvmStatic
  public static final boolean isTrackingLimited(Context paramContext) {
    return Companion.isTrackingLimited(paramContext);
  }
  
  public final String getAndroidAdvertiserId() {
    return (FacebookSdk.isInitialized() && FacebookSdk.getAdvertiserIDCollectionEnabled()) ? this.androidAdvertiserIdValue : null;
  }
  
  public final String getAndroidInstallerPackage() {
    return this.androidInstallerPackage;
  }
  
  public final String getAttributionId() {
    return this.attributionId;
  }
  
  public final boolean isTrackingLimited() {
    return this.isTrackingLimited;
  }
  
  @Metadata(d1 = {"\000:\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\004\n\002\020\b\n\000\n\002\020\t\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\013\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\020\020\021\032\0020\0172\006\020\022\032\0020\017H\002J\020\020\023\032\0020\0172\006\020\024\032\0020\025H\002J\022\020\026\032\004\030\0010\0172\006\020\024\032\0020\025H\002J\022\020\027\032\004\030\0010\0172\006\020\024\032\0020\025H\002J\022\020\030\032\004\030\0010\0172\006\020\024\032\0020\025H\007J\022\020\031\032\004\030\0010\0042\006\020\024\032\0020\025H\002J\020\020\032\032\0020\0332\006\020\024\032\0020\025H\002J\020\020\034\032\0020\0332\006\020\024\032\0020\025H\007R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\004XT¢\006\002\n\000R\016\020\007\032\0020\004XT¢\006\002\n\000R\016\020\b\032\0020\tXT¢\006\002\n\000R\016\020\n\032\0020\013XT¢\006\002\n\000R\016\020\f\032\0020\004XT¢\006\002\n\000R\020\020\r\032\004\030\0010\004X\004¢\006\002\n\000R\032\020\016\032\004\030\0010\0178\000@\000X\016¢\006\b\n\000\022\004\b\020\020\002¨\006\035"}, d2 = {"Lcom/facebook/internal/AttributionIdentifiers$Companion;", "", "()V", "ANDROID_ID_COLUMN_NAME", "", "ATTRIBUTION_ID_COLUMN_NAME", "ATTRIBUTION_ID_CONTENT_PROVIDER", "ATTRIBUTION_ID_CONTENT_PROVIDER_WAKIZASHI", "CONNECTION_RESULT_SUCCESS", "", "IDENTIFIER_REFRESH_INTERVAL_MILLIS", "", "LIMIT_TRACKING_COLUMN_NAME", "TAG", "cachedIdentifiers", "Lcom/facebook/internal/AttributionIdentifiers;", "getCachedIdentifiers$facebook_core_release$annotations", "cacheAndReturnIdentifiers", "identifiers", "getAndroidId", "context", "Landroid/content/Context;", "getAndroidIdViaReflection", "getAndroidIdViaService", "getAttributionIdentifiers", "getInstallerPackageName", "isGooglePlayServicesAvailable", "", "isTrackingLimited", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
    
    private final AttributionIdentifiers cacheAndReturnIdentifiers(AttributionIdentifiers param1AttributionIdentifiers) {
      param1AttributionIdentifiers.fetchTime = System.currentTimeMillis();
      AttributionIdentifiers.cachedIdentifiers = param1AttributionIdentifiers;
      return param1AttributionIdentifiers;
    }
    
    private final AttributionIdentifiers getAndroidId(Context param1Context) {
      Companion companion = this;
      AttributionIdentifiers attributionIdentifiers2 = getAndroidIdViaReflection(param1Context);
      AttributionIdentifiers attributionIdentifiers1 = attributionIdentifiers2;
      if (attributionIdentifiers2 == null) {
        AttributionIdentifiers attributionIdentifiers = getAndroidIdViaService(param1Context);
        attributionIdentifiers1 = attributionIdentifiers;
        if (attributionIdentifiers == null)
          attributionIdentifiers1 = new AttributionIdentifiers(); 
      } 
      return attributionIdentifiers1;
    }
    
    private final AttributionIdentifiers getAndroidIdViaReflection(Context param1Context) {
      try {
        Companion companion = this;
        if (!isGooglePlayServicesAvailable(param1Context))
          return null; 
        boolean bool = false;
        Method method = Utility.getMethodQuietly("com.google.android.gms.ads.identifier.AdvertisingIdClient", "getAdvertisingIdInfo", new Class[] { Context.class });
        if (method != null) {
          Object object = Utility.invokeMethodQuietly(null, method, new Object[] { param1Context });
          if (object != null) {
            Method method1 = Utility.getMethodQuietly(object.getClass(), "getId", new Class[0]);
            Method method2 = Utility.getMethodQuietly(object.getClass(), "isLimitAdTrackingEnabled", new Class[0]);
            if (method1 != null) {
              if (method2 == null)
                return null; 
              AttributionIdentifiers attributionIdentifiers = new AttributionIdentifiers();
              attributionIdentifiers.androidAdvertiserIdValue = (String)Utility.invokeMethodQuietly(object, method1, new Object[0]);
              object = Utility.invokeMethodQuietly(object, method2, new Object[0]);
              if (object != null)
                bool = object.booleanValue(); 
              attributionIdentifiers.isTrackingLimited = bool;
              return attributionIdentifiers;
            } 
          } 
        } 
        return null;
      } catch (Exception exception) {
        Utility.logd("android_id", exception);
        return null;
      } 
    }
    
    private final AttributionIdentifiers getAndroidIdViaService(Context param1Context) {
      AttributionIdentifiers.GoogleAdServiceConnection googleAdServiceConnection = new AttributionIdentifiers.GoogleAdServiceConnection();
      Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
      intent.setPackage("com.google.android.gms");
      try {
        boolean bool = param1Context.bindService(intent, googleAdServiceConnection, 1);
        if (bool) {
          try {
            AttributionIdentifiers.GoogleAdInfo googleAdInfo = new AttributionIdentifiers.GoogleAdInfo(googleAdServiceConnection.getBinder());
            AttributionIdentifiers attributionIdentifiers = new AttributionIdentifiers();
            attributionIdentifiers.androidAdvertiserIdValue = googleAdInfo.getAdvertiserId();
            attributionIdentifiers.isTrackingLimited = googleAdInfo.isTrackingLimited();
            param1Context.unbindService(googleAdServiceConnection);
            return attributionIdentifiers;
          } catch (Exception exception) {
            Utility.logd("android_id", exception);
            param1Context.unbindService(googleAdServiceConnection);
            return null;
          } finally {}
          param1Context.unbindService(googleAdServiceConnection);
          throw intent;
        } 
        return null;
      } catch (SecurityException securityException) {
        return null;
      } 
    }
    
    private final String getInstallerPackageName(Context param1Context) {
      PackageManager packageManager = param1Context.getPackageManager();
      return (packageManager != null) ? packageManager.getInstallerPackageName(param1Context.getPackageName()) : null;
    }
    
    private final boolean isGooglePlayServicesAvailable(Context param1Context) {
      Method method = Utility.getMethodQuietly("com.google.android.gms.common.GooglePlayServicesUtil", "isGooglePlayServicesAvailable", new Class[] { Context.class });
      if (method != null) {
        Object object = Utility.invokeMethodQuietly(null, method, new Object[] { param1Context });
        return (object instanceof Integer && (Intrinsics.areEqual(object, Integer.valueOf(0)) ^ true) == 0);
      } 
      return false;
    }
    
    @JvmStatic
    public final AttributionIdentifiers getAttributionIdentifiers(Context param1Context) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'context'
      //   3: invokestatic checkNotNullParameter : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: aload_0
      //   7: checkcast com/facebook/internal/AttributionIdentifiers$Companion
      //   10: astore #5
      //   12: aload_0
      //   13: aload_1
      //   14: invokespecial getAndroidId : (Landroid/content/Context;)Lcom/facebook/internal/AttributionIdentifiers;
      //   17: astore #7
      //   19: aconst_null
      //   20: astore #6
      //   22: aconst_null
      //   23: checkcast android/database/Cursor
      //   26: astore #5
      //   28: invokestatic myLooper : ()Landroid/os/Looper;
      //   31: invokestatic getMainLooper : ()Landroid/os/Looper;
      //   34: invokestatic areEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   37: ifne -> 406
      //   40: getstatic com/facebook/internal/AttributionIdentifiers.cachedIdentifiers : Lcom/facebook/internal/AttributionIdentifiers;
      //   43: astore #5
      //   45: aload #5
      //   47: ifnull -> 69
      //   50: invokestatic currentTimeMillis : ()J
      //   53: aload #5
      //   55: invokestatic access$getFetchTime$p : (Lcom/facebook/internal/AttributionIdentifiers;)J
      //   58: lsub
      //   59: ldc2_w 3600000
      //   62: lcmp
      //   63: ifge -> 69
      //   66: aload #5
      //   68: areturn
      //   69: aconst_null
      //   70: checkcast android/net/Uri
      //   73: astore #5
      //   75: aload_1
      //   76: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
      //   79: ldc 'com.facebook.katana.provider.AttributionIdProvider'
      //   81: iconst_0
      //   82: invokevirtual resolveContentProvider : (Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;
      //   85: astore #8
      //   87: aload_1
      //   88: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
      //   91: ldc 'com.facebook.wakizashi.provider.AttributionIdProvider'
      //   93: iconst_0
      //   94: invokevirtual resolveContentProvider : (Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;
      //   97: astore #5
      //   99: aload #8
      //   101: ifnull -> 137
      //   104: aload #8
      //   106: getfield packageName : Ljava/lang/String;
      //   109: astore #8
      //   111: aload #8
      //   113: ldc 'contentProviderInfo.packageName'
      //   115: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
      //   118: aload_1
      //   119: aload #8
      //   121: invokestatic validateSignature : (Landroid/content/Context;Ljava/lang/String;)Z
      //   124: ifeq -> 137
      //   127: ldc 'content://com.facebook.katana.provider.AttributionIdProvider'
      //   129: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
      //   132: astore #5
      //   134: goto -> 494
      //   137: aload #5
      //   139: ifnull -> 497
      //   142: aload #5
      //   144: getfield packageName : Ljava/lang/String;
      //   147: astore #5
      //   149: aload #5
      //   151: ldc 'wakizashiProviderInfo.packageName'
      //   153: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
      //   156: aload_1
      //   157: aload #5
      //   159: invokestatic validateSignature : (Landroid/content/Context;Ljava/lang/String;)Z
      //   162: ifeq -> 497
      //   165: ldc 'content://com.facebook.wakizashi.provider.AttributionIdProvider'
      //   167: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
      //   170: astore #5
      //   172: goto -> 494
      //   175: aload_0
      //   176: checkcast com/facebook/internal/AttributionIdentifiers$Companion
      //   179: astore #8
      //   181: aload_0
      //   182: aload_1
      //   183: invokespecial getInstallerPackageName : (Landroid/content/Context;)Ljava/lang/String;
      //   186: astore #8
      //   188: aload #8
      //   190: ifnull -> 200
      //   193: aload #7
      //   195: aload #8
      //   197: invokestatic access$setAndroidInstallerPackage$p : (Lcom/facebook/internal/AttributionIdentifiers;Ljava/lang/String;)V
      //   200: aload #5
      //   202: ifnonnull -> 217
      //   205: aload_0
      //   206: checkcast com/facebook/internal/AttributionIdentifiers$Companion
      //   209: astore_1
      //   210: aload_0
      //   211: aload #7
      //   213: invokespecial cacheAndReturnIdentifiers : (Lcom/facebook/internal/AttributionIdentifiers;)Lcom/facebook/internal/AttributionIdentifiers;
      //   216: areturn
      //   217: aload_1
      //   218: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
      //   221: aload #5
      //   223: iconst_3
      //   224: anewarray java/lang/String
      //   227: dup
      //   228: iconst_0
      //   229: ldc_w 'aid'
      //   232: aastore
      //   233: dup
      //   234: iconst_1
      //   235: ldc_w 'androidid'
      //   238: aastore
      //   239: dup
      //   240: iconst_2
      //   241: ldc_w 'limit_tracking'
      //   244: aastore
      //   245: aconst_null
      //   246: aconst_null
      //   247: aconst_null
      //   248: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
      //   251: astore_1
      //   252: aload_1
      //   253: ifnull -> 369
      //   256: aload_1
      //   257: invokeinterface moveToFirst : ()Z
      //   262: ifne -> 268
      //   265: goto -> 369
      //   268: aload_1
      //   269: ldc_w 'aid'
      //   272: invokeinterface getColumnIndex : (Ljava/lang/String;)I
      //   277: istore_2
      //   278: aload_1
      //   279: ldc_w 'androidid'
      //   282: invokeinterface getColumnIndex : (Ljava/lang/String;)I
      //   287: istore_3
      //   288: aload_1
      //   289: ldc_w 'limit_tracking'
      //   292: invokeinterface getColumnIndex : (Ljava/lang/String;)I
      //   297: istore #4
      //   299: aload #7
      //   301: aload_1
      //   302: iload_2
      //   303: invokeinterface getString : (I)Ljava/lang/String;
      //   308: invokestatic access$setAttributionId$p : (Lcom/facebook/internal/AttributionIdentifiers;Ljava/lang/String;)V
      //   311: iload_3
      //   312: ifle -> 356
      //   315: iload #4
      //   317: ifle -> 356
      //   320: aload #7
      //   322: invokevirtual getAndroidAdvertiserId : ()Ljava/lang/String;
      //   325: ifnonnull -> 356
      //   328: aload #7
      //   330: aload_1
      //   331: iload_3
      //   332: invokeinterface getString : (I)Ljava/lang/String;
      //   337: invokestatic access$setAndroidAdvertiserIdValue$p : (Lcom/facebook/internal/AttributionIdentifiers;Ljava/lang/String;)V
      //   340: aload #7
      //   342: aload_1
      //   343: iload #4
      //   345: invokeinterface getString : (I)Ljava/lang/String;
      //   350: invokestatic parseBoolean : (Ljava/lang/String;)Z
      //   353: invokestatic access$setTrackingLimited$p : (Lcom/facebook/internal/AttributionIdentifiers;Z)V
      //   356: aload_1
      //   357: invokeinterface close : ()V
      //   362: aload_0
      //   363: aload #7
      //   365: invokespecial cacheAndReturnIdentifiers : (Lcom/facebook/internal/AttributionIdentifiers;)Lcom/facebook/internal/AttributionIdentifiers;
      //   368: areturn
      //   369: aload_0
      //   370: checkcast com/facebook/internal/AttributionIdentifiers$Companion
      //   373: astore #5
      //   375: aload_0
      //   376: aload #7
      //   378: invokespecial cacheAndReturnIdentifiers : (Lcom/facebook/internal/AttributionIdentifiers;)Lcom/facebook/internal/AttributionIdentifiers;
      //   381: astore #5
      //   383: aload_1
      //   384: ifnull -> 393
      //   387: aload_1
      //   388: invokeinterface close : ()V
      //   393: aload #5
      //   395: areturn
      //   396: astore #5
      //   398: goto -> 481
      //   401: astore #5
      //   403: goto -> 432
      //   406: new com/facebook/FacebookException
      //   409: dup
      //   410: ldc_w 'getAttributionIdentifiers cannot be called on the main thread.'
      //   413: invokespecial <init> : (Ljava/lang/String;)V
      //   416: checkcast java/lang/Throwable
      //   419: athrow
      //   420: astore #5
      //   422: aload #6
      //   424: astore_1
      //   425: goto -> 481
      //   428: astore #5
      //   430: aconst_null
      //   431: astore_1
      //   432: invokestatic access$getTAG$cp : ()Ljava/lang/String;
      //   435: astore #6
      //   437: new java/lang/StringBuilder
      //   440: dup
      //   441: ldc_w 'Caught unexpected exception in getAttributionId(): '
      //   444: invokespecial <init> : (Ljava/lang/String;)V
      //   447: astore #7
      //   449: aload #7
      //   451: aload #5
      //   453: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   456: pop
      //   457: aload #6
      //   459: aload #7
      //   461: invokevirtual toString : ()Ljava/lang/String;
      //   464: invokestatic logd : (Ljava/lang/String;Ljava/lang/String;)V
      //   467: aload_1
      //   468: ifnull -> 477
      //   471: aload_1
      //   472: invokeinterface close : ()V
      //   477: aconst_null
      //   478: areturn
      //   479: astore #5
      //   481: aload_1
      //   482: ifnull -> 491
      //   485: aload_1
      //   486: invokeinterface close : ()V
      //   491: aload #5
      //   493: athrow
      //   494: goto -> 175
      //   497: aconst_null
      //   498: astore #5
      //   500: goto -> 175
      // Exception table:
      //   from	to	target	type
      //   28	45	428	java/lang/Exception
      //   28	45	420	finally
      //   50	66	428	java/lang/Exception
      //   50	66	420	finally
      //   69	99	428	java/lang/Exception
      //   69	99	420	finally
      //   104	134	428	java/lang/Exception
      //   104	134	420	finally
      //   142	172	428	java/lang/Exception
      //   142	172	420	finally
      //   175	188	428	java/lang/Exception
      //   175	188	420	finally
      //   193	200	428	java/lang/Exception
      //   193	200	420	finally
      //   205	217	428	java/lang/Exception
      //   205	217	420	finally
      //   217	252	428	java/lang/Exception
      //   217	252	420	finally
      //   256	265	401	java/lang/Exception
      //   256	265	396	finally
      //   268	311	401	java/lang/Exception
      //   268	311	396	finally
      //   320	356	401	java/lang/Exception
      //   320	356	396	finally
      //   369	383	401	java/lang/Exception
      //   369	383	396	finally
      //   406	420	428	java/lang/Exception
      //   406	420	420	finally
      //   432	467	479	finally
    }
    
    @JvmStatic
    public final boolean isTrackingLimited(Context param1Context) {
      Intrinsics.checkNotNullParameter(param1Context, "context");
      Companion companion = this;
      AttributionIdentifiers attributionIdentifiers = getAttributionIdentifiers(param1Context);
      return (attributionIdentifiers != null && attributionIdentifiers.isTrackingLimited());
    }
  }
  
  @Metadata(d1 = {"\000\"\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\003\n\002\020\013\n\002\b\004\b\002\030\000 \r2\0020\001:\001\rB\r\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020\f\032\0020\003H\026R\023\020\005\032\004\030\0010\0068F¢\006\006\032\004\b\007\020\bR\016\020\002\032\0020\003X\004¢\006\002\n\000R\021\020\t\032\0020\n8F¢\006\006\032\004\b\t\020\013¨\006\016"}, d2 = {"Lcom/facebook/internal/AttributionIdentifiers$GoogleAdInfo;", "Landroid/os/IInterface;", "binder", "Landroid/os/IBinder;", "(Landroid/os/IBinder;)V", "advertiserId", "", "getAdvertiserId", "()Ljava/lang/String;", "isTrackingLimited", "", "()Z", "asBinder", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class GoogleAdInfo implements IInterface {
    public static final Companion Companion = new Companion(null);
    
    private static final int FIRST_TRANSACTION_CODE = 1;
    
    private static final int SECOND_TRANSACTION_CODE = 2;
    
    private final IBinder binder;
    
    public GoogleAdInfo(IBinder param1IBinder) {
      this.binder = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.binder;
    }
    
    public final String getAdvertiserId() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Intrinsics.checkNotNullExpressionValue(parcel1, "Parcel.obtain()");
      Parcel parcel2 = Parcel.obtain();
      Intrinsics.checkNotNullExpressionValue(parcel2, "Parcel.obtain()");
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        this.binder.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public final boolean isTrackingLimited() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Intrinsics.checkNotNullExpressionValue(parcel1, "Parcel.obtain()");
      Parcel parcel2 = Parcel.obtain();
      Intrinsics.checkNotNullExpressionValue(parcel2, "Parcel.obtain()");
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        boolean bool = true;
        parcel1.writeInt(1);
        this.binder.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        if (i == 0)
          bool = false; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/internal/AttributionIdentifiers$GoogleAdInfo$Companion;", "", "()V", "FIRST_TRANSACTION_CODE", "", "SECOND_TRANSACTION_CODE", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/internal/AttributionIdentifiers$GoogleAdInfo$Companion;", "", "()V", "FIRST_TRANSACTION_CODE", "", "SECOND_TRANSACTION_CODE", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\003\b\002\030\0002\0020\001B\005¢\006\002\020\002J\034\020\013\032\0020\f2\b\020\r\032\004\030\0010\0162\b\020\017\032\004\030\0010\004H\026J\022\020\020\032\0020\f2\b\020\r\032\004\030\0010\016H\026R\021\020\003\032\0020\0048F¢\006\006\032\004\b\005\020\006R\016\020\007\032\0020\bX\004¢\006\002\n\000R\024\020\t\032\b\022\004\022\0020\0040\nX\004¢\006\002\n\000¨\006\021"}, d2 = {"Lcom/facebook/internal/AttributionIdentifiers$GoogleAdServiceConnection;", "Landroid/content/ServiceConnection;", "()V", "binder", "Landroid/os/IBinder;", "getBinder", "()Landroid/os/IBinder;", "consumed", "Ljava/util/concurrent/atomic/AtomicBoolean;", "queue", "Ljava/util/concurrent/BlockingQueue;", "onServiceConnected", "", "name", "Landroid/content/ComponentName;", "service", "onServiceDisconnected", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class GoogleAdServiceConnection implements ServiceConnection {
    private final AtomicBoolean consumed = new AtomicBoolean(false);
    
    private final BlockingQueue<IBinder> queue = new LinkedBlockingDeque<IBinder>();
    
    public final IBinder getBinder() throws InterruptedException {
      if ((this.consumed.compareAndSet(true, true) ^ true) != 0) {
        IBinder iBinder = (IBinder)this.queue.take();
        Intrinsics.checkNotNullExpressionValue(iBinder, "queue.take()");
        return iBinder;
      } 
      throw new IllegalStateException("Binder already consumed".toString());
    }
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      if (param1IBinder != null)
        try {
          this.queue.put(param1IBinder);
          return;
        } catch (InterruptedException interruptedException) {
          return;
        }  
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\AttributionIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */