package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import y.iq;
import y.z00;
import y.獅;
import y.茎;
import y.走;

public class ConstraintProxyUpdateReceiver extends BroadcastReceiver {
  static {
    獅.苦("ConstrntProxyUpdtRecvr");
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    獅 獅;
    if (paramIntent != null) {
      iq = (iq)paramIntent.getAction();
    } else {
      iq = null;
    } 
    if (!"androidx.work.impl.background.systemalarm.UpdateProxies".equals(iq)) {
      獅 = 獅.辛();
      String.format("Ignoring unknown action %s", new Object[] { iq });
      獅.寒(new Throwable[0]);
      return;
    } 
    BroadcastReceiver.PendingResult pendingResult = goAsync();
    iq iq = (z00.ニ((Context)獅)).噛;
    走 走 = new 走(this, paramIntent, 獅, pendingResult, 2);
    ((茎)iq).不((Runnable)走);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\background\systemalarm\ConstraintProxyUpdateReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */