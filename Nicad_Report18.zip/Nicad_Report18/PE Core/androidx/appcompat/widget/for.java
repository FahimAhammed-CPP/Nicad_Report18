package androidx.appcompat.widget;

import android.widget.AutoCompleteTextView;
import y.鰺;

public abstract class for {
  public static void 堅(SearchView.SearchAutoComplete paramSearchAutoComplete, int paramInt) {
    paramSearchAutoComplete.setInputMethodMode(paramInt);
  }
  
  public static void 硬(AutoCompleteTextView paramAutoCompleteTextView) {
    鰺.怖(paramAutoCompleteTextView);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\for.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */