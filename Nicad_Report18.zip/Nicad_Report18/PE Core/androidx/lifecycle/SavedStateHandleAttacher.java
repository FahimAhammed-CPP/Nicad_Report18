package androidx.lifecycle;

import y.aj;
import y.尻;
import y.心;
import y.肉;
import y.腰;

public final class SavedStateHandleAttacher implements 肉 {
  public final aj 淋;
  
  public SavedStateHandleAttacher(aj paramaj) {
    this.淋 = paramaj;
  }
  
  public final void 暑(腰 param腰, 尻 param尻) {
    boolean bool;
    if (param尻 == 尻.ON_CREATE) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      param腰.痒().興((心)this);
      this.淋.堅();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Next event must be ON_CREATE, it was ");
    stringBuilder.append(param尻);
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\SavedStateHandleAttacher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */