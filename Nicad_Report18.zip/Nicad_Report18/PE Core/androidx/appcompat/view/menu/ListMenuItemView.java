package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import y.dk;
import y.q3;
import y.rw;
import y.td;
import y.x2;

public class ListMenuItemView extends LinearLayout implements q3, AbsListView.SelectionBoundsAdjuster {
  public final int 壊;
  
  public boolean 寝;
  
  public final Context 帰;
  
  public ImageView 怖;
  
  public RadioButton 恐;
  
  public final Drawable 歩;
  
  public final Drawable 死;
  
  public final boolean 泳;
  
  public x2 淋;
  
  public LinearLayout 産;
  
  public CheckBox 痒;
  
  public TextView 痛;
  
  public TextView 臭;
  
  public ImageView 興;
  
  public ImageView 起;
  
  public LayoutInflater 踊;
  
  public boolean 返;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    dk dk = dk.嬉(getContext(), paramAttributeSet, td.크, 2130903680);
    this.死 = dk.冷(5);
    this.壊 = dk.不(1, -1);
    this.返 = dk.硬(7, false);
    this.帰 = paramContext;
    this.歩 = dk.冷(8);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, new int[] { 16843049 }, 2130903398, 0);
    this.泳 = typedArray.hasValue(0);
    dk.寂();
    typedArray.recycle();
  }
  
  private LayoutInflater getInflater() {
    if (this.踊 == null)
      this.踊 = LayoutInflater.from(getContext()); 
    return this.踊;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.起;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public final void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.興;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.興.getLayoutParams();
      int i = paramRect.top;
      paramRect.top = this.興.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + i;
    } 
  }
  
  public x2 getItemData() {
    return this.淋;
  }
  
  public final void onFinishInflate() {
    super.onFinishInflate();
    rw.歩((View)this, this.死);
    TextView textView = (TextView)findViewById(2131231372);
    this.痛 = textView;
    int i = this.壊;
    if (i != -1)
      textView.setTextAppearance(this.帰, i); 
    this.臭 = (TextView)findViewById(2131231297);
    ImageView imageView = (ImageView)findViewById(2131231330);
    this.起 = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.歩); 
    this.興 = (ImageView)findViewById(2131231087);
    this.産 = (LinearLayout)findViewById(2131230989);
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    if (this.怖 != null && this.返) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.怖.getLayoutParams();
      int i = layoutParams.height;
      if (i > 0 && layoutParams1.width <= 0)
        layoutParams1.width = i; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    boolean bool;
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.恐 == null && this.痒 == null)
      return; 
    if ((this.淋.産 & 0x4) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (this.恐 == null) {
        RadioButton radioButton2 = (RadioButton)getInflater().inflate(2131427345, (ViewGroup)this, false);
        this.恐 = radioButton2;
        LinearLayout linearLayout = this.産;
        if (linearLayout != null) {
          linearLayout.addView((View)radioButton2, -1);
        } else {
          addView((View)radioButton2, -1);
        } 
      } 
      RadioButton radioButton1 = this.恐;
      CheckBox checkBox1 = this.痒;
    } else {
      if (this.痒 == null) {
        CheckBox checkBox1 = (CheckBox)getInflater().inflate(2131427342, (ViewGroup)this, false);
        this.痒 = checkBox1;
        LinearLayout linearLayout = this.産;
        if (linearLayout != null) {
          linearLayout.addView((View)checkBox1, -1);
        } else {
          addView((View)checkBox1, -1);
        } 
      } 
      checkBox = this.痒;
      radioButton = this.恐;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.淋.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.痒;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.恐;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    boolean bool;
    CheckBox checkBox;
    if ((this.淋.産 & 0x4) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (this.恐 == null) {
        RadioButton radioButton1 = (RadioButton)getInflater().inflate(2131427345, (ViewGroup)this, false);
        this.恐 = radioButton1;
        LinearLayout linearLayout = this.産;
        if (linearLayout != null) {
          linearLayout.addView((View)radioButton1, -1);
        } else {
          addView((View)radioButton1, -1);
        } 
      } 
      RadioButton radioButton = this.恐;
    } else {
      if (this.痒 == null) {
        CheckBox checkBox1 = (CheckBox)getInflater().inflate(2131427342, (ViewGroup)this, false);
        this.痒 = checkBox1;
        LinearLayout linearLayout = this.産;
        if (linearLayout != null) {
          linearLayout.addView((View)checkBox1, -1);
        } else {
          addView((View)checkBox1, -1);
        } 
      } 
      checkBox = this.痒;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.寝 = paramBoolean;
    this.返 = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.興;
    if (imageView != null) {
      byte b;
      if (!this.泳 && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.淋.悲.getClass();
    boolean bool = this.寝;
    if (!bool && !this.返)
      return; 
    ImageView imageView = this.怖;
    if (imageView == null && paramDrawable == null && !this.返)
      return; 
    if (imageView == null) {
      imageView = (ImageView)getInflater().inflate(2131427343, (ViewGroup)this, false);
      this.怖 = imageView;
      LinearLayout linearLayout = this.産;
      if (linearLayout != null) {
        linearLayout.addView((View)imageView, 0);
      } else {
        addView((View)imageView, 0);
      } 
    } 
    if (paramDrawable != null || this.返) {
      imageView = this.怖;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.怖.getVisibility() != 0)
        this.怖.setVisibility(0); 
      return;
    } 
    this.怖.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.痛.setText(paramCharSequence);
      if (this.痛.getVisibility() != 0) {
        this.痛.setVisibility(0);
        return;
      } 
    } else if (this.痛.getVisibility() != 8) {
      this.痛.setVisibility(8);
    } 
  }
  
  public final void 熱(x2 paramx2) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: putfield 淋 : Ly/x2;
    //   5: aload_1
    //   6: invokevirtual isVisible : ()Z
    //   9: istore #5
    //   11: iconst_0
    //   12: istore #4
    //   14: iload #5
    //   16: ifeq -> 24
    //   19: iconst_0
    //   20: istore_3
    //   21: goto -> 27
    //   24: bipush #8
    //   26: istore_3
    //   27: aload_0
    //   28: iload_3
    //   29: invokevirtual setVisibility : (I)V
    //   32: aload_0
    //   33: aload_1
    //   34: getfield 冷 : Ljava/lang/CharSequence;
    //   37: invokevirtual setTitle : (Ljava/lang/CharSequence;)V
    //   40: aload_0
    //   41: aload_1
    //   42: invokevirtual isCheckable : ()Z
    //   45: invokevirtual setCheckable : (Z)V
    //   48: aload_1
    //   49: getfield 悲 : Ly/r2;
    //   52: astore #6
    //   54: aload #6
    //   56: invokevirtual 寂 : ()Z
    //   59: ifeq -> 92
    //   62: aload #6
    //   64: invokevirtual 悲 : ()Z
    //   67: ifeq -> 78
    //   70: aload_1
    //   71: getfield 辛 : C
    //   74: istore_3
    //   75: goto -> 83
    //   78: aload_1
    //   79: getfield 旨 : C
    //   82: istore_3
    //   83: iload_3
    //   84: ifeq -> 92
    //   87: iconst_1
    //   88: istore_3
    //   89: goto -> 94
    //   92: iconst_0
    //   93: istore_3
    //   94: aload #6
    //   96: invokevirtual 悲 : ()Z
    //   99: pop
    //   100: iload_3
    //   101: ifeq -> 169
    //   104: aload_0
    //   105: getfield 淋 : Ly/x2;
    //   108: astore #6
    //   110: aload #6
    //   112: getfield 悲 : Ly/r2;
    //   115: astore #7
    //   117: aload #7
    //   119: invokevirtual 寂 : ()Z
    //   122: ifeq -> 157
    //   125: aload #7
    //   127: invokevirtual 悲 : ()Z
    //   130: ifeq -> 142
    //   133: aload #6
    //   135: getfield 辛 : C
    //   138: istore_3
    //   139: goto -> 148
    //   142: aload #6
    //   144: getfield 旨 : C
    //   147: istore_3
    //   148: iload_3
    //   149: ifeq -> 157
    //   152: iconst_1
    //   153: istore_3
    //   154: goto -> 159
    //   157: iconst_0
    //   158: istore_3
    //   159: iload_3
    //   160: ifeq -> 169
    //   163: iload #4
    //   165: istore_3
    //   166: goto -> 172
    //   169: bipush #8
    //   171: istore_3
    //   172: iload_3
    //   173: ifne -> 496
    //   176: aload_0
    //   177: getfield 臭 : Landroid/widget/TextView;
    //   180: astore #7
    //   182: aload_0
    //   183: getfield 淋 : Ly/x2;
    //   186: astore #6
    //   188: aload #6
    //   190: getfield 悲 : Ly/r2;
    //   193: invokevirtual 悲 : ()Z
    //   196: ifeq -> 208
    //   199: aload #6
    //   201: getfield 辛 : C
    //   204: istore_2
    //   205: goto -> 214
    //   208: aload #6
    //   210: getfield 旨 : C
    //   213: istore_2
    //   214: iload_2
    //   215: ifne -> 226
    //   218: ldc_w ''
    //   221: astore #6
    //   223: goto -> 489
    //   226: aload #6
    //   228: getfield 悲 : Ly/r2;
    //   231: astore #8
    //   233: aload #8
    //   235: getfield 硬 : Landroid/content/Context;
    //   238: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   241: astore #9
    //   243: new java/lang/StringBuilder
    //   246: dup
    //   247: invokespecial <init> : ()V
    //   250: astore #10
    //   252: aload #8
    //   254: getfield 硬 : Landroid/content/Context;
    //   257: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   260: invokevirtual hasPermanentMenuKey : ()Z
    //   263: ifeq -> 280
    //   266: aload #10
    //   268: aload #9
    //   270: ldc_w 2131689489
    //   273: invokevirtual getString : (I)Ljava/lang/String;
    //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: pop
    //   280: aload #8
    //   282: invokevirtual 悲 : ()Z
    //   285: ifeq -> 298
    //   288: aload #6
    //   290: getfield ぱ : I
    //   293: istore #4
    //   295: goto -> 305
    //   298: aload #6
    //   300: getfield 不 : I
    //   303: istore #4
    //   305: iload #4
    //   307: ldc_w 65536
    //   310: aload #9
    //   312: ldc_w 2131689485
    //   315: invokevirtual getString : (I)Ljava/lang/String;
    //   318: aload #10
    //   320: invokestatic 熱 : (IILjava/lang/String;Ljava/lang/StringBuilder;)V
    //   323: iload #4
    //   325: sipush #4096
    //   328: aload #9
    //   330: ldc_w 2131689481
    //   333: invokevirtual getString : (I)Ljava/lang/String;
    //   336: aload #10
    //   338: invokestatic 熱 : (IILjava/lang/String;Ljava/lang/StringBuilder;)V
    //   341: iload #4
    //   343: iconst_2
    //   344: aload #9
    //   346: ldc_w 2131689480
    //   349: invokevirtual getString : (I)Ljava/lang/String;
    //   352: aload #10
    //   354: invokestatic 熱 : (IILjava/lang/String;Ljava/lang/StringBuilder;)V
    //   357: iload #4
    //   359: iconst_1
    //   360: aload #9
    //   362: ldc_w 2131689486
    //   365: invokevirtual getString : (I)Ljava/lang/String;
    //   368: aload #10
    //   370: invokestatic 熱 : (IILjava/lang/String;Ljava/lang/StringBuilder;)V
    //   373: iload #4
    //   375: iconst_4
    //   376: aload #9
    //   378: ldc_w 2131689488
    //   381: invokevirtual getString : (I)Ljava/lang/String;
    //   384: aload #10
    //   386: invokestatic 熱 : (IILjava/lang/String;Ljava/lang/StringBuilder;)V
    //   389: iload #4
    //   391: bipush #8
    //   393: aload #9
    //   395: ldc_w 2131689484
    //   398: invokevirtual getString : (I)Ljava/lang/String;
    //   401: aload #10
    //   403: invokestatic 熱 : (IILjava/lang/String;Ljava/lang/StringBuilder;)V
    //   406: iload_2
    //   407: bipush #8
    //   409: if_icmpeq -> 468
    //   412: iload_2
    //   413: bipush #10
    //   415: if_icmpeq -> 451
    //   418: iload_2
    //   419: bipush #32
    //   421: if_icmpeq -> 434
    //   424: aload #10
    //   426: iload_2
    //   427: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   430: pop
    //   431: goto -> 482
    //   434: aload #10
    //   436: aload #9
    //   438: ldc_w 2131689487
    //   441: invokevirtual getString : (I)Ljava/lang/String;
    //   444: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   447: pop
    //   448: goto -> 482
    //   451: aload #10
    //   453: aload #9
    //   455: ldc_w 2131689483
    //   458: invokevirtual getString : (I)Ljava/lang/String;
    //   461: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   464: pop
    //   465: goto -> 482
    //   468: aload #10
    //   470: aload #9
    //   472: ldc_w 2131689482
    //   475: invokevirtual getString : (I)Ljava/lang/String;
    //   478: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   481: pop
    //   482: aload #10
    //   484: invokevirtual toString : ()Ljava/lang/String;
    //   487: astore #6
    //   489: aload #7
    //   491: aload #6
    //   493: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   496: aload_0
    //   497: getfield 臭 : Landroid/widget/TextView;
    //   500: invokevirtual getVisibility : ()I
    //   503: iload_3
    //   504: if_icmpeq -> 515
    //   507: aload_0
    //   508: getfield 臭 : Landroid/widget/TextView;
    //   511: iload_3
    //   512: invokevirtual setVisibility : (I)V
    //   515: aload_0
    //   516: aload_1
    //   517: invokevirtual getIcon : ()Landroid/graphics/drawable/Drawable;
    //   520: invokevirtual setIcon : (Landroid/graphics/drawable/Drawable;)V
    //   523: aload_0
    //   524: aload_1
    //   525: invokevirtual isEnabled : ()Z
    //   528: invokevirtual setEnabled : (Z)V
    //   531: aload_0
    //   532: aload_1
    //   533: invokevirtual hasSubMenu : ()Z
    //   536: invokespecial setSubMenuArrowVisible : (Z)V
    //   539: aload_0
    //   540: aload_1
    //   541: getfield 怖 : Ljava/lang/CharSequence;
    //   544: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   547: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */