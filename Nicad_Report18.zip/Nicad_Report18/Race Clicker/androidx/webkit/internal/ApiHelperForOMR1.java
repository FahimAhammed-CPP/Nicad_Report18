package androidx.webkit.internal;

import android.content.Context;
import android.net.Uri;
import android.webkit.SafeBrowsingResponse;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import java.util.List;

public class ApiHelperForOMR1 {
  public static void backToSafety(SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    paramSafeBrowsingResponse.backToSafety(paramBoolean);
  }
  
  public static Uri getSafeBrowsingPrivacyPolicyUrl() {
    return WebView.getSafeBrowsingPrivacyPolicyUrl();
  }
  
  public static void proceed(SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    paramSafeBrowsingResponse.proceed(paramBoolean);
  }
  
  public static void setSafeBrowsingWhitelist(List<String> paramList, ValueCallback<Boolean> paramValueCallback) {
    WebView.setSafeBrowsingWhitelist(paramList, paramValueCallback);
  }
  
  public static void showInterstitial(SafeBrowsingResponse paramSafeBrowsingResponse, boolean paramBoolean) {
    paramSafeBrowsingResponse.showInterstitial(paramBoolean);
  }
  
  public static void startSafeBrowsing(Context paramContext, ValueCallback<Boolean> paramValueCallback) {
    WebView.startSafeBrowsing(paramContext, paramValueCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\webkit\internal\ApiHelperForOMR1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */