package com.appsflyer.internal;

public final class AFf1wSDK extends AFa1sSDK {
  public final AFd1sSDK AFKeystoreWrapper() {
    return AFd1sSDK.getLevel;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\appsflyer\internal\AFf1wSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */