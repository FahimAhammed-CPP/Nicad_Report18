package com.applovin.exoplayer2.b;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.PlaybackParams;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Pair;
import com.applovin.exoplayer2.am;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.u;
import com.applovin.exoplayer2.v;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;
import java.util.concurrent.Executor;

public final class n implements h {
  public static boolean a;
  
  private long A;
  
  private long B;
  
  private long C;
  
  private long D;
  
  private int E;
  
  private boolean F;
  
  private boolean G;
  
  private long H;
  
  private float I;
  
  private f[] J;
  
  private ByteBuffer[] K;
  
  private ByteBuffer L;
  
  private int M;
  
  private ByteBuffer N;
  
  private byte[] O;
  
  private int P;
  
  private int Q;
  
  private boolean R;
  
  private boolean S;
  
  private boolean T;
  
  private boolean U;
  
  private int V;
  
  private k W;
  
  private boolean X;
  
  private long Y;
  
  private boolean Z;
  
  private boolean aa;
  
  private final e b;
  
  private final a c;
  
  private final boolean d;
  
  private final m e;
  
  private final x f;
  
  private final f[] g;
  
  private final f[] h;
  
  private final ConditionVariable i;
  
  private final j j;
  
  private final ArrayDeque<e> k;
  
  private final boolean l;
  
  private final int m;
  
  private h n;
  
  private final f<h.b> o;
  
  private final f<h.e> p;
  
  private h.c q;
  
  private b r;
  
  private b s;
  
  private AudioTrack t;
  
  private d u;
  
  private e v;
  
  private e w;
  
  private am x;
  
  private ByteBuffer y;
  
  private int z;
  
  public n(e parame, a parama, boolean paramBoolean1, boolean paramBoolean2, int paramInt) {
    this.b = parame;
    this.c = (a)com.applovin.exoplayer2.l.a.b(parama);
    if (ai.a >= 21 && paramBoolean1) {
      paramBoolean1 = true;
    } else {
      paramBoolean1 = false;
    } 
    this.d = paramBoolean1;
    if (ai.a >= 23 && paramBoolean2) {
      paramBoolean1 = true;
    } else {
      paramBoolean1 = false;
    } 
    this.l = paramBoolean1;
    if (ai.a < 29)
      paramInt = 0; 
    this.m = paramInt;
    this.i = new ConditionVariable(true);
    this.j = new j(new g());
    m m1 = new m();
    this.e = m1;
    x x1 = new x();
    this.f = x1;
    ArrayList<? super l> arrayList = new ArrayList();
    Collections.addAll(arrayList, new l[] { (l)new t(), (l)m1, (l)x1 });
    Collections.addAll(arrayList, (Object[])parama.a());
    this.g = arrayList.<f>toArray(new f[0]);
    this.h = new f[] { (f)new p() };
    this.I = 1.0F;
    this.u = d.a;
    this.V = 0;
    this.W = new k(0, 0.0F);
    this.w = new e(am.a, false, 0L, 0L);
    this.x = am.a;
    this.Q = -1;
    this.J = new f[0];
    this.K = new ByteBuffer[0];
    this.k = new ArrayDeque<e>();
    this.o = new f<h.b>(100L);
    this.p = new f<h.e>(100L);
  }
  
  private long A() {
    return (this.s.c == 0) ? (this.C / this.s.d) : this.D;
  }
  
  private void B() {
    if (!this.S) {
      this.S = true;
      this.j.e(A());
      this.t.stop();
      this.z = 0;
    } 
  }
  
  private static int a(int paramInt1, int paramInt2) {
    AudioAttributes audioAttributes = (new AudioAttributes.Builder()).setUsage(1).setContentType(3).build();
    for (int i = 8; i > 0; i--) {
      if (AudioTrack.isDirectPlaybackSupported((new AudioFormat.Builder()).setEncoding(paramInt1).setSampleRate(paramInt2).setChannelMask(ai.f(i)).build(), audioAttributes))
        return i; 
    } 
    return 0;
  }
  
  private static int a(int paramInt, ByteBuffer paramByteBuffer) {
    StringBuilder stringBuilder;
    switch (paramInt) {
      default:
        stringBuilder = new StringBuilder("Unexpected audio encoding: ");
        stringBuilder.append(paramInt);
        throw new IllegalStateException(stringBuilder.toString());
      case 17:
        return c.a((ByteBuffer)stringBuilder);
      case 16:
        return 1024;
      case 15:
        return 512;
      case 14:
        paramInt = b.b((ByteBuffer)stringBuilder);
        return (paramInt == -1) ? 0 : (b.a((ByteBuffer)stringBuilder, paramInt) * 16);
      case 11:
      case 12:
        return 2048;
      case 10:
        return 1024;
      case 9:
        paramInt = r.b(ai.a((ByteBuffer)stringBuilder, stringBuilder.position()));
        if (paramInt != -1)
          return paramInt; 
        throw new IllegalArgumentException();
      case 7:
      case 8:
        return o.a((ByteBuffer)stringBuilder);
      case 5:
      case 6:
      case 18:
        break;
    } 
    return b.a((ByteBuffer)stringBuilder);
  }
  
  private int a(AudioFormat paramAudioFormat, AudioAttributes paramAudioAttributes) {
    return (ai.a >= 31) ? AudioManager.getPlaybackOffloadSupport(paramAudioFormat, paramAudioAttributes) : (!AudioManager.isOffloadedPlaybackSupported(paramAudioFormat, paramAudioAttributes) ? 0 : ((ai.a == 30 && ai.d.startsWith("Pixel")) ? 2 : 1));
  }
  
  private static int a(AudioTrack paramAudioTrack, ByteBuffer paramByteBuffer, int paramInt) {
    return paramAudioTrack.write(paramByteBuffer, paramInt, 1);
  }
  
  private int a(AudioTrack paramAudioTrack, ByteBuffer paramByteBuffer, int paramInt, long paramLong) {
    if (ai.a >= 26)
      return paramAudioTrack.write(paramByteBuffer, paramInt, 1, paramLong * 1000L); 
    if (this.y == null) {
      ByteBuffer byteBuffer = ByteBuffer.allocate(16);
      this.y = byteBuffer;
      byteBuffer.order(ByteOrder.BIG_ENDIAN);
      this.y.putInt(1431633921);
    } 
    if (this.z == 0) {
      this.y.putInt(4, paramInt);
      this.y.putLong(8, paramLong * 1000L);
      this.y.position(0);
      this.z = paramInt;
    } 
    int i = this.y.remaining();
    if (i > 0) {
      int i1 = paramAudioTrack.write(this.y, i, 1);
      if (i1 < 0) {
        this.z = 0;
        return i1;
      } 
      if (i1 < i)
        return 0; 
    } 
    paramInt = a(paramAudioTrack, paramByteBuffer, paramInt);
    if (paramInt < 0) {
      this.z = 0;
      return paramInt;
    } 
    this.z -= paramInt;
    return paramInt;
  }
  
  private void a(long paramLong) throws h.e {
    int i1 = this.J.length;
    for (int i = i1; i >= 0; i--) {
      ByteBuffer byteBuffer;
      if (i > 0) {
        byteBuffer = this.K[i - 1];
      } else {
        byteBuffer = this.L;
        if (byteBuffer == null)
          byteBuffer = f.a; 
      } 
      if (i == i1) {
        a(byteBuffer, paramLong);
      } else {
        f f1 = this.J[i];
        if (i > this.Q)
          f1.a(byteBuffer); 
        ByteBuffer byteBuffer1 = f1.c();
        this.K[i] = byteBuffer1;
        if (byteBuffer1.hasRemaining()) {
          i++;
          continue;
        } 
      } 
      if (byteBuffer.hasRemaining())
        return; 
    } 
  }
  
  private void a(AudioTrack paramAudioTrack) {
    if (this.n == null)
      this.n = new h(this); 
    this.n.a(paramAudioTrack);
  }
  
  private static void a(AudioTrack paramAudioTrack, float paramFloat) {
    paramAudioTrack.setVolume(paramFloat);
  }
  
  private void a(am paramam, boolean paramBoolean) {
    e e1 = w();
    if (!paramam.equals(e1.a) || paramBoolean != e1.b) {
      e e2 = new e(paramam, paramBoolean, -9223372036854775807L, -9223372036854775807L);
      if (y()) {
        this.v = e2;
        return;
      } 
      this.w = e2;
    } 
  }
  
  private void a(ByteBuffer paramByteBuffer, long paramLong) throws h.e {
    h.e e1;
    int i;
    if (!paramByteBuffer.hasRemaining())
      return; 
    ByteBuffer byteBuffer = this.N;
    boolean bool = true;
    if (byteBuffer != null) {
      boolean bool1;
      if (byteBuffer == paramByteBuffer) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      com.applovin.exoplayer2.l.a.a(bool1);
    } else {
      this.N = paramByteBuffer;
      if (ai.a < 21) {
        i = paramByteBuffer.remaining();
        byte[] arrayOfByte = this.O;
        if (arrayOfByte == null || arrayOfByte.length < i)
          this.O = new byte[i]; 
        int i2 = paramByteBuffer.position();
        paramByteBuffer.get(this.O, 0, i);
        paramByteBuffer.position(i2);
        this.P = 0;
      } 
    } 
    int i1 = paramByteBuffer.remaining();
    if (ai.a < 21) {
      i = this.j.b(this.C);
      if (i > 0) {
        i = Math.min(i1, i);
        int i2 = this.t.write(this.O, this.P, i);
        i = i2;
        if (i2 > 0) {
          this.P += i2;
          paramByteBuffer.position(paramByteBuffer.position() + i2);
          i = i2;
        } 
      } else {
        i = 0;
      } 
    } else if (this.X) {
      boolean bool1;
      if (paramLong != -9223372036854775807L) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      com.applovin.exoplayer2.l.a.b(bool1);
      i = a(this.t, paramByteBuffer, i1, paramLong);
    } else {
      i = a(this.t, paramByteBuffer, i1);
    } 
    this.Y = SystemClock.elapsedRealtime();
    if (i < 0) {
      boolean bool1 = c(i);
      if (bool1)
        r(); 
      e1 = new h.e(i, this.s.a, bool1);
      h.c c1 = this.q;
      if (c1 != null)
        c1.a((Exception)e1); 
      if (!e1.b) {
        this.p.a(e1);
        return;
      } 
      throw e1;
    } 
    this.p.a();
    if (b(this.t)) {
      paramLong = this.D;
      if (paramLong > 0L)
        this.aa = false; 
      if (this.T && this.q != null && i < i1 && !this.aa) {
        paramLong = this.j.c(paramLong);
        this.q.b(paramLong);
      } 
    } 
    if (this.s.c == 0)
      this.C += i; 
    if (i == i1) {
      if (this.s.c != 0) {
        boolean bool1;
        if (e1 == this.L) {
          bool1 = bool;
        } else {
          bool1 = false;
        } 
        com.applovin.exoplayer2.l.a.b(bool1);
        this.D += (this.E * this.M);
      } 
      this.N = null;
    } 
  }
  
  private boolean a(v paramv, d paramd) {
    int i = ai.a;
    boolean bool = false;
    null = bool;
    if (i >= 29) {
      if (this.m == 0)
        return false; 
      i = u.b((String)com.applovin.exoplayer2.l.a.b(paramv.l), paramv.i);
      if (i == 0)
        return false; 
      int i1 = ai.f(paramv.y);
      if (i1 == 0)
        return false; 
      i = a(b(paramv.z, i1, i), paramd.a());
      null = bool;
      if (i != 0) {
        if (i != 1) {
          if (i == 2)
            return true; 
          throw new IllegalStateException();
        } 
        if (paramv.B != 0 || paramv.C != 0) {
          i = 1;
        } else {
          i = 0;
        } 
        if (this.m == 1) {
          i1 = 1;
        } else {
          i1 = 0;
        } 
        if (i != 0) {
          null = bool;
          return (i1 == 0) ? true : null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  private static boolean a(v paramv, e parame) {
    return (b(paramv, parame) != null);
  }
  
  private static AudioFormat b(int paramInt1, int paramInt2, int paramInt3) {
    return (new AudioFormat.Builder()).setSampleRate(paramInt1).setChannelMask(paramInt2).setEncoding(paramInt3).build();
  }
  
  private static Pair<Integer, Integer> b(v paramv, e parame) {
    int i;
    if (parame == null)
      return null; 
    int i2 = u.b((String)com.applovin.exoplayer2.l.a.b(paramv.l), paramv.i);
    int i1 = 6;
    if (i2 == 5 || i2 == 6 || i2 == 18 || i2 == 17 || i2 == 7 || i2 == 8 || i2 == 14) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!i)
      return null; 
    if (i2 == 18 && !parame.a(18)) {
      i = 6;
    } else {
      i = i2;
      if (i2 == 8) {
        i = i2;
        if (!parame.a(8))
          i = 7; 
      } 
    } 
    if (!parame.a(i))
      return null; 
    if (i == 18) {
      if (ai.a >= 29) {
        i2 = a(18, paramv.z);
        i1 = i2;
        if (i2 == 0) {
          q.c("DefaultAudioSink", "E-AC3 JOC encoding supported but no channel count supported");
          return null;
        } 
      } 
    } else {
      i2 = paramv.y;
      i1 = i2;
      if (i2 > parame.a())
        return null; 
    } 
    i1 = e(i1);
    return (i1 == 0) ? null : Pair.create(Integer.valueOf(i), Integer.valueOf(i1));
  }
  
  private void b(long paramLong) {
    boolean bool;
    am am1;
    if (x()) {
      am1 = this.c.a(v());
    } else {
      am1 = am.a;
    } 
    if (x()) {
      bool = this.c.a(m());
    } else {
      bool = false;
    } 
    this.k.add(new e(am1, bool, Math.max(0L, paramLong), this.s.b(A())));
    n();
    h.c c1 = this.q;
    if (c1 != null)
      c1.a(bool); 
  }
  
  private static void b(AudioTrack paramAudioTrack, float paramFloat) {
    paramAudioTrack.setStereoVolume(paramFloat, paramFloat);
  }
  
  private void b(am paramam) {
    am am1 = paramam;
    if (y()) {
      PlaybackParams playbackParams = (new PlaybackParams()).allowDefaults().setSpeed(paramam.b).setPitch(paramam.c).setAudioFallbackMode(2);
      try {
        this.t.setPlaybackParams(playbackParams);
      } catch (IllegalArgumentException illegalArgumentException) {
        q.b("DefaultAudioSink", "Failed to set playback params", illegalArgumentException);
      } 
      am1 = new am(this.t.getPlaybackParams().getSpeed(), this.t.getPlaybackParams().getPitch());
      this.j.a(am1.b);
    } 
    this.x = am1;
  }
  
  private static boolean b(AudioTrack paramAudioTrack) {
    return (ai.a >= 29 && paramAudioTrack.isOffloadedPlayback());
  }
  
  private long c(long paramLong) {
    while (!this.k.isEmpty() && paramLong >= ((e)this.k.getFirst()).d)
      this.w = this.k.remove(); 
    long l = paramLong - this.w.d;
    if (this.w.a.equals(am.a))
      return this.w.c + l; 
    if (this.k.isEmpty()) {
      paramLong = this.c.a(l);
      return this.w.c + paramLong;
    } 
    e e1 = this.k.getFirst();
    paramLong = ai.a(e1.d - paramLong, this.w.a.b);
    return e1.c - paramLong;
  }
  
  private static boolean c(int paramInt) {
    return ((ai.a >= 24 && paramInt == -6) || paramInt == -32);
  }
  
  private long d(long paramLong) {
    return paramLong + this.s.b(this.c.b());
  }
  
  private boolean d(int paramInt) {
    return (this.d && ai.e(paramInt));
  }
  
  private static int e(int paramInt) {
    // Byte code:
    //   0: iload_0
    //   1: istore_1
    //   2: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   5: bipush #28
    //   7: if_icmpgt -> 42
    //   10: iload_0
    //   11: bipush #7
    //   13: if_icmpne -> 22
    //   16: bipush #8
    //   18: istore_1
    //   19: goto -> 42
    //   22: iload_0
    //   23: iconst_3
    //   24: if_icmpeq -> 39
    //   27: iload_0
    //   28: iconst_4
    //   29: if_icmpeq -> 39
    //   32: iload_0
    //   33: istore_1
    //   34: iload_0
    //   35: iconst_5
    //   36: if_icmpne -> 42
    //   39: bipush #6
    //   41: istore_1
    //   42: iload_1
    //   43: istore_0
    //   44: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   47: bipush #26
    //   49: if_icmpgt -> 75
    //   52: iload_1
    //   53: istore_0
    //   54: ldc_w 'fugu'
    //   57: getstatic com/applovin/exoplayer2/l/ai.b : Ljava/lang/String;
    //   60: invokevirtual equals : (Ljava/lang/Object;)Z
    //   63: ifeq -> 75
    //   66: iload_1
    //   67: istore_0
    //   68: iload_1
    //   69: iconst_1
    //   70: if_icmpne -> 75
    //   73: iconst_2
    //   74: istore_0
    //   75: iload_0
    //   76: invokestatic f : (I)I
    //   79: ireturn
  }
  
  private static int f(int paramInt) {
    switch (paramInt) {
      default:
        throw new IllegalArgumentException();
      case 17:
        return 336000;
      case 16:
        return 256000;
      case 15:
        return 8000;
      case 14:
        return 3062500;
      case 12:
        return 7000;
      case 11:
        return 16000;
      case 10:
        return 100000;
      case 9:
        return 40000;
      case 8:
        return 2250000;
      case 7:
        return 192000;
      case 6:
      case 18:
        return 768000;
      case 5:
        break;
    } 
    return 80000;
  }
  
  private void n() {
    f[] arrayOfF = this.s.i;
    ArrayList<f> arrayList = new ArrayList();
    int i1 = arrayOfF.length;
    int i;
    for (i = 0; i < i1; i++) {
      f f1 = arrayOfF[i];
      if (f1.a()) {
        arrayList.add(f1);
      } else {
        f1.e();
      } 
    } 
    i = arrayList.size();
    this.J = arrayList.<f>toArray(new f[i]);
    this.K = new ByteBuffer[i];
    o();
  }
  
  private void o() {
    int i = 0;
    while (true) {
      f[] arrayOfF = this.J;
      if (i < arrayOfF.length) {
        f f1 = arrayOfF[i];
        f1.e();
        this.K[i] = f1.c();
        i++;
        continue;
      } 
      break;
    } 
  }
  
  private void p() throws h.b {
    boolean bool;
    this.i.block();
    AudioTrack audioTrack1 = q();
    this.t = audioTrack1;
    if (b(audioTrack1)) {
      a(this.t);
      if (this.m != 3)
        this.t.setOffloadDelayPadding(this.s.a.B, this.s.a.C); 
    } 
    this.V = this.t.getAudioSessionId();
    j j1 = this.j;
    AudioTrack audioTrack2 = this.t;
    if (this.s.c == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    j1.a(audioTrack2, bool, this.s.g, this.s.d, this.s.h);
    t();
    if (this.W.a != 0) {
      this.t.attachAuxEffect(this.W.a);
      this.t.setAuxEffectSendLevel(this.W.b);
    } 
    this.G = true;
  }
  
  private AudioTrack q() throws h.b {
    try {
      return ((b)com.applovin.exoplayer2.l.a.b(this.s)).a(this.X, this.u, this.V);
    } catch (b b1) {
      r();
      h.c c1 = this.q;
      if (c1 != null)
        c1.a((Exception)b1); 
      throw b1;
    } 
  }
  
  private void r() {
    if (!this.s.a())
      return; 
    this.Z = true;
  }
  
  private boolean s() throws h.e {
    if (this.Q == -1) {
      this.Q = 0;
    } else {
      boolean bool1 = false;
      int i1 = this.Q;
      f[] arrayOfF1 = this.J;
    } 
    boolean bool = true;
    int i = this.Q;
    f[] arrayOfF = this.J;
  }
  
  private void t() {
    if (!y())
      return; 
    if (ai.a >= 21) {
      a(this.t, this.I);
      return;
    } 
    b(this.t, this.I);
  }
  
  private void u() {
    this.A = 0L;
    this.B = 0L;
    this.C = 0L;
    this.D = 0L;
    this.aa = false;
    this.E = 0;
    this.w = new e(v(), m(), 0L, 0L);
    this.H = 0L;
    this.v = null;
    this.k.clear();
    this.L = null;
    this.M = 0;
    this.N = null;
    this.S = false;
    this.R = false;
    this.Q = -1;
    this.y = null;
    this.z = 0;
    this.f.k();
    o();
  }
  
  private am v() {
    return (w()).a;
  }
  
  private e w() {
    e e1 = this.v;
    return (e1 != null) ? e1 : (!this.k.isEmpty() ? this.k.getLast() : this.w);
  }
  
  private boolean x() {
    return (!this.X && "audio/raw".equals(this.s.a.l) && !d(this.s.a.A));
  }
  
  private boolean y() {
    return (this.t != null);
  }
  
  private long z() {
    return (this.s.c == 0) ? (this.A / this.s.b) : this.B;
  }
  
  public long a(boolean paramBoolean) {
    return (!y() || this.G) ? Long.MIN_VALUE : d(c(Math.min(this.j.a(paramBoolean), this.s.b(A()))));
  }
  
  public void a() {
    this.T = true;
    if (y()) {
      this.j.a();
      this.t.play();
    } 
  }
  
  public void a(float paramFloat) {
    if (this.I != paramFloat) {
      this.I = paramFloat;
      t();
    } 
  }
  
  public void a(int paramInt) {
    if (this.V != paramInt) {
      boolean bool;
      this.V = paramInt;
      if (paramInt != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.U = bool;
      j();
    } 
  }
  
  public void a(am paramam) {
    paramam = new am(ai.a(paramam.b, 0.1F, 8.0F), ai.a(paramam.c, 0.1F, 8.0F));
    if (this.l && ai.a >= 23) {
      b(paramam);
      return;
    } 
    a(paramam, m());
  }
  
  public void a(d paramd) {
    if (this.u.equals(paramd))
      return; 
    this.u = paramd;
    if (this.X)
      return; 
    j();
  }
  
  public void a(h.c paramc) {
    this.q = paramc;
  }
  
  public void a(k paramk) {
    if (this.W.equals(paramk))
      return; 
    int i = paramk.a;
    float f1 = paramk.b;
    if (this.t != null) {
      if (this.W.a != i)
        this.t.attachAuxEffect(i); 
      if (i != 0)
        this.t.setAuxEffectSendLevel(f1); 
    } 
    this.W = paramk;
  }
  
  public void a(v paramv, int paramInt, int[] paramArrayOfint) throws h.a {
    b b1;
    int i;
    int i1;
    byte b2;
    byte b3;
    byte b4;
    int i2;
    if ("audio/raw".equals(paramv.l)) {
      f[] arrayOfF2;
      com.applovin.exoplayer2.l.a.a(ai.d(paramv.A));
      b3 = ai.c(paramv.A, paramv.y);
      if (d(paramv.A)) {
        arrayOfF2 = this.h;
      } else {
        arrayOfF2 = this.g;
      } 
      this.f.a(paramv.B, paramv.C);
      if (ai.a < 21 && paramv.y == 8 && paramArrayOfint == null) {
        int[] arrayOfInt = new int[6];
        int i3 = 0;
        while (true) {
          paramArrayOfint = arrayOfInt;
          if (i3 < 6) {
            arrayOfInt[i3] = i3;
            i3++;
            continue;
          } 
          break;
        } 
      } 
      this.e.a(paramArrayOfint);
      f.a a1 = new f.a(paramv.z, paramv.y, paramv.A);
      i1 = arrayOfF2.length;
      i = 0;
      while (i < i1) {
        f f1 = arrayOfF2[i];
        try {
          f.a a2 = f1.a(a1);
          boolean bool = f1.a();
          if (bool)
            a1 = a2; 
          i++;
        } catch (b b5) {
          throw new h.a(b5, paramv);
        } 
      } 
      i = ((f.a)b5).d;
      i2 = ((f.a)b5).b;
      i1 = ai.f(((f.a)b5).c);
      b4 = ai.c(i, ((f.a)b5).c);
      b2 = 0;
      f[] arrayOfF1 = arrayOfF2;
    } else {
      f[] arrayOfF = new f[0];
      i2 = paramv.z;
      boolean bool = a(paramv, this.u);
      b4 = -1;
      if (bool) {
        i = u.b((String)com.applovin.exoplayer2.l.a.b(paramv.l), paramv.i);
        i1 = ai.f(paramv.y);
        b2 = 1;
      } else {
        Pair<Integer, Integer> pair = b(paramv, this.b);
        if (pair != null) {
          i = ((Integer)pair.first).intValue();
          i1 = ((Integer)pair.second).intValue();
          b2 = 2;
        } else {
          stringBuilder = new StringBuilder("Unable to configure passthrough for: ");
          stringBuilder.append(paramv);
          throw new h.a(stringBuilder.toString(), paramv);
        } 
      } 
      b3 = -1;
    } 
    if (i != 0) {
      if (i1 != 0) {
        this.Z = false;
        b1 = new b(paramv, b3, b2, b4, i2, i1, i, paramInt, this.l, (f[])stringBuilder);
        if (y()) {
          this.r = b1;
          return;
        } 
        this.s = b1;
        return;
      } 
      stringBuilder = new StringBuilder("Invalid output channel config (mode=");
      stringBuilder.append(b2);
      stringBuilder.append(") for: ");
      stringBuilder.append(b1);
      throw new h.a(stringBuilder.toString(), b1);
    } 
    StringBuilder stringBuilder = new StringBuilder("Invalid output encoding (mode=");
    stringBuilder.append(b2);
    stringBuilder.append(") for: ");
    stringBuilder.append(b1);
    throw new h.a(stringBuilder.toString(), b1);
  }
  
  public boolean a(v paramv) {
    return (b(paramv) != 0);
  }
  
  public boolean a(ByteBuffer paramByteBuffer, long paramLong, int paramInt) throws h.b, h.e {
    boolean bool;
    ByteBuffer byteBuffer = this.L;
    if (byteBuffer == null || paramByteBuffer == byteBuffer) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.a(bool);
    if (this.r != null) {
      if (!s())
        return false; 
      if (!this.r.a(this.s)) {
        B();
        if (e())
          return false; 
        j();
      } else {
        this.s = this.r;
        this.r = null;
        if (b(this.t) && this.m != 3) {
          this.t.setOffloadEndOfStream();
          this.t.setOffloadDelayPadding(this.s.a.B, this.s.a.C);
          this.aa = true;
        } 
      } 
      b(paramLong);
    } 
    if (!y())
      try {
        p();
      } catch (b b1) {
        if (!b1.b) {
          this.o.a(b1);
          return false;
        } 
        throw b1;
      }  
    this.o.a();
    if (this.G) {
      this.H = Math.max(0L, paramLong);
      this.F = false;
      this.G = false;
      if (this.l && ai.a >= 23)
        b(this.x); 
      b(paramLong);
      if (this.T)
        a(); 
    } 
    if (!this.j.a(A()))
      return false; 
    if (this.L == null) {
      if (b1.order() == ByteOrder.LITTLE_ENDIAN) {
        bool = true;
      } else {
        bool = false;
      } 
      com.applovin.exoplayer2.l.a.a(bool);
      if (!b1.hasRemaining())
        return true; 
      if (this.s.c != 0 && this.E == 0) {
        int i = a(this.s.g, (ByteBuffer)b1);
        this.E = i;
        if (i == 0)
          return true; 
      } 
      if (this.v != null) {
        if (!s())
          return false; 
        b(paramLong);
        this.v = null;
      } 
      long l = this.H + this.s.a(z() - this.f.l());
      if (!this.F && Math.abs(l - paramLong) > 200000L) {
        this.q.a((Exception)new h.d(paramLong, l));
        this.F = true;
      } 
      if (this.F) {
        if (!s())
          return false; 
        l = paramLong - l;
        this.H += l;
        this.F = false;
        b(paramLong);
        h.c c1 = this.q;
        if (c1 != null && l != 0L)
          c1.a(); 
      } 
      if (this.s.c == 0) {
        this.A += b1.remaining();
      } else {
        this.B += (this.E * paramInt);
      } 
      this.L = (ByteBuffer)b1;
      this.M = paramInt;
    } 
    a(paramLong);
    if (!this.L.hasRemaining()) {
      this.L = null;
      this.M = 0;
      return true;
    } 
    if (this.j.d(A())) {
      q.c("DefaultAudioSink", "Resetting stalled audio track");
      j();
      return true;
    } 
    return false;
  }
  
  public int b(v paramv) {
    if ("audio/raw".equals(paramv.l)) {
      if (!ai.d(paramv.A)) {
        StringBuilder stringBuilder = new StringBuilder("Invalid PCM encoding: ");
        stringBuilder.append(paramv.A);
        q.c("DefaultAudioSink", stringBuilder.toString());
        return 0;
      } 
      return (paramv.A != 2) ? ((this.d && paramv.A == 4) ? 2 : 1) : 2;
    } 
    return (!this.Z && a(paramv, this.u)) ? 2 : (a(paramv, this.b) ? 2 : 0);
  }
  
  public void b() {
    this.F = true;
  }
  
  public void b(boolean paramBoolean) {
    a(v(), paramBoolean);
  }
  
  public void c() throws h.e {
    if (!this.R && y() && s()) {
      B();
      this.R = true;
    } 
  }
  
  public boolean d() {
    return (!y() || (this.R && !e()));
  }
  
  public boolean e() {
    return (y() && this.j.f(A()));
  }
  
  public am f() {
    return this.l ? this.x : v();
  }
  
  public void g() {
    boolean bool;
    if (ai.a >= 21) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.b(bool);
    com.applovin.exoplayer2.l.a.b(this.U);
    if (!this.X) {
      this.X = true;
      j();
    } 
  }
  
  public void h() {
    if (this.X) {
      this.X = false;
      j();
    } 
  }
  
  public void i() {
    this.T = false;
    if (y() && this.j.c())
      this.t.pause(); 
  }
  
  public void j() {
    if (y()) {
      u();
      if (this.j.b())
        this.t.pause(); 
      if (b(this.t))
        ((h)com.applovin.exoplayer2.l.a.b(this.n)).b(this.t); 
      AudioTrack audioTrack = this.t;
      this.t = null;
      if (ai.a < 21 && !this.U)
        this.V = 0; 
      b b1 = this.r;
      if (b1 != null) {
        this.s = b1;
        this.r = null;
      } 
      this.j.d();
      this.i.close();
      (new Thread(this, "ExoPlayer:AudioTrackReleaseThread", audioTrack) {
          public void run() {
            try {
              this.a.flush();
              this.a.release();
              return;
            } finally {
              n.a(this.b).open();
            } 
          }
        }).start();
    } 
    this.p.a();
    this.o.a();
  }
  
  public void k() {
    boolean bool;
    if (ai.a < 25) {
      j();
      return;
    } 
    this.p.a();
    this.o.a();
    if (!y())
      return; 
    u();
    if (this.j.b())
      this.t.pause(); 
    this.t.flush();
    this.j.d();
    j j1 = this.j;
    AudioTrack audioTrack = this.t;
    if (this.s.c == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    j1.a(audioTrack, bool, this.s.g, this.s.d, this.s.h);
    this.G = true;
  }
  
  public void l() {
    j();
    f[] arrayOfF = this.g;
    int i1 = arrayOfF.length;
    int i;
    for (i = 0; i < i1; i++)
      arrayOfF[i].f(); 
    arrayOfF = this.h;
    i1 = arrayOfF.length;
    for (i = 0; i < i1; i++)
      arrayOfF[i].f(); 
    this.T = false;
    this.Z = false;
  }
  
  public boolean m() {
    return (w()).b;
  }
  
  public static interface a {
    long a(long param1Long);
    
    am a(am param1am);
    
    boolean a(boolean param1Boolean);
    
    f[] a();
    
    long b();
  }
  
  private static final class b {
    public final v a;
    
    public final int b;
    
    public final int c;
    
    public final int d;
    
    public final int e;
    
    public final int f;
    
    public final int g;
    
    public final int h;
    
    public final f[] i;
    
    public b(v param1v, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, boolean param1Boolean, f[] param1ArrayOff) {
      this.a = param1v;
      this.b = param1Int1;
      this.c = param1Int2;
      this.d = param1Int3;
      this.e = param1Int4;
      this.f = param1Int5;
      this.g = param1Int6;
      this.i = param1ArrayOff;
      this.h = a(param1Int7, param1Boolean);
    }
    
    private int a(float param1Float) {
      boolean bool;
      int i = AudioTrack.getMinBufferSize(this.e, this.f, this.g);
      if (i != -2) {
        bool = true;
      } else {
        bool = false;
      } 
      com.applovin.exoplayer2.l.a.b(bool);
      int j = ai.a(i * 4, (int)c(250000L) * this.d, Math.max(i, (int)c(750000L) * this.d));
      i = j;
      if (param1Float != 1.0F)
        i = Math.round(j * param1Float); 
      return i;
    }
    
    private int a(int param1Int, boolean param1Boolean) {
      float f1;
      if (param1Int != 0)
        return param1Int; 
      param1Int = this.c;
      if (param1Int != 0) {
        if (param1Int != 1) {
          if (param1Int == 2)
            return d(250000L); 
          throw new IllegalStateException();
        } 
        return d(50000000L);
      } 
      if (param1Boolean) {
        f1 = 8.0F;
      } else {
        f1 = 1.0F;
      } 
      return a(f1);
    }
    
    private static AudioAttributes a(d param1d, boolean param1Boolean) {
      return param1Boolean ? b() : param1d.a();
    }
    
    private AudioTrack a(d param1d, int param1Int) {
      int i = ai.g(param1d.d);
      return (param1Int == 0) ? new AudioTrack(i, this.e, this.f, this.g, this.h, 1) : new AudioTrack(i, this.e, this.f, this.g, this.h, 1, param1Int);
    }
    
    private static AudioAttributes b() {
      return (new AudioAttributes.Builder()).setContentType(3).setFlags(16).setUsage(1).build();
    }
    
    private AudioTrack b(boolean param1Boolean, d param1d, int param1Int) {
      return (ai.a >= 29) ? c(param1Boolean, param1d, param1Int) : ((ai.a >= 21) ? d(param1Boolean, param1d, param1Int) : a(param1d, param1Int));
    }
    
    private AudioTrack c(boolean param1Boolean, d param1d, int param1Int) {
      AudioFormat audioFormat = n.a(this.e, this.f, this.g);
      AudioAttributes audioAttributes = a(param1d, param1Boolean);
      AudioTrack.Builder builder = (new AudioTrack.Builder()).setAudioAttributes(audioAttributes).setAudioFormat(audioFormat);
      param1Boolean = true;
      builder = builder.setTransferMode(1).setBufferSizeInBytes(this.h).setSessionId(param1Int);
      if (this.c != 1)
        param1Boolean = false; 
      return builder.setOffloadedPlayback(param1Boolean).build();
    }
    
    private int d(long param1Long) {
      int j = n.b(this.g);
      int i = j;
      if (this.g == 5)
        i = j * 2; 
      return (int)(param1Long * i / 1000000L);
    }
    
    private AudioTrack d(boolean param1Boolean, d param1d, int param1Int) {
      return new AudioTrack(a(param1d, param1Boolean), n.a(this.e, this.f, this.g), this.h, 1, param1Int);
    }
    
    public long a(long param1Long) {
      return param1Long * 1000000L / this.a.z;
    }
    
    public AudioTrack a(boolean param1Boolean, d param1d, int param1Int) throws h.b {
      try {
        AudioTrack audioTrack = b(param1Boolean, param1d, param1Int);
        param1Int = audioTrack.getState();
        if (param1Int == 1)
          return audioTrack; 
        try {
          audioTrack.release();
        } catch (Exception null) {}
      } catch (UnsupportedOperationException null) {
      
      } catch (IllegalArgumentException exception) {}
      throw new h.b(0, this.e, this.f, this.h, this.a, a(), exception);
    }
    
    public boolean a() {
      return (this.c == 1);
    }
    
    public boolean a(b param1b) {
      return (param1b.c == this.c && param1b.g == this.g && param1b.e == this.e && param1b.f == this.f && param1b.d == this.d);
    }
    
    public long b(long param1Long) {
      return param1Long * 1000000L / this.e;
    }
    
    public long c(long param1Long) {
      return param1Long * this.e / 1000000L;
    }
  }
  
  public static class c implements a {
    private final f[] a;
    
    private final u b;
    
    private final w c;
    
    public c(f... param1VarArgs) {
      this(param1VarArgs, new u(), new w());
    }
    
    public c(f[] param1ArrayOff, u param1u, w param1w) {
      f[] arrayOfF = new f[param1ArrayOff.length + 2];
      this.a = arrayOfF;
      System.arraycopy(param1ArrayOff, 0, arrayOfF, 0, param1ArrayOff.length);
      this.b = param1u;
      this.c = param1w;
      arrayOfF[param1ArrayOff.length] = (f)param1u;
      arrayOfF[param1ArrayOff.length + 1] = (f)param1w;
    }
    
    public long a(long param1Long) {
      return this.c.a(param1Long);
    }
    
    public am a(am param1am) {
      this.c.a(param1am.b);
      this.c.b(param1am.c);
      return param1am;
    }
    
    public boolean a(boolean param1Boolean) {
      this.b.a(param1Boolean);
      return param1Boolean;
    }
    
    public f[] a() {
      return this.a;
    }
    
    public long b() {
      return this.b.k();
    }
  }
  
  public static final class d extends RuntimeException {
    private d(String param1String) {
      super(param1String);
    }
  }
  
  private static final class e {
    public final am a;
    
    public final boolean b;
    
    public final long c;
    
    public final long d;
    
    private e(am param1am, boolean param1Boolean, long param1Long1, long param1Long2) {
      this.a = param1am;
      this.b = param1Boolean;
      this.c = param1Long1;
      this.d = param1Long2;
    }
  }
  
  private static final class f<T extends Exception> {
    private final long a;
    
    private T b;
    
    private long c;
    
    public f(long param1Long) {
      this.a = param1Long;
    }
    
    public void a() {
      this.b = null;
    }
    
    public void a(T param1T) throws T {
      long l = SystemClock.elapsedRealtime();
      if (this.b == null) {
        this.b = param1T;
        this.c = this.a + l;
      } 
      if (l >= this.c) {
        T t = this.b;
        if (t != param1T)
          t.addSuppressed((Throwable)param1T); 
        param1T = this.b;
        a();
        throw param1T;
      } 
    }
  }
  
  private final class g implements j.a {
    private g(n this$0) {}
    
    public void a(int param1Int, long param1Long) {
      if (n.c(this.a) != null) {
        long l1 = SystemClock.elapsedRealtime();
        long l2 = n.g(this.a);
        n.c(this.a).a(param1Int, param1Long, l1 - l2);
      } 
    }
    
    public void a(long param1Long) {
      if (n.c(this.a) != null)
        n.c(this.a).a(param1Long); 
    }
    
    public void a(long param1Long1, long param1Long2, long param1Long3, long param1Long4) {
      StringBuilder stringBuilder = new StringBuilder("Spurious audio timestamp (frame position mismatch): ");
      stringBuilder.append(param1Long1);
      stringBuilder.append(", ");
      stringBuilder.append(param1Long2);
      stringBuilder.append(", ");
      stringBuilder.append(param1Long3);
      stringBuilder.append(", ");
      stringBuilder.append(param1Long4);
      stringBuilder.append(", ");
      stringBuilder.append(n.e(this.a));
      stringBuilder.append(", ");
      stringBuilder.append(n.f(this.a));
      String str = stringBuilder.toString();
      if (!n.a) {
        q.c("DefaultAudioSink", str);
        return;
      } 
      throw new n.d(str);
    }
    
    public void b(long param1Long) {
      StringBuilder stringBuilder = new StringBuilder("Ignoring impossibly large audio latency: ");
      stringBuilder.append(param1Long);
      q.c("DefaultAudioSink", stringBuilder.toString());
    }
    
    public void b(long param1Long1, long param1Long2, long param1Long3, long param1Long4) {
      StringBuilder stringBuilder = new StringBuilder("Spurious audio timestamp (system clock mismatch): ");
      stringBuilder.append(param1Long1);
      stringBuilder.append(", ");
      stringBuilder.append(param1Long2);
      stringBuilder.append(", ");
      stringBuilder.append(param1Long3);
      stringBuilder.append(", ");
      stringBuilder.append(param1Long4);
      stringBuilder.append(", ");
      stringBuilder.append(n.e(this.a));
      stringBuilder.append(", ");
      stringBuilder.append(n.f(this.a));
      String str = stringBuilder.toString();
      if (!n.a) {
        q.c("DefaultAudioSink", str);
        return;
      } 
      throw new n.d(str);
    }
  }
  
  private final class h {
    private final Handler b = new Handler();
    
    private final AudioTrack.StreamEventCallback c;
    
    public h(n this$0) {
      this.c = new AudioTrack.StreamEventCallback(this, this$0) {
          public void onDataRequest(AudioTrack param2AudioTrack, int param2Int) {
            boolean bool;
            if (param2AudioTrack == n.b(this.b.a)) {
              bool = true;
            } else {
              bool = false;
            } 
            com.applovin.exoplayer2.l.a.b(bool);
            if (n.c(this.b.a) != null && n.d(this.b.a))
              n.c(this.b.a).b(); 
          }
          
          public void onTearDown(AudioTrack param2AudioTrack) {
            boolean bool;
            if (param2AudioTrack == n.b(this.b.a)) {
              bool = true;
            } else {
              bool = false;
            } 
            com.applovin.exoplayer2.l.a.b(bool);
            if (n.c(this.b.a) != null && n.d(this.b.a))
              n.c(this.b.a).b(); 
          }
        };
    }
    
    public void a(AudioTrack param1AudioTrack) {
      Handler handler = this.b;
      Objects.requireNonNull(handler);
      param1AudioTrack.registerStreamEventCallback((Executor)new n$h$.ExternalSyntheticLambda0(handler), this.c);
    }
    
    public void b(AudioTrack param1AudioTrack) {
      param1AudioTrack.unregisterStreamEventCallback(this.c);
      this.b.removeCallbacksAndMessages(null);
    }
  }
  
  class null extends AudioTrack.StreamEventCallback {
    null(n this$0, n param1n) {}
    
    public void onDataRequest(AudioTrack param1AudioTrack, int param1Int) {
      boolean bool;
      if (param1AudioTrack == n.b(this.b.a)) {
        bool = true;
      } else {
        bool = false;
      } 
      com.applovin.exoplayer2.l.a.b(bool);
      if (n.c(this.b.a) != null && n.d(this.b.a))
        n.c(this.b.a).b(); 
    }
    
    public void onTearDown(AudioTrack param1AudioTrack) {
      boolean bool;
      if (param1AudioTrack == n.b(this.b.a)) {
        bool = true;
      } else {
        bool = false;
      } 
      com.applovin.exoplayer2.l.a.b(bool);
      if (n.c(this.b.a) != null && n.d(this.b.a))
        n.c(this.b.a).b(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\b\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */