package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import y.il0;
import y.億;
import y.첩;
import y.측;

public class Barrier extends 첩 {
  public 億 死;
  
  public int 産;
  
  public int 興;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  public boolean getAllowsGoneWidget() {
    return this.死.し;
  }
  
  public int getMargin() {
    return this.死.私;
  }
  
  public int getType() {
    return this.興;
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.死.し = paramBoolean;
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.死.私 = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.死.私 = paramInt;
  }
  
  public void setType(int paramInt) {
    this.興 = paramInt;
  }
  
  public final void 旨(측 param측, boolean paramBoolean) {
    int i = this.興;
    this.産 = i;
    int j = Build.VERSION.SDK_INT;
    if (paramBoolean) {
      if (i == 5) {
        this.産 = 1;
      } else if (i == 6) {
        this.産 = 0;
      } 
    } else if (i == 5) {
      this.産 = 0;
    } else if (i == 6) {
      this.産 = 1;
    } 
    if (param측 instanceof 億)
      ((億)param측).た = this.産; 
  }
  
  public final void 美(AttributeSet paramAttributeSet) {
    super.美(paramAttributeSet);
    this.死 = new 億();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, il0.興);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == 26) {
          setType(typedArray.getInt(k, 0));
        } else if (k == 25) {
          this.死.し = typedArray.getBoolean(k, true);
        } else if (k == 27) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.死.私 = k;
        } 
      } 
      typedArray.recycle();
    } 
    this.痛 = this.死;
    辛();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */