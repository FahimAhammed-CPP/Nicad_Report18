package com.applovin.exoplayer2.i.a;

import android.text.Layout;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import com.applovin.exoplayer2.i.f;
import com.applovin.exoplayer2.i.h;
import com.applovin.exoplayer2.i.j;
import com.applovin.exoplayer2.i.k;
import com.applovin.exoplayer2.l.e;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.x;
import com.applovin.exoplayer2.l.y;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class b extends c {
  private final y a = new y();
  
  private final x b = new x();
  
  private int c = -1;
  
  private final boolean d;
  
  private final int e;
  
  private final b[] f;
  
  private b g;
  
  private List<com.applovin.exoplayer2.i.a> h;
  
  private List<com.applovin.exoplayer2.i.a> i;
  
  private c j;
  
  private int k;
  
  public b(int paramInt, List<byte[]> paramList) {
    boolean bool = true;
    int i = paramInt;
    if (paramInt == -1)
      i = 1; 
    this.e = i;
    if (paramList == null || !e.a(paramList))
      bool = false; 
    this.d = bool;
    this.f = new b[8];
    for (paramInt = 0; paramInt < 8; paramInt++)
      this.f[paramInt] = new b(); 
    this.g = this.f[0];
  }
  
  private void a(int paramInt) {
    if (paramInt != 0)
      if (paramInt != 3) {
        if (paramInt != 8) {
          StringBuilder stringBuilder;
          switch (paramInt) {
            default:
              if (paramInt >= 17 && paramInt <= 23) {
                StringBuilder stringBuilder1 = new StringBuilder("Currently unsupported COMMAND_EXT1 Command: ");
                stringBuilder1.append(paramInt);
                q.c("Cea708Decoder", stringBuilder1.toString());
                this.b.b(8);
                return;
              } 
              if (paramInt >= 24 && paramInt <= 31) {
                StringBuilder stringBuilder1 = new StringBuilder("Currently unsupported COMMAND_P16 Command: ");
                stringBuilder1.append(paramInt);
                q.c("Cea708Decoder", stringBuilder1.toString());
                this.b.b(16);
                return;
              } 
              stringBuilder = new StringBuilder("Invalid C0 command: ");
              stringBuilder.append(paramInt);
              q.c("Cea708Decoder", stringBuilder.toString());
              return;
            case 13:
              this.g.a('\n');
              return;
            case 12:
              r();
              return;
            case 14:
              break;
          } 
        } else {
          this.g.f();
          return;
        } 
      } else {
        this.h = q();
      }  
  }
  
  private void b(int paramInt) {
    StringBuilder stringBuilder;
    int j = 1;
    int k = 1;
    int i = 1;
    switch (paramInt) {
      default:
        stringBuilder = new StringBuilder("Invalid C1 command: ");
        stringBuilder.append(paramInt);
        q.c("Cea708Decoder", stringBuilder.toString());
        return;
      case 152:
      case 153:
      case 154:
      case 155:
      case 156:
      case 157:
      case 158:
      case 159:
        paramInt -= 152;
        i(paramInt);
        if (this.k != paramInt) {
          this.k = paramInt;
          this.g = this.f[paramInt];
          return;
        } 
        break;
      case 151:
        if (!this.g.d()) {
          this.b.b(32);
          return;
        } 
        p();
        return;
      case 146:
        if (!this.g.d()) {
          this.b.b(16);
          return;
        } 
        o();
        return;
      case 145:
        if (!this.g.d()) {
          this.b.b(24);
          return;
        } 
        n();
        return;
      case 144:
        if (!this.g.d()) {
          this.b.b(16);
          return;
        } 
        m();
        return;
      case 143:
        r();
        return;
      case 141:
        this.b.b(8);
        return;
      case 140:
        while (i <= 8) {
          if (this.b.e())
            this.f[8 - i].b(); 
          i++;
        } 
        break;
      case 139:
        for (paramInt = 1; paramInt <= 8; paramInt++) {
          if (this.b.e()) {
            b b1 = this.f[8 - paramInt];
            b1.a(b1.e() ^ true);
          } 
        } 
        break;
      case 138:
        while (j <= 8) {
          if (this.b.e())
            this.f[8 - j].a(false); 
          j++;
        } 
        break;
      case 137:
        for (paramInt = 1; paramInt <= 8; paramInt++) {
          if (this.b.e())
            this.f[8 - paramInt].a(true); 
        } 
        break;
      case 136:
        while (k <= 8) {
          if (this.b.e())
            this.f[8 - k].c(); 
          k++;
        } 
        break;
      case 128:
      case 129:
      case 130:
      case 131:
      case 132:
      case 133:
      case 134:
      case 135:
        paramInt -= 128;
        if (this.k != paramInt) {
          this.k = paramInt;
          this.g = this.f[paramInt];
        } 
        break;
      case 142:
        break;
    } 
  }
  
  private void c(int paramInt) {
    if (paramInt <= 7)
      return; 
    if (paramInt <= 15) {
      this.b.b(8);
      return;
    } 
    if (paramInt <= 23) {
      this.b.b(16);
      return;
    } 
    if (paramInt <= 31)
      this.b.b(24); 
  }
  
  private void d(int paramInt) {
    if (paramInt <= 135) {
      this.b.b(32);
      return;
    } 
    if (paramInt <= 143) {
      this.b.b(40);
      return;
    } 
    if (paramInt <= 159) {
      this.b.b(2);
      paramInt = this.b.c(6);
      this.b.b(paramInt * 8);
    } 
  }
  
  private void e(int paramInt) {
    if (paramInt == 127) {
      this.g.a('♫');
      return;
    } 
    this.g.a((char)(paramInt & 0xFF));
  }
  
  private void f(int paramInt) {
    this.g.a((char)(paramInt & 0xFF));
  }
  
  private void g(int paramInt) {
    if (paramInt != 32) {
      if (paramInt != 33) {
        if (paramInt != 37) {
          if (paramInt != 42) {
            if (paramInt != 44) {
              if (paramInt != 63) {
                if (paramInt != 57) {
                  if (paramInt != 58) {
                    if (paramInt != 60) {
                      if (paramInt != 61) {
                        StringBuilder stringBuilder;
                        switch (paramInt) {
                          default:
                            switch (paramInt) {
                              default:
                                stringBuilder = new StringBuilder("Invalid G2 character: ");
                                stringBuilder.append(paramInt);
                                q.c("Cea708Decoder", stringBuilder.toString());
                                return;
                              case 127:
                                this.g.a('┌');
                                return;
                              case 126:
                                this.g.a('┘');
                                return;
                              case 125:
                                this.g.a('─');
                                return;
                              case 124:
                                this.g.a('└');
                                return;
                              case 123:
                                this.g.a('┐');
                                return;
                              case 122:
                                this.g.a('│');
                                return;
                              case 121:
                                this.g.a('⅞');
                                return;
                              case 120:
                                this.g.a('⅝');
                                return;
                              case 119:
                                this.g.a('⅜');
                                return;
                              case 118:
                                break;
                            } 
                            this.g.a('⅛');
                            return;
                          case 53:
                            this.g.a('•');
                            return;
                          case 52:
                            this.g.a('”');
                            return;
                          case 51:
                            this.g.a('“');
                            return;
                          case 50:
                            this.g.a('’');
                            return;
                          case 49:
                            this.g.a('‘');
                            return;
                          case 48:
                            break;
                        } 
                        this.g.a('█');
                        return;
                      } 
                      this.g.a('℠');
                      return;
                    } 
                    this.g.a('œ');
                    return;
                  } 
                  this.g.a('š');
                  return;
                } 
                this.g.a('™');
                return;
              } 
              this.g.a('Ÿ');
              return;
            } 
            this.g.a('Œ');
            return;
          } 
          this.g.a('Š');
          return;
        } 
        this.g.a('…');
        return;
      } 
      this.g.a(' ');
      return;
    } 
    this.g.a(' ');
  }
  
  private void h(int paramInt) {
    if (paramInt == 160) {
      this.g.a('㏄');
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Invalid G3 character: ");
    stringBuilder.append(paramInt);
    q.c("Cea708Decoder", stringBuilder.toString());
    this.g.a('_');
  }
  
  private void i() {
    if (this.j == null)
      return; 
    l();
    this.j = null;
  }
  
  private void i(int paramInt) {
    b b1 = this.f[paramInt];
    this.b.b(2);
    boolean bool1 = this.b.e();
    boolean bool2 = this.b.e();
    boolean bool3 = this.b.e();
    paramInt = this.b.c(3);
    boolean bool4 = this.b.e();
    int i = this.b.c(7);
    int j = this.b.c(8);
    int k = this.b.c(4);
    int m = this.b.c(4);
    this.b.b(2);
    int n = this.b.c(6);
    this.b.b(2);
    b1.a(bool1, bool2, bool3, paramInt, bool4, i, j, m, n, k, this.b.c(3), this.b.c(3));
  }
  
  private void l() {
    if (this.j.d != this.j.b * 2 - 1) {
      StringBuilder stringBuilder = new StringBuilder("DtvCcPacket ended prematurely; size is ");
      stringBuilder.append(this.j.b * 2 - 1);
      stringBuilder.append(", but current index is ");
      stringBuilder.append(this.j.d);
      stringBuilder.append(" (sequence number ");
      stringBuilder.append(this.j.a);
      stringBuilder.append(");");
      q.a("Cea708Decoder", stringBuilder.toString());
    } 
    this.b.a(this.j.c, this.j.d);
    int j = this.b.c(3);
    int k = this.b.c(5);
    int i = j;
    if (j == 7) {
      this.b.b(2);
      j = this.b.c(6);
      i = j;
      if (j < 7) {
        StringBuilder stringBuilder = new StringBuilder("Invalid extended service number: ");
        stringBuilder.append(j);
        q.c("Cea708Decoder", stringBuilder.toString());
        i = j;
      } 
    } 
    if (k == 0) {
      if (i != 0) {
        StringBuilder stringBuilder = new StringBuilder("serviceNumber is non-zero (");
        stringBuilder.append(i);
        stringBuilder.append(") when blockSize is 0");
        q.c("Cea708Decoder", stringBuilder.toString());
      } 
      return;
    } 
    if (i != this.e)
      return; 
    for (i = 0; this.b.a() > 0; i = 1) {
      j = this.b.c(8);
      if (j != 16) {
        if (j <= 31) {
          a(j);
          continue;
        } 
        if (j <= 127) {
          e(j);
        } else if (j <= 159) {
          b(j);
        } else if (j <= 255) {
          f(j);
        } else {
          StringBuilder stringBuilder = new StringBuilder("Invalid base command: ");
          stringBuilder.append(j);
          q.c("Cea708Decoder", stringBuilder.toString());
          continue;
        } 
      } else {
        j = this.b.c(8);
        if (j <= 31) {
          c(j);
          continue;
        } 
        if (j <= 127) {
          g(j);
        } else {
          if (j <= 159) {
            d(j);
            continue;
          } 
          if (j <= 255) {
            h(j);
          } else {
            StringBuilder stringBuilder = new StringBuilder("Invalid extended command: ");
            stringBuilder.append(j);
            q.c("Cea708Decoder", stringBuilder.toString());
            continue;
          } 
        } 
      } 
    } 
    if (i != 0)
      this.h = q(); 
  }
  
  private void m() {
    int i = this.b.c(4);
    int j = this.b.c(2);
    int k = this.b.c(2);
    boolean bool1 = this.b.e();
    boolean bool2 = this.b.e();
    int m = this.b.c(3);
    int n = this.b.c(3);
    this.g.a(i, j, k, bool1, bool2, m, n);
  }
  
  private void n() {
    int i = this.b.c(2);
    i = b.a(this.b.c(2), this.b.c(2), this.b.c(2), i);
    int j = this.b.c(2);
    j = b.a(this.b.c(2), this.b.c(2), this.b.c(2), j);
    this.b.b(2);
    int k = b.b(this.b.c(2), this.b.c(2), this.b.c(2));
    this.g.a(i, j, k);
  }
  
  private void o() {
    this.b.b(4);
    int i = this.b.c(4);
    this.b.b(2);
    int j = this.b.c(6);
    this.g.a(i, j);
  }
  
  private void p() {
    int i = this.b.c(2);
    int k = b.a(this.b.c(2), this.b.c(2), this.b.c(2), i);
    int j = this.b.c(2);
    int m = b.b(this.b.c(2), this.b.c(2), this.b.c(2));
    i = j;
    if (this.b.e())
      i = j | 0x4; 
    boolean bool = this.b.e();
    j = this.b.c(2);
    int n = this.b.c(2);
    int i1 = this.b.c(2);
    this.b.b(8);
    this.g.a(k, m, bool, i, j, n, i1);
  }
  
  private List<com.applovin.exoplayer2.i.a> q() {
    ArrayList<a> arrayList = new ArrayList();
    boolean bool = false;
    int i;
    for (i = 0; i < 8; i++) {
      if (!this.f[i].a() && this.f[i].e()) {
        a a = this.f[i].h();
        if (a != null)
          arrayList.add(a); 
      } 
    } 
    Collections.sort(arrayList, a.a());
    ArrayList<com.applovin.exoplayer2.i.a> arrayList1 = new ArrayList(arrayList.size());
    for (i = bool; i < arrayList.size(); i++)
      arrayList1.add(((a)arrayList.get(i)).a); 
    return Collections.unmodifiableList(arrayList1);
  }
  
  private void r() {
    for (int i = 0; i < 8; i++)
      this.f[i].b(); 
  }
  
  protected void a(j paramj) {
    ByteBuffer byteBuffer = (ByteBuffer)com.applovin.exoplayer2.l.a.b(paramj.b);
    byte[] arrayOfByte = byteBuffer.array();
    this.a.a(arrayOfByte, byteBuffer.limit());
    while (this.a.a() >= 3) {
      int i = this.a.h() & 0x7;
      int k = i & 0x3;
      boolean bool = false;
      if ((i & 0x4) == 4) {
        i = 1;
      } else {
        i = 0;
      } 
      byte b1 = (byte)this.a.h();
      byte b2 = (byte)this.a.h();
      if ((k != 2 && k != 3) || i == 0)
        continue; 
      if (k == 3) {
        i();
        int m = (b1 & 0xC0) >> 6;
        i = this.c;
        if (i != -1 && m != (i + 1) % 4) {
          r();
          StringBuilder stringBuilder = new StringBuilder("Sequence number discontinuity. previous=");
          stringBuilder.append(this.c);
          stringBuilder.append(" current=");
          stringBuilder.append(m);
          q.c("Cea708Decoder", stringBuilder.toString());
        } 
        this.c = m;
        k = b1 & 0x3F;
        i = k;
        if (k == 0)
          i = 64; 
        c c1 = new c(m, i);
        this.j = c1;
        byte[] arrayOfByte1 = c1.c;
        c c2 = this.j;
        i = c2.d;
        c2.d = i + 1;
        arrayOfByte1[i] = b2;
      } else {
        if (k == 2)
          bool = true; 
        com.applovin.exoplayer2.l.a.a(bool);
        c c1 = this.j;
        if (c1 == null) {
          q.d("Cea708Decoder", "Encountered DTVCC_PACKET_DATA before DTVCC_PACKET_START");
          continue;
        } 
        byte[] arrayOfByte1 = c1.c;
        c c2 = this.j;
        i = c2.d;
        c2.d = i + 1;
        arrayOfByte1[i] = b1;
        arrayOfByte1 = this.j.c;
        c2 = this.j;
        i = c2.d;
        c2.d = i + 1;
        arrayOfByte1[i] = b2;
      } 
      if (this.j.d == this.j.b * 2 - 1)
        i(); 
    } 
  }
  
  public void c() {
    super.c();
    this.h = null;
    this.i = null;
    this.k = 0;
    this.g = this.f[0];
    r();
    this.j = null;
  }
  
  protected boolean f() {
    return (this.h != this.i);
  }
  
  protected f g() {
    List<com.applovin.exoplayer2.i.a> list = this.h;
    this.i = list;
    return new d((List<com.applovin.exoplayer2.i.a>)com.applovin.exoplayer2.l.a.b(list));
  }
  
  private static final class a {
    private static final Comparator<a> c = (Comparator<a>)new b$a$.ExternalSyntheticLambda0();
    
    public final com.applovin.exoplayer2.i.a a;
    
    public final int b;
    
    public a(CharSequence param1CharSequence, Layout.Alignment param1Alignment, float param1Float1, int param1Int1, int param1Int2, float param1Float2, int param1Int3, float param1Float3, boolean param1Boolean, int param1Int4, int param1Int5) {
      com.applovin.exoplayer2.i.a.a a1 = (new com.applovin.exoplayer2.i.a.a()).a(param1CharSequence).a(param1Alignment).a(param1Float1, param1Int1).a(param1Int2).a(param1Float2).b(param1Int3).b(param1Float3);
      if (param1Boolean)
        a1.c(param1Int4); 
      this.a = a1.e();
      this.b = param1Int5;
    }
  }
  
  private static final class b {
    public static final int a = a(2, 2, 2, 0);
    
    public static final int b;
    
    public static final int c;
    
    private static final int[] d = new int[] { 0, 0, 0, 0, 0, 2, 0 };
    
    private static final int[] e = new int[] { 0, 0, 0, 0, 0, 0, 2 };
    
    private static final int[] f = new int[] { 3, 3, 3, 3, 3, 3, 1 };
    
    private static final boolean[] g = new boolean[] { false, false, false, true, true, true, false };
    
    private static final int[] h;
    
    private static final int[] i = new int[] { 0, 1, 2, 3, 4, 3, 4 };
    
    private static final int[] j = new int[] { 0, 0, 0, 0, 0, 3, 3 };
    
    private static final int[] k;
    
    private int A;
    
    private int B;
    
    private int C;
    
    private int D;
    
    private int E;
    
    private int F;
    
    private int G;
    
    private final List<SpannableString> l = new ArrayList<SpannableString>();
    
    private final SpannableStringBuilder m = new SpannableStringBuilder();
    
    private boolean n;
    
    private boolean o;
    
    private int p;
    
    private boolean q;
    
    private int r;
    
    private int s;
    
    private int t;
    
    private int u;
    
    private boolean v;
    
    private int w;
    
    private int x;
    
    private int y;
    
    private int z;
    
    static {
      k = new int[] { i, i, i, i, i, j, j };
    }
    
    public b() {
      b();
    }
    
    public static int a(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      // Byte code:
      //   0: iconst_0
      //   1: istore #4
      //   3: iload_0
      //   4: iconst_0
      //   5: iconst_4
      //   6: invokestatic a : (III)I
      //   9: pop
      //   10: iload_1
      //   11: iconst_0
      //   12: iconst_4
      //   13: invokestatic a : (III)I
      //   16: pop
      //   17: iload_2
      //   18: iconst_0
      //   19: iconst_4
      //   20: invokestatic a : (III)I
      //   23: pop
      //   24: iload_3
      //   25: iconst_0
      //   26: iconst_4
      //   27: invokestatic a : (III)I
      //   30: pop
      //   31: iload_3
      //   32: ifeq -> 64
      //   35: iload_3
      //   36: iconst_1
      //   37: if_icmpeq -> 64
      //   40: iload_3
      //   41: iconst_2
      //   42: if_icmpeq -> 58
      //   45: iload_3
      //   46: iconst_3
      //   47: if_icmpeq -> 53
      //   50: goto -> 64
      //   53: iconst_0
      //   54: istore_3
      //   55: goto -> 68
      //   58: bipush #127
      //   60: istore_3
      //   61: goto -> 68
      //   64: sipush #255
      //   67: istore_3
      //   68: iload_0
      //   69: iconst_1
      //   70: if_icmple -> 80
      //   73: sipush #255
      //   76: istore_0
      //   77: goto -> 82
      //   80: iconst_0
      //   81: istore_0
      //   82: iload_1
      //   83: iconst_1
      //   84: if_icmple -> 94
      //   87: sipush #255
      //   90: istore_1
      //   91: goto -> 96
      //   94: iconst_0
      //   95: istore_1
      //   96: iload_2
      //   97: iconst_1
      //   98: if_icmple -> 106
      //   101: sipush #255
      //   104: istore #4
      //   106: iload_3
      //   107: iload_0
      //   108: iload_1
      //   109: iload #4
      //   111: invokestatic argb : (IIII)I
      //   114: ireturn
    }
    
    public static int b(int param1Int1, int param1Int2, int param1Int3) {
      return a(param1Int1, param1Int2, param1Int3, 0);
    }
    
    public void a(char param1Char) {
      if (param1Char == '\n') {
        this.l.add(g());
        this.m.clear();
        if (this.A != -1)
          this.A = 0; 
        if (this.B != -1)
          this.B = 0; 
        if (this.C != -1)
          this.C = 0; 
        if (this.E != -1)
          this.E = 0; 
        while ((this.v && this.l.size() >= this.u) || this.l.size() >= 15)
          this.l.remove(0); 
      } else {
        this.m.append(param1Char);
      } 
    }
    
    public void a(int param1Int1, int param1Int2) {
      if (this.G != param1Int1)
        a('\n'); 
      this.G = param1Int1;
    }
    
    public void a(int param1Int1, int param1Int2, int param1Int3) {
      if (this.C != -1 && this.D != param1Int1)
        this.m.setSpan(new ForegroundColorSpan(this.D), this.C, this.m.length(), 33); 
      if (param1Int1 != a) {
        this.C = this.m.length();
        this.D = param1Int1;
      } 
      if (this.E != -1 && this.F != param1Int2)
        this.m.setSpan(new BackgroundColorSpan(this.F), this.E, this.m.length(), 33); 
      if (param1Int2 != b) {
        this.E = this.m.length();
        this.F = param1Int2;
      } 
    }
    
    public void a(int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean1, boolean param1Boolean2, int param1Int4, int param1Int5) {
      if (this.A != -1) {
        if (!param1Boolean1) {
          this.m.setSpan(new StyleSpan(2), this.A, this.m.length(), 33);
          this.A = -1;
        } 
      } else if (param1Boolean1) {
        this.A = this.m.length();
      } 
      if (this.B != -1) {
        if (!param1Boolean2) {
          this.m.setSpan(new UnderlineSpan(), this.B, this.m.length(), 33);
          this.B = -1;
          return;
        } 
      } else if (param1Boolean2) {
        this.B = this.m.length();
      } 
    }
    
    public void a(int param1Int1, int param1Int2, boolean param1Boolean, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.z = param1Int1;
      this.w = param1Int6;
    }
    
    public void a(boolean param1Boolean) {
      this.o = param1Boolean;
    }
    
    public void a(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, int param1Int1, boolean param1Boolean4, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      this.n = true;
      this.o = param1Boolean1;
      this.v = param1Boolean2;
      this.p = param1Int1;
      this.q = param1Boolean4;
      this.r = param1Int2;
      this.s = param1Int3;
      this.t = param1Int6;
      param1Int1 = this.u;
      param1Int2 = param1Int4 + 1;
      if (param1Int1 != param1Int2) {
        this.u = param1Int2;
        while ((param1Boolean2 && this.l.size() >= this.u) || this.l.size() >= 15)
          this.l.remove(0); 
      } 
      if (param1Int7 != 0 && this.x != param1Int7) {
        this.x = param1Int7;
        param1Int1 = param1Int7 - 1;
        a(h[param1Int1], c, g[param1Int1], 0, e[param1Int1], f[param1Int1], d[param1Int1]);
      } 
      if (param1Int8 != 0 && this.y != param1Int8) {
        this.y = param1Int8;
        param1Int1 = param1Int8 - 1;
        a(0, 1, 1, false, false, j[param1Int1], i[param1Int1]);
        a(a, k[param1Int1], b);
      } 
    }
    
    public boolean a() {
      return (!d() || (this.l.isEmpty() && this.m.length() == 0));
    }
    
    public void b() {
      c();
      this.n = false;
      this.o = false;
      this.p = 4;
      this.q = false;
      this.r = 0;
      this.s = 0;
      this.t = 0;
      this.u = 15;
      this.v = true;
      this.w = 0;
      this.x = 0;
      this.y = 0;
      int i = b;
      this.z = i;
      this.D = a;
      this.F = i;
    }
    
    public void c() {
      this.l.clear();
      this.m.clear();
      this.A = -1;
      this.B = -1;
      this.C = -1;
      this.E = -1;
      this.G = 0;
    }
    
    public boolean d() {
      return this.n;
    }
    
    public boolean e() {
      return this.o;
    }
    
    public void f() {
      int i = this.m.length();
      if (i > 0)
        this.m.delete(i - 1, i); 
    }
    
    public SpannableString g() {
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder((CharSequence)this.m);
      int i = spannableStringBuilder.length();
      if (i > 0) {
        if (this.A != -1)
          spannableStringBuilder.setSpan(new StyleSpan(2), this.A, i, 33); 
        if (this.B != -1)
          spannableStringBuilder.setSpan(new UnderlineSpan(), this.B, i, 33); 
        if (this.C != -1)
          spannableStringBuilder.setSpan(new ForegroundColorSpan(this.D), this.C, i, 33); 
        if (this.E != -1)
          spannableStringBuilder.setSpan(new BackgroundColorSpan(this.F), this.E, i, 33); 
      } 
      return new SpannableString((CharSequence)spannableStringBuilder);
    }
    
    public b.a h() {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual a : ()Z
      //   4: ifeq -> 9
      //   7: aconst_null
      //   8: areturn
      //   9: new android/text/SpannableStringBuilder
      //   12: dup
      //   13: invokespecial <init> : ()V
      //   16: astore #7
      //   18: iconst_0
      //   19: istore #5
      //   21: iconst_0
      //   22: istore_3
      //   23: iload_3
      //   24: aload_0
      //   25: getfield l : Ljava/util/List;
      //   28: invokeinterface size : ()I
      //   33: if_icmpge -> 70
      //   36: aload #7
      //   38: aload_0
      //   39: getfield l : Ljava/util/List;
      //   42: iload_3
      //   43: invokeinterface get : (I)Ljava/lang/Object;
      //   48: checkcast java/lang/CharSequence
      //   51: invokevirtual append : (Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;
      //   54: pop
      //   55: aload #7
      //   57: bipush #10
      //   59: invokevirtual append : (C)Landroid/text/SpannableStringBuilder;
      //   62: pop
      //   63: iload_3
      //   64: iconst_1
      //   65: iadd
      //   66: istore_3
      //   67: goto -> 23
      //   70: aload #7
      //   72: aload_0
      //   73: invokevirtual g : ()Landroid/text/SpannableString;
      //   76: invokevirtual append : (Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;
      //   79: pop
      //   80: aload_0
      //   81: getfield w : I
      //   84: istore_3
      //   85: iload_3
      //   86: ifeq -> 157
      //   89: iload_3
      //   90: iconst_1
      //   91: if_icmpeq -> 149
      //   94: iload_3
      //   95: iconst_2
      //   96: if_icmpeq -> 141
      //   99: iload_3
      //   100: iconst_3
      //   101: if_icmpne -> 107
      //   104: goto -> 157
      //   107: new java/lang/StringBuilder
      //   110: dup
      //   111: ldc 'Unexpected justification value: '
      //   113: invokespecial <init> : (Ljava/lang/String;)V
      //   116: astore #6
      //   118: aload #6
      //   120: aload_0
      //   121: getfield w : I
      //   124: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   127: pop
      //   128: new java/lang/IllegalArgumentException
      //   131: dup
      //   132: aload #6
      //   134: invokevirtual toString : ()Ljava/lang/String;
      //   137: invokespecial <init> : (Ljava/lang/String;)V
      //   140: athrow
      //   141: getstatic android/text/Layout$Alignment.ALIGN_CENTER : Landroid/text/Layout$Alignment;
      //   144: astore #6
      //   146: goto -> 162
      //   149: getstatic android/text/Layout$Alignment.ALIGN_OPPOSITE : Landroid/text/Layout$Alignment;
      //   152: astore #6
      //   154: goto -> 162
      //   157: getstatic android/text/Layout$Alignment.ALIGN_NORMAL : Landroid/text/Layout$Alignment;
      //   160: astore #6
      //   162: aload_0
      //   163: getfield q : Z
      //   166: ifeq -> 192
      //   169: aload_0
      //   170: getfield s : I
      //   173: i2f
      //   174: ldc_w 99.0
      //   177: fdiv
      //   178: fstore_1
      //   179: aload_0
      //   180: getfield r : I
      //   183: i2f
      //   184: ldc_w 99.0
      //   187: fdiv
      //   188: fstore_2
      //   189: goto -> 212
      //   192: aload_0
      //   193: getfield s : I
      //   196: i2f
      //   197: ldc_w 209.0
      //   200: fdiv
      //   201: fstore_1
      //   202: aload_0
      //   203: getfield r : I
      //   206: i2f
      //   207: ldc_w 74.0
      //   210: fdiv
      //   211: fstore_2
      //   212: aload_0
      //   213: getfield t : I
      //   216: istore #4
      //   218: iload #4
      //   220: iconst_3
      //   221: idiv
      //   222: ifne -> 230
      //   225: iconst_0
      //   226: istore_3
      //   227: goto -> 245
      //   230: iload #4
      //   232: iconst_3
      //   233: idiv
      //   234: iconst_1
      //   235: if_icmpne -> 243
      //   238: iconst_1
      //   239: istore_3
      //   240: goto -> 245
      //   243: iconst_2
      //   244: istore_3
      //   245: iload #4
      //   247: iconst_3
      //   248: irem
      //   249: ifne -> 258
      //   252: iconst_0
      //   253: istore #4
      //   255: goto -> 275
      //   258: iload #4
      //   260: iconst_3
      //   261: irem
      //   262: iconst_1
      //   263: if_icmpne -> 272
      //   266: iconst_1
      //   267: istore #4
      //   269: goto -> 275
      //   272: iconst_2
      //   273: istore #4
      //   275: aload_0
      //   276: getfield z : I
      //   279: getstatic com/applovin/exoplayer2/i/a/b$b.b : I
      //   282: if_icmpeq -> 288
      //   285: iconst_1
      //   286: istore #5
      //   288: new com/applovin/exoplayer2/i/a/b$a
      //   291: dup
      //   292: aload #7
      //   294: aload #6
      //   296: fload_2
      //   297: ldc_w 0.9
      //   300: fmul
      //   301: ldc_w 0.05
      //   304: fadd
      //   305: iconst_0
      //   306: iload_3
      //   307: fload_1
      //   308: ldc_w 0.9
      //   311: fmul
      //   312: ldc_w 0.05
      //   315: fadd
      //   316: iload #4
      //   318: ldc_w -3.4028235E38
      //   321: iload #5
      //   323: aload_0
      //   324: getfield z : I
      //   327: aload_0
      //   328: getfield p : I
      //   331: invokespecial <init> : (Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;FIIFIFZII)V
      //   334: areturn
    }
    
    static {
      int i = a(0, 0, 0, 0);
      b = i;
      int j = a(0, 0, 0, 3);
      c = j;
    }
    
    static {
      h = new int[] { i, j, i, i, j, i, i };
    }
  }
  
  private static final class c {
    public final int a;
    
    public final int b;
    
    public final byte[] c;
    
    int d;
    
    public c(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = new byte[param1Int2 * 2 - 1];
      this.d = 0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\i\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */