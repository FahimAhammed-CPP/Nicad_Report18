package com.applovin.mediation.adapters;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import com.applovin.impl.sdk.utils.BundleUtils;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.adapter.MaxAdViewAdapter;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.MaxRewardedInterstitialAdapter;
import com.applovin.mediation.adapter.MaxSignalProvider;
import com.applovin.mediation.adapter.listeners.MaxAdViewAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxAppOpenAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxSignalCollectionListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterSignalCollectionParameters;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdFormat;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.ResponseInfo;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.query.QueryInfo;
import com.google.android.gms.ads.query.QueryInfoGenerationCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class GoogleMediationAdapter extends MediationAdapterBase implements MaxSignalProvider, MaxInterstitialAdapter, MaxRewardedInterstitialAdapter, MaxRewardedAdapter, MaxAdViewAdapter {
  private static final int ADVERTISER_VIEW_TAG = 8;
  
  private static final int BODY_VIEW_TAG = 4;
  
  private static final int CALL_TO_ACTION_VIEW_TAG = 5;
  
  private static final int ICON_VIEW_TAG = 3;
  
  private static final int MEDIA_VIEW_CONTAINER_TAG = 2;
  
  private static final int TITLE_LABEL_TAG = 1;
  
  private static final AtomicBoolean initialized = new AtomicBoolean();
  
  private static MaxAdapter.InitializationStatus status;
  
  private AdView adView;
  
  private AppOpenAd appOpenAd;
  
  private AppOpenAdListener appOpenAdListener;
  
  private InterstitialAd appOpenInterstitialAd;
  
  private AppOpenAdListener appOpenInterstitialAdListener;
  
  private InterstitialAd interstitialAd;
  
  private NativeAd nativeAd;
  
  private NativeAdView nativeAdView;
  
  private RewardedAd rewardedAd;
  
  private RewardedAdListener rewardedAdListener;
  
  private RewardedInterstitialAd rewardedInterstitialAd;
  
  private RewardedInterstitialAdListener rewardedInterstitialAdListener;
  
  public GoogleMediationAdapter(AppLovinSdk paramAppLovinSdk) {
    super(paramAppLovinSdk);
  }
  
  private AdRequest createAdRequestWithParameters(boolean paramBoolean, MaxAdFormat paramMaxAdFormat, MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    AdRequest.Builder builder = new AdRequest.Builder();
    Bundle bundle2 = paramMaxAdapterParameters.getServerParameters();
    Bundle bundle1 = new Bundle(6);
    if (paramBoolean) {
      String str1;
      boolean bool1 = "dv360".equalsIgnoreCase(BundleUtils.getString("bidder", "", bundle2));
      if (bool1) {
        str1 = "requester_type_3";
      } else {
        str1 = "requester_type_2";
      } 
      bundle1.putString("query_info_type", str1);
      if (AppLovinSdk.VERSION_CODE >= 11000000 && paramMaxAdFormat.isAdViewAd()) {
        str1 = (String)paramMaxAdapterParameters.getLocalExtraParameters().get("adaptive_banner");
        if (str1 instanceof String && "true".equalsIgnoreCase(str1)) {
          AdSize adSize = toAdSize(paramMaxAdFormat, true, paramMaxAdapterParameters, paramContext);
          bundle1.putInt("adaptive_banner_w", adSize.getWidth());
          bundle1.putInt("adaptive_banner_h", adSize.getHeight());
        } 
      } 
      paramBoolean = bool1;
      if (paramMaxAdapterParameters instanceof MaxAdapterResponseParameters) {
        String str2 = ((MaxAdapterResponseParameters)paramMaxAdapterParameters).getBidResponse();
        paramBoolean = bool1;
        if (AppLovinSdkUtils.isValidString(str2)) {
          builder.setAdString(str2);
          paramBoolean = bool1;
        } 
      } 
    } else {
      paramBoolean = false;
    } 
    if (bundle2.getBoolean("set_mediation_identifier", true)) {
      String str1;
      if (paramBoolean) {
        str1 = "applovin_dv360";
      } else {
        str1 = "applovin";
      } 
      builder.setRequestAgent(str1);
    } 
    String str = BundleUtils.getString("event_id", bundle2);
    if (AppLovinSdkUtils.isValidString(str))
      bundle1.putString("placement_req_id", str); 
    Boolean bool = paramMaxAdapterParameters.hasUserConsent();
    if (bool != null && !bool.booleanValue())
      bundle1.putString("npa", "1"); 
    bool = paramMaxAdapterParameters.isDoNotSell();
    if (bool != null && bool.booleanValue()) {
      bundle1.putInt("rdp", 1);
      PreferenceManager.getDefaultSharedPreferences(paramContext).edit().putInt("gad_rdp", 1).commit();
    } else {
      PreferenceManager.getDefaultSharedPreferences(paramContext).edit().remove("gad_rdp").commit();
    } 
    if (AppLovinSdk.VERSION_CODE >= 11000000) {
      Map map = paramMaxAdapterParameters.getLocalExtraParameters();
      paramMaxAdapterParameters = (MaxAdapterParameters)map.get("google_max_ad_content_rating");
      if (paramMaxAdapterParameters instanceof String)
        bundle1.putString("max_ad_content_rating", (String)paramMaxAdapterParameters); 
      paramMaxAdapterParameters = (MaxAdapterParameters)map.get("google_content_url");
      if (paramMaxAdapterParameters instanceof String)
        builder.setContentUrl((String)paramMaxAdapterParameters); 
      map = (Map)map.get("google_neighbouring_content_url_strings");
      if (map instanceof List)
        try {
          builder.setNeighboringContentUrls((List)map);
        } finally {
          map = null;
        }  
    } 
    builder.addNetworkExtrasBundle(AdMobAdapter.class, bundle1);
    return builder.build();
  }
  
  private int getAdChoicesPlacement(MaxAdapterResponseParameters paramMaxAdapterResponseParameters) {
    int j = AppLovinSdk.VERSION_CODE;
    byte b = 1;
    int i = b;
    if (j >= 11000000) {
      Map map = paramMaxAdapterResponseParameters.getLocalExtraParameters();
      if (map != null) {
        map = (Map)map.get("admob_ad_choices_placement");
      } else {
        map = null;
      } 
      i = b;
      if (isValidAdChoicesPlacement(map))
        i = ((Integer)map).intValue(); 
    } 
    return i;
  }
  
  private int getAdaptiveBannerWidth(MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    if (AppLovinSdk.VERSION_CODE >= 11000000) {
      paramMaxAdapterParameters = (MaxAdapterParameters)paramMaxAdapterParameters.getLocalExtraParameters().get("adaptive_banner_width");
      if (paramMaxAdapterParameters instanceof Integer)
        return ((Integer)paramMaxAdapterParameters).intValue(); 
      if (paramMaxAdapterParameters != null) {
        StringBuilder stringBuilder = new StringBuilder("Expected parameter \"adaptive_banner_width\" to be of type Integer, received: ");
        stringBuilder.append(paramMaxAdapterParameters.getClass());
        e(stringBuilder.toString());
      } 
    } 
    return AppLovinSdkUtils.pxToDp(paramContext, getApplicationWindowWidth(paramContext));
  }
  
  public static int getApplicationWindowWidth(Context paramContext) {
    WindowManager windowManager = (WindowManager)paramContext.getSystemService("window");
    if (Build.VERSION.SDK_INT >= 30)
      return windowManager.getCurrentWindowMetrics().getBounds().width(); 
    Display display = windowManager.getDefaultDisplay();
    DisplayMetrics displayMetrics = new DisplayMetrics();
    display.getMetrics(displayMetrics);
    return displayMetrics.widthPixels;
  }
  
  private Context getContext(Activity paramActivity) {
    return (paramActivity != null) ? paramActivity.getApplicationContext() : getApplicationContext();
  }
  
  private boolean isValidAdChoicesPlacement(Object paramObject) {
    if (paramObject instanceof Integer) {
      paramObject = paramObject;
      int i = paramObject.intValue();
      boolean bool2 = true;
      boolean bool1 = bool2;
      if (i != 0) {
        bool1 = bool2;
        if (paramObject.intValue() != 1) {
          bool1 = bool2;
          if (paramObject.intValue() != 3) {
            if (paramObject.intValue() == 2)
              return true; 
          } else {
            return bool1;
          } 
        } else {
          return bool1;
        } 
      } else {
        return bool1;
      } 
    } 
    return false;
  }
  
  private void setRequestConfiguration(MaxAdapterParameters paramMaxAdapterParameters) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private AdFormat toAdFormat(MaxAdapterSignalCollectionParameters paramMaxAdapterSignalCollectionParameters) {
    boolean bool;
    MaxAdFormat maxAdFormat = paramMaxAdapterSignalCollectionParameters.getAdFormat();
    if (paramMaxAdapterSignalCollectionParameters.getServerParameters().getBoolean("is_native") || maxAdFormat == MaxAdFormat.NATIVE) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? AdFormat.NATIVE : (maxAdFormat.isAdViewAd() ? AdFormat.BANNER : ((maxAdFormat == MaxAdFormat.INTERSTITIAL) ? AdFormat.INTERSTITIAL : ((maxAdFormat == MaxAdFormat.REWARDED) ? AdFormat.REWARDED : ((maxAdFormat == MaxAdFormat.REWARDED_INTERSTITIAL) ? AdFormat.REWARDED_INTERSTITIAL : ((maxAdFormat == MaxAdFormat.APP_OPEN) ? AdFormat.APP_OPEN_AD : AdFormat.UNKNOWN)))));
  }
  
  private AdSize toAdSize(MaxAdFormat paramMaxAdFormat, boolean paramBoolean, MaxAdapterParameters paramMaxAdapterParameters, Context paramContext) {
    if (paramMaxAdFormat == MaxAdFormat.BANNER || paramMaxAdFormat == MaxAdFormat.LEADER)
      return paramBoolean ? AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(paramContext, getAdaptiveBannerWidth(paramMaxAdapterParameters, paramContext)) : ((paramMaxAdFormat == MaxAdFormat.BANNER) ? AdSize.BANNER : AdSize.LEADERBOARD); 
    if (paramMaxAdFormat == MaxAdFormat.MREC)
      return AdSize.MEDIUM_RECTANGLE; 
    StringBuilder stringBuilder = new StringBuilder("Unsupported ad format: ");
    stringBuilder.append(paramMaxAdFormat);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static MaxAdapterError toMaxError(AdError paramAdError) {
    int i = paramAdError.getCode();
    MaxAdapterError maxAdapterError = MaxAdapterError.UNSPECIFIED;
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            switch (i) {
              default:
                return new MaxAdapterError(maxAdapterError.getErrorCode(), maxAdapterError.getErrorMessage(), i, paramAdError.getMessage());
              case 8:
              case 11:
                maxAdapterError = MaxAdapterError.INVALID_CONFIGURATION;
              case 9:
                maxAdapterError = MaxAdapterError.NO_FILL;
              case 10:
                break;
            } 
          } else {
          
          } 
        } else {
          maxAdapterError = MaxAdapterError.NO_CONNECTION;
        }  
      maxAdapterError = MaxAdapterError.BAD_REQUEST;
    } 
    maxAdapterError = MaxAdapterError.INTERNAL_ERROR;
  }
  
  private static void updateMuteState(MaxAdapterResponseParameters paramMaxAdapterResponseParameters) {
    Bundle bundle = paramMaxAdapterResponseParameters.getServerParameters();
    if (bundle.containsKey("is_muted"))
      MobileAds.setAppMuted(bundle.getBoolean("is_muted")); 
  }
  
  public void collectSignal(MaxAdapterSignalCollectionParameters paramMaxAdapterSignalCollectionParameters, Activity paramActivity, final MaxSignalCollectionListener callback) {
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterSignalCollectionParameters);
    Context context = getContext(paramActivity);
    AdRequest adRequest = createAdRequestWithParameters(true, paramMaxAdapterSignalCollectionParameters.getAdFormat(), (MaxAdapterParameters)paramMaxAdapterSignalCollectionParameters, context);
    QueryInfo.generate(context, toAdFormat(paramMaxAdapterSignalCollectionParameters), adRequest, new QueryInfoGenerationCallback() {
          public void onFailure(String param1String) {
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Signal collection failed with error: ");
            stringBuilder.append(param1String);
            googleMediationAdapter.log(stringBuilder.toString());
            callback.onSignalCollectionFailed(param1String);
          }
          
          public void onSuccess(QueryInfo param1QueryInfo) {
            GoogleMediationAdapter.this.log("Signal collection successful");
            callback.onSignalCollected(param1QueryInfo.getQuery());
          }
        });
  }
  
  public String getAdapterVersion() {
    return "22.4.0.0";
  }
  
  public String getSdkVersion() {
    return String.valueOf(MobileAds.getVersion());
  }
  
  public void initialize(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, final MaxAdapter.OnCompletionListener onCompletionListener) {
    log("Initializing Google SDK...");
    if (initialized.compareAndSet(false, true)) {
      Context context = getContext(paramActivity);
      MobileAds.disableMediationAdapterInitialization(context);
      if (paramMaxAdapterInitializationParameters.getServerParameters().getBoolean("init_without_callback", false)) {
        status = MaxAdapter.InitializationStatus.DOES_NOT_APPLY;
        MobileAds.initialize(context);
        onCompletionListener.onCompletion(status, null);
        return;
      } 
      status = MaxAdapter.InitializationStatus.INITIALIZING;
      MobileAds.initialize(context, new OnInitializationCompleteListener() {
            public void onInitializationComplete(InitializationStatus param1InitializationStatus) {
              MaxAdapter.InitializationStatus initializationStatus;
              AdapterStatus adapterStatus = (AdapterStatus)param1InitializationStatus.getAdapterStatusMap().get("com.google.android.gms.ads.MobileAds");
              if (adapterStatus != null) {
                AdapterStatus.State state = adapterStatus.getInitializationState();
              } else {
                adapterStatus = null;
              } 
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder("Initialization complete with status ");
              stringBuilder.append(adapterStatus);
              googleMediationAdapter.log(stringBuilder.toString());
              if (AdapterStatus.State.READY == adapterStatus) {
                initializationStatus = MaxAdapter.InitializationStatus.INITIALIZED_SUCCESS;
              } else {
                initializationStatus = MaxAdapter.InitializationStatus.INITIALIZED_UNKNOWN;
              } 
              GoogleMediationAdapter.access$002(initializationStatus);
              onCompletionListener.onCompletion(GoogleMediationAdapter.status, null);
            }
          });
      return;
    } 
    onCompletionListener.onCompletion(status, null);
  }
  
  public void loadAdViewAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, MaxAdFormat paramMaxAdFormat, Activity paramActivity, MaxAdViewAdapterListener paramMaxAdViewAdapterListener) {
    NativeAdViewListener nativeAdViewListener;
    String str3 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool1 = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    boolean bool2 = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_native");
    StringBuilder stringBuilder = new StringBuilder("Loading ");
    String str2 = "";
    if (bool1) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    String str1 = str2;
    if (bool2)
      str1 = "native "; 
    stringBuilder.append(str1);
    stringBuilder.append(paramMaxAdFormat.getLabel());
    stringBuilder.append(" ad for placement id: ");
    stringBuilder.append(str3);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    Context context = getContext(paramActivity);
    AdRequest adRequest = createAdRequestWithParameters(bool1, paramMaxAdFormat, (MaxAdapterParameters)paramMaxAdapterResponseParameters, context);
    bool1 = false;
    if (bool2) {
      NativeAdOptions.Builder builder = new NativeAdOptions.Builder();
      builder.setAdChoicesPlacement(getAdChoicesPlacement(paramMaxAdapterResponseParameters));
      if (paramMaxAdFormat == MaxAdFormat.MREC)
        bool1 = true; 
      builder.setRequestMultipleImages(bool1);
      nativeAdViewListener = new NativeAdViewListener(paramMaxAdapterResponseParameters, paramMaxAdFormat, paramActivity, paramMaxAdViewAdapterListener);
      (new AdLoader.Builder(context, str3)).withNativeAdOptions(builder.build()).forNativeAd(nativeAdViewListener).withAdListener(nativeAdViewListener).build().loadAd(adRequest);
      return;
    } 
    AdView adView = new AdView(context);
    this.adView = adView;
    adView.setAdUnitId(str3);
    this.adView.setAdListener(new AdViewListener(str3, paramMaxAdFormat, paramMaxAdViewAdapterListener));
    bool1 = nativeAdViewListener.getServerParameters().getBoolean("adaptive_banner", false);
    this.adView.setAdSize(toAdSize(paramMaxAdFormat, bool1, (MaxAdapterParameters)nativeAdViewListener, context));
    this.adView.loadAd(adRequest);
  }
  
  public void loadAppOpenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxAppOpenAdapterListener listener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool1 = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    boolean bool2 = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_inter_placement");
    StringBuilder stringBuilder = new StringBuilder("Loading ");
    String str2 = "";
    if (bool1) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("app open ");
    String str1 = str2;
    if (bool2)
      str1 = "interstitial "; 
    stringBuilder.append(str1);
    stringBuilder.append("ad: ");
    stringBuilder.append(str3);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    Context context = getContext(paramActivity);
    if (bool2) {
      InterstitialAd.load(context, str3, createAdRequestWithParameters(bool1, MaxAdFormat.INTERSTITIAL, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new InterstitialAdLoadCallback() {
            public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
              MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder("App open interstitial ad (");
              stringBuilder.append(placementId);
              stringBuilder.append(") failed to load with error: ");
              stringBuilder.append(maxAdapterError);
              googleMediationAdapter.log(stringBuilder.toString());
              listener.onAppOpenAdLoadFailed(maxAdapterError);
            }
            
            public void onAdLoaded(InterstitialAd param1InterstitialAd) {
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder("App open interstitial ad loaded: ");
              stringBuilder.append(placementId);
              stringBuilder.append("...");
              googleMediationAdapter.log(stringBuilder.toString());
              GoogleMediationAdapter.access$302(GoogleMediationAdapter.this, param1InterstitialAd);
              GoogleMediationAdapter.access$402(GoogleMediationAdapter.this, new GoogleMediationAdapter.AppOpenAdListener(placementId, listener));
              GoogleMediationAdapter.this.appOpenInterstitialAd.setFullScreenContentCallback(GoogleMediationAdapter.this.appOpenInterstitialAdListener);
              ResponseInfo responseInfo = GoogleMediationAdapter.this.appOpenInterstitialAd.getResponseInfo();
              if (responseInfo != null) {
                String str = responseInfo.getResponseId();
              } else {
                responseInfo = null;
              } 
              if (AppLovinSdkUtils.isValidString((String)responseInfo)) {
                Bundle bundle = new Bundle(1);
                bundle.putString("creative_id", (String)responseInfo);
                listener.onAppOpenAdLoaded(bundle);
                return;
              } 
              listener.onAppOpenAdLoaded();
            }
          });
      return;
    } 
    AppOpenAd.load(context, str3, createAdRequestWithParameters(bool1, MaxAdFormat.APP_OPEN, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), AppLovinSdkUtils.getOrientation(context), new AppOpenAd.AppOpenAdLoadCallback() {
          public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("App open ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleMediationAdapter.log(stringBuilder.toString());
            listener.onAppOpenAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(AppOpenAd param1AppOpenAd) {
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("App open ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleMediationAdapter.log(stringBuilder.toString());
            GoogleMediationAdapter.access$502(GoogleMediationAdapter.this, param1AppOpenAd);
            GoogleMediationAdapter.access$602(GoogleMediationAdapter.this, new GoogleMediationAdapter.AppOpenAdListener(placementId, listener));
            param1AppOpenAd.setFullScreenContentCallback(GoogleMediationAdapter.this.appOpenAdListener);
            ResponseInfo responseInfo = GoogleMediationAdapter.this.appOpenAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onAppOpenAdLoaded(bundle);
              return;
            } 
            listener.onAppOpenAdLoaded();
          }
        });
  }
  
  public void loadInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxInterstitialAdapterListener listener) {
    String str1;
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    StringBuilder stringBuilder = new StringBuilder("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("interstitial ad: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    InterstitialAd.load((Context)paramActivity, str2, createAdRequestWithParameters(bool, MaxAdFormat.INTERSTITIAL, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new InterstitialAdLoadCallback() {
          public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Interstitial ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleMediationAdapter.log(stringBuilder.toString());
            listener.onInterstitialAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(InterstitialAd param1InterstitialAd) {
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Interstitial ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleMediationAdapter.log(stringBuilder.toString());
            GoogleMediationAdapter.access$102(GoogleMediationAdapter.this, param1InterstitialAd);
            GoogleMediationAdapter.this.interstitialAd.setFullScreenContentCallback(new GoogleMediationAdapter.InterstitialAdListener(placementId, listener));
            ResponseInfo responseInfo = GoogleMediationAdapter.this.interstitialAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onInterstitialAdLoaded(bundle);
              return;
            } 
            listener.onInterstitialAdLoaded();
          }
        });
  }
  
  public void loadNativeAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxNativeAdAdapterListener paramMaxNativeAdAdapterListener) {
    Context context;
    String str1;
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    StringBuilder stringBuilder = new StringBuilder("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append(" native ad for placement id: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    if (paramActivity != null) {
      context = paramActivity.getApplicationContext();
    } else {
      context = getApplicationContext();
    } 
    AdRequest adRequest = createAdRequestWithParameters(bool, MaxAdFormat.NATIVE, (MaxAdapterParameters)paramMaxAdapterResponseParameters, context);
    NativeAdOptions.Builder builder = new NativeAdOptions.Builder();
    builder.setAdChoicesPlacement(getAdChoicesPlacement(paramMaxAdapterResponseParameters));
    builder.setRequestMultipleImages(BundleUtils.getString("template", "", paramMaxAdapterResponseParameters.getServerParameters()).contains("medium"));
    NativeAdListener nativeAdListener = new NativeAdListener(paramMaxAdapterResponseParameters, context, paramMaxNativeAdAdapterListener);
    (new AdLoader.Builder(context, str2)).withNativeAdOptions(builder.build()).forNativeAd(nativeAdListener).withAdListener(nativeAdListener).build().loadAd(adRequest);
  }
  
  public void loadRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxRewardedAdapterListener listener) {
    String str1;
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    StringBuilder stringBuilder = new StringBuilder("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("rewarded ad: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    RewardedAd.load((Context)paramActivity, str2, createAdRequestWithParameters(bool, MaxAdFormat.REWARDED, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new RewardedAdLoadCallback() {
          public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Rewarded ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleMediationAdapter.log(stringBuilder.toString());
            listener.onRewardedAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(RewardedAd param1RewardedAd) {
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Rewarded ad loaded: ");
            stringBuilder.append(placementId);
            stringBuilder.append("...");
            googleMediationAdapter.log(stringBuilder.toString());
            GoogleMediationAdapter.access$1102(GoogleMediationAdapter.this, param1RewardedAd);
            GoogleMediationAdapter.access$1202(GoogleMediationAdapter.this, new GoogleMediationAdapter.RewardedAdListener(placementId, listener));
            GoogleMediationAdapter.this.rewardedAd.setFullScreenContentCallback(GoogleMediationAdapter.this.rewardedAdListener);
            ResponseInfo responseInfo = GoogleMediationAdapter.this.rewardedAd.getResponseInfo();
            if (responseInfo != null) {
              String str = responseInfo.getResponseId();
            } else {
              responseInfo = null;
            } 
            if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", (String)responseInfo);
              listener.onRewardedAdLoaded(bundle);
              return;
            } 
            listener.onRewardedAdLoaded();
          }
        });
  }
  
  public void loadRewardedInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, final MaxRewardedInterstitialAdapterListener listener) {
    String str1;
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = AppLovinSdkUtils.isValidString(paramMaxAdapterResponseParameters.getBidResponse());
    StringBuilder stringBuilder = new StringBuilder("Loading ");
    if (bool) {
      str1 = "bidding ";
    } else {
      str1 = "";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("rewarded interstitial ad: ");
    stringBuilder.append(str2);
    stringBuilder.append("...");
    log(stringBuilder.toString());
    updateMuteState(paramMaxAdapterResponseParameters);
    setRequestConfiguration((MaxAdapterParameters)paramMaxAdapterResponseParameters);
    RewardedInterstitialAd.load((Context)paramActivity, str2, createAdRequestWithParameters(bool, MaxAdFormat.REWARDED_INTERSTITIAL, (MaxAdapterParameters)paramMaxAdapterResponseParameters, (Context)paramActivity), new RewardedInterstitialAdLoadCallback() {
          public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
            MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
            GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Rewarded interstitial ad (");
            stringBuilder.append(placementId);
            stringBuilder.append(") failed to load with error: ");
            stringBuilder.append(maxAdapterError);
            googleMediationAdapter.log(stringBuilder.toString());
            listener.onRewardedInterstitialAdLoadFailed(maxAdapterError);
          }
          
          public void onAdLoaded(RewardedInterstitialAd param1RewardedInterstitialAd) {
            String str1;
            GoogleMediationAdapter googleMediationAdapter1 = GoogleMediationAdapter.this;
            StringBuilder stringBuilder = new StringBuilder("Rewarded interstitial ad loaded: ");
            stringBuilder.append(placementId);
            googleMediationAdapter1.log(stringBuilder.toString());
            GoogleMediationAdapter.access$702(GoogleMediationAdapter.this, param1RewardedInterstitialAd);
            googleMediationAdapter1 = GoogleMediationAdapter.this;
            GoogleMediationAdapter googleMediationAdapter2 = GoogleMediationAdapter.this;
            String str2 = placementId;
            MaxRewardedInterstitialAdapterListener maxRewardedInterstitialAdapterListener = listener;
            param1RewardedInterstitialAd = null;
            GoogleMediationAdapter.access$802(googleMediationAdapter1, new GoogleMediationAdapter.RewardedInterstitialAdListener(str2, maxRewardedInterstitialAdapterListener));
            GoogleMediationAdapter.this.rewardedInterstitialAd.setFullScreenContentCallback(GoogleMediationAdapter.this.rewardedInterstitialAdListener);
            ResponseInfo responseInfo = GoogleMediationAdapter.this.rewardedInterstitialAd.getResponseInfo();
            if (responseInfo != null)
              str1 = responseInfo.getResponseId(); 
            if (AppLovinSdk.VERSION_CODE > 9150000 && AppLovinSdkUtils.isValidString(str1)) {
              Bundle bundle = new Bundle(1);
              bundle.putString("creative_id", str1);
              listener.onRewardedInterstitialAdLoaded(bundle);
              return;
            } 
            listener.onRewardedInterstitialAdLoaded();
          }
        });
  }
  
  public void onDestroy() {
    StringBuilder stringBuilder = new StringBuilder("Destroy called for adapter ");
    stringBuilder.append(this);
    log(stringBuilder.toString());
    InterstitialAd interstitialAd2 = this.interstitialAd;
    if (interstitialAd2 != null) {
      interstitialAd2.setFullScreenContentCallback(null);
      this.interstitialAd = null;
    } 
    AppOpenAd appOpenAd = this.appOpenAd;
    if (appOpenAd != null) {
      appOpenAd.setFullScreenContentCallback(null);
      this.appOpenAd = null;
      this.appOpenAdListener = null;
    } 
    InterstitialAd interstitialAd1 = this.appOpenInterstitialAd;
    if (interstitialAd1 != null) {
      interstitialAd1.setFullScreenContentCallback(null);
      this.appOpenInterstitialAd = null;
      this.appOpenInterstitialAdListener = null;
    } 
    RewardedInterstitialAd rewardedInterstitialAd = this.rewardedInterstitialAd;
    if (rewardedInterstitialAd != null) {
      rewardedInterstitialAd.setFullScreenContentCallback(null);
      this.rewardedInterstitialAd = null;
      this.rewardedInterstitialAdListener = null;
    } 
    RewardedAd rewardedAd = this.rewardedAd;
    if (rewardedAd != null) {
      rewardedAd.setFullScreenContentCallback(null);
      this.rewardedAd = null;
      this.rewardedAdListener = null;
    } 
    AdView adView = this.adView;
    if (adView != null) {
      adView.destroy();
      this.adView = null;
    } 
    NativeAd nativeAd = this.nativeAd;
    if (nativeAd != null) {
      nativeAd.destroy();
      this.nativeAd = null;
    } 
    NativeAdView nativeAdView = this.nativeAdView;
    if (nativeAdView != null) {
      nativeAdView.destroy();
      this.nativeAdView = null;
    } 
  }
  
  public void showAppOpenAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxAppOpenAdapterListener paramMaxAppOpenAdapterListener) {
    String str1;
    String str2 = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    boolean bool = paramMaxAdapterResponseParameters.getServerParameters().getBoolean("is_inter_placement");
    StringBuilder stringBuilder2 = new StringBuilder("Showing app open ");
    if (bool) {
      str1 = "interstitial ";
    } else {
      str1 = "";
    } 
    stringBuilder2.append(str1);
    stringBuilder2.append("ad: ");
    stringBuilder2.append(str2);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    InterstitialAd interstitialAd = this.appOpenInterstitialAd;
    if (interstitialAd != null) {
      interstitialAd.show(paramActivity);
      return;
    } 
    AppOpenAd appOpenAd = this.appOpenAd;
    if (appOpenAd != null) {
      appOpenAd.show(paramActivity);
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder("App open ad failed to show: ");
    stringBuilder1.append(str2);
    log(stringBuilder1.toString());
    paramMaxAppOpenAdapterListener.onAppOpenAdLoadFailed(new MaxAdapterError(-4205, "Ad display failed", 0, "App open ad not ready"));
  }
  
  public void showInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxInterstitialAdapterListener paramMaxInterstitialAdapterListener) {
    String str = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder("Showing interstitial ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    InterstitialAd interstitialAd = this.interstitialAd;
    if (interstitialAd != null) {
      interstitialAd.show(paramActivity);
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder("Interstitial ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxInterstitialAdapterListener.onInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Interstitial ad not ready"));
  }
  
  public void showRewardedAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedAdapterListener paramMaxRewardedAdapterListener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder("Showing rewarded ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (this.rewardedAd != null) {
      configureReward(paramMaxAdapterResponseParameters);
      this.rewardedAd.show(paramActivity, new OnUserEarnedRewardListener() {
            public void onUserEarnedReward(RewardItem param1RewardItem) {
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder("Rewarded ad user earned reward: ");
              stringBuilder.append(placementId);
              googleMediationAdapter.log(stringBuilder.toString());
              GoogleMediationAdapter.RewardedAdListener.access$1302(GoogleMediationAdapter.this.rewardedAdListener, true);
            }
          });
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder("Rewarded ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxRewardedAdapterListener.onRewardedAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded ad not ready"));
  }
  
  public void showRewardedInterstitialAd(MaxAdapterResponseParameters paramMaxAdapterResponseParameters, Activity paramActivity, MaxRewardedInterstitialAdapterListener paramMaxRewardedInterstitialAdapterListener) {
    final String placementId = paramMaxAdapterResponseParameters.getThirdPartyAdPlacementId();
    StringBuilder stringBuilder2 = new StringBuilder("Showing rewarded interstitial ad: ");
    stringBuilder2.append(str);
    stringBuilder2.append("...");
    log(stringBuilder2.toString());
    if (this.rewardedInterstitialAd != null) {
      configureReward(paramMaxAdapterResponseParameters);
      this.rewardedInterstitialAd.show(paramActivity, new OnUserEarnedRewardListener() {
            public void onUserEarnedReward(RewardItem param1RewardItem) {
              GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
              StringBuilder stringBuilder = new StringBuilder("Rewarded interstitial ad user earned reward: ");
              stringBuilder.append(placementId);
              googleMediationAdapter.log(stringBuilder.toString());
              GoogleMediationAdapter.RewardedInterstitialAdListener.access$1002(GoogleMediationAdapter.this.rewardedInterstitialAdListener, true);
            }
          });
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder("Rewarded interstitial ad failed to show: ");
    stringBuilder1.append(str);
    log(stringBuilder1.toString());
    paramMaxRewardedInterstitialAdapterListener.onRewardedInterstitialAdDisplayFailed(new MaxAdapterError(-4205, "Ad Display Failed", 0, "Rewarded Interstitial ad not ready"));
  }
  
  private class AdViewListener extends AdListener {
    final MaxAdFormat adFormat;
    
    final MaxAdViewAdapterListener listener;
    
    final String placementId;
    
    AdViewListener(String param1String, MaxAdFormat param1MaxAdFormat, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.placementId = param1String;
      this.adFormat = param1MaxAdFormat;
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void onAdClosed() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad closed");
      googleMediationAdapter.log(stringBuilder.toString());
    }
    
    public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error code: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onAdLoaded() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      if (AppLovinSdk.VERSION_CODE >= 9150000) {
        Bundle bundle = new Bundle(3);
        ResponseInfo responseInfo = GoogleMediationAdapter.this.adView.getResponseInfo();
        if (responseInfo != null) {
          String str = responseInfo.getResponseId();
        } else {
          responseInfo = null;
        } 
        if (AppLovinSdkUtils.isValidString((String)responseInfo))
          bundle.putString("creative_id", (String)responseInfo); 
        AdSize adSize = GoogleMediationAdapter.this.adView.getAdSize();
        if (adSize != null) {
          bundle.putInt("ad_width", adSize.getWidth());
          bundle.putInt("ad_height", adSize.getHeight());
        } 
        this.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.adView, bundle);
        return;
      } 
      this.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.adView);
    }
    
    public void onAdOpened() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad opened");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
  }
  
  private class AppOpenAdListener extends FullScreenContentCallback {
    private final MaxAppOpenAdapterListener listener;
    
    private final String placementId;
    
    AppOpenAdListener(String param1String, MaxAppOpenAdapterListener param1MaxAppOpenAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxAppOpenAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("App open ad clicked: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("App open ad hidden: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad display failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("App open ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("App open ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAppOpenAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("App open ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  private class InterstitialAdListener extends FullScreenContentCallback {
    private final MaxInterstitialAdapterListener listener;
    
    private final String placementId;
    
    InterstitialAdListener(String param1String, MaxInterstitialAdapterListener param1MaxInterstitialAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxInterstitialAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Interstitial ad clicked: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Interstitial ad hidden: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Interstitial ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Interstitial ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onInterstitialAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Interstitial ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
    }
  }
  
  private class MaxGoogleNativeAd extends MaxNativeAd {
    public MaxGoogleNativeAd(MaxNativeAd.Builder param1Builder) {
      super(param1Builder);
    }
    
    public boolean prepareForInteraction(List<View> param1List, ViewGroup param1ViewGroup) {
      View view1;
      View view2;
      NativeAd nativeAd = GoogleMediationAdapter.this.nativeAd;
      if (nativeAd == null) {
        GoogleMediationAdapter.this.e("Failed to register native ad views: native ad is null.");
        return false;
      } 
      GoogleMediationAdapter.access$1702(GoogleMediationAdapter.this, new NativeAdView(param1ViewGroup.getContext()));
      if (param1ViewGroup instanceof MaxNativeAdView) {
        MaxNativeAdView maxNativeAdView = (MaxNativeAdView)param1ViewGroup;
        view2 = maxNativeAdView.getMainView();
        maxNativeAdView.removeView(view2);
        GoogleMediationAdapter.this.nativeAdView.addView(view2);
        maxNativeAdView.addView((View)GoogleMediationAdapter.this.nativeAdView);
        GoogleMediationAdapter.this.nativeAdView.setIconView((View)maxNativeAdView.getIconImageView());
        GoogleMediationAdapter.this.nativeAdView.setHeadlineView((View)maxNativeAdView.getTitleTextView());
        GoogleMediationAdapter.this.nativeAdView.setAdvertiserView((View)maxNativeAdView.getAdvertiserTextView());
        GoogleMediationAdapter.this.nativeAdView.setBodyView((View)maxNativeAdView.getBodyTextView());
        GoogleMediationAdapter.this.nativeAdView.setCallToActionView((View)maxNativeAdView.getCallToActionButton());
        view1 = getMediaView();
        if (view1 instanceof MediaView) {
          GoogleMediationAdapter.this.nativeAdView.setMediaView((MediaView)view1);
        } else if (view1 instanceof android.widget.ImageView) {
          GoogleMediationAdapter.this.nativeAdView.setImageView(view1);
        } 
        GoogleMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
        return true;
      } 
      for (View view : view1) {
        Object object = view.getTag();
        if (object == null)
          continue; 
        int i = ((Integer)object).intValue();
        if (i == 1) {
          GoogleMediationAdapter.this.nativeAdView.setHeadlineView(view);
          continue;
        } 
        if (i == 3) {
          GoogleMediationAdapter.this.nativeAdView.setIconView(view);
          continue;
        } 
        if (i == 4) {
          GoogleMediationAdapter.this.nativeAdView.setBodyView(view);
          continue;
        } 
        if (i == 5) {
          GoogleMediationAdapter.this.nativeAdView.setCallToActionView(view);
          continue;
        } 
        if (i == 8)
          GoogleMediationAdapter.this.nativeAdView.setAdvertiserView(view); 
      } 
      View view3 = getMediaView();
      if (view3 != null) {
        ViewGroup viewGroup = (ViewGroup)view3.getParent();
      } else {
        view1 = null;
      } 
      if (view1 != null && view2.findViewById(view1.getId()) != null) {
        view1.removeView(view3);
        GoogleMediationAdapter.this.nativeAdView.addView(view3);
        view1.addView((View)GoogleMediationAdapter.this.nativeAdView);
        if (view3 instanceof MediaView) {
          GoogleMediationAdapter.this.nativeAdView.setMediaView((MediaView)view3);
        } else if (view3 instanceof android.widget.ImageView) {
          GoogleMediationAdapter.this.nativeAdView.setImageView(view3);
        } 
        GoogleMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
        GoogleMediationAdapter.this.nativeAdView.measure(View.MeasureSpec.makeMeasureSpec(view1.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(view1.getHeight(), 1073741824));
        GoogleMediationAdapter.this.nativeAdView.layout(0, 0, view1.getWidth(), view1.getHeight());
      } 
      return true;
    }
    
    public void prepareViewForInteraction(MaxNativeAdView param1MaxNativeAdView) {
      prepareForInteraction(Collections.emptyList(), (ViewGroup)param1MaxNativeAdView);
    }
  }
  
  private class NativeAdListener extends AdListener implements NativeAd.OnNativeAdLoadedListener {
    final Context context;
    
    final MaxNativeAdAdapterListener listener;
    
    final String placementId;
    
    final Bundle serverParameters;
    
    public NativeAdListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, Context param1Context, MaxNativeAdAdapterListener param1MaxNativeAdAdapterListener) {
      this.placementId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.context = param1Context;
      this.listener = param1MaxNativeAdAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter.this.log("Native ad clicked");
      this.listener.onNativeAdClicked();
    }
    
    public void onAdClosed() {
      GoogleMediationAdapter.this.log("Native ad closed");
    }
    
    public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onNativeAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter.this.log("Native ad shown");
      this.listener.onNativeAdDisplayed(null);
    }
    
    public void onAdOpened() {
      GoogleMediationAdapter.this.log("Native ad opened");
    }
    
    public void onNativeAdLoaded(final NativeAd nativeAd) {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ad loaded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      GoogleMediationAdapter.access$1502(GoogleMediationAdapter.this, nativeAd);
      if (AppLovinSdkUtils.isValidString(BundleUtils.getString("template", "", this.serverParameters)) && TextUtils.isEmpty(nativeAd.getHeadline())) {
        googleMediationAdapter = GoogleMediationAdapter.this;
        stringBuilder = new StringBuilder("Native ad (");
        stringBuilder.append(nativeAd);
        stringBuilder.append(") does not have required assets.");
        googleMediationAdapter.e(stringBuilder.toString());
        this.listener.onNativeAdLoadFailed(new MaxAdapterError(-5400, "Missing Native Ad Assets"));
        return;
      } 
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              // Byte code:
              //   0: aload_0
              //   1: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   4: invokevirtual getMediaContent : ()Lcom/google/android/gms/ads/MediaContent;
              //   7: astore #4
              //   9: aload_0
              //   10: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   13: invokevirtual getImages : ()Ljava/util/List;
              //   16: astore_2
              //   17: aconst_null
              //   18: astore #5
              //   20: aload #4
              //   22: ifnull -> 65
              //   25: new com/google/android/gms/ads/nativead/MediaView
              //   28: dup
              //   29: aload_0
              //   30: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
              //   33: getfield context : Landroid/content/Context;
              //   36: invokespecial <init> : (Landroid/content/Context;)V
              //   39: astore_2
              //   40: aload_2
              //   41: aload #4
              //   43: invokevirtual setMediaContent : (Lcom/google/android/gms/ads/MediaContent;)V
              //   46: aload #4
              //   48: invokeinterface getMainImage : ()Landroid/graphics/drawable/Drawable;
              //   53: astore_3
              //   54: aload #4
              //   56: invokeinterface getAspectRatio : ()F
              //   61: fstore_1
              //   62: goto -> 141
              //   65: aload_2
              //   66: ifnull -> 135
              //   69: aload_2
              //   70: invokeinterface size : ()I
              //   75: ifle -> 135
              //   78: aload_2
              //   79: iconst_0
              //   80: invokeinterface get : (I)Ljava/lang/Object;
              //   85: checkcast com/google/android/gms/ads/nativead/NativeAd$Image
              //   88: astore_3
              //   89: new android/widget/ImageView
              //   92: dup
              //   93: aload_0
              //   94: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
              //   97: getfield context : Landroid/content/Context;
              //   100: invokespecial <init> : (Landroid/content/Context;)V
              //   103: astore_2
              //   104: aload_3
              //   105: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   108: astore_3
              //   109: aload_3
              //   110: ifnull -> 135
              //   113: aload_2
              //   114: aload_3
              //   115: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
              //   118: aload_3
              //   119: invokevirtual getIntrinsicWidth : ()I
              //   122: i2f
              //   123: aload_3
              //   124: invokevirtual getIntrinsicHeight : ()I
              //   127: i2f
              //   128: fdiv
              //   129: fstore_1
              //   130: aconst_null
              //   131: astore_3
              //   132: goto -> 141
              //   135: fconst_0
              //   136: fstore_1
              //   137: aconst_null
              //   138: astore_2
              //   139: aload_2
              //   140: astore_3
              //   141: aload_0
              //   142: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   145: invokevirtual getIcon : ()Lcom/google/android/gms/ads/nativead/NativeAd$Image;
              //   148: astore #4
              //   150: aload #4
              //   152: ifnull -> 197
              //   155: aload #4
              //   157: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   160: ifnull -> 180
              //   163: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   166: dup
              //   167: aload #4
              //   169: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
              //   172: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
              //   175: astore #4
              //   177: goto -> 200
              //   180: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   183: dup
              //   184: aload #4
              //   186: invokevirtual getUri : ()Landroid/net/Uri;
              //   189: invokespecial <init> : (Landroid/net/Uri;)V
              //   192: astore #4
              //   194: goto -> 200
              //   197: aconst_null
              //   198: astore #4
              //   200: new com/applovin/mediation/nativeAds/MaxNativeAd$Builder
              //   203: dup
              //   204: invokespecial <init> : ()V
              //   207: getstatic com/applovin/mediation/MaxAdFormat.NATIVE : Lcom/applovin/mediation/MaxAdFormat;
              //   210: invokevirtual setAdFormat : (Lcom/applovin/mediation/MaxAdFormat;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   213: aload_0
              //   214: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   217: invokevirtual getHeadline : ()Ljava/lang/String;
              //   220: invokevirtual setTitle : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   223: aload_0
              //   224: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   227: invokevirtual getAdvertiser : ()Ljava/lang/String;
              //   230: invokevirtual setAdvertiser : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   233: aload_0
              //   234: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   237: invokevirtual getBody : ()Ljava/lang/String;
              //   240: invokevirtual setBody : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   243: aload_0
              //   244: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   247: invokevirtual getCallToAction : ()Ljava/lang/String;
              //   250: invokevirtual setCallToAction : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   253: aload #4
              //   255: invokevirtual setIcon : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   258: aload_2
              //   259: invokevirtual setMediaView : (Landroid/view/View;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   262: astore_2
              //   263: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
              //   266: ldc 11040399
              //   268: if_icmplt -> 284
              //   271: aload_2
              //   272: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
              //   275: dup
              //   276: aload_3
              //   277: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
              //   280: invokevirtual setMainImage : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   283: pop
              //   284: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
              //   287: ldc 11040000
              //   289: if_icmplt -> 298
              //   292: aload_2
              //   293: fload_1
              //   294: invokevirtual setMediaContentAspectRatio : (F)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   297: pop
              //   298: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
              //   301: ldc 11070000
              //   303: if_icmplt -> 318
              //   306: aload_2
              //   307: aload_0
              //   308: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   311: invokevirtual getStarRating : ()Ljava/lang/Double;
              //   314: invokevirtual setStarRating : (Ljava/lang/Double;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
              //   317: pop
              //   318: new com/applovin/mediation/adapters/GoogleMediationAdapter$MaxGoogleNativeAd
              //   321: dup
              //   322: aload_0
              //   323: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
              //   326: getfield this$0 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter;
              //   329: aload_2
              //   330: invokespecial <init> : (Lcom/applovin/mediation/adapters/GoogleMediationAdapter;Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;)V
              //   333: astore_3
              //   334: aload_0
              //   335: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
              //   338: invokevirtual getResponseInfo : ()Lcom/google/android/gms/ads/ResponseInfo;
              //   341: astore #4
              //   343: aload #5
              //   345: astore_2
              //   346: aload #4
              //   348: ifnull -> 357
              //   351: aload #4
              //   353: invokevirtual getResponseId : ()Ljava/lang/String;
              //   356: astore_2
              //   357: new android/os/Bundle
              //   360: dup
              //   361: iconst_1
              //   362: invokespecial <init> : (I)V
              //   365: astore #4
              //   367: aload #4
              //   369: ldc 'creative_id'
              //   371: aload_2
              //   372: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
              //   375: aload_0
              //   376: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
              //   379: getfield listener : Lcom/applovin/mediation/adapter/listeners/MaxNativeAdAdapterListener;
              //   382: aload_3
              //   383: aload #4
              //   385: invokeinterface onNativeAdLoaded : (Lcom/applovin/mediation/nativeAds/MaxNativeAd;Landroid/os/Bundle;)V
              //   390: return
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   4: invokevirtual getMediaContent : ()Lcom/google/android/gms/ads/MediaContent;
      //   7: astore #4
      //   9: aload_0
      //   10: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   13: invokevirtual getImages : ()Ljava/util/List;
      //   16: astore_2
      //   17: aconst_null
      //   18: astore #5
      //   20: aload #4
      //   22: ifnull -> 65
      //   25: new com/google/android/gms/ads/nativead/MediaView
      //   28: dup
      //   29: aload_0
      //   30: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
      //   33: getfield context : Landroid/content/Context;
      //   36: invokespecial <init> : (Landroid/content/Context;)V
      //   39: astore_2
      //   40: aload_2
      //   41: aload #4
      //   43: invokevirtual setMediaContent : (Lcom/google/android/gms/ads/MediaContent;)V
      //   46: aload #4
      //   48: invokeinterface getMainImage : ()Landroid/graphics/drawable/Drawable;
      //   53: astore_3
      //   54: aload #4
      //   56: invokeinterface getAspectRatio : ()F
      //   61: fstore_1
      //   62: goto -> 141
      //   65: aload_2
      //   66: ifnull -> 135
      //   69: aload_2
      //   70: invokeinterface size : ()I
      //   75: ifle -> 135
      //   78: aload_2
      //   79: iconst_0
      //   80: invokeinterface get : (I)Ljava/lang/Object;
      //   85: checkcast com/google/android/gms/ads/nativead/NativeAd$Image
      //   88: astore_3
      //   89: new android/widget/ImageView
      //   92: dup
      //   93: aload_0
      //   94: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
      //   97: getfield context : Landroid/content/Context;
      //   100: invokespecial <init> : (Landroid/content/Context;)V
      //   103: astore_2
      //   104: aload_3
      //   105: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   108: astore_3
      //   109: aload_3
      //   110: ifnull -> 135
      //   113: aload_2
      //   114: aload_3
      //   115: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
      //   118: aload_3
      //   119: invokevirtual getIntrinsicWidth : ()I
      //   122: i2f
      //   123: aload_3
      //   124: invokevirtual getIntrinsicHeight : ()I
      //   127: i2f
      //   128: fdiv
      //   129: fstore_1
      //   130: aconst_null
      //   131: astore_3
      //   132: goto -> 141
      //   135: fconst_0
      //   136: fstore_1
      //   137: aconst_null
      //   138: astore_2
      //   139: aload_2
      //   140: astore_3
      //   141: aload_0
      //   142: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   145: invokevirtual getIcon : ()Lcom/google/android/gms/ads/nativead/NativeAd$Image;
      //   148: astore #4
      //   150: aload #4
      //   152: ifnull -> 197
      //   155: aload #4
      //   157: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   160: ifnull -> 180
      //   163: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   166: dup
      //   167: aload #4
      //   169: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
      //   172: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
      //   175: astore #4
      //   177: goto -> 200
      //   180: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   183: dup
      //   184: aload #4
      //   186: invokevirtual getUri : ()Landroid/net/Uri;
      //   189: invokespecial <init> : (Landroid/net/Uri;)V
      //   192: astore #4
      //   194: goto -> 200
      //   197: aconst_null
      //   198: astore #4
      //   200: new com/applovin/mediation/nativeAds/MaxNativeAd$Builder
      //   203: dup
      //   204: invokespecial <init> : ()V
      //   207: getstatic com/applovin/mediation/MaxAdFormat.NATIVE : Lcom/applovin/mediation/MaxAdFormat;
      //   210: invokevirtual setAdFormat : (Lcom/applovin/mediation/MaxAdFormat;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   213: aload_0
      //   214: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   217: invokevirtual getHeadline : ()Ljava/lang/String;
      //   220: invokevirtual setTitle : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   223: aload_0
      //   224: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   227: invokevirtual getAdvertiser : ()Ljava/lang/String;
      //   230: invokevirtual setAdvertiser : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   233: aload_0
      //   234: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   237: invokevirtual getBody : ()Ljava/lang/String;
      //   240: invokevirtual setBody : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   243: aload_0
      //   244: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   247: invokevirtual getCallToAction : ()Ljava/lang/String;
      //   250: invokevirtual setCallToAction : (Ljava/lang/String;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   253: aload #4
      //   255: invokevirtual setIcon : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   258: aload_2
      //   259: invokevirtual setMediaView : (Landroid/view/View;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   262: astore_2
      //   263: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
      //   266: ldc 11040399
      //   268: if_icmplt -> 284
      //   271: aload_2
      //   272: new com/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage
      //   275: dup
      //   276: aload_3
      //   277: invokespecial <init> : (Landroid/graphics/drawable/Drawable;)V
      //   280: invokevirtual setMainImage : (Lcom/applovin/mediation/nativeAds/MaxNativeAd$MaxNativeAdImage;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   283: pop
      //   284: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
      //   287: ldc 11040000
      //   289: if_icmplt -> 298
      //   292: aload_2
      //   293: fload_1
      //   294: invokevirtual setMediaContentAspectRatio : (F)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   297: pop
      //   298: getstatic com/applovin/sdk/AppLovinSdk.VERSION_CODE : I
      //   301: ldc 11070000
      //   303: if_icmplt -> 318
      //   306: aload_2
      //   307: aload_0
      //   308: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   311: invokevirtual getStarRating : ()Ljava/lang/Double;
      //   314: invokevirtual setStarRating : (Ljava/lang/Double;)Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;
      //   317: pop
      //   318: new com/applovin/mediation/adapters/GoogleMediationAdapter$MaxGoogleNativeAd
      //   321: dup
      //   322: aload_0
      //   323: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
      //   326: getfield this$0 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter;
      //   329: aload_2
      //   330: invokespecial <init> : (Lcom/applovin/mediation/adapters/GoogleMediationAdapter;Lcom/applovin/mediation/nativeAds/MaxNativeAd$Builder;)V
      //   333: astore_3
      //   334: aload_0
      //   335: getfield val$nativeAd : Lcom/google/android/gms/ads/nativead/NativeAd;
      //   338: invokevirtual getResponseInfo : ()Lcom/google/android/gms/ads/ResponseInfo;
      //   341: astore #4
      //   343: aload #5
      //   345: astore_2
      //   346: aload #4
      //   348: ifnull -> 357
      //   351: aload #4
      //   353: invokevirtual getResponseId : ()Ljava/lang/String;
      //   356: astore_2
      //   357: new android/os/Bundle
      //   360: dup
      //   361: iconst_1
      //   362: invokespecial <init> : (I)V
      //   365: astore #4
      //   367: aload #4
      //   369: ldc 'creative_id'
      //   371: aload_2
      //   372: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   375: aload_0
      //   376: getfield this$1 : Lcom/applovin/mediation/adapters/GoogleMediationAdapter$NativeAdListener;
      //   379: getfield listener : Lcom/applovin/mediation/adapter/listeners/MaxNativeAdAdapterListener;
      //   382: aload_3
      //   383: aload #4
      //   385: invokeinterface onNativeAdLoaded : (Lcom/applovin/mediation/nativeAds/MaxNativeAd;Landroid/os/Bundle;)V
      //   390: return
    }
  }
  
  private class NativeAdViewListener extends AdListener implements NativeAd.OnNativeAdLoadedListener {
    final WeakReference<Activity> activityRef;
    
    final MaxAdFormat adFormat;
    
    final MaxAdViewAdapterListener listener;
    
    final String placementId;
    
    final Bundle serverParameters;
    
    NativeAdViewListener(MaxAdapterResponseParameters param1MaxAdapterResponseParameters, MaxAdFormat param1MaxAdFormat, Activity param1Activity, MaxAdViewAdapterListener param1MaxAdViewAdapterListener) {
      this.placementId = param1MaxAdapterResponseParameters.getThirdPartyAdPlacementId();
      this.serverParameters = param1MaxAdapterResponseParameters.getServerParameters();
      this.activityRef = new WeakReference<Activity>(param1Activity);
      this.adFormat = param1MaxAdFormat;
      this.listener = param1MaxAdViewAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad clicked");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdClicked();
    }
    
    public void onAdClosed() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad closed");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdCollapsed();
    }
    
    public void onAdFailedToLoad(LoadAdError param1LoadAdError) {
      MaxAdapterError maxAdapterError = GoogleMediationAdapter.toMaxError((AdError)param1LoadAdError);
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to load with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdLoadFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad shown");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdDisplayed();
    }
    
    public void onAdOpened() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad opened");
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onAdViewAdExpanded();
    }
    
    public void onNativeAdLoaded(final NativeAd nativeAd) {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Native ");
      stringBuilder.append(this.adFormat.getLabel());
      stringBuilder.append(" ad loaded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      if (TextUtils.isEmpty(nativeAd.getHeadline())) {
        googleMediationAdapter = GoogleMediationAdapter.this;
        stringBuilder = new StringBuilder("Native ");
        stringBuilder.append(this.adFormat.getLabel());
        stringBuilder.append(" ad failed to load: Google native ad is missing one or more required assets");
        googleMediationAdapter.log(stringBuilder.toString());
        this.listener.onAdViewAdLoadFailed(MaxAdapterError.INVALID_CONFIGURATION);
        nativeAd.destroy();
        return;
      } 
      GoogleMediationAdapter.access$1502(GoogleMediationAdapter.this, nativeAd);
      final Activity activity = this.activityRef.get();
      final Context context = GoogleMediationAdapter.this.getContext(activity);
      final MediaView mediaView = new MediaView(context);
      MediaContent mediaContent = nativeAd.getMediaContent();
      if (mediaContent != null)
        mediaView.setMediaContent(mediaContent); 
      NativeAd.Image image = nativeAd.getIcon();
      if (image != null) {
        MaxNativeAd.MaxNativeAdImage maxNativeAdImage;
        if (image.getDrawable() != null) {
          maxNativeAdImage = new MaxNativeAd.MaxNativeAdImage(image.getDrawable());
        } else {
          maxNativeAdImage = new MaxNativeAd.MaxNativeAdImage(maxNativeAdImage.getUri());
        } 
      } else {
        image = null;
      } 
      final MaxNativeAd maxNativeAd = (new MaxNativeAd.Builder()).setAdFormat(this.adFormat).setTitle(nativeAd.getHeadline()).setBody(nativeAd.getBody()).setCallToAction(nativeAd.getCallToAction()).setIcon((MaxNativeAd.MaxNativeAdImage)image).setMediaView((View)mediaView).build();
      final String templateName = BundleUtils.getString("template", "", this.serverParameters);
      if (str.contains("vertical") && AppLovinSdk.VERSION_CODE < 9140500)
        GoogleMediationAdapter.this.log("Vertical native banners are only supported on MAX SDK 9.14.5 and above. Default horizontal native template will be used."); 
      AppLovinSdkUtils.runOnUiThread(new Runnable() {
            public void run() {
              MaxNativeAdView maxNativeAdView;
              if (AppLovinSdk.VERSION_CODE >= 11010000) {
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, context);
              } else {
                maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, activity);
              } 
              GoogleMediationAdapter.access$1702(GoogleMediationAdapter.this, new NativeAdView(context));
              GoogleMediationAdapter.this.nativeAdView.setIconView((View)maxNativeAdView.getIconContentView());
              GoogleMediationAdapter.this.nativeAdView.setHeadlineView((View)maxNativeAdView.getTitleTextView());
              GoogleMediationAdapter.this.nativeAdView.setBodyView((View)maxNativeAdView.getBodyTextView());
              GoogleMediationAdapter.this.nativeAdView.setMediaView(mediaView);
              GoogleMediationAdapter.this.nativeAdView.setCallToActionView((View)maxNativeAdView.getCallToActionButton());
              GoogleMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
              GoogleMediationAdapter.this.nativeAdView.addView((View)maxNativeAdView);
              ResponseInfo responseInfo = nativeAd.getResponseInfo();
              if (responseInfo != null) {
                String str = responseInfo.getResponseId();
              } else {
                responseInfo = null;
              } 
              if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
                Bundle bundle = new Bundle(1);
                bundle.putString("creative_id", (String)responseInfo);
                GoogleMediationAdapter.NativeAdViewListener.this.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.nativeAdView, bundle);
                return;
              } 
              GoogleMediationAdapter.NativeAdViewListener.this.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.nativeAdView);
            }
          });
    }
  }
  
  class null implements Runnable {
    public void run() {
      MaxNativeAdView maxNativeAdView;
      if (AppLovinSdk.VERSION_CODE >= 11010000) {
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, context);
      } else {
        maxNativeAdView = new MaxNativeAdView(maxNativeAd, templateName, activity);
      } 
      GoogleMediationAdapter.access$1702(GoogleMediationAdapter.this, new NativeAdView(context));
      GoogleMediationAdapter.this.nativeAdView.setIconView((View)maxNativeAdView.getIconContentView());
      GoogleMediationAdapter.this.nativeAdView.setHeadlineView((View)maxNativeAdView.getTitleTextView());
      GoogleMediationAdapter.this.nativeAdView.setBodyView((View)maxNativeAdView.getBodyTextView());
      GoogleMediationAdapter.this.nativeAdView.setMediaView(mediaView);
      GoogleMediationAdapter.this.nativeAdView.setCallToActionView((View)maxNativeAdView.getCallToActionButton());
      GoogleMediationAdapter.this.nativeAdView.setNativeAd(nativeAd);
      GoogleMediationAdapter.this.nativeAdView.addView((View)maxNativeAdView);
      ResponseInfo responseInfo = nativeAd.getResponseInfo();
      if (responseInfo != null) {
        String str = responseInfo.getResponseId();
      } else {
        responseInfo = null;
      } 
      if (AppLovinSdk.VERSION_CODE >= 9150000 && AppLovinSdkUtils.isValidString((String)responseInfo)) {
        Bundle bundle = new Bundle(1);
        bundle.putString("creative_id", (String)responseInfo);
        this.this$1.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.nativeAdView, bundle);
        return;
      } 
      this.this$1.listener.onAdViewAdLoaded((View)GoogleMediationAdapter.this.nativeAdView);
    }
  }
  
  private class RewardedAdListener extends FullScreenContentCallback {
    private boolean hasGrantedReward;
    
    private final MaxRewardedAdapterListener listener;
    
    private final String placementId;
    
    RewardedAdListener(String param1String, MaxRewardedAdapterListener param1MaxRewardedAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxRewardedAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad clicked: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      this.listener.onRewardedAdVideoCompleted();
      if (this.hasGrantedReward || GoogleMediationAdapter.this.shouldAlwaysRewardUser()) {
        MaxReward maxReward = GoogleMediationAdapter.this.getReward();
        GoogleMediationAdapter googleMediationAdapter1 = GoogleMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder("Rewarded user with reward: ");
        stringBuilder1.append(maxReward);
        googleMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad hidden: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedAdVideoStarted();
    }
  }
  
  private class RewardedInterstitialAdListener extends FullScreenContentCallback {
    private boolean hasGrantedReward;
    
    private final MaxRewardedInterstitialAdapterListener listener;
    
    private final String placementId;
    
    private RewardedInterstitialAdListener(String param1String, MaxRewardedInterstitialAdapterListener param1MaxRewardedInterstitialAdapterListener) {
      this.placementId = param1String;
      this.listener = param1MaxRewardedInterstitialAdapterListener;
    }
    
    public void onAdClicked() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded interstitial ad clicked: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdClicked();
    }
    
    public void onAdDismissedFullScreenContent() {
      this.listener.onRewardedInterstitialAdVideoCompleted();
      if (this.hasGrantedReward || GoogleMediationAdapter.this.shouldAlwaysRewardUser()) {
        MaxReward maxReward = GoogleMediationAdapter.this.getReward();
        GoogleMediationAdapter googleMediationAdapter1 = GoogleMediationAdapter.this;
        StringBuilder stringBuilder1 = new StringBuilder("Rewarded interstitial ad rewarded user with reward: ");
        stringBuilder1.append(maxReward);
        googleMediationAdapter1.log(stringBuilder1.toString());
        this.listener.onUserRewarded(maxReward);
      } 
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded interstitial ad hidden: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdHidden();
    }
    
    public void onAdFailedToShowFullScreenContent(AdError param1AdError) {
      MaxAdapterError maxAdapterError = new MaxAdapterError(-4205, "Ad Display Failed", param1AdError.getCode(), param1AdError.getMessage());
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded interstitial ad (");
      stringBuilder.append(this.placementId);
      stringBuilder.append(") failed to show with error: ");
      stringBuilder.append(maxAdapterError);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdDisplayFailed(maxAdapterError);
    }
    
    public void onAdImpression() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded interstitial ad impression recorded: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdDisplayed();
    }
    
    public void onAdShowedFullScreenContent() {
      GoogleMediationAdapter googleMediationAdapter = GoogleMediationAdapter.this;
      StringBuilder stringBuilder = new StringBuilder("Rewarded interstitial ad shown: ");
      stringBuilder.append(this.placementId);
      googleMediationAdapter.log(stringBuilder.toString());
      this.listener.onRewardedInterstitialAdVideoStarted();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\mediation\adapters\GoogleMediationAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */