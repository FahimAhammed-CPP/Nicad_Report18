package com.facebook.ads.internal.api;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;

public abstract class AdNativeComponentView extends RelativeLayout implements AdComponentView {
  protected AdComponentViewApi mAdComponentViewApi;
  
  private final AdComponentViewParentApi mAdComponentViewParentApi = new AdComponentViewParentApi() {
      public void addView(View param1View) {
        AdNativeComponentView.this.addView(param1View);
      }
      
      public void addView(View param1View, int param1Int) {
        AdNativeComponentView.this.addView(param1View, param1Int);
      }
      
      public void addView(View param1View, int param1Int1, int param1Int2) {
        AdNativeComponentView.this.addView(param1View, param1Int1, param1Int2);
      }
      
      public void addView(View param1View, int param1Int, ViewGroup.LayoutParams param1LayoutParams) {
        AdNativeComponentView.this.addView(param1View, param1Int, param1LayoutParams);
      }
      
      public void addView(View param1View, ViewGroup.LayoutParams param1LayoutParams) {
        AdNativeComponentView.this.addView(param1View, param1LayoutParams);
      }
      
      public void bringChildToFront(View param1View) {
        AdNativeComponentView.this.bringChildToFront(param1View);
      }
      
      public void onAttachedToWindow() {
        AdNativeComponentView.this.onAttachedToWindow();
      }
      
      public void onDetachedFromWindow() {
        AdNativeComponentView.this.onDetachedFromWindow();
      }
      
      public void onMeasure(int param1Int1, int param1Int2) {
        AdNativeComponentView.this.onMeasure(param1Int1, param1Int2);
      }
      
      public void onVisibilityChanged(View param1View, int param1Int) {
        AdNativeComponentView.this.onVisibilityChanged(param1View, param1Int);
      }
      
      public void onWindowFocusChanged(boolean param1Boolean) {
        AdNativeComponentView.this.onWindowFocusChanged(param1Boolean);
      }
      
      public void setLayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
        AdNativeComponentView.this.setLayoutParams(param1LayoutParams);
      }
      
      public void setMeasuredDimension(int param1Int1, int param1Int2) {
        AdNativeComponentView.this.setMeasuredDimension(param1Int1, param1Int2);
      }
    };
  
  public AdNativeComponentView(Context paramContext) {
    super(paramContext);
  }
  
  public AdNativeComponentView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public AdNativeComponentView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public AdNativeComponentView(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void addView(View paramView) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView);
      return;
    } 
    super.addView(paramView);
  }
  
  public void addView(View paramView, int paramInt) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView, paramInt);
      return;
    } 
    super.addView(paramView, paramInt);
  }
  
  public void addView(View paramView, int paramInt1, int paramInt2) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView, paramInt1, paramInt2);
      return;
    } 
    super.addView(paramView, paramInt1, paramInt2);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.addView(paramView, paramLayoutParams);
      return;
    } 
    super.addView(paramView, paramLayoutParams);
  }
  
  protected void attachAdComponentViewApi(AdComponentViewApiProvider paramAdComponentViewApiProvider) {
    if (DynamicLoaderFactory.isFallbackMode())
      return; 
    if (this.mAdComponentViewApi == null) {
      paramAdComponentViewApiProvider.getAdComponentViewApi().onAttachedToView(this, this.mAdComponentViewParentApi);
      this.mAdComponentViewApi = paramAdComponentViewApiProvider.getAdComponentViewApi();
      return;
    } 
    throw new IllegalStateException("AdComponentViewApi can't be attached more then once.");
  }
  
  public void bringChildToFront(View paramView) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.bringChildToFront(paramView);
      return;
    } 
    super.bringChildToFront(paramView);
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.viewOnTouch("com.facebook.ads", (View)this, paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  public abstract View getAdContentsView();
  
  protected void onAttachedToWindow() {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onAttachedToWindow();
      return;
    } 
    super.onAttachedToWindow();
  }
  
  protected void onDetachedFromWindow() {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onDetachedFromWindow();
      return;
    } 
    super.onDetachedFromWindow();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onMeasure(paramInt1, paramInt2);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onVisibilityChanged(View paramView, int paramInt) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onVisibilityChanged(paramView, paramInt);
      return;
    } 
    super.onVisibilityChanged(paramView, paramInt);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.onWindowFocusChanged(paramBoolean);
      return;
    } 
    super.onWindowFocusChanged(paramBoolean);
  }
  
  public void setLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    AdComponentViewApi adComponentViewApi = this.mAdComponentViewApi;
    if (adComponentViewApi != null) {
      adComponentViewApi.setLayoutParams(paramLayoutParams);
      return;
    } 
    super.setLayoutParams(paramLayoutParams);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\ads\internal\api\AdNativeComponentView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */