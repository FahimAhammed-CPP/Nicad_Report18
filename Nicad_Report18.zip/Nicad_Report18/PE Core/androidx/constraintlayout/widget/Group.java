package androidx.constraintlayout.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewParent;
import y.첩;
import y.체;

public class Group extends 첩 {
  public Group(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      暑((ConstraintLayout)viewParent); 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      暑((ConstraintLayout)viewParent); 
  }
  
  public void setVisibility(int paramInt) {
    super.setVisibility(paramInt);
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      暑((ConstraintLayout)viewParent); 
  }
  
  public final void 不() {
    체 체 = (체)getLayoutParams();
    체.퉁.か(0);
    체.퉁.触(0);
  }
  
  public final void 冷(ConstraintLayout paramConstraintLayout) {
    暑(paramConstraintLayout);
  }
  
  public final void 美(AttributeSet paramAttributeSet) {
    super.美(paramAttributeSet);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\constraintlayout\widget\Group.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */