package androidx.lifecycle;

import y.尻;
import y.肉;
import y.腰;

final class RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1 implements 肉 {
  public final void 暑(腰 param腰, 尻 param尻) {
    if (param尻 != 尻.ON_DESTROY)
      return; 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */