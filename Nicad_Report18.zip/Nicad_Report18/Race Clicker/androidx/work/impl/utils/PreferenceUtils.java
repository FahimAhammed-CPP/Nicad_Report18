package androidx.work.impl.utils;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.model.Preference;

public class PreferenceUtils {
  public static final String KEY_LAST_CANCEL_ALL_TIME_MS = "last_cancel_all_time_ms";
  
  public static final String KEY_RESCHEDULE_NEEDED = "reschedule_needed";
  
  public static final String PREFERENCES_FILE_NAME = "androidx.work.util.preferences";
  
  private final WorkDatabase mWorkDatabase;
  
  public PreferenceUtils(WorkDatabase paramWorkDatabase) {
    this.mWorkDatabase = paramWorkDatabase;
  }
  
  public static void migrateLegacyPreferences(Context paramContext, SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    SharedPreferences sharedPreferences = paramContext.getSharedPreferences("androidx.work.util.preferences", 0);
    if (sharedPreferences.contains("reschedule_needed") || sharedPreferences.contains("last_cancel_all_time_ms")) {
      long l1 = 0L;
      long l2 = sharedPreferences.getLong("last_cancel_all_time_ms", 0L);
      if (sharedPreferences.getBoolean("reschedule_needed", false))
        l1 = 1L; 
      paramSupportSQLiteDatabase.beginTransaction();
      try {
        paramSupportSQLiteDatabase.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "last_cancel_all_time_ms", Long.valueOf(l2) });
        paramSupportSQLiteDatabase.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[] { "reschedule_needed", Long.valueOf(l1) });
        sharedPreferences.edit().clear().apply();
        paramSupportSQLiteDatabase.setTransactionSuccessful();
        return;
      } finally {
        paramSupportSQLiteDatabase.endTransaction();
      } 
    } 
  }
  
  public long getLastCancelAllTimeMillis() {
    Long long_ = this.mWorkDatabase.preferenceDao().getLongValue("last_cancel_all_time_ms");
    return (long_ != null) ? long_.longValue() : 0L;
  }
  
  public LiveData<Long> getLastCancelAllTimeMillisLiveData() {
    return Transformations.map(this.mWorkDatabase.preferenceDao().getObservableLongValue("last_cancel_all_time_ms"), new Function<Long, Long>() {
          public Long apply(Long param1Long) {
            long l;
            if (param1Long != null) {
              l = param1Long.longValue();
            } else {
              l = 0L;
            } 
            return Long.valueOf(l);
          }
        });
  }
  
  public boolean getNeedsReschedule() {
    Long long_ = this.mWorkDatabase.preferenceDao().getLongValue("reschedule_needed");
    return (long_ != null && long_.longValue() == 1L);
  }
  
  public void setLastCancelAllTimeMillis(long paramLong) {
    Preference preference = new Preference("last_cancel_all_time_ms", paramLong);
    this.mWorkDatabase.preferenceDao().insertPreference(preference);
  }
  
  public void setNeedsReschedule(boolean paramBoolean) {
    Preference preference = new Preference("reschedule_needed", paramBoolean);
    this.mWorkDatabase.preferenceDao().insertPreference(preference);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\work\imp\\utils\PreferenceUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */