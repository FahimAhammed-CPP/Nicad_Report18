package com.applovin.exoplayer2.e;

public interface v {
  a a(long paramLong);
  
  boolean a();
  
  long b();
  
  public static final class a {
    public final w a;
    
    public final w b;
    
    public a(w param1w) {
      this(param1w, param1w);
    }
    
    public a(w param1w1, w param1w2) {
      this.a = (w)com.applovin.exoplayer2.l.a.b(param1w1);
      this.b = (w)com.applovin.exoplayer2.l.a.b(param1w2);
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        return (this.a.equals(((a)param1Object).a) && this.b.equals(((a)param1Object).b));
      } 
      return false;
    }
    
    public int hashCode() {
      return this.a.hashCode() * 31 + this.b.hashCode();
    }
    
    public String toString() {
      String str;
      StringBuilder stringBuilder = new StringBuilder("[");
      stringBuilder.append(this.a);
      if (this.a.equals(this.b)) {
        str = "";
      } else {
        StringBuilder stringBuilder1 = new StringBuilder(", ");
        stringBuilder1.append(this.b);
        str = stringBuilder1.toString();
      } 
      stringBuilder.append(str);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  public static class b implements v {
    private final long a;
    
    private final v.a b;
    
    public b(long param1Long) {
      this(param1Long, 0L);
    }
    
    public b(long param1Long1, long param1Long2) {
      w w;
      this.a = param1Long1;
      if (param1Long2 == 0L) {
        w = w.a;
      } else {
        w = new w(0L, param1Long2);
      } 
      this.b = new v.a(w);
    }
    
    public v.a a(long param1Long) {
      return this.b;
    }
    
    public boolean a() {
      return false;
    }
    
    public long b() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\e\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */