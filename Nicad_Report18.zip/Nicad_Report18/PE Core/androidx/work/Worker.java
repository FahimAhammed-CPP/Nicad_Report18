package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import y.qk;
import y.姉;
import y.祖;
import y.정;

public abstract class Worker extends ListenableWorker {
  public qk 臭;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public abstract 祖 doWork();
  
  public final 姉 startWork() {
    this.臭 = new qk();
    getBackgroundExecutor().execute((Runnable)new 정(9, this));
    return (姉)this.臭;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */