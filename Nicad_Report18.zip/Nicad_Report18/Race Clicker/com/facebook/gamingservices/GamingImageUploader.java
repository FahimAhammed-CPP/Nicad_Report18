package com.facebook.gamingservices;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import java.io.File;
import java.io.FileNotFoundException;

public class GamingImageUploader {
  private static final String photoUploadEdge = "me/photos";
  
  private Context context;
  
  public GamingImageUploader(Context paramContext) {
    this.context = paramContext;
  }
  
  public void uploadToMediaLibrary(String paramString, Bitmap paramBitmap, boolean paramBoolean) {
    uploadToMediaLibrary(paramString, paramBitmap, paramBoolean, (GraphRequest.Callback)null);
  }
  
  public void uploadToMediaLibrary(String paramString, Bitmap paramBitmap, boolean paramBoolean, GraphRequest.Callback paramCallback) {
    OpenGamingMediaDialog openGamingMediaDialog;
    AccessToken accessToken = AccessToken.getCurrentAccessToken();
    if (paramBoolean)
      openGamingMediaDialog = new OpenGamingMediaDialog(this.context, paramCallback); 
    GraphRequest.newUploadPhotoRequest(accessToken, "me/photos", paramBitmap, paramString, null, (GraphRequest.Callback)openGamingMediaDialog).executeAsync();
  }
  
  public void uploadToMediaLibrary(String paramString, Uri paramUri, boolean paramBoolean) throws FileNotFoundException {
    uploadToMediaLibrary(paramString, paramUri, paramBoolean, (GraphRequest.Callback)null);
  }
  
  public void uploadToMediaLibrary(String paramString, Uri paramUri, boolean paramBoolean, GraphRequest.Callback paramCallback) throws FileNotFoundException {
    OpenGamingMediaDialog openGamingMediaDialog;
    AccessToken accessToken = AccessToken.getCurrentAccessToken();
    if (paramBoolean)
      openGamingMediaDialog = new OpenGamingMediaDialog(this.context, paramCallback); 
    GraphRequest.newUploadPhotoRequest(accessToken, "me/photos", paramUri, paramString, null, (GraphRequest.Callback)openGamingMediaDialog).executeAsync();
  }
  
  public void uploadToMediaLibrary(String paramString, File paramFile, boolean paramBoolean) throws FileNotFoundException {
    uploadToMediaLibrary(paramString, paramFile, paramBoolean, (GraphRequest.Callback)null);
  }
  
  public void uploadToMediaLibrary(String paramString, File paramFile, boolean paramBoolean, GraphRequest.Callback paramCallback) throws FileNotFoundException {
    OpenGamingMediaDialog openGamingMediaDialog;
    AccessToken accessToken = AccessToken.getCurrentAccessToken();
    if (paramBoolean)
      openGamingMediaDialog = new OpenGamingMediaDialog(this.context, paramCallback); 
    GraphRequest.newUploadPhotoRequest(accessToken, "me/photos", paramFile, paramString, null, (GraphRequest.Callback)openGamingMediaDialog).executeAsync();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\gamingservices\GamingImageUploader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */