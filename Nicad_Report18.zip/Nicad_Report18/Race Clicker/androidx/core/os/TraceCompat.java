package androidx.core.os;

import android.os.Build;
import android.os.Trace;
import android.util.Log;
import java.lang.reflect.Method;

@Deprecated
public final class TraceCompat {
  private static final String TAG = "TraceCompat";
  
  private static Method sAsyncTraceBeginMethod;
  
  private static Method sAsyncTraceEndMethod;
  
  private static Method sIsTagEnabledMethod;
  
  private static Method sTraceCounterMethod;
  
  private static long sTraceTagApp;
  
  static {
    if (Build.VERSION.SDK_INT < 29)
      try {
        sTraceTagApp = Trace.class.getField("TRACE_TAG_APP").getLong(null);
        sIsTagEnabledMethod = Trace.class.getMethod("isTagEnabled", new Class[] { long.class });
        sAsyncTraceBeginMethod = Trace.class.getMethod("asyncTraceBegin", new Class[] { long.class, String.class, int.class });
        sAsyncTraceEndMethod = Trace.class.getMethod("asyncTraceEnd", new Class[] { long.class, String.class, int.class });
        sTraceCounterMethod = Trace.class.getMethod("traceCounter", new Class[] { long.class, String.class, int.class });
        return;
      } catch (Exception exception) {
        Log.i("TraceCompat", "Unable to initialize via reflection.", exception);
      }  
  }
  
  public static void beginAsyncSection(String paramString, int paramInt) {
    if (Build.VERSION.SDK_INT >= 29) {
      Api29Impl.beginAsyncSection(paramString, paramInt);
      return;
    } 
    try {
      sAsyncTraceBeginMethod.invoke(null, new Object[] { Long.valueOf(sTraceTagApp), paramString, Integer.valueOf(paramInt) });
      return;
    } catch (Exception exception) {
      Log.v("TraceCompat", "Unable to invoke asyncTraceBegin() via reflection.");
      return;
    } 
  }
  
  public static void beginSection(String paramString) {
    Api18Impl.beginSection(paramString);
  }
  
  public static void endAsyncSection(String paramString, int paramInt) {
    if (Build.VERSION.SDK_INT >= 29) {
      Api29Impl.endAsyncSection(paramString, paramInt);
      return;
    } 
    try {
      sAsyncTraceEndMethod.invoke(null, new Object[] { Long.valueOf(sTraceTagApp), paramString, Integer.valueOf(paramInt) });
      return;
    } catch (Exception exception) {
      Log.v("TraceCompat", "Unable to invoke endAsyncSection() via reflection.");
      return;
    } 
  }
  
  public static void endSection() {
    Api18Impl.endSection();
  }
  
  public static boolean isEnabled() {
    if (Build.VERSION.SDK_INT >= 29)
      return Api29Impl.isEnabled(); 
    try {
      return ((Boolean)sIsTagEnabledMethod.invoke(null, new Object[] { Long.valueOf(sTraceTagApp) })).booleanValue();
    } catch (Exception exception) {
      Log.v("TraceCompat", "Unable to invoke isTagEnabled() via reflection.");
      return false;
    } 
  }
  
  public static void setCounter(String paramString, int paramInt) {
    if (Build.VERSION.SDK_INT >= 29) {
      Api29Impl.setCounter(paramString, paramInt);
      return;
    } 
    try {
      sTraceCounterMethod.invoke(null, new Object[] { Long.valueOf(sTraceTagApp), paramString, Integer.valueOf(paramInt) });
      return;
    } catch (Exception exception) {
      Log.v("TraceCompat", "Unable to invoke traceCounter() via reflection.");
      return;
    } 
  }
  
  static class Api18Impl {
    static void beginSection(String param1String) {
      Trace.beginSection(param1String);
    }
    
    static void endSection() {
      Trace.endSection();
    }
  }
  
  static class Api29Impl {
    static void beginAsyncSection(String param1String, int param1Int) {
      Trace.beginAsyncSection(param1String, param1Int);
    }
    
    static void endAsyncSection(String param1String, int param1Int) {
      Trace.endAsyncSection(param1String, param1Int);
    }
    
    static boolean isEnabled() {
      return Trace.isEnabled();
    }
    
    static void setCounter(String param1String, long param1Long) {
      Trace.setCounter(param1String, param1Long);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\core\os\TraceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */