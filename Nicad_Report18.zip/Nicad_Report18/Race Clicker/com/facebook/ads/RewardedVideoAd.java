package com.facebook.ads;

import android.content.Context;
import com.facebook.ads.internal.api.AdCompanionView;
import com.facebook.ads.internal.api.RewardedVideoAdApi;
import com.facebook.ads.internal.dynamicloading.DynamicLoaderFactory;
import com.facebook.ads.internal.util.common.Preconditions;

public class RewardedVideoAd implements FullScreenAd {
  public static final int UNSET_VIDEO_DURATION = -1;
  
  private final RewardedVideoAdApi mRewardedVideoAdApi;
  
  public RewardedVideoAd(Context paramContext, String paramString) {
    this.mRewardedVideoAdApi = DynamicLoaderFactory.makeLoader(paramContext).createRewardedVideoAd(paramContext, paramString, this);
  }
  
  public RewardedVideoAdLoadConfigBuilder buildLoadAdConfig() {
    return this.mRewardedVideoAdApi.buildLoadAdConfig();
  }
  
  public RewardedVideoAdShowConfigBuilder buildShowAdConfig() {
    return this.mRewardedVideoAdApi.buildShowAdConfig();
  }
  
  public void destroy() {
    this.mRewardedVideoAdApi.destroy();
  }
  
  public String getPlacementId() {
    return this.mRewardedVideoAdApi.getPlacementId();
  }
  
  public int getVideoDuration() {
    return this.mRewardedVideoAdApi.getVideoDuration();
  }
  
  public boolean isAdInvalidated() {
    return this.mRewardedVideoAdApi.isAdInvalidated();
  }
  
  public boolean isAdLoaded() {
    return this.mRewardedVideoAdApi.isAdLoaded();
  }
  
  public void loadAd() {
    this.mRewardedVideoAdApi.loadAd();
  }
  
  public void loadAd(RewardedVideoLoadAdConfig paramRewardedVideoLoadAdConfig) {
    this.mRewardedVideoAdApi.loadAd(paramRewardedVideoLoadAdConfig);
  }
  
  public void registerAdCompanionView(AdCompanionView paramAdCompanionView) {
    Preconditions.checkIsOnMainThread();
    this.mRewardedVideoAdApi.registerAdCompanionView(paramAdCompanionView);
  }
  
  @Deprecated
  public void setExtraHints(ExtraHints paramExtraHints) {
    this.mRewardedVideoAdApi.setExtraHints(paramExtraHints);
  }
  
  public boolean show() {
    return this.mRewardedVideoAdApi.show();
  }
  
  public boolean show(RewardedVideoShowAdConfig paramRewardedVideoShowAdConfig) {
    return this.mRewardedVideoAdApi.show(paramRewardedVideoShowAdConfig);
  }
  
  public void unregisterAdCompanionView() {
    Preconditions.checkIsOnMainThread();
    this.mRewardedVideoAdApi.unregisterAdCompanionView();
  }
  
  public static interface RewardedVideoAdLoadConfigBuilder extends Ad.LoadConfigBuilder {
    RewardedVideoAd.RewardedVideoLoadAdConfig build();
    
    RewardedVideoAdLoadConfigBuilder withAdCompanionView(boolean param1Boolean);
    
    RewardedVideoAdLoadConfigBuilder withAdExperience(AdExperienceType param1AdExperienceType);
    
    RewardedVideoAdLoadConfigBuilder withAdListener(RewardedVideoAdListener param1RewardedVideoAdListener);
    
    RewardedVideoAdLoadConfigBuilder withBid(String param1String);
    
    RewardedVideoAdLoadConfigBuilder withFailOnCacheFailureEnabled(boolean param1Boolean);
    
    RewardedVideoAdLoadConfigBuilder withRewardData(RewardData param1RewardData);
  }
  
  public static interface RewardedVideoAdShowConfigBuilder extends FullScreenAd.ShowConfigBuilder {
    RewardedVideoAd.RewardedVideoShowAdConfig build();
    
    RewardedVideoAdShowConfigBuilder withAppOrientation(int param1Int);
  }
  
  public static interface RewardedVideoLoadAdConfig extends Ad.LoadAdConfig {}
  
  public static interface RewardedVideoShowAdConfig extends FullScreenAd.ShowAdConfig {}
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\ads\RewardedVideoAd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */