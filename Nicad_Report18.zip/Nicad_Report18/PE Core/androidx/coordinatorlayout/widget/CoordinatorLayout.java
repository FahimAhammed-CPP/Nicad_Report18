package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import y.cx;
import y.for;
import y.gw;
import y.l5;
import y.m5;
import y.n5;
import y.ol;
import y.oy0;
import y.p31;
import y.r9;
import y.rw;
import y.td;
import y.ts;
import y.z6;
import y.zz;
import y.役;
import y.殻;
import y.탈;
import y.톨;
import y.통;
import y.퇴;
import y.투;
import y.퉁;
import y.튀;
import y.트;
import y.홰;

public class CoordinatorLayout extends ViewGroup implements l5, m5 {
  public static final Class[] あ;
  
  public static final ThreadLocal か;
  
  public static final 트 ち;
  
  public static final r9 ゃ;
  
  public static final String 投;
  
  public 役 噛;
  
  public View 壊;
  
  public ViewGroup.OnHierarchyChangeListener 寝;
  
  public 퉁 帰;
  
  public final ts 怖 = new ts(4);
  
  public final ArrayList 恐 = new ArrayList();
  
  public zz 歩;
  
  public View 死;
  
  public boolean 泳;
  
  public final ArrayList 淋 = new ArrayList();
  
  public final int[] 産;
  
  public final int[] 痒 = new int[2];
  
  public final ArrayList 痛 = new ArrayList();
  
  public final int[] 臭 = new int[2];
  
  public boolean 興;
  
  public final n5 触;
  
  public boolean 起;
  
  public Drawable 踊;
  
  public boolean 返;
  
  static {
    Package package_ = CoordinatorLayout.class.getPackage();
    if (package_ != null) {
      String str = package_.getName();
    } else {
      package_ = null;
    } 
    投 = (String)package_;
    int i = Build.VERSION.SDK_INT;
    ち = new 트(0);
    あ = new Class[] { Context.class, AttributeSet.class };
    か = new ThreadLocal();
    ゃ = new r9();
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903329);
    int i = 0;
    this.触 = new n5(0);
    int[] arrayOfInt = oy0.辛;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, 2130903329, 0);
    if (Build.VERSION.SDK_INT >= 29)
      saveAttributeDataForStyleable(paramContext, arrayOfInt, paramAttributeSet, typedArray, 2130903329, 0); 
    int j = typedArray.getResourceId(0, 0);
    if (j != 0) {
      Resources resources = paramContext.getResources();
      int[] arrayOfInt1 = resources.getIntArray(j);
      this.産 = arrayOfInt1;
      float f = (resources.getDisplayMetrics()).density;
      j = arrayOfInt1.length;
      while (i < j) {
        int[] arrayOfInt2 = this.産;
        arrayOfInt2[i] = (int)(arrayOfInt2[i] * f);
        i++;
      } 
    } 
    this.踊 = typedArray.getDrawable(1);
    typedArray.recycle();
    起();
    super.setOnHierarchyChangeListener((ViewGroup.OnHierarchyChangeListener)new 퇴(this));
    if (rw.旨((View)this) == 0)
      rw.踊((View)this, 1); 
  }
  
  public static 투 嬉(View paramView) {
    투 투 = (투)paramView.getLayoutParams();
    if (!투.堅) {
      통 통;
      Class<?> clazz = paramView.getClass();
      paramView = null;
      while (clazz != null) {
        통 통1 = clazz.<통>getAnnotation(통.class);
        통 = 통1;
        if (통1 == null) {
          clazz = clazz.getSuperclass();
          통 = 통1;
        } 
      } 
      if (통 != null)
        try {
          톨 톨1 = 통.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
          톨 톨2 = 투.硬;
          if (톨2 != 톨1) {
            if (톨2 != null)
              톨2.冷(); 
            투.硬 = 톨1;
            투.堅 = true;
            if (톨1 != null)
              톨1.熱(투); 
          } 
        } catch (Exception exception) {
          통.value().getClass();
        }  
      투.堅 = true;
    } 
    return 투;
  }
  
  public static void 痒(View paramView, int paramInt) {
    투 투 = (투)paramView.getLayoutParams();
    int i = 투.不;
    if (i != paramInt) {
      rw.怖(paramView, paramInt - i);
      투.不 = paramInt;
    } 
  }
  
  public static Rect 美() {
    Rect rect2 = (Rect)ゃ.硬();
    Rect rect1 = rect2;
    if (rect2 == null)
      rect1 = new Rect(); 
    return rect1;
  }
  
  public static void 臭(View paramView, int paramInt) {
    투 투 = (투)paramView.getLayoutParams();
    int i = 투.辛;
    if (i != paramInt) {
      rw.恐(paramView, paramInt - i);
      투.辛 = paramInt;
    } 
  }
  
  public static void 苦(int paramInt1, Rect paramRect1, Rect paramRect2, 투 param투, int paramInt2, int paramInt3) {
    int j = param투.熱;
    int i = j;
    if (j == 0)
      i = 17; 
    int k = p31.美(i, paramInt1);
    j = param투.暑;
    i = j;
    if ((j & 0x7) == 0)
      i = j | 0x800003; 
    j = i;
    if ((i & 0x70) == 0)
      j = i | 0x30; 
    paramInt1 = p31.美(j, paramInt1);
    int m = k & 0x7;
    k &= 0x70;
    j = paramInt1 & 0x7;
    i = paramInt1 & 0x70;
    if (j != 1) {
      if (j != 5) {
        paramInt1 = paramRect1.left;
      } else {
        paramInt1 = paramRect1.right;
      } 
    } else {
      paramInt1 = paramRect1.left + paramRect1.width() / 2;
    } 
    if (i != 16) {
      if (i != 80) {
        i = paramRect1.top;
      } else {
        i = paramRect1.bottom;
      } 
    } else {
      i = paramRect1.top + paramRect1.height() / 2;
    } 
    if (m != 1) {
      j = paramInt1;
      if (m != 5)
        j = paramInt1 - paramInt2; 
    } else {
      j = paramInt1 - paramInt2 / 2;
    } 
    if (k != 16) {
      paramInt1 = i;
      if (k != 80)
        paramInt1 = i - paramInt3; 
    } else {
      paramInt1 = i - paramInt3 / 2;
    } 
    paramRect2.set(j, paramInt1, paramInt2 + j, paramInt3 + paramInt1);
  }
  
  public final boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof 투 && super.checkLayoutParams(paramLayoutParams));
  }
  
  public final boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    톨 톨 = ((투)paramView.getLayoutParams()).硬;
    if (톨 != null)
      톨.getClass(); 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public final void drawableStateChanged() {
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.踊;
    byte b = 0;
    int i = b;
    if (drawable != null) {
      i = b;
      if (drawable.isStateful())
        i = false | drawable.setState(arrayOfInt); 
    } 
    if (i != 0)
      invalidate(); 
  }
  
  public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new 투();
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new 투(getContext(), paramAttributeSet);
  }
  
  public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof 투) ? new 투((투)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new 투((ViewGroup.MarginLayoutParams)paramLayoutParams) : new 투(paramLayoutParams)));
  }
  
  public final List<View> getDependencySortedChildren() {
    恐();
    return Collections.unmodifiableList(this.淋);
  }
  
  public final zz getLastWindowInsets() {
    return this.歩;
  }
  
  public int getNestedScrollAxes() {
    n5 n51 = this.触;
    int i = n51.淋;
    return n51.怖 | i;
  }
  
  public Drawable getStatusBarBackground() {
    return this.踊;
  }
  
  public int getSuggestedMinimumHeight() {
    int i = super.getSuggestedMinimumHeight();
    int j = getPaddingTop();
    return Math.max(i, getPaddingBottom() + j);
  }
  
  public int getSuggestedMinimumWidth() {
    int i = super.getSuggestedMinimumWidth();
    int j = getPaddingLeft();
    return Math.max(i, getPaddingRight() + j);
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    痛(false);
    if (this.返) {
      if (this.帰 == null)
        this.帰 = new 퉁(this); 
      getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.帰);
    } 
    if (this.歩 == null && rw.美((View)this))
      rw.死((View)this); 
    this.興 = true;
  }
  
  public final void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    痛(false);
    if (this.返 && this.帰 != null)
      getViewTreeObserver().removeOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.帰); 
    View view = this.壊;
    if (view != null)
      onStopNestedScroll(view); 
    this.興 = false;
  }
  
  public final void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.泳 && this.踊 != null) {
      boolean bool;
      zz zz1 = this.歩;
      if (zz1 != null) {
        bool = zz1.暑();
      } else {
        bool = false;
      } 
      if (bool) {
        this.踊.setBounds(0, 0, getWidth(), bool);
        this.踊.draw(paramCanvas);
      } 
    } 
  }
  
  public final boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      痛(true); 
    boolean bool = 怖(paramMotionEvent, 0);
    if (i == 1 || i == 3)
      痛(true); 
    return bool;
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = rw.不((View)this);
    ArrayList<View> arrayList = this.淋;
    paramInt3 = arrayList.size();
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = arrayList.get(paramInt1);
      if (view.getVisibility() != 8) {
        톨 톨 = ((투)view.getLayoutParams()).硬;
        if (톨 == null || !톨.美(this, view, paramInt2))
          淋(view, paramInt2); 
      } 
    } 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 恐 : ()V
    //   4: aload_0
    //   5: invokevirtual getChildCount : ()I
    //   8: istore #5
    //   10: iconst_0
    //   11: istore_3
    //   12: iload_3
    //   13: iload #5
    //   15: if_icmpge -> 123
    //   18: aload_0
    //   19: iload_3
    //   20: invokevirtual getChildAt : (I)Landroid/view/View;
    //   23: astore #27
    //   25: aload_0
    //   26: getfield 怖 : Ly/ts;
    //   29: astore #28
    //   31: aload #28
    //   33: getfield 堅 : Ljava/lang/Object;
    //   36: checkcast y/ol
    //   39: getfield 恐 : I
    //   42: istore #6
    //   44: iconst_0
    //   45: istore #4
    //   47: iload #4
    //   49: iload #6
    //   51: if_icmpge -> 102
    //   54: aload #28
    //   56: getfield 堅 : Ljava/lang/Object;
    //   59: checkcast y/ol
    //   62: iload #4
    //   64: invokevirtual 辛 : (I)Ljava/lang/Object;
    //   67: checkcast java/util/ArrayList
    //   70: astore #29
    //   72: aload #29
    //   74: ifnull -> 93
    //   77: aload #29
    //   79: aload #27
    //   81: invokevirtual contains : (Ljava/lang/Object;)Z
    //   84: ifeq -> 93
    //   87: iconst_1
    //   88: istore #4
    //   90: goto -> 105
    //   93: iload #4
    //   95: iconst_1
    //   96: iadd
    //   97: istore #4
    //   99: goto -> 47
    //   102: iconst_0
    //   103: istore #4
    //   105: iload #4
    //   107: ifeq -> 116
    //   110: iconst_1
    //   111: istore #26
    //   113: goto -> 126
    //   116: iload_3
    //   117: iconst_1
    //   118: iadd
    //   119: istore_3
    //   120: goto -> 12
    //   123: iconst_0
    //   124: istore #26
    //   126: iload #26
    //   128: aload_0
    //   129: getfield 返 : Z
    //   132: if_icmpeq -> 215
    //   135: iload #26
    //   137: ifeq -> 185
    //   140: aload_0
    //   141: getfield 興 : Z
    //   144: ifeq -> 177
    //   147: aload_0
    //   148: getfield 帰 : Ly/퉁;
    //   151: ifnonnull -> 166
    //   154: aload_0
    //   155: new y/퉁
    //   158: dup
    //   159: aload_0
    //   160: invokespecial <init> : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V
    //   163: putfield 帰 : Ly/퉁;
    //   166: aload_0
    //   167: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   170: aload_0
    //   171: getfield 帰 : Ly/퉁;
    //   174: invokevirtual addOnPreDrawListener : (Landroid/view/ViewTreeObserver$OnPreDrawListener;)V
    //   177: aload_0
    //   178: iconst_1
    //   179: putfield 返 : Z
    //   182: goto -> 215
    //   185: aload_0
    //   186: getfield 興 : Z
    //   189: ifeq -> 210
    //   192: aload_0
    //   193: getfield 帰 : Ly/퉁;
    //   196: ifnull -> 210
    //   199: aload_0
    //   200: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   203: aload_0
    //   204: getfield 帰 : Ly/퉁;
    //   207: invokevirtual removeOnPreDrawListener : (Landroid/view/ViewTreeObserver$OnPreDrawListener;)V
    //   210: aload_0
    //   211: iconst_0
    //   212: putfield 返 : Z
    //   215: aload_0
    //   216: invokevirtual getPaddingLeft : ()I
    //   219: istore #15
    //   221: aload_0
    //   222: invokevirtual getPaddingTop : ()I
    //   225: istore #18
    //   227: aload_0
    //   228: invokevirtual getPaddingRight : ()I
    //   231: istore #16
    //   233: aload_0
    //   234: invokevirtual getPaddingBottom : ()I
    //   237: istore #19
    //   239: aload_0
    //   240: invokestatic 不 : (Landroid/view/View;)I
    //   243: istore #11
    //   245: iload #11
    //   247: iconst_1
    //   248: if_icmpne -> 257
    //   251: iconst_1
    //   252: istore #8
    //   254: goto -> 260
    //   257: iconst_0
    //   258: istore #8
    //   260: iload_1
    //   261: invokestatic getMode : (I)I
    //   264: istore #20
    //   266: iload_1
    //   267: invokestatic getSize : (I)I
    //   270: istore #21
    //   272: iload_2
    //   273: invokestatic getMode : (I)I
    //   276: istore #22
    //   278: iload_2
    //   279: invokestatic getSize : (I)I
    //   282: istore #23
    //   284: aload_0
    //   285: invokevirtual getSuggestedMinimumWidth : ()I
    //   288: istore #12
    //   290: aload_0
    //   291: invokevirtual getSuggestedMinimumHeight : ()I
    //   294: istore #5
    //   296: aload_0
    //   297: getfield 歩 : Ly/zz;
    //   300: ifnull -> 316
    //   303: aload_0
    //   304: invokestatic 美 : (Landroid/view/View;)Z
    //   307: ifeq -> 316
    //   310: iconst_1
    //   311: istore #9
    //   313: goto -> 319
    //   316: iconst_0
    //   317: istore #9
    //   319: aload_0
    //   320: getfield 淋 : Ljava/util/ArrayList;
    //   323: astore #27
    //   325: aload #27
    //   327: invokevirtual size : ()I
    //   330: istore #10
    //   332: iconst_0
    //   333: istore #4
    //   335: iconst_0
    //   336: istore_3
    //   337: iload #16
    //   339: istore #7
    //   341: iload #15
    //   343: istore #6
    //   345: iload #6
    //   347: istore #13
    //   349: iload_3
    //   350: iload #10
    //   352: if_icmpge -> 799
    //   355: aload #27
    //   357: iload_3
    //   358: invokevirtual get : (I)Ljava/lang/Object;
    //   361: checkcast android/view/View
    //   364: astore #28
    //   366: aload #28
    //   368: invokevirtual getVisibility : ()I
    //   371: bipush #8
    //   373: if_icmpne -> 379
    //   376: goto -> 788
    //   379: aload #28
    //   381: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   384: checkcast y/투
    //   387: astore #29
    //   389: aload #29
    //   391: getfield 冷 : I
    //   394: istore #6
    //   396: iload #6
    //   398: iflt -> 573
    //   401: iload #20
    //   403: ifeq -> 573
    //   406: aload_0
    //   407: getfield 産 : [I
    //   410: astore #30
    //   412: aload #30
    //   414: ifnonnull -> 428
    //   417: aload_0
    //   418: invokevirtual toString : ()Ljava/lang/String;
    //   421: pop
    //   422: iconst_0
    //   423: istore #6
    //   425: goto -> 462
    //   428: iload #6
    //   430: iflt -> 454
    //   433: iload #6
    //   435: aload #30
    //   437: arraylength
    //   438: if_icmplt -> 444
    //   441: goto -> 454
    //   444: aload #30
    //   446: iload #6
    //   448: iaload
    //   449: istore #6
    //   451: goto -> 462
    //   454: aload_0
    //   455: invokevirtual toString : ()Ljava/lang/String;
    //   458: pop
    //   459: goto -> 422
    //   462: aload #29
    //   464: getfield 熱 : I
    //   467: istore #17
    //   469: iload #17
    //   471: istore #14
    //   473: iload #17
    //   475: ifne -> 483
    //   478: ldc_w 8388661
    //   481: istore #14
    //   483: iload #14
    //   485: iload #11
    //   487: invokestatic 美 : (II)I
    //   490: bipush #7
    //   492: iand
    //   493: istore #14
    //   495: iload #14
    //   497: iconst_3
    //   498: if_icmpne -> 506
    //   501: iload #8
    //   503: ifeq -> 517
    //   506: iload #14
    //   508: iconst_5
    //   509: if_icmpne -> 534
    //   512: iload #8
    //   514: ifeq -> 534
    //   517: iconst_0
    //   518: iload #21
    //   520: iload #7
    //   522: isub
    //   523: iload #6
    //   525: isub
    //   526: invokestatic max : (II)I
    //   529: istore #6
    //   531: goto -> 579
    //   534: iload #14
    //   536: iconst_5
    //   537: if_icmpne -> 545
    //   540: iload #8
    //   542: ifeq -> 556
    //   545: iload #14
    //   547: iconst_3
    //   548: if_icmpne -> 570
    //   551: iload #8
    //   553: ifeq -> 570
    //   556: iconst_0
    //   557: iload #6
    //   559: iload #13
    //   561: isub
    //   562: invokestatic max : (II)I
    //   565: istore #6
    //   567: goto -> 579
    //   570: goto -> 576
    //   573: goto -> 570
    //   576: iconst_0
    //   577: istore #6
    //   579: iload #5
    //   581: istore #17
    //   583: iload #9
    //   585: ifeq -> 665
    //   588: aload #28
    //   590: invokestatic 美 : (Landroid/view/View;)Z
    //   593: ifne -> 665
    //   596: aload_0
    //   597: getfield 歩 : Ly/zz;
    //   600: invokevirtual 堅 : ()I
    //   603: istore #5
    //   605: aload_0
    //   606: getfield 歩 : Ly/zz;
    //   609: invokevirtual 熱 : ()I
    //   612: istore #25
    //   614: aload_0
    //   615: getfield 歩 : Ly/zz;
    //   618: invokevirtual 暑 : ()I
    //   621: istore #14
    //   623: aload_0
    //   624: getfield 歩 : Ly/zz;
    //   627: invokevirtual 硬 : ()I
    //   630: istore #24
    //   632: iload #21
    //   634: iload #25
    //   636: iload #5
    //   638: iadd
    //   639: isub
    //   640: iload #20
    //   642: invokestatic makeMeasureSpec : (II)I
    //   645: istore #5
    //   647: iload #23
    //   649: iload #24
    //   651: iload #14
    //   653: iadd
    //   654: isub
    //   655: iload #22
    //   657: invokestatic makeMeasureSpec : (II)I
    //   660: istore #14
    //   662: goto -> 671
    //   665: iload_1
    //   666: istore #5
    //   668: iload_2
    //   669: istore #14
    //   671: aload #29
    //   673: getfield 硬 : Ly/톨;
    //   676: astore #30
    //   678: aload #30
    //   680: ifnull -> 703
    //   683: aload #30
    //   685: aload_0
    //   686: aload #28
    //   688: iload #5
    //   690: iload #6
    //   692: iload #14
    //   694: invokevirtual 旨 : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)Z
    //   697: ifne -> 716
    //   700: goto -> 703
    //   703: aload_0
    //   704: aload #28
    //   706: iload #5
    //   708: iload #6
    //   710: iload #14
    //   712: iconst_0
    //   713: invokevirtual measureChildWithMargins : (Landroid/view/View;IIII)V
    //   716: iload #12
    //   718: aload #28
    //   720: invokevirtual getMeasuredWidth : ()I
    //   723: iload #15
    //   725: iload #16
    //   727: iadd
    //   728: iadd
    //   729: aload #29
    //   731: getfield leftMargin : I
    //   734: iadd
    //   735: aload #29
    //   737: getfield rightMargin : I
    //   740: iadd
    //   741: invokestatic max : (II)I
    //   744: istore #12
    //   746: iload #17
    //   748: aload #28
    //   750: invokevirtual getMeasuredHeight : ()I
    //   753: iload #18
    //   755: iload #19
    //   757: iadd
    //   758: iadd
    //   759: aload #29
    //   761: getfield topMargin : I
    //   764: iadd
    //   765: aload #29
    //   767: getfield bottomMargin : I
    //   770: iadd
    //   771: invokestatic max : (II)I
    //   774: istore #5
    //   776: iload #4
    //   778: aload #28
    //   780: invokevirtual getMeasuredState : ()I
    //   783: invokestatic combineMeasuredStates : (II)I
    //   786: istore #4
    //   788: iload_3
    //   789: iconst_1
    //   790: iadd
    //   791: istore_3
    //   792: iload #13
    //   794: istore #6
    //   796: goto -> 345
    //   799: aload_0
    //   800: iload #12
    //   802: iload_1
    //   803: ldc_w -16777216
    //   806: iload #4
    //   808: iand
    //   809: invokestatic resolveSizeAndState : (III)I
    //   812: iload #5
    //   814: iload_2
    //   815: iload #4
    //   817: bipush #16
    //   819: ishl
    //   820: invokestatic resolveSizeAndState : (III)I
    //   823: invokevirtual setMeasuredDimension : (II)V
    //   826: return
  }
  
  public final boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    int j = getChildCount();
    int i;
    for (i = 0; i < j; i++) {
      paramView = getChildAt(i);
      if (paramView.getVisibility() != 8) {
        투 투 = (투)paramView.getLayoutParams();
        if (투.硬(0))
          톨 톨 = 투.硬; 
      } 
    } 
    return false;
  }
  
  public final boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    int j = getChildCount();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      boolean bool1;
      View view = getChildAt(i);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        투 투 = (투)view.getLayoutParams();
        if (!투.硬(0)) {
          bool1 = bool;
        } else {
          톨 톨 = 투.硬;
          bool1 = bool;
          if (톨 != null)
            bool1 = bool | 톨.不(paramView); 
        } 
      } 
      i++;
    } 
    return bool;
  }
  
  public final void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    熱(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public final void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    冷(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0);
  }
  
  public final void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    硬(paramView1, paramView2, paramInt, 0);
  }
  
  public final void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof 튀)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    튀 튀 = (튀)paramParcelable;
    super.onRestoreInstanceState(((for)튀).淋);
    SparseArray sparseArray = 튀.恐;
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      int k = view.getId();
      톨 톨 = (嬉(view)).硬;
      if (k != -1 && 톨 != null) {
        Parcelable parcelable = (Parcelable)sparseArray.get(k);
        if (parcelable != null)
          톨.嬉(view, parcelable); 
      } 
    } 
  }
  
  public final Parcelable onSaveInstanceState() {
    튀 튀 = new 튀(super.onSaveInstanceState());
    SparseArray sparseArray = new SparseArray();
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      int k = view.getId();
      톨 톨 = ((투)view.getLayoutParams()).硬;
      if (k != -1 && 톨 != null) {
        Parcelable parcelable = 톨.悲(view);
        if (parcelable != null)
          sparseArray.append(k, parcelable); 
      } 
    } 
    튀.恐 = sparseArray;
    return (Parcelable)튀;
  }
  
  public final boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return 寒(paramView1, paramView2, paramInt, 0);
  }
  
  public final void onStopNestedScroll(View paramView) {
    堅(paramView, 0);
  }
  
  public final boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield 死 : Landroid/view/View;
    //   9: ifnonnull -> 29
    //   12: aload_0
    //   13: aload_1
    //   14: iconst_1
    //   15: invokevirtual 怖 : (Landroid/view/MotionEvent;I)Z
    //   18: istore_3
    //   19: iload_3
    //   20: istore #4
    //   22: iload_3
    //   23: ifeq -> 75
    //   26: goto -> 31
    //   29: iconst_0
    //   30: istore_3
    //   31: aload_0
    //   32: getfield 死 : Landroid/view/View;
    //   35: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   38: checkcast y/투
    //   41: getfield 硬 : Ly/톨;
    //   44: astore #8
    //   46: iload_3
    //   47: istore #4
    //   49: aload #8
    //   51: ifnull -> 75
    //   54: aload #8
    //   56: aload_0
    //   57: getfield 死 : Landroid/view/View;
    //   60: aload_1
    //   61: invokevirtual 怖 : (Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   64: istore #5
    //   66: iload_3
    //   67: istore #4
    //   69: iload #5
    //   71: istore_3
    //   72: goto -> 77
    //   75: iconst_0
    //   76: istore_3
    //   77: aload_0
    //   78: getfield 死 : Landroid/view/View;
    //   81: astore #9
    //   83: aconst_null
    //   84: astore #8
    //   86: aload #9
    //   88: ifnonnull -> 106
    //   91: iload_3
    //   92: aload_0
    //   93: aload_1
    //   94: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   97: ior
    //   98: istore #5
    //   100: aload #8
    //   102: astore_1
    //   103: goto -> 143
    //   106: iload_3
    //   107: istore #5
    //   109: aload #8
    //   111: astore_1
    //   112: iload #4
    //   114: ifeq -> 143
    //   117: invokestatic uptimeMillis : ()J
    //   120: lstore #6
    //   122: lload #6
    //   124: lload #6
    //   126: iconst_3
    //   127: fconst_0
    //   128: fconst_0
    //   129: iconst_0
    //   130: invokestatic obtain : (JJIFFI)Landroid/view/MotionEvent;
    //   133: astore_1
    //   134: aload_0
    //   135: aload_1
    //   136: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   139: pop
    //   140: iload_3
    //   141: istore #5
    //   143: aload_1
    //   144: ifnull -> 151
    //   147: aload_1
    //   148: invokevirtual recycle : ()V
    //   151: iload_2
    //   152: iconst_1
    //   153: if_icmpeq -> 161
    //   156: iload_2
    //   157: iconst_3
    //   158: if_icmpne -> 166
    //   161: aload_0
    //   162: iconst_0
    //   163: invokevirtual 痛 : (Z)V
    //   166: iload #5
    //   168: ireturn
  }
  
  public final boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    톨 톨 = ((투)paramView.getLayoutParams()).硬;
    if (톨 != null)
      톨.苦(this, paramView); 
    return super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public final void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean && !this.起) {
      痛(false);
      this.起 = true;
    } 
  }
  
  public void setFitsSystemWindows(boolean paramBoolean) {
    super.setFitsSystemWindows(paramBoolean);
    起();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.寝 = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    Drawable drawable = this.踊;
    if (drawable != paramDrawable) {
      Drawable drawable1 = null;
      if (drawable != null)
        drawable.setCallback(null); 
      if (paramDrawable != null)
        drawable1 = paramDrawable.mutate(); 
      this.踊 = drawable1;
      if (drawable1 != null) {
        boolean bool;
        if (drawable1.isStateful())
          this.踊.setState(getDrawableState()); 
        td.痒(this.踊, rw.不((View)this));
        paramDrawable = this.踊;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        paramDrawable.setVisible(bool, false);
        this.踊.setCallback((Drawable.Callback)this);
      } 
      rw.痒((View)this);
    } 
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    setStatusBarBackground((Drawable)new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      Context context = getContext();
      Object object = 殻.硬;
      int i = Build.VERSION.SDK_INT;
      drawable = 탈.堅(context, paramInt);
    } else {
      drawable = null;
    } 
    setStatusBarBackground(drawable);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.踊;
    if (drawable != null && drawable.isVisible() != bool)
      this.踊.setVisible(bool, false); 
  }
  
  public final boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.踊);
  }
  
  public final void ぱ(View paramView, Rect paramRect) {
    ThreadLocal threadLocal = cx.硬;
    paramRect.set(0, 0, paramView.getWidth(), paramView.getHeight());
    ThreadLocal<Matrix> threadLocal1 = cx.硬;
    Matrix matrix = threadLocal1.get();
    if (matrix == null) {
      matrix = new Matrix();
      threadLocal1.set(matrix);
    } else {
      matrix.reset();
    } 
    cx.硬((ViewParent)this, paramView, matrix);
    ThreadLocal<RectF> threadLocal2 = cx.堅;
    RectF rectF2 = threadLocal2.get();
    RectF rectF1 = rectF2;
    if (rectF2 == null) {
      rectF1 = new RectF();
      threadLocal2.set(rectF1);
    } 
    rectF1.set(paramRect);
    matrix.mapRect(rectF1);
    paramRect.set((int)(rectF1.left + 0.5F), (int)(rectF1.top + 0.5F), (int)(rectF1.right + 0.5F), (int)(rectF1.bottom + 0.5F));
  }
  
  public final void 不(View paramView, Rect paramRect, boolean paramBoolean) {
    if (paramView.isLayoutRequested() || paramView.getVisibility() == 8) {
      paramRect.setEmpty();
      return;
    } 
    if (paramBoolean) {
      ぱ(paramView, paramRect);
      return;
    } 
    paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
  }
  
  public final void 冷(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    暑(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0, this.臭);
  }
  
  public final void 堅(View paramView, int paramInt) {
    n5 n51 = this.触;
    if (paramInt == 1) {
      n51.怖 = 0;
    } else {
      n51.淋 = 0;
    } 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      투 투 = (투)view.getLayoutParams();
      if (투.硬(paramInt)) {
        톨 톨 = 투.硬;
        if (톨 != null)
          톨.淋(view, paramView, paramInt); 
        if (paramInt != 0) {
          if (paramInt == 1)
            투.寂 = false; 
        } else {
          투.悲 = false;
        } 
        투.getClass();
      } 
    } 
    this.壊 = null;
  }
  
  public final void 寂(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic 不 : (Landroid/view/View;)I
    //   4: istore #6
    //   6: aload_0
    //   7: getfield 淋 : Ljava/util/ArrayList;
    //   10: astore #10
    //   12: aload #10
    //   14: invokevirtual size : ()I
    //   17: istore_2
    //   18: invokestatic 美 : ()Landroid/graphics/Rect;
    //   21: astore #15
    //   23: invokestatic 美 : ()Landroid/graphics/Rect;
    //   26: astore #16
    //   28: invokestatic 美 : ()Landroid/graphics/Rect;
    //   31: astore #17
    //   33: iload_1
    //   34: istore #4
    //   36: iconst_0
    //   37: istore_3
    //   38: getstatic androidx/coordinatorlayout/widget/CoordinatorLayout.ゃ : Ly/r9;
    //   41: astore #18
    //   43: iload_3
    //   44: iload_2
    //   45: if_icmpge -> 1228
    //   48: aload #10
    //   50: iload_3
    //   51: invokevirtual get : (I)Ljava/lang/Object;
    //   54: checkcast android/view/View
    //   57: astore #13
    //   59: aload #13
    //   61: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   64: checkcast y/투
    //   67: astore #12
    //   69: iload #4
    //   71: ifne -> 103
    //   74: aload #13
    //   76: invokevirtual getVisibility : ()I
    //   79: bipush #8
    //   81: if_icmpne -> 103
    //   84: iload_3
    //   85: istore #5
    //   87: iload_2
    //   88: istore_3
    //   89: aload #10
    //   91: astore #11
    //   93: iload #4
    //   95: istore_2
    //   96: iload #5
    //   98: istore #4
    //   100: goto -> 1207
    //   103: iconst_0
    //   104: istore #4
    //   106: aload #10
    //   108: astore #11
    //   110: aload #13
    //   112: astore #10
    //   114: iload #4
    //   116: iload_3
    //   117: if_icmpge -> 409
    //   120: aload #11
    //   122: iload #4
    //   124: invokevirtual get : (I)Ljava/lang/Object;
    //   127: checkcast android/view/View
    //   130: astore #13
    //   132: aload #12
    //   134: getfield 苦 : Landroid/view/View;
    //   137: aload #13
    //   139: if_acmpne -> 400
    //   142: aload #10
    //   144: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   147: checkcast y/투
    //   150: astore #14
    //   152: aload #14
    //   154: getfield ぱ : Landroid/view/View;
    //   157: ifnull -> 400
    //   160: invokestatic 美 : ()Landroid/graphics/Rect;
    //   163: astore #19
    //   165: invokestatic 美 : ()Landroid/graphics/Rect;
    //   168: astore #20
    //   170: invokestatic 美 : ()Landroid/graphics/Rect;
    //   173: astore #21
    //   175: aload_0
    //   176: aload #14
    //   178: getfield ぱ : Landroid/view/View;
    //   181: aload #19
    //   183: invokevirtual ぱ : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   186: aload_0
    //   187: aload #10
    //   189: aload #20
    //   191: iconst_0
    //   192: invokevirtual 不 : (Landroid/view/View;Landroid/graphics/Rect;Z)V
    //   195: aload #10
    //   197: invokevirtual getMeasuredWidth : ()I
    //   200: istore #7
    //   202: aload #10
    //   204: invokevirtual getMeasuredHeight : ()I
    //   207: istore #8
    //   209: aload #10
    //   211: astore #13
    //   213: iload #6
    //   215: aload #19
    //   217: aload #21
    //   219: aload #14
    //   221: iload #7
    //   223: iload #8
    //   225: invokestatic 苦 : (ILandroid/graphics/Rect;Landroid/graphics/Rect;Ly/투;II)V
    //   228: aload #21
    //   230: getfield left : I
    //   233: aload #20
    //   235: getfield left : I
    //   238: if_icmpne -> 263
    //   241: aload #21
    //   243: getfield top : I
    //   246: aload #20
    //   248: getfield top : I
    //   251: if_icmpeq -> 257
    //   254: goto -> 263
    //   257: iconst_0
    //   258: istore #5
    //   260: goto -> 266
    //   263: iconst_1
    //   264: istore #5
    //   266: aload_0
    //   267: aload #14
    //   269: aload #21
    //   271: iload #7
    //   273: iload #8
    //   275: invokevirtual 旨 : (Ly/투;Landroid/graphics/Rect;II)V
    //   278: aload #21
    //   280: getfield left : I
    //   283: aload #20
    //   285: getfield left : I
    //   288: isub
    //   289: istore #7
    //   291: aload #21
    //   293: getfield top : I
    //   296: aload #20
    //   298: getfield top : I
    //   301: isub
    //   302: istore #8
    //   304: iload #7
    //   306: ifeq -> 316
    //   309: aload #13
    //   311: iload #7
    //   313: invokestatic 怖 : (Landroid/view/View;I)V
    //   316: iload #8
    //   318: ifeq -> 328
    //   321: aload #13
    //   323: iload #8
    //   325: invokestatic 恐 : (Landroid/view/View;I)V
    //   328: iload #5
    //   330: ifeq -> 358
    //   333: aload #14
    //   335: getfield 硬 : Ly/톨;
    //   338: astore #22
    //   340: aload #22
    //   342: ifnull -> 358
    //   345: aload #22
    //   347: aload #13
    //   349: aload #14
    //   351: getfield ぱ : Landroid/view/View;
    //   354: invokevirtual 暑 : (Landroid/view/View;Landroid/view/View;)Z
    //   357: pop
    //   358: aload #19
    //   360: invokevirtual setEmpty : ()V
    //   363: aload #18
    //   365: aload #19
    //   367: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   370: pop
    //   371: aload #20
    //   373: invokevirtual setEmpty : ()V
    //   376: aload #18
    //   378: aload #20
    //   380: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   383: pop
    //   384: aload #21
    //   386: invokevirtual setEmpty : ()V
    //   389: aload #18
    //   391: aload #21
    //   393: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   396: pop
    //   397: goto -> 400
    //   400: iload #4
    //   402: iconst_1
    //   403: iadd
    //   404: istore #4
    //   406: goto -> 114
    //   409: iload_3
    //   410: istore #4
    //   412: aload_0
    //   413: aload #10
    //   415: aload #16
    //   417: iconst_1
    //   418: invokevirtual 不 : (Landroid/view/View;Landroid/graphics/Rect;Z)V
    //   421: aload #12
    //   423: getfield 美 : I
    //   426: ifeq -> 577
    //   429: aload #16
    //   431: invokevirtual isEmpty : ()Z
    //   434: ifne -> 577
    //   437: aload #12
    //   439: getfield 美 : I
    //   442: iload #6
    //   444: invokestatic 美 : (II)I
    //   447: istore_3
    //   448: iload_3
    //   449: bipush #112
    //   451: iand
    //   452: istore #5
    //   454: iload #5
    //   456: bipush #48
    //   458: if_icmpeq -> 497
    //   461: iload #5
    //   463: bipush #80
    //   465: if_icmpeq -> 471
    //   468: goto -> 515
    //   471: aload #15
    //   473: aload #15
    //   475: getfield bottom : I
    //   478: aload_0
    //   479: invokevirtual getHeight : ()I
    //   482: aload #16
    //   484: getfield top : I
    //   487: isub
    //   488: invokestatic max : (II)I
    //   491: putfield bottom : I
    //   494: goto -> 515
    //   497: aload #15
    //   499: aload #15
    //   501: getfield top : I
    //   504: aload #16
    //   506: getfield bottom : I
    //   509: invokestatic max : (II)I
    //   512: putfield top : I
    //   515: iload_3
    //   516: bipush #7
    //   518: iand
    //   519: istore_3
    //   520: iload_3
    //   521: iconst_3
    //   522: if_icmpeq -> 559
    //   525: iload_3
    //   526: iconst_5
    //   527: if_icmpeq -> 533
    //   530: goto -> 577
    //   533: aload #15
    //   535: aload #15
    //   537: getfield right : I
    //   540: aload_0
    //   541: invokevirtual getWidth : ()I
    //   544: aload #16
    //   546: getfield left : I
    //   549: isub
    //   550: invokestatic max : (II)I
    //   553: putfield right : I
    //   556: goto -> 577
    //   559: aload #15
    //   561: aload #15
    //   563: getfield left : I
    //   566: aload #16
    //   568: getfield right : I
    //   571: invokestatic max : (II)I
    //   574: putfield left : I
    //   577: aload #12
    //   579: getfield 旨 : I
    //   582: ifeq -> 1092
    //   585: aload #10
    //   587: invokevirtual getVisibility : ()I
    //   590: ifne -> 1092
    //   593: aload #10
    //   595: invokestatic 寂 : (Landroid/view/View;)Z
    //   598: ifne -> 604
    //   601: goto -> 1092
    //   604: aload #10
    //   606: invokevirtual getWidth : ()I
    //   609: ifle -> 1092
    //   612: aload #10
    //   614: invokevirtual getHeight : ()I
    //   617: ifgt -> 623
    //   620: goto -> 1092
    //   623: aload #10
    //   625: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   628: checkcast y/투
    //   631: astore #14
    //   633: aload #14
    //   635: getfield 硬 : Ly/톨;
    //   638: astore #19
    //   640: invokestatic 美 : ()Landroid/graphics/Rect;
    //   643: astore #12
    //   645: invokestatic 美 : ()Landroid/graphics/Rect;
    //   648: astore #13
    //   650: aload #13
    //   652: aload #10
    //   654: invokevirtual getLeft : ()I
    //   657: aload #10
    //   659: invokevirtual getTop : ()I
    //   662: aload #10
    //   664: invokevirtual getRight : ()I
    //   667: aload #10
    //   669: invokevirtual getBottom : ()I
    //   672: invokevirtual set : (IIII)V
    //   675: aload #19
    //   677: ifnull -> 759
    //   680: aload #19
    //   682: aload #10
    //   684: invokevirtual 硬 : (Landroid/view/View;)Z
    //   687: ifeq -> 759
    //   690: aload #13
    //   692: aload #12
    //   694: invokevirtual contains : (Landroid/graphics/Rect;)Z
    //   697: ifeq -> 703
    //   700: goto -> 766
    //   703: new java/lang/StringBuilder
    //   706: dup
    //   707: ldc_w 'Rect should be within the child's bounds. Rect:'
    //   710: invokespecial <init> : (Ljava/lang/String;)V
    //   713: astore #10
    //   715: aload #10
    //   717: aload #12
    //   719: invokevirtual toShortString : ()Ljava/lang/String;
    //   722: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   725: pop
    //   726: aload #10
    //   728: ldc_w ' | Bounds:'
    //   731: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   734: pop
    //   735: aload #10
    //   737: aload #13
    //   739: invokevirtual toShortString : ()Ljava/lang/String;
    //   742: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   745: pop
    //   746: new java/lang/IllegalArgumentException
    //   749: dup
    //   750: aload #10
    //   752: invokevirtual toString : ()Ljava/lang/String;
    //   755: invokespecial <init> : (Ljava/lang/String;)V
    //   758: athrow
    //   759: aload #12
    //   761: aload #13
    //   763: invokevirtual set : (Landroid/graphics/Rect;)V
    //   766: aload #13
    //   768: invokevirtual setEmpty : ()V
    //   771: aload #18
    //   773: aload #13
    //   775: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   778: pop
    //   779: aload #12
    //   781: invokevirtual isEmpty : ()Z
    //   784: ifeq -> 803
    //   787: aload #12
    //   789: invokevirtual setEmpty : ()V
    //   792: aload #18
    //   794: aload #12
    //   796: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   799: pop
    //   800: goto -> 1092
    //   803: aload #14
    //   805: getfield 旨 : I
    //   808: iload #6
    //   810: invokestatic 美 : (II)I
    //   813: istore #7
    //   815: iload #7
    //   817: bipush #48
    //   819: iand
    //   820: bipush #48
    //   822: if_icmpne -> 870
    //   825: aload #12
    //   827: getfield top : I
    //   830: aload #14
    //   832: getfield topMargin : I
    //   835: isub
    //   836: aload #14
    //   838: getfield 辛 : I
    //   841: isub
    //   842: istore_3
    //   843: aload #15
    //   845: getfield top : I
    //   848: istore #5
    //   850: iload_3
    //   851: iload #5
    //   853: if_icmpge -> 870
    //   856: aload #10
    //   858: iload #5
    //   860: iload_3
    //   861: isub
    //   862: invokestatic 臭 : (Landroid/view/View;I)V
    //   865: iconst_1
    //   866: istore_3
    //   867: goto -> 872
    //   870: iconst_0
    //   871: istore_3
    //   872: iload_3
    //   873: istore #5
    //   875: iload #7
    //   877: bipush #80
    //   879: iand
    //   880: bipush #80
    //   882: if_icmpne -> 939
    //   885: aload_0
    //   886: invokevirtual getHeight : ()I
    //   889: aload #12
    //   891: getfield bottom : I
    //   894: isub
    //   895: aload #14
    //   897: getfield bottomMargin : I
    //   900: isub
    //   901: aload #14
    //   903: getfield 辛 : I
    //   906: iadd
    //   907: istore #8
    //   909: aload #15
    //   911: getfield bottom : I
    //   914: istore #9
    //   916: iload_3
    //   917: istore #5
    //   919: iload #8
    //   921: iload #9
    //   923: if_icmpge -> 939
    //   926: aload #10
    //   928: iload #8
    //   930: iload #9
    //   932: isub
    //   933: invokestatic 臭 : (Landroid/view/View;I)V
    //   936: iconst_1
    //   937: istore #5
    //   939: iload #5
    //   941: ifne -> 950
    //   944: aload #10
    //   946: iconst_0
    //   947: invokestatic 臭 : (Landroid/view/View;I)V
    //   950: iload #7
    //   952: iconst_3
    //   953: iand
    //   954: iconst_3
    //   955: if_icmpne -> 1003
    //   958: aload #12
    //   960: getfield left : I
    //   963: aload #14
    //   965: getfield leftMargin : I
    //   968: isub
    //   969: aload #14
    //   971: getfield 不 : I
    //   974: isub
    //   975: istore_3
    //   976: aload #15
    //   978: getfield left : I
    //   981: istore #5
    //   983: iload_3
    //   984: iload #5
    //   986: if_icmpge -> 1003
    //   989: aload #10
    //   991: iload #5
    //   993: iload_3
    //   994: isub
    //   995: invokestatic 痒 : (Landroid/view/View;I)V
    //   998: iconst_1
    //   999: istore_3
    //   1000: goto -> 1005
    //   1003: iconst_0
    //   1004: istore_3
    //   1005: iload #7
    //   1007: iconst_5
    //   1008: iand
    //   1009: iconst_5
    //   1010: if_icmpne -> 1066
    //   1013: aload_0
    //   1014: invokevirtual getWidth : ()I
    //   1017: aload #12
    //   1019: getfield right : I
    //   1022: isub
    //   1023: aload #14
    //   1025: getfield rightMargin : I
    //   1028: isub
    //   1029: aload #14
    //   1031: getfield 不 : I
    //   1034: iadd
    //   1035: istore #5
    //   1037: aload #15
    //   1039: getfield right : I
    //   1042: istore #7
    //   1044: iload #5
    //   1046: iload #7
    //   1048: if_icmpge -> 1066
    //   1051: aload #10
    //   1053: iload #5
    //   1055: iload #7
    //   1057: isub
    //   1058: invokestatic 痒 : (Landroid/view/View;I)V
    //   1061: iconst_1
    //   1062: istore_3
    //   1063: goto -> 1066
    //   1066: iload_3
    //   1067: ifne -> 1076
    //   1070: aload #10
    //   1072: iconst_0
    //   1073: invokestatic 痒 : (Landroid/view/View;I)V
    //   1076: aload #12
    //   1078: invokevirtual setEmpty : ()V
    //   1081: aload #18
    //   1083: aload #12
    //   1085: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   1088: pop
    //   1089: goto -> 1092
    //   1092: iload_1
    //   1093: iconst_2
    //   1094: if_icmpeq -> 1142
    //   1097: aload #17
    //   1099: aload #10
    //   1101: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1104: checkcast y/투
    //   1107: getfield 淋 : Landroid/graphics/Rect;
    //   1110: invokevirtual set : (Landroid/graphics/Rect;)V
    //   1113: aload #17
    //   1115: aload #16
    //   1117: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1120: ifeq -> 1126
    //   1123: goto -> 1203
    //   1126: aload #10
    //   1128: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1131: checkcast y/투
    //   1134: getfield 淋 : Landroid/graphics/Rect;
    //   1137: aload #16
    //   1139: invokevirtual set : (Landroid/graphics/Rect;)V
    //   1142: iload #4
    //   1144: iconst_1
    //   1145: iadd
    //   1146: istore_3
    //   1147: aload #11
    //   1149: astore #10
    //   1151: aload #10
    //   1153: astore #11
    //   1155: iload_3
    //   1156: iload_2
    //   1157: if_icmpge -> 1203
    //   1160: aload #10
    //   1162: iload_3
    //   1163: invokevirtual get : (I)Ljava/lang/Object;
    //   1166: checkcast android/view/View
    //   1169: astore #11
    //   1171: aload #11
    //   1173: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1176: checkcast y/투
    //   1179: getfield 硬 : Ly/톨;
    //   1182: astore #12
    //   1184: aload #12
    //   1186: ifnull -> 1196
    //   1189: aload #12
    //   1191: aload #11
    //   1193: invokevirtual 堅 : (Landroid/view/View;)V
    //   1196: iload_3
    //   1197: iconst_1
    //   1198: iadd
    //   1199: istore_3
    //   1200: goto -> 1151
    //   1203: iload_2
    //   1204: istore_3
    //   1205: iload_1
    //   1206: istore_2
    //   1207: iload #4
    //   1209: iconst_1
    //   1210: iadd
    //   1211: istore #5
    //   1213: aload #11
    //   1215: astore #10
    //   1217: iload_2
    //   1218: istore #4
    //   1220: iload_3
    //   1221: istore_2
    //   1222: iload #5
    //   1224: istore_3
    //   1225: goto -> 38
    //   1228: aload #15
    //   1230: invokevirtual setEmpty : ()V
    //   1233: aload #18
    //   1235: aload #15
    //   1237: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   1240: pop
    //   1241: aload #16
    //   1243: invokevirtual setEmpty : ()V
    //   1246: aload #18
    //   1248: aload #16
    //   1250: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   1253: pop
    //   1254: aload #17
    //   1256: invokevirtual setEmpty : ()V
    //   1259: aload #18
    //   1261: aload #17
    //   1263: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   1266: pop
    //   1267: return
  }
  
  public final boolean 寒(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    int j = getChildCount();
    int i = 0;
    boolean bool = false;
    while (i < j) {
      paramView1 = getChildAt(i);
      if (paramView1.getVisibility() != 8) {
        투 투 = (투)paramView1.getLayoutParams();
        톨 톨 = 투.硬;
        if (톨 != null) {
          boolean bool1 = 톨.寂(paramView1, paramInt1, paramInt2);
          bool |= bool1;
          if (paramInt2 != 0) {
            if (paramInt2 == 1)
              투.寂 = bool1; 
          } else {
            투.悲 = bool1;
          } 
        } else if (paramInt2 != 0) {
          if (paramInt2 == 1)
            투.寂 = false; 
        } else {
          투.悲 = false;
        } 
      } 
      i++;
    } 
    return bool;
  }
  
  public final boolean 怖(MotionEvent paramMotionEvent, int paramInt) {
    boolean bool2;
    int m = paramMotionEvent.getActionMasked();
    ArrayList<View> arrayList = this.恐;
    arrayList.clear();
    boolean bool1 = isChildrenDrawingOrderEnabled();
    int k = getChildCount();
    int i;
    for (i = k - 1; i >= 0; i--) {
      int i1;
      if (bool1) {
        i1 = getChildDrawingOrder(k, i);
      } else {
        i1 = i;
      } 
      arrayList.add(getChildAt(i1));
    } 
    트 트1 = ち;
    if (트1 != null)
      Collections.sort(arrayList, (Comparator<? super View>)트1); 
    int n = arrayList.size();
    트1 = null;
    int j = 0;
    bool1 = false;
    i = 0;
    while (true) {
      bool2 = bool1;
      if (j < n) {
        boolean bool;
        MotionEvent motionEvent;
        트 트2;
        View view = arrayList.get(j);
        투 투 = (투)view.getLayoutParams();
        톨 톨 = 투.硬;
        if ((bool1 || i != 0) && m != 0) {
          트2 = 트1;
          bool = bool1;
          k = i;
          if (톨 != null) {
            트2 = 트1;
            if (트1 == null) {
              long l = SystemClock.uptimeMillis();
              motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
            } 
            if (paramInt != 0) {
              if (paramInt != 1) {
                bool = bool1;
                k = i;
              } else {
                톨.怖(view, motionEvent);
                bool = bool1;
                k = i;
              } 
            } else {
              톨.寒(this, view, motionEvent);
              bool = bool1;
              k = i;
            } 
          } 
        } else {
          int i1;
          bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (톨 != null) {
              if (paramInt != 0) {
                if (paramInt == 1)
                  bool1 = 톨.怖(view, paramMotionEvent); 
              } else {
                bool1 = 톨.寒(this, view, paramMotionEvent);
              } 
              bool2 = bool1;
              if (bool1) {
                this.死 = view;
                bool2 = bool1;
              } 
            } 
          } 
          if (((투)motionEvent).硬 == null)
            ((투)motionEvent).嬉 = false; 
          bool = ((투)motionEvent).嬉;
          if (bool) {
            bool1 = true;
          } else {
            i1 = bool | false;
            ((투)motionEvent).嬉 = i1;
          } 
          if (i1 != 0 && !bool) {
            i = 1;
          } else {
            i = 0;
          } 
          트2 = 트1;
          bool = bool2;
          k = i;
          if (i1 != 0) {
            트2 = 트1;
            bool = bool2;
            k = i;
            if (i == 0)
              break; 
          } 
        } 
        j++;
        트1 = 트2;
        bool1 = bool;
        i = k;
        continue;
      } 
      break;
    } 
    arrayList.clear();
    return bool2;
  }
  
  public final void 恐() {
    // Byte code:
    //   0: aload_0
    //   1: getfield 淋 : Ljava/util/ArrayList;
    //   4: astore #9
    //   6: aload #9
    //   8: invokevirtual clear : ()V
    //   11: aload_0
    //   12: getfield 怖 : Ly/ts;
    //   15: astore #10
    //   17: aload #10
    //   19: getfield 堅 : Ljava/lang/Object;
    //   22: checkcast y/ol
    //   25: getfield 恐 : I
    //   28: istore_2
    //   29: iconst_0
    //   30: istore #4
    //   32: iconst_0
    //   33: istore_1
    //   34: iload_1
    //   35: iload_2
    //   36: if_icmpge -> 87
    //   39: aload #10
    //   41: getfield 堅 : Ljava/lang/Object;
    //   44: checkcast y/ol
    //   47: iload_1
    //   48: invokevirtual 辛 : (I)Ljava/lang/Object;
    //   51: checkcast java/util/ArrayList
    //   54: astore #7
    //   56: aload #7
    //   58: ifnull -> 80
    //   61: aload #7
    //   63: invokevirtual clear : ()V
    //   66: aload #10
    //   68: getfield 硬 : Ljava/lang/Object;
    //   71: checkcast y/q9
    //   74: aload #7
    //   76: invokevirtual 堅 : (Ljava/lang/Object;)Z
    //   79: pop
    //   80: iload_1
    //   81: iconst_1
    //   82: iadd
    //   83: istore_1
    //   84: goto -> 34
    //   87: aload #10
    //   89: getfield 堅 : Ljava/lang/Object;
    //   92: checkcast y/ol
    //   95: invokevirtual clear : ()V
    //   98: aload_0
    //   99: invokevirtual getChildCount : ()I
    //   102: istore #5
    //   104: iconst_0
    //   105: istore_1
    //   106: iload_1
    //   107: iload #5
    //   109: if_icmpge -> 838
    //   112: aload_0
    //   113: iload_1
    //   114: invokevirtual getChildAt : (I)Landroid/view/View;
    //   117: astore #11
    //   119: aload #11
    //   121: invokestatic 嬉 : (Landroid/view/View;)Ly/투;
    //   124: astore #12
    //   126: aload #12
    //   128: getfield 寒 : I
    //   131: istore_3
    //   132: iload_3
    //   133: iconst_m1
    //   134: if_icmpne -> 152
    //   137: aload #12
    //   139: aconst_null
    //   140: putfield 苦 : Landroid/view/View;
    //   143: aload #12
    //   145: aconst_null
    //   146: putfield ぱ : Landroid/view/View;
    //   149: goto -> 440
    //   152: aload #12
    //   154: getfield ぱ : Landroid/view/View;
    //   157: astore #7
    //   159: aload #7
    //   161: ifnull -> 268
    //   164: aload #7
    //   166: invokevirtual getId : ()I
    //   169: iload_3
    //   170: if_icmpeq -> 176
    //   173: goto -> 250
    //   176: aload #12
    //   178: getfield ぱ : Landroid/view/View;
    //   181: astore #8
    //   183: aload #8
    //   185: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   188: astore #7
    //   190: aload #7
    //   192: aload_0
    //   193: if_acmpeq -> 255
    //   196: aload #7
    //   198: ifnull -> 238
    //   201: aload #7
    //   203: aload #11
    //   205: if_acmpne -> 211
    //   208: goto -> 238
    //   211: aload #7
    //   213: instanceof android/view/View
    //   216: ifeq -> 226
    //   219: aload #7
    //   221: checkcast android/view/View
    //   224: astore #8
    //   226: aload #7
    //   228: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   233: astore #7
    //   235: goto -> 190
    //   238: aload #12
    //   240: aconst_null
    //   241: putfield 苦 : Landroid/view/View;
    //   244: aload #12
    //   246: aconst_null
    //   247: putfield ぱ : Landroid/view/View;
    //   250: iconst_0
    //   251: istore_2
    //   252: goto -> 264
    //   255: aload #12
    //   257: aload #8
    //   259: putfield 苦 : Landroid/view/View;
    //   262: iconst_1
    //   263: istore_2
    //   264: iload_2
    //   265: ifne -> 440
    //   268: aload_0
    //   269: iload_3
    //   270: invokevirtual findViewById : (I)Landroid/view/View;
    //   273: astore #8
    //   275: aload #12
    //   277: aload #8
    //   279: putfield ぱ : Landroid/view/View;
    //   282: aload #8
    //   284: ifnull -> 421
    //   287: aload #8
    //   289: aload_0
    //   290: if_acmpne -> 326
    //   293: aload_0
    //   294: invokevirtual isInEditMode : ()Z
    //   297: ifeq -> 315
    //   300: aload #12
    //   302: aconst_null
    //   303: putfield 苦 : Landroid/view/View;
    //   306: aload #12
    //   308: aconst_null
    //   309: putfield ぱ : Landroid/view/View;
    //   312: goto -> 440
    //   315: new java/lang/IllegalStateException
    //   318: dup
    //   319: ldc_w 'View can not be anchored to the the parent CoordinatorLayout'
    //   322: invokespecial <init> : (Ljava/lang/String;)V
    //   325: athrow
    //   326: aload #8
    //   328: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   331: astore #7
    //   333: aload #7
    //   335: aload_0
    //   336: if_acmpeq -> 411
    //   339: aload #7
    //   341: ifnull -> 411
    //   344: aload #7
    //   346: aload #11
    //   348: if_acmpne -> 384
    //   351: aload_0
    //   352: invokevirtual isInEditMode : ()Z
    //   355: ifeq -> 373
    //   358: aload #12
    //   360: aconst_null
    //   361: putfield 苦 : Landroid/view/View;
    //   364: aload #12
    //   366: aconst_null
    //   367: putfield ぱ : Landroid/view/View;
    //   370: goto -> 440
    //   373: new java/lang/IllegalStateException
    //   376: dup
    //   377: ldc_w 'Anchor must not be a descendant of the anchored view'
    //   380: invokespecial <init> : (Ljava/lang/String;)V
    //   383: athrow
    //   384: aload #7
    //   386: instanceof android/view/View
    //   389: ifeq -> 399
    //   392: aload #7
    //   394: checkcast android/view/View
    //   397: astore #8
    //   399: aload #7
    //   401: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   406: astore #7
    //   408: goto -> 333
    //   411: aload #12
    //   413: aload #8
    //   415: putfield 苦 : Landroid/view/View;
    //   418: goto -> 440
    //   421: aload_0
    //   422: invokevirtual isInEditMode : ()Z
    //   425: ifeq -> 782
    //   428: aload #12
    //   430: aconst_null
    //   431: putfield 苦 : Landroid/view/View;
    //   434: aload #12
    //   436: aconst_null
    //   437: putfield ぱ : Landroid/view/View;
    //   440: aload #10
    //   442: getfield 堅 : Ljava/lang/Object;
    //   445: checkcast y/ol
    //   448: aload #11
    //   450: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   453: ifne -> 471
    //   456: aload #10
    //   458: getfield 堅 : Ljava/lang/Object;
    //   461: checkcast y/ol
    //   464: aload #11
    //   466: aconst_null
    //   467: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   470: pop
    //   471: iconst_0
    //   472: istore_2
    //   473: iload_2
    //   474: iload #5
    //   476: if_icmpge -> 775
    //   479: iload_2
    //   480: iload_1
    //   481: if_icmpne -> 487
    //   484: goto -> 768
    //   487: aload_0
    //   488: iload_2
    //   489: invokevirtual getChildAt : (I)Landroid/view/View;
    //   492: astore #13
    //   494: aload #13
    //   496: aload #12
    //   498: getfield 苦 : Landroid/view/View;
    //   501: if_acmpeq -> 583
    //   504: aload_0
    //   505: invokestatic 不 : (Landroid/view/View;)I
    //   508: istore_3
    //   509: aload #13
    //   511: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   514: checkcast y/투
    //   517: getfield 美 : I
    //   520: iload_3
    //   521: invokestatic 美 : (II)I
    //   524: istore #6
    //   526: iload #6
    //   528: ifeq -> 553
    //   531: aload #12
    //   533: getfield 旨 : I
    //   536: iload_3
    //   537: invokestatic 美 : (II)I
    //   540: iload #6
    //   542: iand
    //   543: iload #6
    //   545: if_icmpne -> 553
    //   548: iconst_1
    //   549: istore_3
    //   550: goto -> 555
    //   553: iconst_0
    //   554: istore_3
    //   555: iload_3
    //   556: ifne -> 583
    //   559: aload #12
    //   561: getfield 硬 : Ly/톨;
    //   564: astore #7
    //   566: aload #7
    //   568: ifnull -> 578
    //   571: aload #7
    //   573: aload #11
    //   575: invokevirtual 堅 : (Landroid/view/View;)V
    //   578: iconst_0
    //   579: istore_3
    //   580: goto -> 585
    //   583: iconst_1
    //   584: istore_3
    //   585: iload_3
    //   586: ifeq -> 768
    //   589: aload #10
    //   591: getfield 堅 : Ljava/lang/Object;
    //   594: checkcast y/ol
    //   597: aload #13
    //   599: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   602: ifne -> 636
    //   605: aload #10
    //   607: getfield 堅 : Ljava/lang/Object;
    //   610: checkcast y/ol
    //   613: aload #13
    //   615: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   618: ifne -> 636
    //   621: aload #10
    //   623: getfield 堅 : Ljava/lang/Object;
    //   626: checkcast y/ol
    //   629: aload #13
    //   631: aconst_null
    //   632: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   635: pop
    //   636: aload #10
    //   638: getfield 堅 : Ljava/lang/Object;
    //   641: checkcast y/ol
    //   644: aload #13
    //   646: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   649: ifeq -> 757
    //   652: aload #10
    //   654: getfield 堅 : Ljava/lang/Object;
    //   657: checkcast y/ol
    //   660: aload #11
    //   662: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   665: ifeq -> 757
    //   668: aload #10
    //   670: getfield 堅 : Ljava/lang/Object;
    //   673: checkcast y/ol
    //   676: aload #13
    //   678: aconst_null
    //   679: invokevirtual getOrDefault : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   682: checkcast java/util/ArrayList
    //   685: astore #8
    //   687: aload #8
    //   689: astore #7
    //   691: aload #8
    //   693: ifnonnull -> 746
    //   696: aload #10
    //   698: getfield 硬 : Ljava/lang/Object;
    //   701: checkcast y/q9
    //   704: invokevirtual 硬 : ()Ljava/lang/Object;
    //   707: checkcast java/util/ArrayList
    //   710: astore #8
    //   712: aload #8
    //   714: astore #7
    //   716: aload #8
    //   718: ifnonnull -> 730
    //   721: new java/util/ArrayList
    //   724: dup
    //   725: invokespecial <init> : ()V
    //   728: astore #7
    //   730: aload #10
    //   732: getfield 堅 : Ljava/lang/Object;
    //   735: checkcast y/ol
    //   738: aload #13
    //   740: aload #7
    //   742: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   745: pop
    //   746: aload #7
    //   748: aload #11
    //   750: invokevirtual add : (Ljava/lang/Object;)Z
    //   753: pop
    //   754: goto -> 768
    //   757: new java/lang/IllegalArgumentException
    //   760: dup
    //   761: ldc_w 'All nodes must be present in the graph before being added as an edge'
    //   764: invokespecial <init> : (Ljava/lang/String;)V
    //   767: athrow
    //   768: iload_2
    //   769: iconst_1
    //   770: iadd
    //   771: istore_2
    //   772: goto -> 473
    //   775: iload_1
    //   776: iconst_1
    //   777: iadd
    //   778: istore_1
    //   779: goto -> 106
    //   782: new java/lang/StringBuilder
    //   785: dup
    //   786: ldc_w 'Could not find CoordinatorLayout descendant view with id '
    //   789: invokespecial <init> : (Ljava/lang/String;)V
    //   792: astore #7
    //   794: aload #7
    //   796: aload_0
    //   797: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   800: iload_3
    //   801: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   804: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   807: pop
    //   808: aload #7
    //   810: ldc_w ' to anchor view '
    //   813: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   816: pop
    //   817: aload #7
    //   819: aload #11
    //   821: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   824: pop
    //   825: new java/lang/IllegalStateException
    //   828: dup
    //   829: aload #7
    //   831: invokevirtual toString : ()Ljava/lang/String;
    //   834: invokespecial <init> : (Ljava/lang/String;)V
    //   837: athrow
    //   838: aload #10
    //   840: getfield 熱 : Ljava/lang/Object;
    //   843: checkcast java/util/ArrayList
    //   846: invokevirtual clear : ()V
    //   849: aload #10
    //   851: getfield 暑 : Ljava/lang/Object;
    //   854: checkcast java/util/HashSet
    //   857: invokevirtual clear : ()V
    //   860: aload #10
    //   862: getfield 堅 : Ljava/lang/Object;
    //   865: checkcast y/ol
    //   868: getfield 恐 : I
    //   871: istore_2
    //   872: iload #4
    //   874: istore_1
    //   875: iload_1
    //   876: iload_2
    //   877: if_icmpge -> 920
    //   880: aload #10
    //   882: aload #10
    //   884: getfield 堅 : Ljava/lang/Object;
    //   887: checkcast y/ol
    //   890: iload_1
    //   891: invokevirtual 旨 : (I)Ljava/lang/Object;
    //   894: aload #10
    //   896: getfield 熱 : Ljava/lang/Object;
    //   899: checkcast java/util/ArrayList
    //   902: aload #10
    //   904: getfield 暑 : Ljava/lang/Object;
    //   907: checkcast java/util/HashSet
    //   910: invokevirtual 不 : (Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V
    //   913: iload_1
    //   914: iconst_1
    //   915: iadd
    //   916: istore_1
    //   917: goto -> 875
    //   920: aload #9
    //   922: aload #10
    //   924: getfield 熱 : Ljava/lang/Object;
    //   927: checkcast java/util/ArrayList
    //   930: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   933: pop
    //   934: aload #9
    //   936: invokestatic reverse : (Ljava/util/List;)V
    //   939: return
  }
  
  public final boolean 悲(View paramView, int paramInt1, int paramInt2) {
    r9 r91 = ゃ;
    Rect rect = 美();
    ぱ(paramView, rect);
    try {
      return rect.contains(paramInt1, paramInt2);
    } finally {
      rect.setEmpty();
      r91.堅(rect);
    } 
  }
  
  public final void 旨(투 param투, Rect paramRect, int paramInt1, int paramInt2) {
    int j = getWidth();
    int i = getHeight();
    j = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams)param투).leftMargin, Math.min(paramRect.left, j - getPaddingRight() - paramInt1 - ((ViewGroup.MarginLayoutParams)param투).rightMargin));
    i = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams)param투).topMargin, Math.min(paramRect.top, i - getPaddingBottom() - paramInt2 - ((ViewGroup.MarginLayoutParams)param투).bottomMargin));
    paramRect.set(j, i, paramInt1 + j, paramInt2 + i);
  }
  
  public final void 暑(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    int m = getChildCount();
    boolean bool = false;
    int i = 0;
    int k = 0;
    int j;
    for (j = 0; i < m; j = paramInt1) {
      int n;
      paramView = getChildAt(i);
      if (paramView.getVisibility() == 8) {
        n = k;
        paramInt1 = j;
      } else {
        투 투 = (투)paramView.getLayoutParams();
        if (!투.硬(paramInt5)) {
          n = k;
          paramInt1 = j;
        } else {
          톨 톨 = 투.硬;
          n = k;
          paramInt1 = j;
          if (톨 != null) {
            int[] arrayOfInt = this.痒;
            arrayOfInt[0] = 0;
            arrayOfInt[1] = 0;
            톨.ぱ(this, paramView, paramInt2, paramInt3, paramInt4, arrayOfInt);
            if (paramInt3 > 0) {
              paramInt1 = Math.max(k, arrayOfInt[0]);
            } else {
              paramInt1 = Math.min(k, arrayOfInt[0]);
            } 
            k = paramInt1;
            if (paramInt4 > 0) {
              paramInt1 = Math.max(j, arrayOfInt[1]);
            } else {
              paramInt1 = Math.min(j, arrayOfInt[1]);
            } 
            bool = true;
            n = k;
          } 
        } 
      } 
      i++;
      k = n;
    } 
    paramArrayOfint[0] = paramArrayOfint[0] + k;
    paramArrayOfint[1] = paramArrayOfint[1] + j;
    if (bool)
      寂(1); 
  }
  
  public final void 淋(View paramView, int paramInt) {
    int i;
    int k;
    투 투 = (투)paramView.getLayoutParams();
    View view = 투.ぱ;
    int j = 0;
    if (view == null && 투.寒 != -1) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!i) {
      투 투1;
      Rect rect;
      r9 r91 = ゃ;
      if (view != null) {
        rect = 美();
        Rect rect1 = 美();
        try {
          ぱ(view, rect);
          투 투2 = (투)paramView.getLayoutParams();
          i = paramView.getMeasuredWidth();
          j = paramView.getMeasuredHeight();
          苦(paramInt, rect, rect1, 투2, i, j);
          旨(투2, rect1, i, j);
          paramView.layout(rect1.left, rect1.top, rect1.right, rect1.bottom);
          return;
        } finally {
          rect.setEmpty();
          r91.堅(rect);
          rect1.setEmpty();
          r91.堅(rect1);
        } 
      } 
      int m = ((투)rect).冷;
      if (m >= 0) {
        투1 = (투)paramView.getLayoutParams();
        k = 투1.熱;
        i = k;
        if (k == 0)
          i = 8388661; 
        i = p31.美(i, paramInt);
        int i4 = i & 0x7;
        int i3 = i & 0x70;
        int i2 = getWidth();
        int i1 = getHeight();
        k = paramView.getMeasuredWidth();
        int n = paramView.getMeasuredHeight();
        i = m;
        if (paramInt == 1)
          i = i2 - m; 
        int[] arrayOfInt = this.産;
        if (arrayOfInt == null) {
          toString();
        } else if (i < 0 || i >= arrayOfInt.length) {
          toString();
        } else {
          paramInt = arrayOfInt[i];
          paramInt -= k;
        } 
        paramInt = 0;
      } else {
        투 투2 = (투)paramView.getLayoutParams();
        Rect rect1 = 美();
        rect1.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams)투2).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams)투2).topMargin, getWidth() - getPaddingRight() - ((ViewGroup.MarginLayoutParams)투2).rightMargin, getHeight() - getPaddingBottom() - ((ViewGroup.MarginLayoutParams)투2).bottomMargin);
        if (this.歩 != null && rw.美((View)this) && !rw.美(paramView)) {
          i = rect1.left;
          rect1.left = this.歩.堅() + i;
          i = rect1.top;
          rect1.top = this.歩.暑() + i;
          rect1.right -= this.歩.熱();
          rect1.bottom -= this.歩.硬();
        } 
        Rect rect2 = 美();
        j = 투2.熱;
        i = j;
        if ((j & 0x7) == 0)
          i = j | 0x800003; 
        j = i;
        if ((i & 0x70) == 0)
          j = i | 0x30; 
        i = paramView.getMeasuredWidth();
        m = paramView.getMeasuredHeight();
        k = Build.VERSION.SDK_INT;
        홰.堅(j, i, m, rect1, rect2, paramInt);
        paramView.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
        rect1.setEmpty();
        투1.堅(rect1);
        rect2.setEmpty();
        투1.堅(rect2);
        return;
      } 
    } else {
      throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
    } 
    paramInt -= k;
  }
  
  public final void 熱(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    int n = getChildCount();
    int k = 0;
    int m = 0;
    int j = 0;
    int i;
    for (i = 0; k < n; i = i2) {
      int i1;
      int i2;
      int i3;
      View view = getChildAt(k);
      if (view.getVisibility() == 8) {
        i3 = m;
        i1 = j;
        i2 = i;
      } else {
        투 투 = (투)view.getLayoutParams();
        if (!투.硬(paramInt3)) {
          i3 = m;
          i1 = j;
          i2 = i;
        } else {
          톨 톨 = 투.硬;
          i3 = m;
          i1 = j;
          i2 = i;
          if (톨 != null) {
            int[] arrayOfInt = this.痒;
            arrayOfInt[0] = 0;
            arrayOfInt[1] = 0;
            톨.辛(view, paramView, paramInt2, arrayOfInt, paramInt3);
            if (paramInt1 > 0) {
              i = Math.max(m, arrayOfInt[0]);
            } else {
              i = Math.min(m, arrayOfInt[0]);
            } 
            if (paramInt2 > 0) {
              j = Math.max(j, arrayOfInt[1]);
            } else {
              j = Math.min(j, arrayOfInt[1]);
            } 
            i2 = 1;
            i1 = j;
            i3 = i;
          } 
        } 
      } 
      k++;
      m = i3;
      j = i1;
    } 
    paramArrayOfint[0] = m;
    paramArrayOfint[1] = j;
    if (i != 0)
      寂(1); 
  }
  
  public final void 痛(boolean paramBoolean) {
    int j = getChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getChildAt(i);
      톨 톨 = ((투)view.getLayoutParams()).硬;
      if (톨 != null) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        if (paramBoolean) {
          톨.寒(this, view, motionEvent);
        } else {
          톨.怖(view, motionEvent);
        } 
        motionEvent.recycle();
      } 
    } 
    for (i = 0; i < j; i++)
      ((투)getChildAt(i).getLayoutParams()).嬉 = false; 
    this.死 = null;
    this.起 = false;
  }
  
  public final void 硬(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    n5 n51 = this.触;
    if (paramInt2 == 1) {
      n51.怖 = paramInt1;
    } else {
      n51.淋 = paramInt1;
    } 
    this.壊 = paramView2;
    paramInt2 = getChildCount();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++)
      ((투)getChildAt(paramInt1).getLayoutParams()).getClass(); 
  }
  
  public final void 起() {
    int i = Build.VERSION.SDK_INT;
    if (rw.美((View)this)) {
      if (this.噛 == null)
        this.噛 = new 役(3, this); 
      gw.臭((View)this, (z6)this.噛);
      setSystemUiVisibility(1280);
      return;
    } 
    gw.臭((View)this, null);
  }
  
  public final ArrayList 辛(View paramView) {
    ts ts1 = this.怖;
    int j = ((ol)ts1.堅).恐;
    ArrayList<Object> arrayList2 = null;
    int i = 0;
    while (i < j) {
      ArrayList arrayList3 = (ArrayList)((ol)ts1.堅).辛(i);
      ArrayList<Object> arrayList = arrayList2;
      if (arrayList3 != null) {
        arrayList = arrayList2;
        if (arrayList3.contains(paramView)) {
          arrayList = arrayList2;
          if (arrayList2 == null)
            arrayList = new ArrayList(); 
          arrayList.add(((ol)ts1.堅).旨(i));
        } 
      } 
      i++;
      arrayList2 = arrayList;
    } 
    ArrayList<Object> arrayList1 = this.痛;
    arrayList1.clear();
    if (arrayList2 != null)
      arrayList1.addAll(arrayList2); 
    return arrayList1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\coordinatorlayout\widget\CoordinatorLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */