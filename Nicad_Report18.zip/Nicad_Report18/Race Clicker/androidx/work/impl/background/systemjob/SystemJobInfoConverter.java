package androidx.work.impl.background.systemjob;

import android.app.job.JobInfo;
import android.content.ComponentName;
import android.content.Context;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.PersistableBundle;
import androidx.core.os.BuildCompat;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ContentUriTriggers;
import androidx.work.Logger;
import androidx.work.NetworkType;
import androidx.work.impl.model.WorkSpec;
import java.util.Iterator;

class SystemJobInfoConverter {
  static final String EXTRA_IS_PERIODIC = "EXTRA_IS_PERIODIC";
  
  static final String EXTRA_WORK_SPEC_ID = "EXTRA_WORK_SPEC_ID";
  
  private static final String TAG = Logger.tagWithPrefix("SystemJobInfoConverter");
  
  private final ComponentName mWorkServiceComponent;
  
  SystemJobInfoConverter(Context paramContext) {
    this.mWorkServiceComponent = new ComponentName(paramContext.getApplicationContext(), SystemJobService.class);
  }
  
  private static JobInfo.TriggerContentUri convertContentUriTrigger(ContentUriTriggers.Trigger paramTrigger) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  static int convertNetworkType(NetworkType paramNetworkType) {
    int i = null.$SwitchMap$androidx$work$NetworkType[paramNetworkType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i == 5 && Build.VERSION.SDK_INT >= 26)
              return 4; 
          } else if (Build.VERSION.SDK_INT >= 24) {
            return 3;
          } 
          Logger.get().debug(TAG, String.format("API version too low. Cannot convert network type value %s", new Object[] { paramNetworkType }), new Throwable[0]);
          return 1;
        } 
        return 2;
      } 
      return 1;
    } 
    return 0;
  }
  
  static void setRequiredNetwork(JobInfo.Builder paramBuilder, NetworkType paramNetworkType) {
    if (Build.VERSION.SDK_INT >= 30 && paramNetworkType == NetworkType.TEMPORARILY_UNMETERED) {
      paramBuilder.setRequiredNetwork((new NetworkRequest.Builder()).addCapability(25).build());
      return;
    } 
    paramBuilder.setRequiredNetworkType(convertNetworkType(paramNetworkType));
  }
  
  JobInfo convert(WorkSpec paramWorkSpec, int paramInt) {
    Constraints constraints = paramWorkSpec.constraints;
    PersistableBundle persistableBundle = new PersistableBundle();
    persistableBundle.putString("EXTRA_WORK_SPEC_ID", paramWorkSpec.id);
    persistableBundle.putBoolean("EXTRA_IS_PERIODIC", paramWorkSpec.isPeriodic());
    JobInfo.Builder builder = (new JobInfo.Builder(paramInt, this.mWorkServiceComponent)).setRequiresCharging(constraints.requiresCharging()).setRequiresDeviceIdle(constraints.requiresDeviceIdle()).setExtras(persistableBundle);
    setRequiredNetwork(builder, constraints.getRequiredNetworkType());
    boolean bool1 = constraints.requiresDeviceIdle();
    boolean bool = false;
    if (!bool1) {
      if (paramWorkSpec.backoffPolicy == BackoffPolicy.LINEAR) {
        paramInt = 0;
      } else {
        paramInt = 1;
      } 
      builder.setBackoffCriteria(paramWorkSpec.backoffDelayDuration, paramInt);
    } 
    long l = Math.max(paramWorkSpec.calculateNextRunTime() - System.currentTimeMillis(), 0L);
    if (Build.VERSION.SDK_INT <= 28) {
      builder.setMinimumLatency(l);
    } else if (l > 0L) {
      builder.setMinimumLatency(l);
    } else if (!paramWorkSpec.expedited) {
      builder.setImportantWhileForeground(true);
    } 
    if (Build.VERSION.SDK_INT >= 24 && constraints.hasContentUriTriggers()) {
      Iterator<ContentUriTriggers.Trigger> iterator = constraints.getContentUriTriggers().getTriggers().iterator();
      while (iterator.hasNext())
        builder.addTriggerContentUri(convertContentUriTrigger(iterator.next())); 
      builder.setTriggerContentUpdateDelay(constraints.getTriggerContentUpdateDelay());
      builder.setTriggerContentMaxDelay(constraints.getTriggerMaxContentDelay());
    } 
    builder.setPersisted(false);
    if (Build.VERSION.SDK_INT >= 26) {
      builder.setRequiresBatteryNotLow(constraints.requiresBatteryNotLow());
      builder.setRequiresStorageNotLow(constraints.requiresStorageNotLow());
    } 
    paramInt = bool;
    if (paramWorkSpec.runAttemptCount > 0)
      paramInt = 1; 
    if (BuildCompat.isAtLeastS() && paramWorkSpec.expedited && paramInt == 0)
      builder.setExpedited(true); 
    return builder.build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\work\impl\background\systemjob\SystemJobInfoConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */