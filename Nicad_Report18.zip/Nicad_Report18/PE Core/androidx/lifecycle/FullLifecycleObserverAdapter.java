package androidx.lifecycle;

import y.尻;
import y.肉;
import y.腰;
import y.녁;
import y.왼;

class FullLifecycleObserverAdapter implements 肉 {
  public final 肉 怖;
  
  public final 녁 淋;
  
  public FullLifecycleObserverAdapter(녁 param녁, 肉 param肉) {
    this.淋 = param녁;
    this.怖 = param肉;
  }
  
  public final void 暑(腰 param腰, 尻 param尻) {
    int i = 왼.硬[param尻.ordinal()];
    녁 녁1 = this.淋;
    switch (i) {
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        녁1.onDestroy();
        break;
      case 5:
        녁1.硬();
        break;
      case 4:
        녁1.onPause();
        break;
      case 3:
        녁1.onResume();
        break;
      case 2:
        녁1.冷();
        break;
      case 1:
        녁1.堅();
        break;
    } 
    肉 肉1 = this.怖;
    if (肉1 != null)
      肉1.暑(param腰, param尻); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */