package androidx.work.impl.workers;

import android.content.Context;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import y.そ;
import y.祖;

public class CombineContinuationsWorker extends Worker {
  public CombineContinuationsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public final 祖 doWork() {
    return (祖)new そ(getInputData());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\work\impl\workers\CombineContinuationsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */