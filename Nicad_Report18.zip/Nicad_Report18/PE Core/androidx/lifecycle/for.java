package androidx.lifecycle;

import android.os.Looper;
import androidx.activity.do;
import java.util.Map;
import y.bm;
import y.mx;
import y.qi;
import y.t6;
import y.ti;
import y.ぞ;
import y.伯;
import y.叔;
import y.心;
import y.新;
import y.銅;
import y.정;

public class for {
  public static final Object ぱ = new Object();
  
  public boolean 不;
  
  public volatile Object 冷;
  
  public final ti 堅 = new ti();
  
  public volatile Object 寒;
  
  public boolean 旨;
  
  public boolean 暑;
  
  public int 熱 = 0;
  
  public final Object 硬 = new Object();
  
  public int 美;
  
  public final 정 辛;
  
  public for() {
    Object object = ぱ;
    this.寒 = object;
    this.辛 = new 정(6, this);
    this.冷 = object;
    this.美 = -1;
  }
  
  public static void 硬(String paramString) {
    boolean bool;
    (新.れ()).태.getClass();
    if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      return; 
    throw new IllegalStateException(bm.痛("Cannot invoke ", paramString, " on a background thread"));
  }
  
  public final void 冷(t6 paramt6) {
    硬("observeForever");
    伯 伯 = new 伯(this, paramt6);
    叔 叔 = (叔)this.堅.冷(paramt6, 伯);
    if (!(叔 instanceof LiveData$LifecycleBoundObserver)) {
      if (叔 != null)
        return; 
      伯.熱(true);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public final void 堅(叔 param叔) {
    if (!param叔.怖)
      return; 
    if (!param叔.旨()) {
      param叔.熱(false);
      return;
    } 
    int i = param叔.恐;
    int j = this.美;
    if (i >= j)
      return; 
    param叔.恐 = j;
    param叔.淋.淋(this.冷);
  }
  
  public final void 寒(Object paramObject) {
    synchronized (this.硬) {
      boolean bool;
      if (this.寒 == ぱ) {
        bool = true;
      } else {
        bool = false;
      } 
      this.寒 = paramObject;
      if (!bool)
        return; 
      新.れ().俺((Runnable)this.辛);
      return;
    } 
  }
  
  public final void 暑(銅 param銅, mx parammx) {
    硬("observe");
    if (((do)param銅).痛.興 == ぞ.淋)
      return; 
    LiveData$LifecycleBoundObserver liveData$LifecycleBoundObserver = new LiveData$LifecycleBoundObserver(this, param銅, parammx);
    叔 叔 = (叔)this.堅.冷(parammx, liveData$LifecycleBoundObserver);
    if (叔 == null || 叔.美(param銅)) {
      if (叔 != null)
        return; 
      ((do)param銅).痛.硬((心)liveData$LifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public final void 熱(叔 param叔) {
    if (this.旨) {
      this.不 = true;
      return;
    } 
    this.旨 = true;
    while (true) {
      叔 叔1;
      this.不 = false;
      if (param叔 != null) {
        堅(param叔);
        叔1 = null;
      } else {
        ti ti1 = this.堅;
        ti1.getClass();
        qi qi = new qi(ti1);
        ti1.恐.put(qi, Boolean.FALSE);
        while (true) {
          叔1 = param叔;
          if (qi.hasNext()) {
            堅((叔)((Map.Entry)qi.next()).getValue());
            if (this.不) {
              叔1 = param叔;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      param叔 = 叔1;
      if (!this.不) {
        this.旨 = false;
        return;
      } 
    } 
  }
  
  public final void 美(Object paramObject) {
    硬("setValue");
    this.美++;
    this.冷 = paramObject;
    熱(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\for.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */