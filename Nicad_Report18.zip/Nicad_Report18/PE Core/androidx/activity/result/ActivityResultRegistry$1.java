package androidx.activity.result;

import y.尻;
import y.肉;
import y.腰;

class ActivityResultRegistry$1 implements 肉 {
  public final void 暑(腰 param腰, 尻 param尻) {
    if (!尻.ON_START.equals(param尻)) {
      if (!尻.ON_STOP.equals(param尻)) {
        if (!尻.ON_DESTROY.equals(param尻))
          return; 
        throw null;
      } 
      throw null;
    } 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */