package com.applovin.exoplayer2.i.a;

import com.applovin.exoplayer2.c.f;
import com.applovin.exoplayer2.c.i;
import com.applovin.exoplayer2.i.f;
import com.applovin.exoplayer2.i.g;
import com.applovin.exoplayer2.i.h;
import com.applovin.exoplayer2.i.j;
import com.applovin.exoplayer2.i.k;
import com.applovin.exoplayer2.l.ai;
import java.util.ArrayDeque;
import java.util.PriorityQueue;

abstract class c implements g {
  private final ArrayDeque<a> a = new ArrayDeque<a>();
  
  private final ArrayDeque<k> b;
  
  private final PriorityQueue<a> c;
  
  private a d;
  
  private long e;
  
  private long f;
  
  public c() {
    boolean bool = false;
    int i;
    for (i = 0; i < 10; i++)
      this.a.add(new a()); 
    this.b = new ArrayDeque<k>();
    for (i = bool; i < 2; i++)
      this.b.add(new b((i.a<b>)new c$.ExternalSyntheticLambda0(this))); 
    this.c = new PriorityQueue<a>();
  }
  
  private void a(a parama) {
    parama.a();
    this.a.add(parama);
  }
  
  public void a(long paramLong) {
    this.e = paramLong;
  }
  
  protected abstract void a(j paramj);
  
  protected void a(k paramk) {
    paramk.a();
    this.b.add(paramk);
  }
  
  public void b(j paramj) throws h {
    boolean bool;
    if (paramj == this.d) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.a(bool);
    paramj = paramj;
    if (paramj.b()) {
      a((a)paramj);
    } else {
      long l = this.f;
      this.f = 1L + l;
      a.a((a)paramj, l);
      this.c.add(paramj);
    } 
    this.d = null;
  }
  
  public void c() {
    this.f = 0L;
    this.e = 0L;
    while (!this.c.isEmpty())
      a((a)ai.a(this.c.poll())); 
    a a1 = this.d;
    if (a1 != null) {
      a(a1);
      this.d = null;
    } 
  }
  
  public void d() {}
  
  public k e() throws h {
    if (this.b.isEmpty())
      return null; 
    while (!this.c.isEmpty() && ((a)ai.a((a)this.c.peek())).d <= this.e) {
      a a1 = (a)ai.a(this.c.poll());
      if (a1.c()) {
        k k = (k)ai.a(this.b.pollFirst());
        k.b(4);
        a(a1);
        return k;
      } 
      a(a1);
      if (f()) {
        f f = g();
        k k = (k)ai.a(this.b.pollFirst());
        k.a(a1.d, f, Long.MAX_VALUE);
        a(a1);
        return k;
      } 
      a(a1);
    } 
    return null;
  }
  
  protected abstract boolean f();
  
  protected abstract f g();
  
  public j h() throws h {
    boolean bool;
    if (this.d == null) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.b(bool);
    if (this.a.isEmpty())
      return null; 
    a a1 = this.a.pollFirst();
    this.d = a1;
    return a1;
  }
  
  protected final k j() {
    return this.b.pollFirst();
  }
  
  protected final long k() {
    return this.e;
  }
  
  private static final class a extends j implements Comparable<a> {
    private long g;
    
    private a() {}
    
    public int a(a param1a) {
      if (c() != param1a.c())
        return c() ? 1 : -1; 
      long l2 = this.d - param1a.d;
      long l1 = l2;
      if (l2 == 0L) {
        l2 = this.g - param1a.g;
        l1 = l2;
        if (l2 == 0L)
          return 0; 
      } 
      return (l1 > 0L) ? 1 : -1;
    }
  }
  
  private static final class b extends k {
    private i.a<b> c;
    
    public b(i.a<b> param1a) {
      this.c = param1a;
    }
    
    public final void f() {
      this.c.releaseOutputBuffer((i)this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\applovin\exoplayer2\i\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */