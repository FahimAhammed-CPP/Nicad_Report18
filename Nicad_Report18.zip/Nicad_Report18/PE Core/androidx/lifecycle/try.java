package androidx.lifecycle;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import y.da;
import y.xf;
import y.尻;
import y.鰺;
import y.못;

public final class try extends 못 {
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT < 29) {
      int i = xf.怖;
      ((xf)paramActivity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag")).淋 = da.this.興;
    } 
  }
  
  public void onActivityPaused(Activity paramActivity) {
    da da1 = da.this;
    int i = da1.怖 - 1;
    da1.怖 = i;
    if (i == 0)
      da1.痒.postDelayed((Runnable)da1.起, 700L); 
  }
  
  public void onActivityPreCreated(Activity paramActivity, Bundle paramBundle) {
    鰺.不(paramActivity, new new(this));
  }
  
  public void onActivityStopped(Activity paramActivity) {
    da da1 = da.this;
    int i = da1.淋 - 1;
    da1.淋 = i;
    if (i == 0 && da1.恐) {
      da1.臭.消(尻.ON_STOP);
      da1.痛 = true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\lifecycle\try.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */