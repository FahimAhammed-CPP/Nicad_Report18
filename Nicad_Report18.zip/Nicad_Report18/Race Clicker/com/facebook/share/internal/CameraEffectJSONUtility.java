package com.facebook.share.internal;

import com.facebook.share.model.CameraEffectArguments;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CameraEffectJSONUtility {
  private static final Map<Class<?>, Setter> SETTERS;
  
  static {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    SETTERS = (Map)hashMap;
    hashMap.put(String.class, new Setter() {
          public void setOnArgumentsBuilder(CameraEffectArguments.Builder param1Builder, String param1String, Object param1Object) throws JSONException {
            param1Builder.putArgument(param1String, (String)param1Object);
          }
          
          public void setOnJSON(JSONObject param1JSONObject, String param1String, Object param1Object) throws JSONException {
            param1JSONObject.put(param1String, param1Object);
          }
        });
    hashMap.put(String[].class, new Setter() {
          public void setOnArgumentsBuilder(CameraEffectArguments.Builder param1Builder, String param1String, Object param1Object) throws JSONException {
            throw new IllegalArgumentException("Unexpected type from JSON");
          }
          
          public void setOnJSON(JSONObject param1JSONObject, String param1String, Object param1Object) throws JSONException {
            JSONArray jSONArray = new JSONArray();
            param1Object = param1Object;
            int j = param1Object.length;
            int i;
            for (i = 0; i < j; i++)
              jSONArray.put(param1Object[i]); 
            param1JSONObject.put(param1String, jSONArray);
          }
        });
    hashMap.put(JSONArray.class, new Setter() {
          public void setOnArgumentsBuilder(CameraEffectArguments.Builder param1Builder, String param1String, Object param1Object) throws JSONException {
            StringBuilder stringBuilder;
            JSONArray jSONArray = (JSONArray)param1Object;
            String[] arrayOfString = new String[jSONArray.length()];
            int i = 0;
            while (i < jSONArray.length()) {
              param1Object = jSONArray.get(i);
              if (param1Object instanceof String) {
                arrayOfString[i] = (String)param1Object;
                i++;
                continue;
              } 
              stringBuilder = new StringBuilder("Unexpected type in an array: ");
              stringBuilder.append(param1Object.getClass());
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            stringBuilder.putArgument(param1String, arrayOfString);
          }
          
          public void setOnJSON(JSONObject param1JSONObject, String param1String, Object param1Object) throws JSONException {
            throw new IllegalArgumentException("JSONArray's are not supported in bundles.");
          }
        });
  }
  
  public static CameraEffectArguments convertToCameraEffectArguments(JSONObject paramJSONObject) throws JSONException {
    if (paramJSONObject == null)
      return null; 
    CameraEffectArguments.Builder builder = new CameraEffectArguments.Builder();
    Iterator<String> iterator = paramJSONObject.keys();
    while (iterator.hasNext()) {
      String str = iterator.next();
      Object object = paramJSONObject.get(str);
      if (object == null || object == JSONObject.NULL)
        continue; 
      Setter setter = SETTERS.get(object.getClass());
      if (setter != null) {
        setter.setOnArgumentsBuilder(builder, str, object);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder("Unsupported type: ");
      stringBuilder.append(object.getClass());
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return builder.build();
  }
  
  public static JSONObject convertToJSON(CameraEffectArguments paramCameraEffectArguments) throws JSONException {
    if (paramCameraEffectArguments == null)
      return null; 
    JSONObject jSONObject = new JSONObject();
    for (String str : paramCameraEffectArguments.keySet()) {
      Object object = paramCameraEffectArguments.get(str);
      if (object == null)
        continue; 
      Setter setter = SETTERS.get(object.getClass());
      if (setter != null) {
        setter.setOnJSON(jSONObject, str, object);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder("Unsupported type: ");
      stringBuilder.append(object.getClass());
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return jSONObject;
  }
  
  public static interface Setter {
    void setOnArgumentsBuilder(CameraEffectArguments.Builder param1Builder, String param1String, Object param1Object) throws JSONException;
    
    void setOnJSON(JSONObject param1JSONObject, String param1String, Object param1Object) throws JSONException;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\share\internal\CameraEffectJSONUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */