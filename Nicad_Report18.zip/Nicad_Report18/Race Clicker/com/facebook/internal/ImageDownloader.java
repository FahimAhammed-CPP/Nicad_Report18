package com.facebook.internal;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.HashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000f\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020%\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\020\002\n\002\b\t\n\002\030\002\n\000\n\002\020$\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\t\bÆ\002\030\0002\0020\001:\004-./0B\007\b\002¢\006\002\020\002J\020\020\021\032\0020\0222\006\020\023\032\0020\024H\007J\b\020\025\032\0020\026H\007J\020\020\027\032\0020\0262\006\020\030\032\0020\017H\002J\022\020\031\032\0020\0262\b\020\023\032\004\030\0010\024H\007J \020\032\032\0020\0262\006\020\023\032\0020\0242\006\020\030\032\0020\0172\006\020\033\032\0020\022H\002J\030\020\034\032\0020\0262\006\020\023\032\0020\0242\006\020\030\032\0020\017H\002J(\020\035\032\0020\0262\006\020\023\032\0020\0242\006\020\030\032\0020\0172\006\020\036\032\0020\0072\006\020\037\032\0020 H\002J\024\020!\032\016\022\004\022\0020\017\022\004\022\0020\0200\"H\007J2\020#\032\0020\0262\006\020\030\032\0020\0172\016\020$\032\n\030\0010%j\004\030\001`&2\b\020'\032\004\030\0010(2\006\020)\032\0020\022H\002J\020\020*\032\0020\0262\006\020\023\032\0020\024H\007J\030\020+\032\0020\0262\006\020\030\032\0020\0172\006\020\033\032\0020\022H\002J\022\020,\032\004\030\0010\0202\006\020\030\032\0020\017H\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000R\016\020\006\032\0020\007X\004¢\006\002\n\000R\016\020\b\032\0020\007X\004¢\006\002\n\000R\030\020\t\032\004\030\0010\n8BX\016¢\006\b\n\000\032\004\b\013\020\fR\032\020\r\032\016\022\004\022\0020\017\022\004\022\0020\0200\016X\004¢\006\002\n\000¨\0061"}, d2 = {"Lcom/facebook/internal/ImageDownloader;", "", "()V", "CACHE_READ_QUEUE_MAX_CONCURRENT", "", "DOWNLOAD_QUEUE_MAX_CONCURRENT", "cacheReadQueue", "Lcom/facebook/internal/WorkQueue;", "downloadQueue", "handler", "Landroid/os/Handler;", "getHandler", "()Landroid/os/Handler;", "pendingRequests", "", "Lcom/facebook/internal/ImageDownloader$RequestKey;", "Lcom/facebook/internal/ImageDownloader$DownloaderContext;", "cancelRequest", "", "request", "Lcom/facebook/internal/ImageRequest;", "clearCache", "", "download", "key", "downloadAsync", "enqueueCacheRead", "allowCachedRedirects", "enqueueDownload", "enqueueRequest", "workQueue", "workItem", "Ljava/lang/Runnable;", "getPendingRequests", "", "issueResponse", "error", "Ljava/lang/Exception;", "Lkotlin/Exception;", "bitmap", "Landroid/graphics/Bitmap;", "isCachedRedirect", "prioritizeRequest", "readFromCache", "removePendingRequest", "CacheReadWorkItem", "DownloadImageWorkItem", "DownloaderContext", "RequestKey", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
public final class ImageDownloader {
  private static final int CACHE_READ_QUEUE_MAX_CONCURRENT = 2;
  
  private static final int DOWNLOAD_QUEUE_MAX_CONCURRENT = 8;
  
  public static final ImageDownloader INSTANCE = new ImageDownloader();
  
  private static final WorkQueue cacheReadQueue;
  
  private static final WorkQueue downloadQueue = new WorkQueue(8, null, 2, null);
  
  private static Handler handler;
  
  private static final Map<RequestKey, DownloaderContext> pendingRequests;
  
  static {
    cacheReadQueue = new WorkQueue(2, null, 2, null);
    pendingRequests = new HashMap<RequestKey, DownloaderContext>();
  }
  
  @JvmStatic
  public static final boolean cancelRequest(ImageRequest paramImageRequest) {
    Intrinsics.checkNotNullParameter(paramImageRequest, "request");
    null = new RequestKey(paramImageRequest.getImageUri(), paramImageRequest.getCallerTag());
    synchronized (pendingRequests) {
      DownloaderContext downloaderContext = null.get(null);
      if (downloaderContext != null) {
        WorkQueue.WorkItem workItem = downloaderContext.getWorkItem();
        boolean bool1 = true;
        if (workItem != null && workItem.cancel()) {
          null.remove(null);
        } else {
          downloaderContext.setCancelled(true);
        } 
        Unit unit1 = Unit.INSTANCE;
        return bool1;
      } 
    } 
    boolean bool = false;
    Unit unit = Unit.INSTANCE;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/facebook/internal/ImageRequest}, name=paramImageRequest} */
    return bool;
  }
  
  @JvmStatic
  public static final void clearCache() {
    ImageResponseCache.clearCache();
    UrlRedirectCache.clearCache();
  }
  
  private final void download(RequestKey paramRequestKey) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #10
    //   3: aconst_null
    //   4: astore #6
    //   6: aconst_null
    //   7: astore #9
    //   9: aconst_null
    //   10: checkcast java/net/HttpURLConnection
    //   13: astore #5
    //   15: aconst_null
    //   16: checkcast java/io/InputStream
    //   19: astore #5
    //   21: aconst_null
    //   22: checkcast java/lang/Exception
    //   25: astore #5
    //   27: aconst_null
    //   28: checkcast android/graphics/Bitmap
    //   31: astore #5
    //   33: iconst_1
    //   34: istore_3
    //   35: iconst_1
    //   36: istore_2
    //   37: new java/net/URL
    //   40: dup
    //   41: aload_1
    //   42: invokevirtual getUri : ()Landroid/net/Uri;
    //   45: invokevirtual toString : ()Ljava/lang/String;
    //   48: invokespecial <init> : (Ljava/lang/String;)V
    //   51: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   54: astore #5
    //   56: aload #5
    //   58: ifnull -> 552
    //   61: aload #5
    //   63: checkcast java/net/HttpURLConnection
    //   66: astore #5
    //   68: aload #5
    //   70: iconst_0
    //   71: invokevirtual setInstanceFollowRedirects : (Z)V
    //   74: aload #5
    //   76: invokevirtual getResponseCode : ()I
    //   79: istore #4
    //   81: iload #4
    //   83: sipush #200
    //   86: if_icmpeq -> 455
    //   89: iload #4
    //   91: sipush #301
    //   94: if_icmpeq -> 337
    //   97: iload #4
    //   99: sipush #302
    //   102: if_icmpeq -> 337
    //   105: aload #5
    //   107: invokevirtual getErrorStream : ()Ljava/io/InputStream;
    //   110: astore #9
    //   112: aload #9
    //   114: astore #7
    //   116: aload #5
    //   118: astore #8
    //   120: aload #9
    //   122: astore #6
    //   124: new java/lang/StringBuilder
    //   127: dup
    //   128: invokespecial <init> : ()V
    //   131: astore #11
    //   133: aload #9
    //   135: ifnull -> 259
    //   138: aload #9
    //   140: astore #7
    //   142: aload #5
    //   144: astore #8
    //   146: aload #9
    //   148: astore #6
    //   150: new java/io/InputStreamReader
    //   153: dup
    //   154: aload #9
    //   156: invokespecial <init> : (Ljava/io/InputStream;)V
    //   159: astore #12
    //   161: aload #9
    //   163: astore #7
    //   165: aload #5
    //   167: astore #8
    //   169: aload #9
    //   171: astore #6
    //   173: sipush #128
    //   176: newarray char
    //   178: astore #13
    //   180: aload #9
    //   182: astore #7
    //   184: aload #5
    //   186: astore #8
    //   188: aload #9
    //   190: astore #6
    //   192: aload #12
    //   194: aload #13
    //   196: iconst_0
    //   197: sipush #128
    //   200: invokevirtual read : ([CII)I
    //   203: istore #4
    //   205: iload #4
    //   207: ifle -> 236
    //   210: aload #9
    //   212: astore #7
    //   214: aload #5
    //   216: astore #8
    //   218: aload #9
    //   220: astore #6
    //   222: aload #11
    //   224: aload #13
    //   226: iconst_0
    //   227: iload #4
    //   229: invokevirtual append : ([CII)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: goto -> 180
    //   236: aload #9
    //   238: astore #7
    //   240: aload #5
    //   242: astore #8
    //   244: aload #9
    //   246: astore #6
    //   248: aload #12
    //   250: checkcast java/io/Closeable
    //   253: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   256: goto -> 298
    //   259: aload #9
    //   261: astore #7
    //   263: aload #5
    //   265: astore #8
    //   267: aload #9
    //   269: astore #6
    //   271: aload #11
    //   273: ldc 'Unexpected error while downloading an image.'
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: pop
    //   279: aload #9
    //   281: astore #7
    //   283: aload #5
    //   285: astore #8
    //   287: aload #9
    //   289: astore #6
    //   291: aload #11
    //   293: ldc 'errorMessageBuilder.appe…e downloading an image.")'
    //   295: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
    //   298: aload #9
    //   300: astore #7
    //   302: aload #5
    //   304: astore #8
    //   306: aload #9
    //   308: astore #6
    //   310: new com/facebook/FacebookException
    //   313: dup
    //   314: aload #11
    //   316: invokevirtual toString : ()Ljava/lang/String;
    //   319: invokespecial <init> : (Ljava/lang/String;)V
    //   322: checkcast java/lang/Exception
    //   325: astore #11
    //   327: aconst_null
    //   328: astore #6
    //   330: aload #11
    //   332: astore #7
    //   334: goto -> 488
    //   337: aload #5
    //   339: ldc 'location'
    //   341: invokevirtual getHeaderField : (Ljava/lang/String;)Ljava/lang/String;
    //   344: astore #7
    //   346: aload #7
    //   348: invokestatic isNullOrEmpty : (Ljava/lang/String;)Z
    //   351: ifne -> 425
    //   354: aload #7
    //   356: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   359: astore #7
    //   361: aload_1
    //   362: invokevirtual getUri : ()Landroid/net/Uri;
    //   365: aload #7
    //   367: invokestatic cacheUriRedirect : (Landroid/net/Uri;Landroid/net/Uri;)V
    //   370: aload_0
    //   371: aload_1
    //   372: invokespecial removePendingRequest : (Lcom/facebook/internal/ImageDownloader$RequestKey;)Lcom/facebook/internal/ImageDownloader$DownloaderContext;
    //   375: astore #8
    //   377: aload #8
    //   379: ifnull -> 425
    //   382: aload #8
    //   384: invokevirtual isCancelled : ()Z
    //   387: ifne -> 425
    //   390: aload #8
    //   392: invokevirtual getRequest : ()Lcom/facebook/internal/ImageRequest;
    //   395: astore #8
    //   397: aload #7
    //   399: ldc_w 'redirectUri'
    //   402: invokestatic checkNotNullExpressionValue : (Ljava/lang/Object;Ljava/lang/String;)V
    //   405: aload_0
    //   406: aload #8
    //   408: new com/facebook/internal/ImageDownloader$RequestKey
    //   411: dup
    //   412: aload #7
    //   414: aload_1
    //   415: invokevirtual getTag : ()Ljava/lang/Object;
    //   418: invokespecial <init> : (Landroid/net/Uri;Ljava/lang/Object;)V
    //   421: iconst_0
    //   422: invokespecial enqueueCacheRead : (Lcom/facebook/internal/ImageRequest;Lcom/facebook/internal/ImageDownloader$RequestKey;Z)V
    //   425: aconst_null
    //   426: astore #6
    //   428: aload #6
    //   430: astore #7
    //   432: iconst_0
    //   433: istore_2
    //   434: goto -> 488
    //   437: astore #7
    //   439: aconst_null
    //   440: astore #6
    //   442: iconst_0
    //   443: istore_2
    //   444: aload #5
    //   446: astore #9
    //   448: aload #6
    //   450: astore #5
    //   452: goto -> 581
    //   455: aload #5
    //   457: invokestatic interceptAndCacheImageStream : (Ljava/net/HttpURLConnection;)Ljava/io/InputStream;
    //   460: astore #9
    //   462: aload #9
    //   464: astore #7
    //   466: aload #5
    //   468: astore #8
    //   470: aload #9
    //   472: astore #6
    //   474: aload #9
    //   476: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   479: astore #11
    //   481: aconst_null
    //   482: astore #7
    //   484: aload #11
    //   486: astore #6
    //   488: aload #9
    //   490: checkcast java/io/Closeable
    //   493: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   496: aload #5
    //   498: checkcast java/net/URLConnection
    //   501: invokestatic disconnectQuietly : (Ljava/net/URLConnection;)V
    //   504: aload #6
    //   506: astore #5
    //   508: goto -> 616
    //   511: astore #6
    //   513: iload_3
    //   514: istore_2
    //   515: aload #5
    //   517: astore #9
    //   519: aload #7
    //   521: astore #5
    //   523: aload #6
    //   525: astore #7
    //   527: goto -> 581
    //   530: astore_1
    //   531: goto -> 636
    //   534: astore #7
    //   536: aconst_null
    //   537: astore #6
    //   539: iload_3
    //   540: istore_2
    //   541: aload #5
    //   543: astore #9
    //   545: aload #6
    //   547: astore #5
    //   549: goto -> 581
    //   552: new java/lang/NullPointerException
    //   555: dup
    //   556: ldc_w 'null cannot be cast to non-null type java.net.HttpURLConnection'
    //   559: invokespecial <init> : (Ljava/lang/String;)V
    //   562: athrow
    //   563: astore_1
    //   564: aconst_null
    //   565: astore #5
    //   567: goto -> 636
    //   570: astore #7
    //   572: aconst_null
    //   573: astore #9
    //   575: aload #9
    //   577: astore #5
    //   579: iload_3
    //   580: istore_2
    //   581: aload #9
    //   583: astore #8
    //   585: aload #5
    //   587: astore #6
    //   589: aload #7
    //   591: checkcast java/lang/Exception
    //   594: astore #7
    //   596: aload #5
    //   598: checkcast java/io/Closeable
    //   601: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   604: aload #9
    //   606: checkcast java/net/URLConnection
    //   609: invokestatic disconnectQuietly : (Ljava/net/URLConnection;)V
    //   612: aload #10
    //   614: astore #5
    //   616: iload_2
    //   617: ifeq -> 630
    //   620: aload_0
    //   621: aload_1
    //   622: aload #7
    //   624: aload #5
    //   626: iconst_0
    //   627: invokespecial issueResponse : (Lcom/facebook/internal/ImageDownloader$RequestKey;Ljava/lang/Exception;Landroid/graphics/Bitmap;Z)V
    //   630: return
    //   631: astore_1
    //   632: aload #8
    //   634: astore #5
    //   636: aload #6
    //   638: checkcast java/io/Closeable
    //   641: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   644: aload #5
    //   646: checkcast java/net/URLConnection
    //   649: invokestatic disconnectQuietly : (Ljava/net/URLConnection;)V
    //   652: aload_1
    //   653: athrow
    // Exception table:
    //   from	to	target	type
    //   37	56	570	java/io/IOException
    //   37	56	563	finally
    //   61	68	570	java/io/IOException
    //   61	68	563	finally
    //   68	81	534	java/io/IOException
    //   68	81	530	finally
    //   105	112	534	java/io/IOException
    //   105	112	530	finally
    //   124	133	511	java/io/IOException
    //   124	133	631	finally
    //   150	161	511	java/io/IOException
    //   150	161	631	finally
    //   173	180	511	java/io/IOException
    //   173	180	631	finally
    //   192	205	511	java/io/IOException
    //   192	205	631	finally
    //   222	233	511	java/io/IOException
    //   222	233	631	finally
    //   248	256	511	java/io/IOException
    //   248	256	631	finally
    //   271	279	511	java/io/IOException
    //   271	279	631	finally
    //   291	298	511	java/io/IOException
    //   291	298	631	finally
    //   310	327	511	java/io/IOException
    //   310	327	631	finally
    //   337	377	437	java/io/IOException
    //   337	377	530	finally
    //   382	425	437	java/io/IOException
    //   382	425	530	finally
    //   455	462	534	java/io/IOException
    //   455	462	530	finally
    //   474	481	511	java/io/IOException
    //   474	481	631	finally
    //   552	563	570	java/io/IOException
    //   552	563	563	finally
    //   589	596	631	finally
  }
  
  @JvmStatic
  public static final void downloadAsync(ImageRequest paramImageRequest) {
    if (paramImageRequest == null)
      return; 
    RequestKey requestKey = new RequestKey(paramImageRequest.getImageUri(), paramImageRequest.getCallerTag());
    synchronized (pendingRequests) {
      Unit unit;
      DownloaderContext downloaderContext = null.get(requestKey);
      if (downloaderContext != null) {
        downloaderContext.setRequest(paramImageRequest);
        downloaderContext.setCancelled(false);
        WorkQueue.WorkItem workItem = downloaderContext.getWorkItem();
        if (workItem != null) {
          workItem.moveToFront();
          unit = Unit.INSTANCE;
        } 
      } else {
        INSTANCE.enqueueCacheRead((ImageRequest)unit, requestKey, unit.isCachedRedirectAllowed());
        unit = Unit.INSTANCE;
      } 
      return;
    } 
  }
  
  private final void enqueueCacheRead(ImageRequest paramImageRequest, RequestKey paramRequestKey, boolean paramBoolean) {
    enqueueRequest(paramImageRequest, paramRequestKey, cacheReadQueue, new CacheReadWorkItem(paramRequestKey, paramBoolean));
  }
  
  private final void enqueueDownload(ImageRequest paramImageRequest, RequestKey paramRequestKey) {
    enqueueRequest(paramImageRequest, paramRequestKey, downloadQueue, new DownloadImageWorkItem(paramRequestKey));
  }
  
  private final void enqueueRequest(ImageRequest paramImageRequest, RequestKey paramRequestKey, WorkQueue paramWorkQueue, Runnable paramRunnable) {
    synchronized (pendingRequests) {
      DownloaderContext downloaderContext = new DownloaderContext(paramImageRequest);
      null.put(paramRequestKey, downloaderContext);
      downloaderContext.setWorkItem(WorkQueue.addActiveWorkItem$default(paramWorkQueue, paramRunnable, false, 2, null));
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  private final Handler getHandler() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/facebook/internal/ImageDownloader.handler : Landroid/os/Handler;
    //   5: ifnonnull -> 21
    //   8: new android/os/Handler
    //   11: dup
    //   12: invokestatic getMainLooper : ()Landroid/os/Looper;
    //   15: invokespecial <init> : (Landroid/os/Looper;)V
    //   18: putstatic com/facebook/internal/ImageDownloader.handler : Landroid/os/Handler;
    //   21: getstatic com/facebook/internal/ImageDownloader.handler : Landroid/os/Handler;
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: areturn
    //   29: astore_1
    //   30: aload_0
    //   31: monitorexit
    //   32: aload_1
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	29	finally
    //   21	25	29	finally
  }
  
  private final void issueResponse(RequestKey paramRequestKey, Exception paramException, Bitmap paramBitmap, boolean paramBoolean) {
    DownloaderContext downloaderContext = removePendingRequest(paramRequestKey);
    if (downloaderContext != null && !downloaderContext.isCancelled()) {
      ImageRequest imageRequest = downloaderContext.getRequest();
      if (imageRequest != null) {
        ImageRequest.Callback callback = imageRequest.getCallback();
      } else {
        downloaderContext = null;
      } 
      if (downloaderContext != null) {
        Handler handler = getHandler();
        if (handler != null)
          handler.post(new ImageDownloader$issueResponse$1(imageRequest, paramException, paramBoolean, paramBitmap, (ImageRequest.Callback)downloaderContext)); 
      } 
    } 
  }
  
  @JvmStatic
  public static final void prioritizeRequest(ImageRequest paramImageRequest) {
    Intrinsics.checkNotNullParameter(paramImageRequest, "request");
    null = new RequestKey(paramImageRequest.getImageUri(), paramImageRequest.getCallerTag());
    synchronized (pendingRequests) {
      DownloaderContext downloaderContext = null.get(null);
      if (downloaderContext != null) {
        WorkQueue.WorkItem workItem = downloaderContext.getWorkItem();
        if (workItem != null)
          workItem.moveToFront(); 
      } 
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  private final void readFromCache(RequestKey paramRequestKey, boolean paramBoolean) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #5
    //   3: aconst_null
    //   4: checkcast java/io/InputStream
    //   7: astore #4
    //   9: iconst_0
    //   10: istore_3
    //   11: iload_2
    //   12: ifeq -> 56
    //   15: aload_1
    //   16: invokevirtual getUri : ()Landroid/net/Uri;
    //   19: invokestatic getRedirectedUri : (Landroid/net/Uri;)Landroid/net/Uri;
    //   22: astore #4
    //   24: aload #4
    //   26: ifnull -> 56
    //   29: aload #4
    //   31: invokestatic getCachedImageStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   34: astore #6
    //   36: iload_3
    //   37: istore_2
    //   38: aload #6
    //   40: astore #4
    //   42: aload #6
    //   44: ifnull -> 61
    //   47: iconst_1
    //   48: istore_2
    //   49: aload #6
    //   51: astore #4
    //   53: goto -> 61
    //   56: aconst_null
    //   57: astore #4
    //   59: iload_3
    //   60: istore_2
    //   61: iload_2
    //   62: ifne -> 74
    //   65: aload_1
    //   66: invokevirtual getUri : ()Landroid/net/Uri;
    //   69: invokestatic getCachedImageStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   72: astore #4
    //   74: aload #4
    //   76: ifnull -> 104
    //   79: aload #4
    //   81: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   84: astore #5
    //   86: aload #4
    //   88: checkcast java/io/Closeable
    //   91: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   94: aload_0
    //   95: aload_1
    //   96: aconst_null
    //   97: aload #5
    //   99: iload_2
    //   100: invokespecial issueResponse : (Lcom/facebook/internal/ImageDownloader$RequestKey;Ljava/lang/Exception;Landroid/graphics/Bitmap;Z)V
    //   103: return
    //   104: aload_0
    //   105: aload_1
    //   106: invokespecial removePendingRequest : (Lcom/facebook/internal/ImageDownloader$RequestKey;)Lcom/facebook/internal/ImageDownloader$DownloaderContext;
    //   109: astore #6
    //   111: aload #5
    //   113: astore #4
    //   115: aload #6
    //   117: ifnull -> 127
    //   120: aload #6
    //   122: invokevirtual getRequest : ()Lcom/facebook/internal/ImageRequest;
    //   125: astore #4
    //   127: aload #6
    //   129: ifnull -> 152
    //   132: aload #6
    //   134: invokevirtual isCancelled : ()Z
    //   137: ifne -> 152
    //   140: aload #4
    //   142: ifnull -> 152
    //   145: aload_0
    //   146: aload #4
    //   148: aload_1
    //   149: invokespecial enqueueDownload : (Lcom/facebook/internal/ImageRequest;Lcom/facebook/internal/ImageDownloader$RequestKey;)V
    //   152: return
  }
  
  private final DownloaderContext removePendingRequest(RequestKey paramRequestKey) {
    synchronized (pendingRequests) {
      return null.remove(paramRequestKey);
    } 
  }
  
  public final Map<RequestKey, DownloaderContext> getPendingRequests() {
    return pendingRequests;
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\020\002\n\000\b\002\030\0002\0020\001B\027\b\000\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\b\020\007\032\0020\bH\026R\016\020\004\032\0020\005X\004¢\006\002\n\000R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006\t"}, d2 = {"Lcom/facebook/internal/ImageDownloader$CacheReadWorkItem;", "Ljava/lang/Runnable;", "key", "Lcom/facebook/internal/ImageDownloader$RequestKey;", "allowCachedRedirects", "", "(Lcom/facebook/internal/ImageDownloader$RequestKey;Z)V", "run", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class CacheReadWorkItem implements Runnable {
    private final boolean allowCachedRedirects;
    
    private final ImageDownloader.RequestKey key;
    
    public CacheReadWorkItem(ImageDownloader.RequestKey param1RequestKey, boolean param1Boolean) {
      this.key = param1RequestKey;
      this.allowCachedRedirects = param1Boolean;
    }
    
    public void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\002\n\000\b\002\030\0002\0020\001B\017\b\000\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020\005\032\0020\006H\026R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006\007"}, d2 = {"Lcom/facebook/internal/ImageDownloader$DownloadImageWorkItem;", "Ljava/lang/Runnable;", "key", "Lcom/facebook/internal/ImageDownloader$RequestKey;", "(Lcom/facebook/internal/ImageDownloader$RequestKey;)V", "run", "", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  private static final class DownloadImageWorkItem implements Runnable {
    private final ImageDownloader.RequestKey key;
    
    public DownloadImageWorkItem(ImageDownloader.RequestKey param1RequestKey) {
      this.key = param1RequestKey;
    }
    
    public void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
  
  @Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\007\n\002\030\002\n\002\b\005\b\007\030\0002\0020\001B\017\b\000\022\006\020\002\032\0020\003¢\006\002\020\004R\032\020\005\032\0020\006X\016¢\006\016\n\000\032\004\b\005\020\007\"\004\b\b\020\tR\032\020\002\032\0020\003X\016¢\006\016\n\000\032\004\b\n\020\013\"\004\b\f\020\004R\034\020\r\032\004\030\0010\016X\016¢\006\016\n\000\032\004\b\017\020\020\"\004\b\021\020\022¨\006\023"}, d2 = {"Lcom/facebook/internal/ImageDownloader$DownloaderContext;", "", "request", "Lcom/facebook/internal/ImageRequest;", "(Lcom/facebook/internal/ImageRequest;)V", "isCancelled", "", "()Z", "setCancelled", "(Z)V", "getRequest", "()Lcom/facebook/internal/ImageRequest;", "setRequest", "workItem", "Lcom/facebook/internal/WorkQueue$WorkItem;", "getWorkItem", "()Lcom/facebook/internal/WorkQueue$WorkItem;", "setWorkItem", "(Lcom/facebook/internal/WorkQueue$WorkItem;)V", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class DownloaderContext {
    private boolean isCancelled;
    
    private ImageRequest request;
    
    private WorkQueue.WorkItem workItem;
    
    public DownloaderContext(ImageRequest param1ImageRequest) {
      this.request = param1ImageRequest;
    }
    
    public final ImageRequest getRequest() {
      return this.request;
    }
    
    public final WorkQueue.WorkItem getWorkItem() {
      return this.workItem;
    }
    
    public final boolean isCancelled() {
      return this.isCancelled;
    }
    
    public final void setCancelled(boolean param1Boolean) {
      this.isCancelled = param1Boolean;
    }
    
    public final void setRequest(ImageRequest param1ImageRequest) {
      Intrinsics.checkNotNullParameter(param1ImageRequest, "<set-?>");
      this.request = param1ImageRequest;
    }
    
    public final void setWorkItem(WorkQueue.WorkItem param1WorkItem) {
      this.workItem = param1WorkItem;
    }
  }
  
  @Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\013\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\002\b\007\030\000 \0232\0020\001:\001\023B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\001¢\006\002\020\005J\023\020\016\032\0020\0172\b\020\020\032\004\030\0010\001H\002J\b\020\021\032\0020\022H\026R\032\020\004\032\0020\001X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\tR\032\020\002\032\0020\003X\016¢\006\016\n\000\032\004\b\n\020\013\"\004\b\f\020\r¨\006\024"}, d2 = {"Lcom/facebook/internal/ImageDownloader$RequestKey;", "", "uri", "Landroid/net/Uri;", "tag", "(Landroid/net/Uri;Ljava/lang/Object;)V", "getTag", "()Ljava/lang/Object;", "setTag", "(Ljava/lang/Object;)V", "getUri", "()Landroid/net/Uri;", "setUri", "(Landroid/net/Uri;)V", "equals", "", "o", "hashCode", "", "Companion", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class RequestKey {
    public static final Companion Companion = new Companion(null);
    
    private static final int HASH_MULTIPLIER = 37;
    
    private static final int HASH_SEED = 29;
    
    private Object tag;
    
    private Uri uri;
    
    public RequestKey(Uri param1Uri, Object param1Object) {
      this.uri = param1Uri;
      this.tag = param1Object;
    }
    
    public boolean equals(Object param1Object) {
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (param1Object != null) {
        bool1 = bool2;
        if (param1Object instanceof RequestKey) {
          param1Object = param1Object;
          bool1 = bool2;
          if (((RequestKey)param1Object).uri == this.uri) {
            bool1 = bool2;
            if (((RequestKey)param1Object).tag == this.tag)
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    }
    
    public final Object getTag() {
      return this.tag;
    }
    
    public final Uri getUri() {
      return this.uri;
    }
    
    public int hashCode() {
      return (1073 + this.uri.hashCode()) * 37 + this.tag.hashCode();
    }
    
    public final void setTag(Object param1Object) {
      Intrinsics.checkNotNullParameter(param1Object, "<set-?>");
      this.tag = param1Object;
    }
    
    public final void setUri(Uri param1Uri) {
      Intrinsics.checkNotNullParameter(param1Uri, "<set-?>");
      this.uri = param1Uri;
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/internal/ImageDownloader$RequestKey$Companion;", "", "()V", "HASH_MULTIPLIER", "", "HASH_SEED", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
    public static final class Companion {
      private Companion() {}
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Lcom/facebook/internal/ImageDownloader$RequestKey$Companion;", "", "()V", "HASH_MULTIPLIER", "", "HASH_SEED", "facebook-core_release"}, k = 1, mv = {1, 5, 1})
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "run"}, k = 3, mv = {1, 5, 1})
  static final class ImageDownloader$issueResponse$1 implements Runnable {
    ImageDownloader$issueResponse$1(ImageRequest param1ImageRequest, Exception param1Exception, boolean param1Boolean, Bitmap param1Bitmap, ImageRequest.Callback param1Callback) {}
    
    public final void run() {
      if (CrashShieldHandler.isObjectCrashing(this))
        return; 
      try {
        boolean bool = CrashShieldHandler.isObjectCrashing(this);
      } finally {
        Exception exception = null;
        CrashShieldHandler.handleThrowable(exception, this);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\internal\ImageDownloader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */