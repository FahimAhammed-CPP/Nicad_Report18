package androidx.activity;

import y.qx;
import y.尻;
import y.心;
import y.肉;
import y.腰;
import y.쌍;
import y.존;

class ComponentActivity$5 implements 肉 {
  public ComponentActivity$5(쌍 param쌍) {}
  
  public final void 暑(腰 param腰, 尻 param尻) {
    do do1 = this.淋;
    if (do1.臭 == null) {
      존 존 = (존)do1.getLastNonConfigurationInstance();
      if (존 != null)
        do1.臭 = 존.硬; 
      if (do1.臭 == null)
        do1.臭 = new qx(); 
    } 
    do1.痛.興((心)this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\activity\ComponentActivity$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */