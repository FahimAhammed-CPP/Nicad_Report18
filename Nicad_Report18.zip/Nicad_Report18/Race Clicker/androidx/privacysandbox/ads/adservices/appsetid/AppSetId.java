package androidx.privacysandbox.ads.adservices.appsetid;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\000\n\002\020\016\n\000\n\002\020\b\n\002\b\006\n\002\020\013\n\002\b\005\030\000 \0202\0020\001:\001\020B\025\022\006\020\002\032\0020\003\022\006\020\004\032\0020\005¢\006\002\020\006J\023\020\013\032\0020\f2\b\020\r\032\004\030\0010\001H\002J\b\020\016\032\0020\005H\026J\b\020\017\032\0020\003H\026R\021\020\002\032\0020\003¢\006\b\n\000\032\004\b\007\020\bR\021\020\004\032\0020\005¢\006\b\n\000\032\004\b\t\020\n¨\006\021"}, d2 = {"Landroidx/privacysandbox/ads/adservices/appsetid/AppSetId;", "", "id", "", "scope", "", "(Ljava/lang/String;I)V", "getId", "()Ljava/lang/String;", "getScope", "()I", "equals", "", "other", "hashCode", "toString", "Companion", "ads-adservices_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class AppSetId {
  public static final Companion Companion = new Companion(null);
  
  public static final int SCOPE_APP = 1;
  
  public static final int SCOPE_DEVELOPER = 2;
  
  private final String id;
  
  private final int scope;
  
  public AppSetId(String paramString, int paramInt) {
    this.id = paramString;
    this.scope = paramInt;
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (paramInt != 1)
      if (paramInt == 2) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    if (bool1)
      return; 
    throw new IllegalArgumentException("Scope undefined.".toString());
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof AppSetId))
      return false; 
    String str = this.id;
    paramObject = paramObject;
    return (Intrinsics.areEqual(str, ((AppSetId)paramObject).id) && this.scope == ((AppSetId)paramObject).scope);
  }
  
  public final String getId() {
    return this.id;
  }
  
  public final int getScope() {
    return this.scope;
  }
  
  public int hashCode() {
    return this.id.hashCode() * 31 + this.scope;
  }
  
  public String toString() {
    String str;
    if (this.scope == 1) {
      str = "SCOPE_APP";
    } else {
      str = "SCOPE_DEVELOPER";
    } 
    StringBuilder stringBuilder = new StringBuilder("AppSetId: id=");
    stringBuilder.append(this.id);
    stringBuilder.append(", scope=");
    stringBuilder.append(str);
    return stringBuilder.toString();
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\016\020\003\032\0020\004XT¢\006\002\n\000R\016\020\005\032\0020\004XT¢\006\002\n\000¨\006\006"}, d2 = {"Landroidx/privacysandbox/ads/adservices/appsetid/AppSetId$Companion;", "", "()V", "SCOPE_APP", "", "SCOPE_DEVELOPER", "ads-adservices_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\androidx\privacysandbox\ads\adservices\appsetid\AppSetId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */