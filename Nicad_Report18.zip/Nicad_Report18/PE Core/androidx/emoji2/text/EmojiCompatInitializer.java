package androidx.emoji2.text;

import android.content.Context;
import android.os.Build;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import y.p31;
import y.し;
import y.心;
import y.腰;
import y.駅;
import y.마;
import y.막;

public class EmojiCompatInitializer implements し {
  public final void 暑(Context paramContext) {
    駅 駅 = 駅.熱(paramContext);
    駅.getClass();
    synchronized (駅.冷) {
      Object object2 = 駅.硬.get(ProcessLifecycleInitializer.class);
      Object object1 = object2;
      if (object2 == null)
        object1 = 駅.堅(ProcessLifecycleInitializer.class, new HashSet()); 
      object1 = ((腰)object1).痒();
      object1.硬((心)new EmojiCompatInitializer$1(this, (p31)object1));
      return;
    } 
  }
  
  public final Boolean 熱(Context paramContext) {
    int i = Build.VERSION.SDK_INT;
    막 막 = new 막(paramContext);
    if (마.辛 == null)
      synchronized (마.不) {
        if (마.辛 == null)
          마.辛 = new 마(막); 
      }  
    暑(paramContext);
    return Boolean.TRUE;
  }
  
  public final List 硬() {
    return Collections.singletonList(ProcessLifecycleInitializer.class);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */