package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import y.h3;
import y.ls;
import y.r2;
import y.yx;
import y.ぷ;
import y.ツ;
import y.蚊;
import y.꾀;
import y.칭;
import y.함;

public class ContentFrameLayout extends FrameLayout {
  public TypedValue 怖;
  
  public TypedValue 恐;
  
  public TypedValue 淋;
  
  public TypedValue 痒;
  
  public TypedValue 痛;
  
  public TypedValue 臭;
  
  public 칭 興;
  
  public final Rect 起 = new Rect();
  
  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
  }
  
  public TypedValue getFixedHeightMajor() {
    if (this.痒 == null)
      this.痒 = new TypedValue(); 
    return this.痒;
  }
  
  public TypedValue getFixedHeightMinor() {
    if (this.臭 == null)
      this.臭 = new TypedValue(); 
    return this.臭;
  }
  
  public TypedValue getFixedWidthMajor() {
    if (this.恐 == null)
      this.恐 = new TypedValue(); 
    return this.恐;
  }
  
  public TypedValue getFixedWidthMinor() {
    if (this.痛 == null)
      this.痛 = new TypedValue(); 
    return this.痛;
  }
  
  public TypedValue getMinWidthMajor() {
    if (this.淋 == null)
      this.淋 = new TypedValue(); 
    return this.淋;
  }
  
  public TypedValue getMinWidthMinor() {
    if (this.怖 == null)
      this.怖 = new TypedValue(); 
    return this.怖;
  }
  
  public final void onAttachedToWindow() {
    super.onAttachedToWindow();
    칭 칭1 = this.興;
    if (칭1 != null)
      칭1.getClass(); 
  }
  
  public final void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    칭 칭1 = this.興;
    if (칭1 != null) {
      ぷ ぷ = (ぷ)((함)칭1).怖;
      꾀 꾀 = ぷ.噛;
      if (꾀 != null) {
        꾀 = 꾀;
        꾀.苦();
        ActionMenuView actionMenuView = ((ls)((ActionBarOverlayLayout)꾀).痒).硬.淋;
        if (actionMenuView != null) {
          ツ ツ = actionMenuView.投;
          if (ツ != null) {
            ツ.暑();
            蚊 蚊 = ツ.投;
            if (蚊 != null && 蚊.堅())
              ((h3)蚊).辛.dismiss(); 
          } 
        } 
      } 
      if (ぷ.ち != null) {
        ぷ.帰.getDecorView().removeCallbacks((Runnable)ぷ.ゃ);
        if (ぷ.ち.isShowing())
          try {
            ぷ.ち.dismiss();
          } catch (IllegalArgumentException illegalArgumentException) {} 
        ぷ.ち = null;
      } 
      yx yx = ぷ.赤;
      if (yx != null)
        yx.堅(); 
      r2 r2 = (ぷ.壊(0)).旨;
      if (r2 != null)
        r2.熱(true); 
    } 
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContext : ()Landroid/content/Context;
    //   4: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   7: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   10: astore #10
    //   12: aload #10
    //   14: getfield widthPixels : I
    //   17: istore #4
    //   19: aload #10
    //   21: getfield heightPixels : I
    //   24: istore #5
    //   26: iconst_1
    //   27: istore #7
    //   29: iload #4
    //   31: iload #5
    //   33: if_icmpge -> 42
    //   36: iconst_1
    //   37: istore #4
    //   39: goto -> 45
    //   42: iconst_0
    //   43: istore #4
    //   45: iload_1
    //   46: invokestatic getMode : (I)I
    //   49: istore #8
    //   51: iload_2
    //   52: invokestatic getMode : (I)I
    //   55: istore #6
    //   57: aload_0
    //   58: getfield 起 : Landroid/graphics/Rect;
    //   61: astore #11
    //   63: iload #8
    //   65: ldc -2147483648
    //   67: if_icmpne -> 198
    //   70: iload #4
    //   72: ifeq -> 84
    //   75: aload_0
    //   76: getfield 痛 : Landroid/util/TypedValue;
    //   79: astore #9
    //   81: goto -> 90
    //   84: aload_0
    //   85: getfield 恐 : Landroid/util/TypedValue;
    //   88: astore #9
    //   90: aload #9
    //   92: ifnull -> 198
    //   95: aload #9
    //   97: getfield type : I
    //   100: istore #5
    //   102: iload #5
    //   104: ifeq -> 198
    //   107: iload #5
    //   109: iconst_5
    //   110: if_icmpne -> 128
    //   113: aload #9
    //   115: aload #10
    //   117: invokevirtual getDimension : (Landroid/util/DisplayMetrics;)F
    //   120: fstore_3
    //   121: fload_3
    //   122: f2i
    //   123: istore #5
    //   125: goto -> 160
    //   128: iload #5
    //   130: bipush #6
    //   132: if_icmpne -> 157
    //   135: aload #10
    //   137: getfield widthPixels : I
    //   140: istore #5
    //   142: aload #9
    //   144: iload #5
    //   146: i2f
    //   147: iload #5
    //   149: i2f
    //   150: invokevirtual getFraction : (FF)F
    //   153: fstore_3
    //   154: goto -> 121
    //   157: iconst_0
    //   158: istore #5
    //   160: iload #5
    //   162: ifle -> 198
    //   165: iload #5
    //   167: aload #11
    //   169: getfield left : I
    //   172: aload #11
    //   174: getfield right : I
    //   177: iadd
    //   178: isub
    //   179: iload_1
    //   180: invokestatic getSize : (I)I
    //   183: invokestatic min : (II)I
    //   186: ldc 1073741824
    //   188: invokestatic makeMeasureSpec : (II)I
    //   191: istore #5
    //   193: iconst_1
    //   194: istore_1
    //   195: goto -> 203
    //   198: iload_1
    //   199: istore #5
    //   201: iconst_0
    //   202: istore_1
    //   203: iload #6
    //   205: ldc -2147483648
    //   207: if_icmpne -> 335
    //   210: iload #4
    //   212: ifeq -> 224
    //   215: aload_0
    //   216: getfield 痒 : Landroid/util/TypedValue;
    //   219: astore #9
    //   221: goto -> 230
    //   224: aload_0
    //   225: getfield 臭 : Landroid/util/TypedValue;
    //   228: astore #9
    //   230: aload #9
    //   232: ifnull -> 335
    //   235: aload #9
    //   237: getfield type : I
    //   240: istore #6
    //   242: iload #6
    //   244: ifeq -> 335
    //   247: iload #6
    //   249: iconst_5
    //   250: if_icmpne -> 268
    //   253: aload #9
    //   255: aload #10
    //   257: invokevirtual getDimension : (Landroid/util/DisplayMetrics;)F
    //   260: fstore_3
    //   261: fload_3
    //   262: f2i
    //   263: istore #6
    //   265: goto -> 300
    //   268: iload #6
    //   270: bipush #6
    //   272: if_icmpne -> 297
    //   275: aload #10
    //   277: getfield heightPixels : I
    //   280: istore #6
    //   282: aload #9
    //   284: iload #6
    //   286: i2f
    //   287: iload #6
    //   289: i2f
    //   290: invokevirtual getFraction : (FF)F
    //   293: fstore_3
    //   294: goto -> 261
    //   297: iconst_0
    //   298: istore #6
    //   300: iload #6
    //   302: ifle -> 335
    //   305: iload #6
    //   307: aload #11
    //   309: getfield top : I
    //   312: aload #11
    //   314: getfield bottom : I
    //   317: iadd
    //   318: isub
    //   319: iload_2
    //   320: invokestatic getSize : (I)I
    //   323: invokestatic min : (II)I
    //   326: ldc 1073741824
    //   328: invokestatic makeMeasureSpec : (II)I
    //   331: istore_2
    //   332: goto -> 335
    //   335: aload_0
    //   336: iload #5
    //   338: iload_2
    //   339: invokespecial onMeasure : (II)V
    //   342: aload_0
    //   343: invokevirtual getMeasuredWidth : ()I
    //   346: istore #6
    //   348: iload #6
    //   350: ldc 1073741824
    //   352: invokestatic makeMeasureSpec : (II)I
    //   355: istore #5
    //   357: iload_1
    //   358: ifne -> 493
    //   361: iload #8
    //   363: ldc -2147483648
    //   365: if_icmpne -> 493
    //   368: iload #4
    //   370: ifeq -> 382
    //   373: aload_0
    //   374: getfield 怖 : Landroid/util/TypedValue;
    //   377: astore #9
    //   379: goto -> 388
    //   382: aload_0
    //   383: getfield 淋 : Landroid/util/TypedValue;
    //   386: astore #9
    //   388: aload #9
    //   390: ifnull -> 493
    //   393: aload #9
    //   395: getfield type : I
    //   398: istore_1
    //   399: iload_1
    //   400: ifeq -> 493
    //   403: iload_1
    //   404: iconst_5
    //   405: if_icmpne -> 422
    //   408: aload #9
    //   410: aload #10
    //   412: invokevirtual getDimension : (Landroid/util/DisplayMetrics;)F
    //   415: fstore_3
    //   416: fload_3
    //   417: f2i
    //   418: istore_1
    //   419: goto -> 449
    //   422: iload_1
    //   423: bipush #6
    //   425: if_icmpne -> 447
    //   428: aload #10
    //   430: getfield widthPixels : I
    //   433: istore_1
    //   434: aload #9
    //   436: iload_1
    //   437: i2f
    //   438: iload_1
    //   439: i2f
    //   440: invokevirtual getFraction : (FF)F
    //   443: fstore_3
    //   444: goto -> 416
    //   447: iconst_0
    //   448: istore_1
    //   449: iload_1
    //   450: istore #4
    //   452: iload_1
    //   453: ifle -> 471
    //   456: iload_1
    //   457: aload #11
    //   459: getfield left : I
    //   462: aload #11
    //   464: getfield right : I
    //   467: iadd
    //   468: isub
    //   469: istore #4
    //   471: iload #6
    //   473: iload #4
    //   475: if_icmpge -> 493
    //   478: iload #4
    //   480: ldc 1073741824
    //   482: invokestatic makeMeasureSpec : (II)I
    //   485: istore #4
    //   487: iload #7
    //   489: istore_1
    //   490: goto -> 499
    //   493: iconst_0
    //   494: istore_1
    //   495: iload #5
    //   497: istore #4
    //   499: iload_1
    //   500: ifeq -> 510
    //   503: aload_0
    //   504: iload #4
    //   506: iload_2
    //   507: invokespecial onMeasure : (II)V
    //   510: return
  }
  
  public void setAttachListener(칭 param칭) {
    this.興 = param칭;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Math Games-dex2jar.jar!\androidx\appcompat\widget\ContentFrameLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */