package com.facebook.login;

import android.net.Uri;
import com.facebook.internal.instrument.crashshield.CrashShieldHandler;
import java.util.Collection;

public class DeviceLoginManager extends LoginManager {
  private static volatile DeviceLoginManager instance;
  
  private String deviceAuthTargetUserId;
  
  private Uri deviceRedirectUri;
  
  public static DeviceLoginManager getInstance() {
    // Byte code:
    //   0: ldc com/facebook/login/DeviceLoginManager
    //   2: invokestatic isObjectCrashing : (Ljava/lang/Object;)Z
    //   5: ifeq -> 10
    //   8: aconst_null
    //   9: areturn
    //   10: getstatic com/facebook/login/DeviceLoginManager.instance : Lcom/facebook/login/DeviceLoginManager;
    //   13: ifnonnull -> 47
    //   16: ldc com/facebook/login/DeviceLoginManager
    //   18: monitorenter
    //   19: getstatic com/facebook/login/DeviceLoginManager.instance : Lcom/facebook/login/DeviceLoginManager;
    //   22: ifnonnull -> 35
    //   25: new com/facebook/login/DeviceLoginManager
    //   28: dup
    //   29: invokespecial <init> : ()V
    //   32: putstatic com/facebook/login/DeviceLoginManager.instance : Lcom/facebook/login/DeviceLoginManager;
    //   35: ldc com/facebook/login/DeviceLoginManager
    //   37: monitorexit
    //   38: goto -> 47
    //   41: astore_0
    //   42: ldc com/facebook/login/DeviceLoginManager
    //   44: monitorexit
    //   45: aload_0
    //   46: athrow
    //   47: getstatic com/facebook/login/DeviceLoginManager.instance : Lcom/facebook/login/DeviceLoginManager;
    //   50: astore_0
    //   51: aload_0
    //   52: areturn
    //   53: astore_0
    //   54: aload_0
    //   55: ldc com/facebook/login/DeviceLoginManager
    //   57: invokestatic handleThrowable : (Ljava/lang/Throwable;Ljava/lang/Object;)V
    //   60: aconst_null
    //   61: areturn
    // Exception table:
    //   from	to	target	type
    //   10	19	53	finally
    //   19	35	41	finally
    //   35	38	41	finally
    //   42	45	41	finally
    //   45	47	53	finally
    //   47	51	53	finally
  }
  
  protected LoginClient.Request createLoginRequest(Collection<String> paramCollection) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      LoginClient.Request request = super.createLoginRequest(paramCollection);
      Uri uri = getDeviceRedirectUri();
      if (uri != null)
        request.setDeviceRedirectUriString(uri.toString()); 
      return request;
    } finally {
      paramCollection = null;
      CrashShieldHandler.handleThrowable((Throwable)paramCollection, this);
    } 
  }
  
  public String getDeviceAuthTargetUserId() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return this.deviceAuthTargetUserId;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  public Uri getDeviceRedirectUri() {
    if (CrashShieldHandler.isObjectCrashing(this))
      return null; 
    try {
      return this.deviceRedirectUri;
    } finally {
      Exception exception = null;
      CrashShieldHandler.handleThrowable(exception, this);
    } 
  }
  
  public void setDeviceAuthTargetUserId(String paramString) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramString = null;
      CrashShieldHandler.handleThrowable((Throwable)paramString, this);
    } 
  }
  
  public void setDeviceRedirectUri(Uri paramUri) {
    if (CrashShieldHandler.isObjectCrashing(this))
      return; 
    try {
      return;
    } finally {
      paramUri = null;
      CrashShieldHandler.handleThrowable((Throwable)paramUri, this);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Race Clicker-dex2jar.jar!\com\facebook\login\DeviceLoginManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */